import Subit.DensityTree
import Mathlib.Data.Set.Finite.List

/-!
# Модель ℛ_comp (G8) і щільність 10.10

Рішення (v6.13.16): ℛ_comp := функції S∞ → S∞, які реалізуються скінченною програмою з оракулом
дерева. Формально: g ∈ ℛ_comp, якщо існує глибина n така, що g залежить лише від міток на
адресах довжини ≤ n (скінченна програма читає скінченно багато адрес), і g(s) — скінченне дерево
для кожного s (вихід — скінченна таблиця пар; скінченність значень робить множину зліченною).

Формалізовано: означення `RComp`, скінченність `trT`, належність наближення `Gap` до `RComp`,
і щільність (10.10) як `density_comp`: для кожного нерозтягувального F і n існує G ∈ ℛ_comp,
нерозтягувальне, з `d_S(G s, F s) ≤ 2^{-n}` для всіх s.
НЕ формалізовано: перетин з ℛ_caus у просторі неперервних відображень (d_ℛ — sup за s,
bound за s дає оцінку sup) і злічність ℛ_comp.
-/

namespace Subit
open Set

variable {A : Type*}

/-- Скінченне дерево: скінченно багато вузлів з міткою ≠ none. -/
def IsFiniteTree (t : Tree A) : Prop := {σ : Pos | t.1 σ ≠ Lab.none}.Finite

/-- Модель ℛ_comp: скінченна глибина залежності і скінченні значення. -/
def RComp (A : Type*) : Set (Tree A → Tree A) :=
  {g | ∃ n : ℕ, (∀ s t : Tree A, (∀ σ : Pos, σ.length ≤ n → s.1 σ = t.1 σ) → g s = g t) ∧
      ∀ s : Tree A, IsFiniteTree (g s)}

theorem trT_finite (a₀ : A) (n : ℕ) (s : Tree A) : IsFiniteTree (trT a₀ n s) := by
  unfold IsFiniteTree
  apply (List.finite_length_le (α := Fin 3) (n := n)).subset
  intro σ hσ
  simp only [mem_setOf_eq] at hσ ⊢
  by_contra h
  push_neg at h
  exact hσ (tr_gt a₀ n s.1 h)

/-- Наближення `Gap` належить ℛ_comp. -/
theorem Gap_mem_RComp (a₀ : A) (n : ℕ) (F : Tree A → Tree A) :
    Gap a₀ n F ∈ RComp A :=
  ⟨n, fun s t h => Gap_finDep a₀ n F s t h, fun s => trT_finite a₀ n _⟩

/-- 10.10 (щільність ℛ_comp ∩ ℛ_caus у ℛ_caus, поточкова оцінка d_S). -/
theorem density_comp (a₀ : A) (F : Tree A → Tree A) (hF : TNonexp F) (n : ℕ) :
    ∃ G : Tree A → Tree A, G ∈ RComp A ∧ TNonexp G ∧
      ∀ s : Tree A, dS (G s).1 (F s).1 ≤ (1 / 2 : ℝ) ^ n :=
  ⟨Gap a₀ n F, Gap_mem_RComp a₀ n F, Gap_nonexp a₀ n F hF, Gap_close a₀ n F hF⟩

end Subit
