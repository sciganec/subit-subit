import Mathlib.Tactic.Ring

/-!
# W8: арифметичний крок підрахунку (G9, частина)

У записі W8 (§11.6) оцінка p_d(N) ≤ (2N+1)·2^M·(N+2), де M — найменше з 2^M ≥ t+1 і t+1 ≤ N+2.
Звідси 2^M < 2(N+3) і 2(2N+1)(N+2)(N+3) — константа з тексту.

Тут формалізовано ЛИШЕ цей арифметичний крок. Комбінаторна частина (плитки, вікна,
підрахунок вмісту вікна для нескінченного слова d) НЕ формалізована.
-/

namespace Subit

theorem W8_arith (N t M : ℕ) (ht : t + 1 ≤ N + 2) (hM : t + 1 ≤ 2 ^ M)
    (hmin : ∀ k < M, 2 ^ k < t + 1) :
    (2 * N + 1) * 2 ^ M * (N + 2) ≤ 2 * (2 * N + 1) * (N + 2) * (N + 3) := by
  have h2M : 2 ^ M < 2 * (N + 3) := by
    rcases M with _ | M
    · simp; omega
    · have := hmin M (Nat.lt_succ_self M)
      rw [pow_succ]
      omega
  have hle : 2 ^ M ≤ 2 * (N + 3) := le_of_lt h2M
  calc (2 * N + 1) * 2 ^ M * (N + 2) ≤ (2 * N + 1) * (2 * (N + 3)) * (N + 2) :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ hle)
    _ = 2 * (2 * N + 1) * (N + 2) * (N + 3) := by ring

end Subit
