import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Topology.Algebra.Order.LiminfLimsup
import Mathlib.Data.Fintype.Pi
import Subit.Basic
/-!
# SUBIT-∞ v6.11.3 — етап 3a: топологічна ентропія за Боуеном і лема 4.6

Ентропію задано для довільної функції відстані `d : X → X → ℝ` (аксіоми метрики потрібні
лише там, де їх використовують). h_top ∈ EReal.
-/
open Filter
namespace Subit

section Def
variable {X : Type*}

/-- (n,ε)-роздільна скінченна множина: різні точки розходяться більш ніж на ε на якомусь i < n. -/
def IsSep (d : X → X → ℝ) (T : X → X) (n : ℕ) (ε : ℝ) (S : Finset X) : Prop :=
  ∀ x ∈ S, ∀ y ∈ S, x ≠ y → ∃ i < n, ε < d (iter T i x) (iter T i y)

/-- s(n, ε): найбільша потужність (n,ε)-роздільної множини. Значення коректне, коли s(n,ε) скінченне
  (наприклад, для цілковито обмеженого X); для необмеженого X sSup у ℕ дає 0 (умовне значення),
  тому h_top за цим означенням має сенс лише для цілковито обмежених X. -/
noncomputable def sepNum (d : X → X → ℝ) (T : X → X) (n : ℕ) (ε : ℝ) : ℕ :=
  sSup {k | ∃ S : Finset X, IsSep d T n ε S ∧ S.card = k}

/-- h_top = sup_{ε>0} limsup_n (1/n) log s(n, ε) ∈ EReal. -/
noncomputable def htop (d : X → X → ℝ) (T : X → X) : EReal :=
  ⨆ ε : {ε : ℝ // 0 < ε},
    limsup (fun n : ℕ => ((Real.log (sepNum d T n ε) / n : ℝ) : EReal)) atTop

theorem sepNum_le {d : X → X → ℝ} {T : X → X} {n : ℕ} {ε : ℝ} (B : ℕ)
    (h : ∀ S : Finset X, IsSep d T n ε S → S.card ≤ B) : sepNum d T n ε ≤ B := by
  apply csSup_le
  · exact ⟨0, ∅, by intro x hx; simp at hx, rfl⟩
  · rintro k ⟨S, hS, rfl⟩; exact h S hS

theorem le_sepNum {d : X → X → ℝ} {T : X → X} {n : ℕ} {ε : ℝ} (B : ℕ)
    (h : ∀ S : Finset X, IsSep d T n ε S → S.card ≤ B) (S : Finset X)
    (hS : IsSep d T n ε S) : S.card ≤ sepNum d T n ε :=
  le_csSup ⟨B, by rintro k ⟨S', hS', rfl⟩; exact h S' hS'⟩ ⟨S, hS, rfl⟩

end Def

end Subit
