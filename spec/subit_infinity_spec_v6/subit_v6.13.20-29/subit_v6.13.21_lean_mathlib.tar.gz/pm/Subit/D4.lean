import Subit.Q28b
import Subit.Zero

/-!
# SUBIT-∞: твердження 11.6 (D4) у Lean

Якщо g∞ = π_R, то D∞(s, ρ) = (ρ(s), ρ) нерозтягувальне на X = S∞ × ℛ₀ (max-метрика),
тож h_top = 0 (D3) на всьому X і на кожній замкненій інваріантній множині.
Тут перевіряється h_top = 0; твердження про відсутність CHAOTIC з цього не виводиться.
-/

noncomputable section

namespace Subit
open Set Topology

variable {A : Type*} [Finite A]

/-- D∞ при g∞ = π_R: (s, ρ) ↦ (ρ(s), ρ). -/
def Dpi (q : TreeM A × RZ A) : TreeM A × RZ A := (q.2.1 q.1, q.2)

/-- D∞ при g∞ = π_R нерозтягувальне (спирається на app_dist_le). -/
lemma Dpi_nonexp (q r : TreeM A × RZ A) : dist (Dpi q) (Dpi r) ≤ dist q r := by
  rw [Prod.dist_eq, Prod.dist_eq]
  apply max_le
  · have h1 := app_dist_le q.2 r.2 q.1 r.1
    exact le_trans h1 (le_of_eq (max_comm _ _))
  · exact le_max_right _ _

instance instCompactRZ : CompactSpace (RZ A) :=
  isCompact_iff_compactSpace.1 isCompact_RZ

/-- D4 (повний простір): h_top(Dpi) = 0 на X = S∞ × ℛ₀. -/
theorem D4_total : htop (fun x y : TreeM A × RZ A => dist x y) Dpi = 0 :=
  D3 isCompact_univ.totallyBounded Dpi (fun x y => Dpi_nonexp x y)

/-- Обмеження D∞ на замкнену інваріантну P: P → P. -/
def restrictD (P : Set (TreeM A × RZ A)) (hinv : Dpi '' P ⊆ P) : P → P :=
  fun p => ⟨Dpi p.1, hinv ⟨p.1, p.2, rfl⟩⟩

/-- D4 на замкненій інваріантній множині: h_top(D∞|P) = 0. -/
theorem D4_closed (P : Set (TreeM A × RZ A)) (hP : IsClosed P) (hinv : Dpi '' P ⊆ P) :
    htop (fun x y : P => dist x y) (restrictD P hinv) = 0 := by
  haveI : CompactSpace P := isCompact_iff_compactSpace.1 hP.isCompact
  exact D3 isCompact_univ.totallyBounded (restrictD P hinv) (fun x y => Dpi_nonexp x.1 y.1)

end Subit

end
