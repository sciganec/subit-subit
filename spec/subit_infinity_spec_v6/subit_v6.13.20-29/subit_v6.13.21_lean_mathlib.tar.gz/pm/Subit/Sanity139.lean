import Subit
/-! Перевірка здійсненності (non-vacuity) гіпотез нових LEAN-CHECKED тверджень. -/
open Subit Set
namespace Subit.Sanity139

example {A : Type} [Finite A] : htop (fun x y : TreeM A × RZ A => dist x y) Dpi = 0 :=
  D4_total

example {A : Type} [Finite A] :
    htop (fun x y : (univ : Set (TreeM A × RZ A)) => dist (x : TreeM A × RZ A) y) (restrictD univ (fun _ _ => trivial)) = 0 :=
  D4_closed univ isClosed_univ (fun _ _ => trivial)

example {A : Type} [Finite A] (c : TreeM A) :
    ∃ F : TreeM A → TreeM A, Continuous F ∧ ∀ a : ({c} : Set (TreeM A)), F a = a :=
  (extend_tree {c} isClosed_singleton (fun a => a) continuous_of_discreteTopology).imp
    fun F hF => ⟨hF.1, fun a => hF.2 a⟩

example {A : Type} [Finite A] (x0 : TreeM A) :
    Continuous (gInf (fun c : TreeM A => c) x0) ∧ Continuous (Dinf (fun c : TreeM A => c) x0) :=
  let h := q28b_lean (A := A) univ isClosed_univ (fun c : TreeM A => c) continuous_id
    (fun c _ => mem_univ _) (fun d _ => ⟨d, mem_univ _, rfl⟩) x0
  ⟨h.1, h.2.1⟩

example : ∃ rule g : ℕ → ℕ → ℕ,
    (∀ r < (1 + 1 - 1) / 1, ∀ s < 64, rule r s < 64) := by
  obtain ⟨rule, g, h1, _⟩ := A4_general 1 1 0 le_rfl le_rfl (by norm_num) (by norm_num) id
    (fun q hq => by simp only [id]; omega)
  exact ⟨rule, g, h1⟩

end Subit.Sanity139
