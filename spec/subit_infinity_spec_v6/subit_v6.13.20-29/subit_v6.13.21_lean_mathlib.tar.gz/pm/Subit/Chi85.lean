import Subit.Discrete2

/-!
# Застереження 8.5 у Lean (G4)

Для неінваріантної U формула χ_U не є морфізмом. Контрприклад із тексту: S = {0,1},
f(0) = f(1) = 1, U = {0}. Тоді χ_U(0) = 0, але χ_U(f 0) = χ_U(1) = ∞ ≠ max(0 − 1, 0) = 0.
-/

namespace Subit
open Function

/-- Константна відображення f(0) = f(1) = 1 на S = Fin 2. -/
def f85 : Fin 2 → Fin 2 := fun _ => 1

theorem f85_fix : f85 1 = 1 := rfl

theorem iter_f85_one (k : ℕ) : iter f85 k (1 : Fin 2) = 1 := by
  rw [iter_eq_iterate]
  exact Function.iterate_fixed f85_fix k

/-- Застереження 8.5: χ_{{0}} не задовольняє рівняння морфізму для f85 (U не інваріантна). -/
theorem chi_not_dynmor_8_5 : ¬ IsDynMor f85 (chi f85 ({0} : Set (Fin 2))) := by
  intro h
  have hx := h 0
  have h0 : chi f85 ({0} : Set (Fin 2)) 0 = 0 := by
    rw [chi_eq_zero_iff]; exact rfl
  have h1 : chi f85 ({0} : Set (Fin 2)) (f85 0) = ⊤ := by
    unfold chi
    rw [dif_neg]
    rintro ⟨k, hk⟩
    have : iter f85 k (1 : Fin 2) = 1 := iter_f85_one k
    have hf : f85 0 = 1 := rfl
    rw [hf] at hk
    rw [this] at hk
    exact absurd hk (by decide)
  rw [h0, h1] at hx
  simp at hx

end Subit
