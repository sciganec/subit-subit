import Subit.Tree
import Subit.ExtendUltra
import Mathlib.Topology.MetricSpace.Ultra.Basic
import Mathlib.Topology.Metrizable.Uniformity

/-!
# SUBIT-∞: Tree∞ як ультраметричний компактний простір (для леми 11.9)

Тип-синонім `TreeM A := Tree A` з метрикою d_S. Доведено:
- метрика d_S (`MetricSpace`), ультраметричність;
- топологія метрики збігається з топологією підпростору Tree∞;
- компактність;
- застосування `extend_ultra` (лема 11.9) до замкненої A ⊆ Tree∞.
-/

namespace Subit
open Filter Topology Set

variable {A : Type*} [Finite A]

/-- Tree∞ з метрикою d_S (тип-синонім, щоб уникнути конфлікту з топологією підпростору). -/
def TreeM (A : Type*) := Tree A

noncomputable instance : MetricSpace (TreeM A) where
  dist x y := dS (x : Tree A).1 (y : Tree A).1
  dist_self x := by
    show dS (x : Tree A).1 (x : Tree A).1 = 0
    exact (dS_eq_zero_iff _ _).2 rfl
  dist_comm x y := dS_comm _ _
  dist_triangle x y z := by
    show dS (x : Tree A).1 (z : Tree A).1 ≤ dS (x : Tree A).1 (y : Tree A).1 + dS (y : Tree A).1 (z : Tree A).1
    have h1 := dS_nonneg (x : Tree A).1 (y : Tree A).1
    have h2 := dS_nonneg (y : Tree A).1 (z : Tree A).1
    exact le_trans (dS_ultra _ _ _) (max_le (le_add_of_nonneg_right h2) (le_add_of_nonneg_left h1))
  eq_of_dist_eq_zero {x y} h := by
    apply Subtype.ext
    exact (dS_eq_zero_iff _ _).1 h

instance : IsUltrametricDist (TreeM A) where
  dist_triangle_max x y z := by
    show dS (x : Tree A).1 (z : Tree A).1 ≤ max (dS (x : Tree A).1 (y : Tree A).1) (dS (y : Tree A).1 (z : Tree A).1)
    exact dS_ultra _ _ _


/-- Тотожне приведення TreeM A → Tree A. -/
def toT (x : TreeM A) : Tree A := x

/-- Топологія метрики d_S збігається з топологією підпростору Tree∞. -/
theorem topo_eq : (inferInstance : TopologicalSpace (TreeM A)) =
    (inferInstance : TopologicalSpace (Tree A)) := by
  refine TopologicalSpace.ext_nhds fun (x : TreeM A) => ?_
  refine Filter.ext fun s => ?_
  have hR : @nhds (TreeM A) (inferInstance : TopologicalSpace (Tree A)) x =
      Filter.comap Subtype.val (nhds (toT x).1) := nhds_induced Subtype.val (toT x)
  rw [hR, Metric.mem_nhds_iff]
  refine Iff.trans ?_ Filter.mem_comap.symm
  constructor
  · rintro ⟨ε, hε, hsub⟩
    obtain ⟨n, hn⟩ := exists_pow_lt_of_lt_one hε (by norm_num : (1/2:ℝ) < 1)
    refine ⟨{g : Pos → Lab A | dS (toT x).1 g < (1/2 : ℝ) ^ n},
      (dS_nhds_basis (toT x).1).mem_of_mem trivial, fun y hy => hsub ?_⟩
    have hy' : dS (toT x).1 (toT y).1 < (1/2 : ℝ) ^ n := hy
    show dS (toT y).1 (toT x).1 < ε
    rw [dS_comm]
    exact lt_trans hy' hn
  · rintro ⟨t, ht, hsub⟩
    obtain ⟨n, -, hn⟩ := (dS_nhds_basis (toT x).1).mem_iff.1 ht
    refine ⟨(1/2 : ℝ) ^ n, by positivity, fun y hy => hsub (hn ?_)⟩
    have hy' : dist y x < (1/2 : ℝ) ^ n := hy
    show dS (toT x).1 (toT y).1 < (1/2 : ℝ) ^ n
    rw [dS_comm]
    exact hy'

/-- Гомеоморфізм TreeM A ≃ₜ Tree A (тотожне відображення). -/
noncomputable def homeoTM : TreeM A ≃ₜ Tree A :=
  ⟨Equiv.refl _, continuous_id_of_le topo_eq.le, continuous_id_of_le topo_eq.ge⟩

instance : CompactSpace (TreeM A) := homeoTM.symm.compactSpace

/-- Лема 11.9 для Tree∞: продовження неперервного відображення з замкненої
A' ⊆ Tree∞ у Tree∞. -/
theorem extend_tree (A' : Set (TreeM A)) (hA' : IsClosed A') (f : A' → TreeM A)
    (hf : Continuous f) :
    ∃ F : TreeM A → TreeM A, Continuous F ∧ ∀ a : A', F a = f a :=
  extend_ultra A' hA' f hf

end Subit
