import Subit.Q28b

/-!
# 11.11 для загального R (G11)

У 11.11 g∞(ρ, s) = κ_{T′(p(ρ))} має значення в ℛ₀. Для загального замкненого R ⊆ ℛ₀ (за H2 R компактний)
конструкція лишається в X = S∞ × R тоді й тільки тоді, коли всі сталі правила κ_c (c ∈ S∞) лежать у R.
Ця умова (K ⊆ R) тут явна. Для R = ℛ₀ вона виконується автоматично.
Теорема: за K ⊆ R (і без припущень про R понад це) всі твердження 11.11 переносяться на X = S∞ × R:
D∞(X) ⊆ X, g∞ має значення в R, P ⊆ X замкнена, D∞[P] = P, і P містить точку D∞(x) ≠ x.
-/

namespace Subit
open Set

variable {A : Type*} [Finite A]

theorem q28b_R (R : Set (RZ A)) (hκ : ∀ c : TreeM A, kap c ∈ R)
    (Y : Set (TreeM A)) (hY : IsClosed Y) (T : Y → Y) (hT : Continuous T)
    (hsurj : Function.Surjective T) (x0 : TreeM A) :
    ∃ T' : TreeM A → TreeM A, Continuous T' ∧ (∀ c : Y, T' c = (T c : TreeM A)) ∧
      Continuous (gInf T' x0) ∧ Continuous (Dinf T' x0) ∧ IsClosed (Pset Y T') ∧
      Dinf T' x0 '' Pset Y T' = Pset Y T' ∧
      (∀ c ∈ Y, T' c ≠ c → Dinf T' x0 (c, kap (T' c)) ≠ (c, kap (T' c))) ∧
      (∀ q : TreeM A × RZ A, (Dinf T' x0 q).2 ∈ R) ∧
      (∀ c ∈ Y, (c, kap (T' c)) ∈ (univ ×ˢ R : Set (TreeM A × RZ A))) := by
  obtain ⟨T', hT'c, hT'Y, hg, hD, hP, hDP, hne⟩ := q28b_full Y hY T hT hsurj x0
  refine ⟨T', hT'c, hT'Y, hg, hD, hP, hDP, hne, ?_, ?_⟩
  · intro q
    simp only [Dinf, gInf]
    exact hκ _
  · intro c _
    exact ⟨mem_univ _, hκ _⟩

end Subit
