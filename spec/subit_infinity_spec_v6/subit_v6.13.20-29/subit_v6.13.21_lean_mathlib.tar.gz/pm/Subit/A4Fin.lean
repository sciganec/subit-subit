import Subit.A4
import Mathlib.Data.Fintype.Card
import Mathlib.Data.Fintype.EquivFin

/-!
# Твердження 2.4′ для довільної скінченної множини станів (G3)

`A4_general` задано для Q = {0,…,n−1}. Тут: для будь-якої скінченної Q і тотальної δ : Q → Q існує
перенумерація e : Q ≃ Fin n, після якої правила й вкладення працюють як у 2.4′.
-/

namespace Subit
open Fintype

theorem A4_fintype {Q : Type*} [Fintype Q] [Nonempty Q] (m t : ℕ) (hm : 1 ≤ m)
    (hmt : m + t ≤ 64) (hk : (card Q + m - 1) / m ≤ 64 ^ t) (δ : Q → Q) :
    ∃ (e : Q ≃ Fin (card Q)) (rule g : Nat → Nat → Nat),
      (∀ r < (card Q + m - 1) / m, ∀ s < 64, rule r s < 64) ∧
      (∀ r < (card Q + m - 1) / m, ∀ s < 64, g r s < (card Q + m - 1) / m) ∧
      (∀ q : Q, A4step rule g (A4enc m (e q : ℕ)).1 (A4enc m (e q : ℕ)).2
          = A4enc m (e (δ q) : ℕ)) ∧
      (∀ q₁ q₂ : Q, A4enc m (e q₁ : ℕ) = A4enc m (e q₂ : ℕ) → q₁ = q₂) ∧
      (∀ a < (card Q + m - 1) / m, ∀ b < (card Q + m - 1) / m,
        (∀ s < 64, rule a s = rule b s) → a = b) := by
  set n := card Q with hn_def
  have hn : 1 ≤ n := Fintype.card_pos
  let e : Q ≃ Fin n := Fintype.equivFin Q
  let δ' : Nat → Nat := fun q => if h : q < n then (e (δ (e.symm ⟨q, h⟩)) : ℕ) else q
  have hδ' : ∀ q < n, δ' q < n := by
    intro q hq
    simp only [δ', dif_pos hq]
    exact (e (δ (e.symm ⟨q, hq⟩))).isLt
  obtain ⟨rule, g, h1, h2, h3, h4, h5⟩ :=
    A4_general n m t hn hm hmt hk δ' hδ'
  refine ⟨e, rule, g, h1, h2, ?_, ?_, ?_⟩
  · intro q
    have hq : (e q : ℕ) < n := (e q).isLt
    have := h3 (e q : ℕ) hq
    have hδq : δ' (e q : ℕ) = (e (δ q) : ℕ) := by
      simp only [δ', dif_pos hq]
      congr 1
      simp
    rw [hδq] at this
    exact this
  · intro q₁ q₂ h
    have hq1 : (e q₁ : ℕ) < n := (e q₁).isLt
    have hq2 : (e q₂ : ℕ) < n := (e q₂).isLt
    have := h4 (e q₁ : ℕ) hq1 (e q₂ : ℕ) hq2 h
    exact e.injective (Fin.ext this)
  · exact h5

end Subit
