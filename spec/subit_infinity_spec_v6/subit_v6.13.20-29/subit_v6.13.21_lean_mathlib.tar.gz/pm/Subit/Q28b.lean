import Subit.RZero
import Subit.TreeUltra

/-!
# SUBIT-∞: твердження 11.11 (Q28b) у Lean

S∞ = Tree∞ (метрика d_S), R = ℛ₀ = `RZ A`, X = S∞ × ℛ₀ з max-метрикою.
κ_c — сталі відображення; p(ρ) = ρ(x₀); g∞(ρ,s) = κ_{T′(p(ρ))};
D∞(s,ρ) = (ρ(s), g∞(ρ,s)); P = {(c, κ_{T(c)}) : c ∈ Y}.
T′ — неперервне продовження T (лема 11.9, `extend_tree`); тут — як гіпотеза.
-/

noncomputable section

namespace Subit
open Set Topology

variable {A : Type*} [Finite A]

/-- κ_c: сталі відображення c (належить ℛ₀). -/
def kap (c : TreeM A) : RZ A :=
  ⟨ContinuousMap.const (TreeM A) c, fun x y => by
    simp only [ContinuousMap.const_apply, dist_self]
    exact dist_nonneg⟩

lemma kap_lipschitz : LipschitzWith 1 (kap (A := A)) := by
  refine LipschitzWith.of_dist_le_mul fun c c' => ?_
  simp only [NNReal.coe_one, one_mul]
  rw [Subtype.dist_eq]
  refine (ContinuousMap.dist_le dist_nonneg).2 fun x => ?_
  exact le_rfl

/-- Обчислення ρ(x₀) (p(ρ) у 11.11). -/
def ev (x0 : TreeM A) (ρ : RZ A) : TreeM A := ρ.1 x0

lemma ev_lipschitz (x0 : TreeM A) : LipschitzWith 1 (ev (A := A) x0) := by
  refine LipschitzWith.of_dist_le_mul fun ρ σ => ?_
  simp only [NNReal.coe_one, one_mul]
  rw [Subtype.dist_eq]
  exact ContinuousMap.dist_apply_le_dist x0

/-- Оцінка для спільної 1-ліпшицевості: d(ρ s, σ t) ≤ max(d(ρ,σ), d(s,t)). -/
lemma app_dist_le (ρ σ : RZ A) (s t : TreeM A) :
    dist (ρ.1 s) (σ.1 t) ≤ max (dist ρ σ) (dist s t) := by
  have h1 : dist (ρ.1 s) (σ.1 s) ≤ dist ρ σ := by
    have := ContinuousMap.dist_apply_le_dist (f := ρ.1) (g := σ.1) s
    rw [Subtype.dist_eq]
    exact this
  have h2 : dist (σ.1 s) (σ.1 t) ≤ dist s t := σ.2 s t
  exact le_trans (IsUltrametricDist.dist_triangle_max (ρ.1 s) (σ.1 s) (σ.1 t))
    (max_le (le_max_of_le_left h1) (le_max_of_le_right h2))

/-- Спільна неперервність (ρ, s) ↦ ρ(s) на ℛ₀ × S∞. -/
lemma app_cont : Continuous (fun q : TreeM A × RZ A => q.2.1 q.1) := by
  rw [Metric.continuous_iff]
  rintro ⟨t, σ⟩ ε hε
  refine ⟨ε, hε, fun ⟨s, ρ⟩ h => ?_⟩
  rw [Prod.dist_eq] at h
  have hst : dist s t < ε := lt_of_le_of_lt (le_max_left _ _) h
  have hρσ : dist ρ σ < ε := lt_of_le_of_lt (le_max_right _ _) h
  exact lt_of_le_of_lt (app_dist_le ρ σ s t) (max_lt hρσ hst)

/-- g∞(ρ, s) := κ_{T′(p(ρ))}. -/
def gInf (T' : TreeM A → TreeM A) (x0 : TreeM A) (p : RZ A × TreeM A) : RZ A :=
  kap (T' (ev x0 p.1))

/-- D∞(s, ρ) := (ρ(s), g∞(ρ, s)). -/
def Dinf (T' : TreeM A → TreeM A) (x0 : TreeM A) (q : TreeM A × RZ A) : TreeM A × RZ A :=
  (q.2.1 q.1, gInf T' x0 (q.2, q.1))

/-- P := {(c, κ_{T′(c)}) : c ∈ Y}. -/
def Pset (Y : Set (TreeM A)) (T' : TreeM A → TreeM A) : Set (TreeM A × RZ A) :=
  (fun c => (c, kap (T' c))) '' Y

lemma gInf_cont (T' : TreeM A → TreeM A) (hT' : Continuous T') (x0 : TreeM A) :
    Continuous (gInf T' x0) :=
  (kap_lipschitz.continuous).comp (hT'.comp ((ev_lipschitz x0).continuous.comp continuous_fst))

lemma Dinf_cont (T' : TreeM A → TreeM A) (hT' : Continuous T') (x0 : TreeM A) :
    Continuous (Dinf T' x0) :=
  app_cont.prodMk ((gInf_cont T' hT' x0).comp (continuous_snd.prodMk continuous_fst))

/-- Для c ∈ Y: D∞(c, κ_{T′c}) = (T′c, κ_{T′(T′c)}). -/
lemma Dinf_pt (T' : TreeM A → TreeM A) (x0 c : TreeM A) :
    Dinf T' x0 (c, kap (T' c)) = (T' c, kap (T' (T' c))) := rfl

theorem q28b_lean (Y : Set (TreeM A)) (hY : IsClosed Y) (T' : TreeM A → TreeM A)
    (hT' : Continuous T') (hmaps : ∀ c ∈ Y, T' c ∈ Y)
    (hsurj : ∀ d ∈ Y, ∃ c ∈ Y, T' c = d) (x0 : TreeM A) :
    Continuous (gInf T' x0) ∧ Continuous (Dinf T' x0) ∧ IsClosed (Pset Y T') ∧
      Dinf T' x0 '' Pset Y T' = Pset Y T' ∧
      ∀ c ∈ Y, T' c ≠ c → Dinf T' x0 (c, kap (T' c)) ≠ (c, kap (T' c)) := by
  refine ⟨gInf_cont T' hT' x0, Dinf_cont T' hT' x0, ?_, ?_, ?_⟩
  · have hPc : Continuous (fun c : TreeM A => (c, kap (T' c))) :=
      continuous_id.prodMk (kap_lipschitz.continuous.comp hT')
    exact (hY.isCompact.image hPc).isClosed
  · apply Set.Subset.antisymm
    · rintro _ ⟨_, ⟨c, hc, rfl⟩, rfl⟩
      exact ⟨T' c, hmaps c hc, rfl⟩
    · rintro _ ⟨d, hd, rfl⟩
      obtain ⟨c, hc, hcd⟩ := hsurj d hd
      refine ⟨(c, kap (T' c)), ⟨c, hc, rfl⟩, ?_⟩
      subst hcd
      rfl
  · intro c _ hne heq
    apply hne
    exact congrArg Prod.fst heq

theorem q28b_full (Y : Set (TreeM A)) (hY : IsClosed Y) (T : Y → Y) (hT : Continuous T)
    (hsurj : Function.Surjective T) (x0 : TreeM A) :
    ∃ T' : TreeM A → TreeM A, Continuous T' ∧ (∀ c : Y, T' c = (T c : TreeM A)) ∧
      Continuous (gInf T' x0) ∧ Continuous (Dinf T' x0) ∧ IsClosed (Pset Y T') ∧
      Dinf T' x0 '' Pset Y T' = Pset Y T' ∧
      ∀ c ∈ Y, T' c ≠ c → Dinf T' x0 (c, kap (T' c)) ≠ (c, kap (T' c)) := by
  obtain ⟨F, hFc, hF⟩ := extend_tree Y hY (fun y : Y => (T y : TreeM A))
    (continuous_subtype_val.comp hT)
  have hmaps : ∀ c ∈ Y, F c ∈ Y := fun c hc => by
    have := hF ⟨c, hc⟩
    rw [this]
    exact (T ⟨c, hc⟩).2
  have hsurj' : ∀ d ∈ Y, ∃ c ∈ Y, F c = d := fun d hd => by
    obtain ⟨c, hc⟩ := hsurj ⟨d, hd⟩
    refine ⟨c.1, c.2, ?_⟩
    rw [hF c]
    exact congrArg Subtype.val hc
  refine ⟨F, hFc, fun c => hF c, q28b_lean Y hY F hFc hmaps hsurj' x0⟩

end Subit

end
