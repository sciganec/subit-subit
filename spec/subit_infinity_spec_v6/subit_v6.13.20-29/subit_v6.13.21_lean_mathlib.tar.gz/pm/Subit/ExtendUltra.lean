import Mathlib.Topology.Metrizable.Uniformity
import Mathlib.Topology.Metrizable.Basic
import Mathlib.Topology.MetricSpace.Cauchy
import Mathlib.Topology.UniformSpace.HeineCantor
import Mathlib.Topology.UniformSpace.Cauchy
import Mathlib.Topology.UniformSpace.UniformConvergence
import Mathlib.Topology.MetricSpace.Pseudo.Basic
import Mathlib.Topology.Separation.Hausdorff
import Mathlib.Topology.MetricSpace.Cauchy
import Mathlib.Topology.MetricSpace.Defs
import Mathlib.Topology.MetricSpace.Ultra.Basic
import Mathlib.Topology.Compactness.Compact

/-!
Лема 11.9 (продовження в ультраметриці), крок 3: наближення F_n і
локальна сталість на кулях радіуса r_n = (1/2)^n.
-/

universe u

open Metric Topology Set IsUltrametricDist
open scoped Classical

variable {X : Type u} [MetricSpace X] [IsUltrametricDist X]

/-- Вибір точки з множини; `x0` — запасний варіант для порожньої. -/
noncomputable def chooseOn (s : Set X) (x0 : X) : X :=
  if h : s.Nonempty then h.some else x0

/-- Радіуси (1/2)^n. -/
noncomputable def rad (n : ℕ) : ℝ := (1/2 : ℝ) ^ n

lemma rad_succ_le (n : ℕ) : rad (n+1) ≤ rad n := by
  unfold rad
  rw [pow_succ]
  nlinarith [pow_pos (by norm_num : (0:ℝ) < 1/2) n]

/-- Наближення F_n. Рівень n+1 бере значення `g` у точці вибору з `A ∩ ball x (rad n)`,
інакше — попередній рівень. -/
noncomputable def approx (A : Set X) (g : X → X) (x0 : X) : ℕ → X → X
  | 0 => fun _ => x0
  | n + 1 => fun x =>
      if (A ∩ ball x (rad n)).Nonempty then g (chooseOn (A ∩ ball x (rad n)) x0)
      else approx A g x0 n x

/-- F_n сталий на кулях радіуса rad n. -/
lemma approx_const (A : Set X) (g : X → X) (x0 : X) :
    ∀ n : ℕ, ∀ x y : X, y ∈ ball x (rad n) → approx A g x0 n x = approx A g x0 n y := by
  intro n
  induction n with
  | zero =>
    intro x y _
    rfl
  | succ n ih =>
    intro x y hy
    have hy' : y ∈ ball x (rad n) := (ball_subset_ball (rad_succ_le n)) hy
    have hball : ball y (rad n) = ball x (rad n) := (ball_eq_of_mem hy').symm
    simp only [approx]
    rw [hball]
    by_cases hne : (A ∩ ball x (rad n)).Nonempty
    · rw [if_pos hne, if_pos hne]
    · rw [if_neg hne, if_neg hne]
      exact ih x y hy'


lemma approx_succ (A : Set X) (g : X → X) (x0 : X) (n : ℕ) (x : X) :
    approx A g x0 (n+1) x =
      if (A ∩ ball x (rad n)).Nonempty then g (chooseOn (A ∩ ball x (rad n)) x0)
      else approx A g x0 n x := rfl

lemma rad_pos (n : ℕ) : 0 < rad n := by unfold rad; positivity

lemma rad_anti {i j : ℕ} (h : i ≤ j) : rad j ≤ rad i := by
  unfold rad
  exact pow_le_pow_of_le_one (by norm_num) (by norm_num) h

lemma chooseOn_mem {s : Set X} (h : s.Nonempty) (x0 : X) : chooseOn s x0 ∈ s := by
  unfold chooseOn
  rw [dif_pos h]
  exact h.some_mem

/-- Крок наближення: сусідні рівні відрізняються менше ніж на ε,
якщо радіус rad j < δ (δ — модуль неперервності g на A). -/
lemma step_bound (A : Set X) (g : X → X) (x0 : X) (ε δ : ℝ) (hε : 0 < ε)
    (hg : ∀ a ∈ A, ∀ b ∈ A, dist a b < δ → dist (g a) (g b) < ε)
    (j : ℕ) (hj : rad j < δ) (x : X) :
    dist (approx A g x0 (j+1+1) x) (approx A g x0 (j+1) x) < ε := by
  have e1 := approx_succ A g x0 (j+1) x
  have e2 := approx_succ A g x0 j x
  rw [e1]
  by_cases h1 : (A ∩ ball x (rad (j+1))).Nonempty
  · have h0 : (A ∩ ball x (rad j)).Nonempty := by
      obtain ⟨a, ha⟩ := h1
      exact ⟨a, ha.1, (ball_subset_ball (rad_succ_le j)) ha.2⟩
    rw [if_pos h1, e2, if_pos h0]
    have hc1 := chooseOn_mem h1 x0
    have hc0 := chooseOn_mem h0 x0
    apply hg _ hc1.1 _ hc0.1
    have d1 : dist (chooseOn (A ∩ ball x (rad (j+1))) x0) x < rad (j+1) := mem_ball.1 hc1.2
    have d0 : dist (chooseOn (A ∩ ball x (rad j)) x0) x < rad j := mem_ball.1 hc0.2
    have hd : dist (chooseOn (A ∩ ball x (rad (j+1))) x0) (chooseOn (A ∩ ball x (rad j)) x0) < rad j := by
      refine lt_of_le_of_lt (IsUltrametricDist.dist_triangle_max (x := chooseOn (A ∩ ball x (rad (j+1))) x0) (y := x)
        (z := chooseOn (A ∩ ball x (rad j)) x0)) ?_
      apply max_lt
      · exact lt_of_lt_of_le d1 (rad_succ_le j)
      · rw [dist_comm]; exact d0
    exact lt_trans hd hj
  · rw [if_neg h1]
    rw [dist_self]
    exact hε

lemma approx_cont (A : Set X) (g : X → X) (x0 : X) (n : ℕ) :
    Continuous (approx A g x0 n) := by
  rw [continuous_iff_continuousAt]
  intro x
  have h : ∀ᶠ y in 𝓝 x, approx A g x0 n x = approx A g x0 n y :=
    Filter.mem_of_superset (ball_mem_nhds x (rad_pos n))
      (fun y hy => approx_const A g x0 n x y hy)
  exact continuousAt_const.congr h

/-- Оцінка рівня K+1 і всіх наступних рівнів. -/
lemma approx_near (A : Set X) (g : X → X) (x0 : X) (ε δ : ℝ) (hε : 0 < ε)
    (hg : ∀ a ∈ A, ∀ b ∈ A, dist a b < δ → dist (g a) (g b) < ε)
    (K : ℕ) (hK : rad K < δ) (x : X) :
    ∀ m, K + 1 ≤ m → dist (approx A g x0 m x) (approx A g x0 (K+1) x) < ε := by
  intro m hm
  induction m, hm using Nat.le_induction with
  | base => rw [dist_self]; exact hε
  | succ m hm ih =>
    obtain ⟨j, rfl⟩ : ∃ j, m = j + 1 := ⟨m - 1, by omega⟩
    have hj : rad j < δ := lt_of_le_of_lt (rad_anti (by omega)) hK
    have hs := step_bound A g x0 ε δ hε hg j hj x
    have htri := IsUltrametricDist.dist_triangle_max (x := approx A g x0 (j+1+1) x)
      (y := approx A g x0 (j+1) x) (z := approx A g x0 (K+1) x)
    exact lt_of_le_of_lt htri (max_lt hs ih)


open Filter

/-- Лема 11.9: продовження неперервного відображення з замкненої підмножини
компактного ультраметричного простору. -/
theorem extend_ultra [CompactSpace X] (A : Set X) (hA : IsClosed A)
    (f : A → X) (hf : Continuous f) :
    ∃ F : X → X, Continuous F ∧ ∀ a : A, F a = f a := by
  rcases isEmpty_or_nonempty X with hX | hX
  · exact ⟨id, continuous_id, fun a => (IsEmpty.false a.1).elim⟩
  obtain ⟨x0⟩ := hX
  classical
  haveI : CompactSpace A := isCompact_iff_compactSpace.1 hA.isCompact

  set g : X → X := fun y => if h : y ∈ A then f ⟨y, h⟩ else y with hgdef
  have hg_of : ∀ a (ha : a ∈ A), g a = f ⟨a, ha⟩ := fun a ha => by
    simp [hgdef, ha]
  have hu : UniformContinuous f := CompactSpace.uniformContinuous_of_continuous hf
  have hmod : ∀ ε > 0, ∃ δ > 0, ∀ a ∈ A, ∀ b ∈ A, dist a b < δ → dist (g a) (g b) < ε := by
    intro ε hε
    obtain ⟨δ, hδ, h⟩ := Metric.uniformContinuous_iff.1 hu ε hε
    refine ⟨δ, hδ, fun a ha b hb hab => ?_⟩
    rw [hg_of a ha, hg_of b hb]
    exact h (a := ⟨a, ha⟩) (b := ⟨b, hb⟩) hab
  have hlim : ∀ x, ∃ y, Tendsto (fun n => approx A g x0 n x) atTop (𝓝 y) := by
    intro x
    apply cauchySeq_tendsto_of_complete
    rw [Metric.cauchySeq_iff']
    intro ε hε
    obtain ⟨δ, hδ, hg⟩ := hmod ε hε
    obtain ⟨K, hK⟩ := exists_pow_lt_of_lt_one hδ (by norm_num : (1/2:ℝ) < 1)
    have hK' : rad K < δ := hK
    exact ⟨K+1, fun n hn => approx_near A g x0 ε δ hε hg K hK' x n hn⟩
  choose F hF using hlim
  have hunif : ∀ ε > 0, ∃ N, ∀ m, N ≤ m → ∀ x, dist (F x) (approx A g x0 m x) < ε := by
    intro ε hε
    obtain ⟨δ, hδ, hg⟩ := hmod (ε/2) (by positivity)
    obtain ⟨K, hK⟩ := exists_pow_lt_of_lt_one hδ (by norm_num : (1/2:ℝ) < 1)
    have hK' : rad K < δ := hK
    refine ⟨K+1, fun m hm x => ?_⟩
    have hA1 := approx_near A g x0 (ε/2) δ (by positivity) hg K hK' x m hm
    rw [dist_comm] at hA1
    have hlimd : dist (F x) (approx A g x0 (K+1) x) ≤ ε/2 := by
      have ht : Tendsto (fun n => dist (approx A g x0 n x) (approx A g x0 (K+1) x)) atTop
          (𝓝 (dist (F x) (approx A g x0 (K+1) x))) := (hF x).dist tendsto_const_nhds
      apply le_of_tendsto ht
      exact Filter.eventually_atTop.2 ⟨K+1, fun n hn =>
        (approx_near A g x0 (ε/2) δ (by positivity) hg K hK' x n hn).le⟩
    have htri := IsUltrametricDist.dist_triangle_max (x := F x)
      (y := approx A g x0 (K+1) x) (z := approx A g x0 m x)
    exact lt_of_le_of_lt htri (max_lt (by linarith) (by linarith))
  have hTU : TendstoUniformly (fun n x => approx A g x0 n x) F atTop := by
    rw [Metric.tendstoUniformly_iff]
    intro ε hε
    obtain ⟨N, hN⟩ := hunif ε hε
    exact Filter.eventually_atTop.2 ⟨N, fun m hm x => hN m hm x⟩
  have hcont : Continuous F :=
    hTU.continuous (Filter.Eventually.of_forall (approx_cont A g x0)).frequently
  refine ⟨F, hcont, fun a => ?_⟩
  have hga : Tendsto (fun n => approx A g x0 n (a : X)) atTop (𝓝 (g a)) := by
    rw [Metric.tendsto_atTop]
    intro ε hε
    obtain ⟨δ, hδ, hg⟩ := hmod ε hε
    obtain ⟨K, hK⟩ := exists_pow_lt_of_lt_one hδ (by norm_num : (1/2:ℝ) < 1)
    have hK' : rad K < δ := hK
    refine ⟨K+2, fun n hn => ?_⟩
    obtain ⟨j, rfl⟩ : ∃ j, n = j + 1 := ⟨n - 1, by omega⟩
    have hne : (A ∩ ball (a : X) (rad j)).Nonempty :=
      ⟨a, a.2, mem_ball_self (rad_pos j)⟩
    rw [approx_succ, if_pos hne]
    have hc := chooseOn_mem hne x0
    have hd : dist (chooseOn (A ∩ ball (a : X) (rad j)) x0) (a : X) < δ :=
      lt_of_lt_of_le (mem_ball.1 hc.2) (le_of_lt (lt_of_le_of_lt (rad_anti (by omega)) hK'))
    exact hg _ hc.1 _ a.2 hd
  have heq : F a = g a := tendsto_nhds_unique (hF a) hga
  rw [heq, hg_of (a : X) a.2]
