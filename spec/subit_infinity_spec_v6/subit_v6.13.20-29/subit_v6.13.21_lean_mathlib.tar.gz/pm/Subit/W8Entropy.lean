import Subit.D6
import Subit.W8Count
import Mathlib.Topology.Instances.EReal.Lemmas
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
/-!
# W8: нульова топологічна ентропія на ω-границі слова d

Модель: простір послідовностей `X = ℕ → Bool` з добутковою топологією, зсув
`shift x = (n ↦ x (n+1))`, відстань `dC x y = 2^{-k}`, де k — перший індекс розбіжності
(`Subit.dC` з `FullShift.lean`; `dC x y = 0`, якщо x = y).

Відповідність специфікації: там d_S(f,g) = 2^{-m}, m — довжина мінімальної адреси розбіжності
(`DSExact.dS_eq_pow_minlen`). Тут індекс розбіжності k відповідає адресі довжини k або k+1
залежно від нумерації, тож dC і d_S відрізняються не більше ніж множником 2. Цей зв'язок
НЕ доведено формально; результат нижче не залежить від сталого множника (ε довільне).

Головні результати:
* `htop_eq_zero_of_poly` — загальна лема: поліноміальне зростання s(n,ε) ⇒ h_top = 0.
* `prefix_mem_factor` — кожен префікс точки ω(d) є вікном (фактором) слова d.
* `htopOn_zero_of_factor` — для інваріантної W, усі префікси точок якої є факторами d,
  ентропія зсуву на W дорівнює 0.
* `htop_omega_zero` — ентропія зсуву на ω(d) дорівнює 0 (у моделі послідовностей).

Тільки: propext, Classical.choice, Quot.sound. Без sorry, native_decide і нових аксіом.
-/

open Filter Topology

namespace Subit.W8Entropy

/-! ### Загальна лема: поліноміальне зростання ⇒ h_top = 0 -/

section Poly
variable {X : Type*}

/-- Якщо для кожного ε > 0 величини s(n, ε) мажоруються многочленом від n (для n ≥ 1),
то h_top = 0. Це узагальнення `htop_eq_zero_of_bound` (там D = 0). -/
theorem htop_eq_zero_of_poly (d : X → X → ℝ) (T : X → X)
    (hP : ∀ ε : ℝ, 0 < ε → ∃ A D : ℕ, ∀ n : ℕ, 1 ≤ n → sepNum d T n ε ≤ A * n ^ D) :
    htop d T = 0 := by
  have key : ∀ ε : {ε : ℝ // 0 < ε},
      limsup (fun n : ℕ => ((Real.log (sepNum d T n ε) / n : ℝ) : EReal)) atTop = 0 := by
    rintro ⟨ε, hε⟩
    obtain ⟨A, D, hA⟩ := hP ε hε
    have hup : Tendsto (fun n : ℕ => Real.log ((A : ℝ) + 1) / n
        + (D : ℝ) * (Real.log n / n)) atTop (𝓝 0) := by
      have h1 := tendsto_const_div_atTop_nhds_zero_nat (Real.log ((A : ℝ) + 1))
      have h2 : Tendsto (fun n : ℕ => Real.log n / n) atTop (𝓝 0) :=
        Real.isLittleO_log_id_atTop.tendsto_div_nhds_zero.comp tendsto_natCast_atTop_atTop
      have h3 := h1.add (h2.const_mul (D : ℝ))
      rw [mul_zero, add_zero] at h3
      exact h3
    have hlim : Tendsto (fun n : ℕ => Real.log (sepNum d T n ε) / n) atTop (𝓝 0) := by
      refine tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hup ?_ ?_
      · exact Eventually.of_forall fun n => sepNum_nonneg_term d T n ε
      · filter_upwards [eventually_ge_atTop 1] with n hn
        have hA1 : (0 : ℝ) ≤ (A : ℝ) := Nat.cast_nonneg A
        have hlogA : 0 ≤ Real.log ((A : ℝ) + 1) := Real.log_nonneg (by linarith)
        have hlogn : 0 ≤ Real.log (n : ℝ) := Real.log_nonneg (by exact_mod_cast hn)
        have hs : Real.log (sepNum d T n ε) ≤ Real.log ((A : ℝ) + 1) + D * Real.log n := by
          rcases Nat.eq_zero_or_pos (sepNum d T n ε) with h0 | hpos
          · rw [h0, Nat.cast_zero, Real.log_zero]
            positivity
          · have hnat := hA n hn
            have hreal : (sepNum d T n ε : ℝ) ≤ (A : ℝ) * (n : ℝ) ^ D := by
              exact_mod_cast hnat
            have hpow : (0 : ℝ) ≤ (n : ℝ) ^ D := by positivity
            have hle : (sepNum d T n ε : ℝ) ≤ ((A : ℝ) + 1) * (n : ℝ) ^ D := by nlinarith
            have hpos' : (0 : ℝ) < (sepNum d T n ε : ℝ) := by exact_mod_cast hpos
            calc Real.log (sepNum d T n ε)
                ≤ Real.log (((A : ℝ) + 1) * (n : ℝ) ^ D) := Real.log_le_log hpos' hle
              _ = Real.log ((A : ℝ) + 1) + D * Real.log n := by
                rw [Real.log_mul (by positivity) (by positivity), Real.log_pow]
        have hn' : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
        have e : Real.log ((A : ℝ) + 1) / n + (D : ℝ) * (Real.log n / n)
            = (Real.log ((A : ℝ) + 1) + D * Real.log n) / n := by ring
        rw [e]
        exact div_le_div_of_nonneg_right hs hn'
    have h := (EReal.tendsto_coe.2 hlim).limsup_eq
    rw [EReal.coe_zero] at h
    exact h
  unfold htop
  haveI : Nonempty {ε : ℝ // 0 < ε} := ⟨⟨1, one_pos⟩⟩
  simp only [key]
  exact iSup_const

end Poly

/-! ### Ітерації звуження -/

section Restrict

/-- Зсув на послідовностях (`Subit.shift`) неперервний у добутковій топології. -/
theorem continuous_shift : Continuous shift :=
  continuous_pi fun n => continuous_apply (n + 1)

/-- Значення ітерації звуження на W — це ітерація зсуву. -/
theorem iter_restrict_val (W : Set (ℕ → Bool)) (hW : Set.MapsTo shift W W) (i : ℕ)
    (a : W) : (iter (restrict shift W hW) i a).1 = iter shift i a.1 := by
  induction i with
  | zero => rfl
  | succ i ih =>
    show shift (iter (restrict shift W hW) i a).1 = shift (iter shift i a.1)
    rw [ih]

end Restrict

/-! ### Мова ω-границі: кожен префікс точки ω(d) є вікном d -/

section Language

/-- Якщо x ∈ ω(d), то кожен префікс x є вікном слова d:
x(0..L-1) = d(p..p+L-1) для деякого p. Доведення: x лежить у замиканні орбіти d,
а циліндр {y | y agrees with x on [0,L)} є відкритим околом x. -/
theorem prefix_mem_factor {x : ℕ → Bool} (hx : x ∈ Subit.omega shift Subit.W8.dW)
    (L : ℕ) : ∃ p : ℕ, ∀ j < L, x j = Subit.W8.dW (p + j) := by
  have hcl : x ∈ closure (Set.range fun k => iter shift (0 + k) Subit.W8.dW) :=
    Set.mem_iInter.1 hx 0
  have hU : IsOpen {y : ℕ → Bool | ∀ j < L, y j = x j} := by
    have e : {y : ℕ → Bool | ∀ j < L, y j = x j}
        = ⋂ j ∈ Finset.range L, (fun y : ℕ → Bool => y j) ⁻¹' {x j} := by
      ext y
      simp
    rw [e]
    exact isOpen_biInter_finset fun j _ =>
      (continuous_apply j).isOpen_preimage _ (isOpen_discrete _)
  obtain ⟨y, hyU, k, hk⟩ := mem_closure_iff.1 hcl _ hU (fun j _ => rfl)
  subst hk
  refine ⟨k, fun j hj => ?_⟩
  have h : Subit.W8.dW (j + (0 + k)) = x j := by
    have := hyU j hj
    simp only [iter_shift] at this
    exact this
  rw [show k + j = j + (0 + k) by omega]
  exact h.symm

end Language

/-! ### Підрахунок роздільних множин -/

section Count

/-- Для інваріантної W, усі префікси точок якої є факторами d, і будь-якого K:
ε-роздільна множина в W має не більш ніж 2(n+K+1)² точок, якщо (1/2)^K < ε. -/
theorem sepNum_restrict_le (W : Set (ℕ → Bool)) (hW : Set.MapsTo shift W W)
    (hfac : ∀ x ∈ W, ∀ L : ℕ, ∃ p : ℕ, ∀ j < L, x j = Subit.W8.dW (p + j))
    (K : ℕ) (ε : ℝ) (hK : (1 / 2 : ℝ) ^ K < ε) (n : ℕ) :
    sepNum (fun a b : W => Subit.dC a.1 b.1) (restrict shift W hW) n ε
      ≤ 2 * (n + K + 1) ^ 2 := by
  refine sepNum_le _ fun S hS => ?_
  obtain ⟨T, hT, hcard⟩ := Subit.W8.factor_bound_sq (n + K + 1) (by omega)
  refine le_trans ?_ hcard
  refine Finset.card_le_card_of_injOn
    (fun a : W => List.ofFn (fun j : Fin (n + K + 1) => a.1 j)) ?_ ?_
  · intro a _
    obtain ⟨p, hp⟩ := hfac a.1 a.2 (n + K + 1)
    have e : List.ofFn (fun j : Fin (n + K + 1) => a.1 j)
        = List.ofFn (fun j : Fin (n + K + 1) => Subit.W8.dW (p + j)) := by
      congr 1
      funext j
      exact hp j j.isLt
    show List.ofFn (fun j : Fin (n + K + 1) => a.1 j) ∈ T
    rw [e]
    exact hT p
  · intro a ha b hb hab
    by_contra hne
    obtain ⟨i, hi, hd⟩ := hS a ha b hb hne
    have hfun := List.ofFn_injective hab
    have hagree : ∀ j, j < n + K + 1 → a.1 j = b.1 j := fun j hj =>
      congrFun hfun ⟨j, hj⟩
    have hle : Subit.dC (iter shift i a.1) (iter shift i b.1) ≤ (1 / 2 : ℝ) ^ K := by
      apply Subit.dC_le
      intro m hm
      rw [iter_shift, iter_shift]
      exact hagree (m + i) (by omega)
    simp only [iter_restrict_val] at hd
    linarith

end Count

/-! ### Нульова ентропія -/

section Zero

/-- Для інваріантної W, усі префікси точок якої є факторами d, ентропія зсуву на W дорівнює 0. -/
theorem htopOn_zero_of_factor (W : Set (ℕ → Bool)) (hW : Set.MapsTo shift W W)
    (hfac : ∀ x ∈ W, ∀ L : ℕ, ∃ p : ℕ, ∀ j < L, x j = Subit.W8.dW (p + j)) :
    Subit.htopOn Subit.dC shift W hW = 0 := by
  unfold Subit.htopOn
  apply htop_eq_zero_of_poly
  intro ε hε
  obtain ⟨K, hK⟩ := exists_pow_lt_of_lt_one hε (by norm_num : (1 / 2 : ℝ) < 1)
  refine ⟨2 * (K + 2) ^ 2, 2, fun n hn => ?_⟩
  have h1 := sepNum_restrict_le W hW hfac K ε hK n
  have h2 : n + K + 1 ≤ (K + 2) * n := by nlinarith
  calc _ ≤ 2 * (n + K + 1) ^ 2 := h1
    _ ≤ 2 * ((K + 2) * n) ^ 2 := by gcongr
    _ = 2 * (K + 2) ^ 2 * n ^ 2 := by ring

end Zero

/-! ### Головний результат -/

/-- Відображення зсуву переводить ω(d) в себе (D1, ω-границя неперервного відображення). -/
theorem omega_maps_shift :
    Set.MapsTo shift (Subit.omega shift Subit.W8.dW) (Subit.omega shift Subit.W8.dW) :=
  fun _ hy => Subit.omega_forward shift continuous_shift _ (Set.mem_image_of_mem shift hy)

/-- Головна теорема: зсув на ω-границі слова d (у моделі послідовностей ℕ → Bool з відстанню
`Subit.dC`) має нульову топологічну ентропію. -/
theorem htop_omega_zero :
    Subit.htopOn Subit.dC shift (Subit.omega shift Subit.W8.dW) omega_maps_shift = 0 :=
  htopOn_zero_of_factor _ _ fun _ hx L => prefix_mem_factor hx L

end Subit.W8Entropy
