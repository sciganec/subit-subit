import Subit.FullShift

/-!
# G10: свідок CHAOTIC для нескінченної системи

За §4.3 предикат CHAOTIC означає h_top > 0, тож «CHAOTIC ⇔ h_top > 0» є означенням, а не
теоремою. Формалізовано лише нетривіальний свідок: повний зсув на {0,1}^ℕ має h_top = log 2 > 0.
-/

namespace Subit


theorem chaotic_witness_fullshift : (0 : EReal) < htop dC shift := by
  rw [lemma_4_6]
  exact_mod_cast Real.log_pos (by norm_num : (1 : ℝ) < 2)

end Subit
