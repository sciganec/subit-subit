import Subit.DynTopos
import Mathlib.CategoryTheory.Topos.Sheaf
import Mathlib.CategoryTheory.Monoidal.Closed.Cartesian
import Mathlib.CategoryTheory.Monoidal.Closed.FunctorToTypes
import Mathlib.CategoryTheory.Monoidal.Types.Basic
import Mathlib.CategoryTheory.Monoidal.Cartesian.FunctorCategory
import Mathlib.CategoryTheory.Limits.Shapes.FiniteLimits
import Mathlib.CategoryTheory.Limits.Shapes.BinaryProducts
import Mathlib.CategoryTheory.Limits.Preserves.Shapes.BinaryProducts
import Mathlib.CategoryTheory.Adjunction.Basic
import Mathlib.CategoryTheory.Opposites

/-!
# G6: Dyn as an elementary topos, transferred from presheaves along `dynEquiv`

Mathlib has no `Topos` class. Following the elementary-topos definition, the
three properties are stated separately:

1. `HasFiniteLimits` (`dyn_hasFiniteLimits`),
2. `HasSubobjectClassifier` (`dyn_hasSubobjectClassifier`),
3. exponentiability of every object, i.e. `(prod.functor.obj X).IsLeftAdjoint`
   for all `X` (`dyn_exponentiable`), which is Mathlib's Prop-level form of
   "cartesian closed".

Transfer lemmas are proved generically for any equivalence `e : C ≌ D`.
The presheaf inputs come from Mathlib (`Cᵒᵖ ⥤ Type`, `EssentiallySmall`,
`FunctorToTypes.closed`), and the bridge is `Subit.CatSub.dynEquiv`.
-/

open CategoryTheory CategoryTheory.Limits

namespace Subit.CatSub.G6

section Transfer

variable {C : Type*} [Category* C] {D : Type*} [Category* D]

/-- Finite limits transfer along an equivalence. -/
theorem hasFiniteLimits_of_equiv (e : C ≌ D) [HasFiniteLimits D] : HasFiniteLimits C :=
  ⟨fun _ _ _ => Adjunction.hasLimitsOfShape_of_equivalence e.functor⟩

/-- A subobject classifier transfers along an equivalence. -/
theorem hasSubobjectClassifier_of_equiv (e : C ≌ D) [HasSubobjectClassifier D] :
    HasSubobjectClassifier C := by
  obtain ⟨𝒞⟩ := (HasSubobjectClassifier.exists_classifier (C := D))
  exact ⟨⟨𝒞.ofEquivalence e.symm⟩⟩

/-- Exponentiability of `X` transfers along an equivalence once every object of the
target is exponentiable. The proof uses that `e.functor` preserves binary products. -/
theorem isLeftAdjoint_prod_functor_of_equiv (e : C ≌ D) [HasBinaryProducts C]
    [HasBinaryProducts D] (h : ∀ Y : D, (prod.functor.obj Y).IsLeftAdjoint) (X : C) :
    (prod.functor.obj X).IsLeftAdjoint := by
  have hiso : prod.functor.obj X ⋙ e.functor ≅ e.functor ⋙ prod.functor.obj (e.functor.obj X) :=
    prodComparisonNatIso e.functor X
  have h1 : (e.functor ⋙ prod.functor.obj (e.functor.obj X)).IsLeftAdjoint := by
    haveI := h (e.functor.obj X)
    infer_instance
  have h2 : (prod.functor.obj X ⋙ e.functor).IsLeftAdjoint :=
    Functor.isLeftAdjoint_of_iso hiso.symm
  exact (Functor.isLeftAdjoint_comp_iff_left _ _).mp h2

end Transfer

/-! ## Presheaf inputs over Bℕ -/

/-- `Bn ⥤ Type` is a presheaf category on the essentially small category `Bnᵒᵖ`
(Mathlib's instance is stated for `Cᵒᵖ ⥤ Type`), transported along `Bn ≌ Bnᵒᵖᵒᵖ`. -/
instance presheaf_hasSubobjectClassifier : HasSubobjectClassifier (Bn ⥤ Type) :=
  hasSubobjectClassifier_of_equiv
    (Equivalence.congrLeft (E := Type) (opOpEquivalence Bn).symm)

/-- Every presheaf over Bℕ is exponentiable (Mathlib's pointwise closed structure). -/
theorem presheaf_exponentiable (Y : Bn ⥤ Type) : (prod.functor.obj Y).IsLeftAdjoint := by
  letI := FunctorToTypes.closed Y
  exact CartesianMonoidalCategory.isLeftAdjoint_prod_functor Y

/-! ## Transfer to Dyn -/

/-- Dyn has finite limits. -/
instance dyn_hasFiniteLimits : HasFiniteLimits DynObj :=
  hasFiniteLimits_of_equiv dynEquiv

/-- Dyn has a subobject classifier. -/
instance dyn_hasSubobjectClassifier : HasSubobjectClassifier DynObj :=
  hasSubobjectClassifier_of_equiv dynEquiv

/-- Dyn is cartesian closed in the Prop sense: every object `X` is exponentiable,
i.e. `X ⨯ -` has a right adjoint. -/
theorem dyn_exponentiable (X : DynObj) : (prod.functor.obj X).IsLeftAdjoint :=
  isLeftAdjoint_prod_functor_of_equiv dynEquiv presheaf_exponentiable X

end Subit.CatSub.G6
