import Subit.TreeUltra
import Mathlib.Topology.UniformSpace.Ascoli
import Mathlib.Topology.MetricSpace.UniformConvergence
import Mathlib.Topology.ContinuousMap.Compact
import Mathlib.Topology.ContinuousMap.Basic

/-!
# SUBIT-∞: ℛ₀ як компактний ультраметричний простір (T6, Lean)

ℛ₀ = {f : S∞ → S∞ : d_S(f s, f t) ≤ d_S(s, t)} (означення 10.1), з sup-метрикою d_ℛ.
Тут ℛ₀ — підмножина `ContinuousMap (TreeM A) (TreeM A)` з метрикою sup (для компактного
простору області це саме d_ℛ). Компактність — за Arzelà–Ascoli з Mathlib.
-/

namespace Subit
open Set Topology

variable {A : Type*} [Finite A]

/-- ℛ₀ у вигляді множини неперервних відображень Tree∞ → Tree∞. -/
def RZ (A : Type*) [Finite A] : Set (ContinuousMap (TreeM A) (TreeM A)) :=
  {f | ∀ x y : TreeM A, dist (f x) (f y) ≤ dist x y}

/-- Відображення з RZ 1-ліпшицеве (як функція, без обгортки ContinuousMap). -/
lemma lipschitz_of_mem {f : ContinuousMap (TreeM A) (TreeM A)} (hf : f ∈ RZ A) :
    LipschitzWith 1 f :=
  LipschitzWith.of_dist_le_mul fun x y => by simpa using hf x y

/-- Образ ℛ₀ під обгорткою функції — це множина всіх 1-ліпшицевих відображень. -/
lemma image_eq :
    (ContinuousMap.toFun '' RZ A) = {g : TreeM A → TreeM A | ∀ x y, dist (g x) (g y) ≤ dist x y} := by
  ext g
  constructor
  · rintro ⟨f, hf, rfl⟩
    exact hf
  · intro hg
    refine ⟨⟨g, (LipschitzWith.of_dist_le_mul (K := 1) fun x y => by simpa using hg x y).continuous⟩,
      fun x y => ?_, rfl⟩
    exact hg x y

/-- ℛ₀ (як множина в C(Tree∞, Tree∞)) компактний: Arzelà–Ascoli. -/
theorem isCompact_RZ : IsCompact (RZ A) := by
  refine ArzelaAscoli.isCompact_of_equicontinuous (RZ A) ?_ ?_
  · rw [image_eq]
    have hclosed : IsClosed {g : TreeM A → TreeM A | ∀ x y, dist (g x) (g y) ≤ dist x y} := by
      simp only [setOf_forall]
      refine isClosed_iInter fun x => isClosed_iInter fun y => ?_
      exact isClosed_le ((continuous_apply x).dist (continuous_apply y)) continuous_const
    exact isCompact_univ.of_isClosed_subset hclosed (subset_univ _)
  · have h : ∀ f : RZ A, LipschitzWith 1 (fun x => (f : ContinuousMap (TreeM A) (TreeM A)) x) :=
      fun f => lipschitz_of_mem f.2
    exact (LipschitzWith.uniformEquicontinuous (fun (f : RZ A) (x : TreeM A) => (f : ContinuousMap (TreeM A) (TreeM A)) x) 1 h).equicontinuous

/-- Sup-метрика на C(Tree∞, Tree∞) ультраметрична (поточково, з ultrametric-нерівністю). -/
instance instIsUltrametricDistCM : IsUltrametricDist (ContinuousMap (TreeM A) (TreeM A)) where
  dist_triangle_max f g h := by
    refine (ContinuousMap.dist_le (le_max_of_le_left dist_nonneg)).2 fun x => ?_
    refine le_trans (IsUltrametricDist.dist_triangle_max (f x) (g x) (h x)) (max_le ?_ ?_)
    · exact le_max_of_le_left (ContinuousMap.dist_apply_le_dist (f := f) (g := g) x)
    · exact le_max_of_le_right (ContinuousMap.dist_apply_le_dist (f := g) (g := h) x)

/-- ℛ₀ з sup-метрикою ультраметричний (T6, ультраметрична частина). -/
example : IsUltrametricDist (RZ A) := inferInstance

end Subit
