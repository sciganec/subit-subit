import Subit.Hex

/-!
# Порядки Белнапа зі специфікації (G2)

§1, означення 1.1: «Порядок істинності: F < N < T і F < B < T. Порядок інформації: N < F < B і N < T < B.»
Тут ці відношення записано явно (як список пар, транзитивне замикання вже враховано) і доведено,
що `leT`/`leK` (через таблицю `belnap`) збігаються з ними на всіх чотирьох значеннях.
-/

namespace Subit
open Bel

/-- Порядок істинності з §1: рефлексивний, плюс пари F<N, F<B, F<T, N<T, B<T. -/
def specTLE (a b : Bel) : Bool :=
  decide (a = b) || [(F, N), (F, B), (F, T), (N, T), (B, T)].contains (a, b)

/-- Порядок інформації з §1: рефлексивний, плюс пари N<F, N<T, F<B, T<B, N<B. -/
def specKLE (a b : Bel) : Bool :=
  decide (a = b) || [(N, F), (N, T), (F, B), (T, B), (N, B)].contains (a, b)

theorem belnap_truth_matches_spec : ∀ x y : Bool × Bool,
    decide (leT x y) = specTLE (belnap x) (belnap y) := by decide

theorem belnap_info_matches_spec : ∀ x y : Bool × Bool,
    decide (leK x y) = specKLE (belnap x) (belnap y) := by decide

/-- Порядок істинності на A є частковим порядком з F як найменшим і T як найбільшим елементом. -/
theorem spec_truth_bounds : ∀ a : Bel, specTLE F a = true ∧ specTLE a T = true := by
  intro a; cases a <;> decide

end Subit
