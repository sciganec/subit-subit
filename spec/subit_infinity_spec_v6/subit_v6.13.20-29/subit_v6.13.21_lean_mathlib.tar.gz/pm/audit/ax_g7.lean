import Subit.GraphEntropy
#print axioms Subit.htop_graph
#print axioms Subit.htop_eq_of_maxT
#print axioms Subit.sepNum_iso
#print axioms Subit.sep_card_pow
