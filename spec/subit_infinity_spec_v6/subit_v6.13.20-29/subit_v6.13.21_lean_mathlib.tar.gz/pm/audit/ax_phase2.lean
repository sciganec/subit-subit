import Subit
#print axioms Subit.CatSub.K1_subset
#print axioms Subit.CatSub.K2_termF
#print axioms Subit.CatSub.K3_full
#print axioms Subit.q28b_R
