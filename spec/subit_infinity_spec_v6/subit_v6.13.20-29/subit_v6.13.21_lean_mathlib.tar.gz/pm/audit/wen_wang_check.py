# Перевірка Додатка А специфікації проти двох зовнішніх джерел послідовності Вень-вана (G1).
# Джерело 1 (повні 64): Wikipedia «List of hexagrams of the I Ching» (лінії знизу вгору, 1 = суцільна).
# Джерело 2 (36 гексаграм): Wikipedia «King Wen sequence» (лінії знизу вгору).
# Запуск: python3 wen_wang_check.py <spec.md> <wen_wang_source.txt> <wen_wang_second_source.txt>
import re, sys
spec = open(sys.argv[1], encoding='utf-8').read().split('\n')
start = next(i for i, l in enumerate(spec) if l.startswith('## Додаток А. Гексаграми'))
codes = {}
for l in spec[start:start + 150]:
    if not l.startswith('| '): continue
    cells = [c.strip() for c in l.strip().strip('|').split('|')]
    if len(cells) != 12: continue
    for k in range(4):
        num, g, c = cells[3*k:3*k+3]
        if re.fullmatch(r'\d\d', num) and re.fullmatch(r'[01]{6}', c): codes[int(num)] = c
src1 = {int(l.split('|')[0]): l.split('|')[1].strip() for l in open(sys.argv[2]) if '|' in l}
src2 = {int(l.split()[0]): l.split()[1] for l in open(sys.argv[3]) if l.strip()}
print('джерело 1: розбіжностей із специфікацією =', sum(codes[n] != src1[n] for n in range(1, 65)), 'з 64')
print('джерело 2: розбіжностей =', sum(codes[n] != c for n, c in src2.items()), 'з', len(src2))
