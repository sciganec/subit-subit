# Перевірка таблиці гексаграм: Додаток А специфікації (v6.13.10) проти Lean `hexTable` (HexData.lean).
# Запуск: python3 hex_check.py <шлях_до_специфікації> <шлях_до_HexData.lean>
import re, sys
spec_path, lean_path = sys.argv[1], sys.argv[2]
spec = open(spec_path, encoding='utf-8').read().split('\n')
start = next(i for i, l in enumerate(spec) if l.startswith('## Додаток А. Гексаграми'))
rows = {}; codes = []; glyphs = []
for l in spec[start:start + 150]:
    if not l.startswith('| '): continue
    cells = [c.strip() for c in l.strip().strip('|').split('|')]
    if len(cells) != 12: continue
    for k in range(4):
        num, g, c = cells[3*k:3*k+3]
        if re.fullmatch(r'\d\d', num) and re.fullmatch(r'[01]{6}', c):
            rows[int(num)] = (g, c); codes.append(c); glyphs.append(g)
lean = open(lean_path, encoding='utf-8').read()
body = lean[lean.index('def hexTable'):]; body = body[:body.index(']')]
ent = re.findall(r'\((\d+),\s*(\d+),\s*(\d+)\)', body)
bad = []
for n, cp, code in ent:
    n, cp, code = int(n), int(cp), int(code)
    if n not in rows: bad.append((n, 'немає в специфікації')); continue
    g, c = rows[n]
    if ord(g) != cp: bad.append((n, 'гліф'))
    if int(c, 2) != code: bad.append((n, 'код'))
print('записів у специфікації:', len(rows), '| у Lean:', len(ent))
print('номери 1..64 повні:', sorted(rows) == list(range(1, 65)) and sorted(int(e[0]) for e in ent) == list(range(1, 65)))
print('коди унікальні:', len(set(codes)) == 64, '| гліфи унікальні:', len(set(glyphs)) == 64)
print('розбіжності:', bad if bad else 'немає')
