import Subit.RComp
#print axioms Subit.density_comp
#print axioms Subit.Gap_mem_RComp
