import sys, subprocess, shutil, os
base='/tmp/claude-0/-home-claude/2e70a0f6-edb4-5da6-8dbd-4dd00733438d/scratchpad/clean_v6139/pm/'
mut=os.path.join(os.path.dirname(os.path.abspath(__file__)),'mut/pm/')
cases=[
 ('M1 extend_ultra без IsClosed A','Subit/ExtendUltra.lean','(hA : IsClosed A)\n','','Subit.ExtendUltra'),
]
for name,f,old,new,mod in cases:
    src=open(base+f,encoding='utf-8').read()
    shutil.copy(base+f, mut+f)
    cnt=src.count(old)
    if cnt!=1:
        print(name,'PATTERN COUNT',cnt); continue
    open(mut+f,'w',encoding='utf-8').write(src.replace(old,new))
    r=subprocess.run(['lake','build',mod],cwd=mut,capture_output=True,text=True,env=os.environ)
    errs=[l for l in (r.stdout+r.stderr).splitlines() if 'error' in l]
    print(name,'-> exit',r.returncode,'| errors:',len(errs))
    for l in errs[:2]: print('   ',l[:200])
    shutil.copy(base+f, mut+f)
