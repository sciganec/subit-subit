import Subit
#print axioms Subit.A4_fintype
#print axioms Subit.chi_not_dynmor_8_5
#print axioms Subit.belnap_truth_matches_spec
#print axioms Subit.belnap_info_matches_spec
