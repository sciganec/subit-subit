import Subit.Tree
import Subit.TreeUltra
import Mathlib.Tactic.FinCases
import Subit.FullShift
import Subit.LemmaE
import Subit.W8Entropy
/-!
# W8, крок T1: «хребет» t : {α,β}^ℕ → Tree (§9.5 специфікації)

Позиції (Fin 3, у Lean 0,1,2 відповідають специфікаційним 1,2,3):
* 0^k              — node (хребет);
* 0^k·1 (довжина k+1) — leaf (a k)   [специфікаційне 1^k·2];
* 0^k·2 (довжина k+1) — leaf η       [специфікаційне 1^k·3];
* інше             — none.

Доведено: `spine a η` задовольняє (T1)–(T4), тобто є елементом Tree.
-/
namespace Subit.W8Spine
open Subit

variable {A : Type*}

/-- Чи всі координати σ нульові (тобто σ = 0^k). -/
def zeros (σ : List (Fin 3)) : Bool := σ.all (fun i => i == 0)

def spine (a : ℕ → A) (η : A) : Pos → Lab A := fun σ =>
  if zeros σ then .node
  else if zeros σ.dropLast && σ.getLast? == some 1 then .leaf (a (σ.length - 1))
  else if zeros σ.dropLast && σ.getLast? == some 2 then .leaf η
  else .none

theorem zeros_append_single (σ : List (Fin 3)) (i : Fin 3) :
    zeros (σ ++ [i]) = (zeros σ && (i == 0)) := by
  simp [zeros, List.all_append]

/-- Якщо ρ ++ [i] має мітку ≠ none, то ρ — вузол. -/
theorem node_of_ne_none (a : ℕ → A) (η : A) (ρ : List (Fin 3)) (i : Fin 3)
    (h : spine a η (ρ ++ [i]) ≠ .none) : spine a η ρ = .node := by
  by_cases hz : zeros ρ = true
  · simp [spine, hz]
  · exfalso
    apply h
    simp [spine, zeros_append_single, List.dropLast_concat, hz]

/-- Листок має σ з ¬zeros σ; тоді всі дочірні позиції — none. -/
theorem none_of_not_zeros (a : ℕ → A) (η : A) (σ : List (Fin 3)) (i : Fin 3)
    (hσ : zeros σ = false) : spine a η (σ ++ [i]) = .none := by
  simp [spine, zeros_append_single, List.dropLast_concat, hσ]

theorem zeros_of_node (a : ℕ → A) (η : A) (σ : List (Fin 3))
    (h : spine a η σ = .node) : zeros σ = true := by
  by_contra hz
  simp only [Bool.not_eq_true] at hz
  unfold spine at h
  simp [hz] at h
  split_ifs at h <;> simp_all

theorem spine_isTree (a : ℕ → A) (η : A) : IsTree (spine a η) where
  t1 := by simp [spine, zeros]
  t2 := by
    intro σ hσ i
    have hz := zeros_of_node a η σ hσ
    fin_cases i <;> simp [spine, zeros_append_single, List.dropLast_concat,
      List.getLast?_concat, hz]
  t3 := by
    intro σ b hσ i
    have hz : zeros σ = false := by
      cases hzz : zeros σ
      · rfl
      · exfalso
        unfold spine at hσ
        simp [hzz] at hσ
    exact none_of_not_zeros a η σ i hz
  t4 := by
    have key : ∀ (τ : List (Fin 3)) (σ : List (Fin 3)),
        spine a η (σ ++ τ) ≠ .none → spine a η σ ≠ .none := by
      intro τ
      induction τ with
      | nil => intro σ h; simpa using h
      | cons i τ ih =>
        intro σ h
        have h1 : spine a η (σ ++ [i]) ≠ .none :=
          ih (σ ++ [i]) (by simpa [List.append_assoc] using h)
        rw [node_of_ne_none a η σ i h1]
        simp
    intro σ hσ τ
    by_contra hne
    exact key τ σ hne hσ


/-- Розбіжність хребтів: якщо f σ ≠ g σ, то σ — листок-позиція довжини ≥ k+1, де k — перший
індекс розбіжності a, b. -/
theorem length_of_diff (a b : ℕ → A) (η : A) (k : ℕ) (hk : ∀ j < k, a j = b j)
    (σ : List (Fin 3)) (hσ : spine a η σ ≠ spine b η σ) : k + 1 ≤ σ.length := by
  unfold spine at hσ
  by_cases hz : zeros σ = true
  · exfalso; simp [hz] at hσ
  · simp only [Bool.not_eq_true] at hz
    by_cases h1 : (zeros σ.dropLast && σ.getLast? == some 1) = true
    · simp only [h1, if_true] at hσ
      -- тут a (len-1) ≠ b (len-1), тож len-1 ≥ k
      have hne : a (σ.length - 1) ≠ b (σ.length - 1) := by
        intro h; apply hσ; simp [h]
      have hkle : k ≤ σ.length - 1 := by
        by_contra hlt
        exact hne (hk _ (by omega))
      have hpos : 0 < σ.length := by
        rcases Nat.eq_zero_or_pos σ.length with h0 | h0
        · exfalso
          have : σ = [] := List.length_eq_zero_iff.1 h0
          subst this
          simp [zeros] at hz
        · exact h0
      omega
    · by_cases h2 : (zeros σ.dropLast && σ.getLast? == some 2) = true
      · simp only [h1, h2, if_true, Bool.false_eq_true, if_false] at hσ
        exact absurd rfl hσ
      · exfalso
        simp only [h1, h2, Bool.false_eq_true, if_false] at hσ
        exact hσ rfl

/-- Точка розбіжності: σ_k := 0^k·1 (довжина k+1). -/
theorem diff_at (a b : ℕ → A) (η : A) (k : ℕ) (hkne : a k ≠ b k) :
    spine a η (List.replicate k 0 ++ [1]) ≠ spine b η (List.replicate k 0 ++ [1]) := by
  have hz : zeros (List.replicate k 0) = true := by unfold zeros; simp
  have hd : (List.replicate k 0 ++ [1]).dropLast = List.replicate k 0 := by simp
  have hl : (List.replicate k 0 ++ [1]).getLast? = some 1 := by simp
  have hlen : (List.replicate k 0 ++ [1]).length - 1 = k := by simp
  simp [spine, zeros_append_single, hz, List.dropLast_concat, List.getLast?_concat, hkne]

/-- Розбіжність хребтів у першому індексі k дає dS = (1/2)^(k+1). -/
theorem dS_spine (a b : ℕ → A) (η : A) (k : ℕ) (hk : ∀ j < k, a j = b j) (hkne : a k ≠ b k) :
    Subit.dS (spine a η) (spine b η) = (1 / 2 : ℝ) ^ (k + 1) := by
  have hdiff := diff_at a b η k hkne
  haveI : Nonempty {σ : List (Fin 3) // spine a η σ ≠ spine b η σ} := ⟨⟨_, hdiff⟩⟩
  unfold Subit.dS
  apply le_antisymm
  · apply ciSup_le
    rintro ⟨σ, hσ⟩
    apply pow_le_pow_of_le_one (by norm_num) (by norm_num)
    exact length_of_diff a b η k hk σ hσ
  · have hb : BddAbove (Set.range fun σ : {σ : Pos // spine a η σ ≠ spine b η σ} =>
        (1 / 2 : ℝ) ^ σ.1.length) :=
      ⟨1, by rintro _ ⟨σ, rfl⟩; exact pow_le_one₀ (by norm_num) (by norm_num)⟩
    have key := le_ciSup hb (⟨List.replicate k 0 ++ [1], hdiff⟩ :
      {σ : Pos // spine a η σ ≠ spine b η σ})
    simpa using key


/-- Кодування бітової послідовності літерами α/β. -/
def enc (α β : A) (x : ℕ → Bool) : ℕ → A := fun j => if x j then α else β

/-- Хребет послідовності x ∈ {α,β}^ℕ як елемент Tree∞ (спецификація 9.5). -/
def tM (α β η : A) (x : ℕ → Bool) : TreeM A :=
  (Subtype.mk (spine (enc α β x) η) (spine_isTree (enc α β x) η) : Tree A)

/-- d_S(t(x), t(y)) = d_C(x, y)/2: відстань хребта — половина відстані зсуву. -/
theorem dist_tM (α β η : A) (hαβ : α ≠ β) (x y : ℕ → Bool) :
    dist (tM α β η x) (tM α β η y) = Subit.dC x y / 2 := by
  by_cases hxy : x = y
  · subst hxy
    have h0 : Subit.dC x x = 0 := by
      unfold Subit.dC
      rw [dif_neg]
      push_neg
      intro n; rfl
    rw [h0, dist_self]; norm_num
  · have hex : ∃ n, x n ≠ y n := by
      by_contra h
      push_neg at h
      exact hxy (funext h)
    set k := Nat.find hex with hkdef
    have hk : ∀ j < k, enc α β x j = enc α β y j := by
      intro j hj
      have := Nat.find_min hex hj
      push_neg at this
      simp [enc, this]
    have hkne : enc α β x k ≠ enc α β y k := by
      have := Nat.find_spec hex
      unfold enc
      cases hx : x k <;> cases hy : y k <;> simp_all [Ne.symm hαβ]
    have hd : dist (tM α β η x) (tM α β η y) = (1 / 2 : ℝ) ^ (k + 1) := by
      show Subit.dS (spine (enc α β x) η) (spine (enc α β y) η) = _
      exact dS_spine _ _ η k hk hkne
    have hC : Subit.dC x y = (1 / 2 : ℝ) ^ k := by
      unfold Subit.dC
      rw [dif_pos hex]
    rw [hd, hC]
    ring


/-- Оцінка: якщо x, y збігаються на j < k, то d_S(t x, t y) ≤ 2^{-(k+1)}. -/
theorem dist_tM_le (α β η : A) (hαβ : α ≠ β) (x y : ℕ → Bool) (k : ℕ)
    (h : ∀ j < k, x j = y j) : dist (tM α β η x) (tM α β η y) ≤ (1 / 2 : ℝ) ^ (k + 1) := by
  rw [dist_tM α β η hαβ x y]
  have := Subit.dC_le x y k h
  rw [pow_succ]
  linarith

/-- t неперервне (з топологією добутку на {α,β}^ℕ). -/
theorem tM_continuous (α β η : A) (hαβ : α ≠ β) : Continuous (tM α β η) := by
  refine continuous_iff_continuousAt.2 fun x => ?_
  refine Metric.tendsto_nhds.2 fun ε hε => ?_
  obtain ⟨n, hn⟩ := exists_pow_lt_of_lt_one hε (show (1 / 2 : ℝ) < 1 by norm_num)
  have hev : ∀ᶠ y in nhds x, ∀ j ∈ Finset.range n, y j = x j := by
    rw [Filter.eventually_all_finset]
    intro j _
    have h1 := ((continuous_apply j).tendsto x).eventually
      ((isOpen_discrete ({x j} : Set Bool)).mem_nhds (Set.mem_singleton _))
    filter_upwards [h1] with y hy
    exact hy
  filter_upwards [hev] with y hy
  have hlt : ∀ j < n, y j = x j := fun j hj => hy j (Finset.mem_range.2 hj)
  refine lt_of_le_of_lt (dist_tM_le α β η hαβ y x n hlt) ?_
  calc (1 / 2 : ℝ) ^ (n + 1) ≤ (1 / 2 : ℝ) ^ n :=
        pow_le_pow_of_le_one (by norm_num) (by norm_num) (Nat.le_succ n)
    _ < ε := hn

/-- t ін'єктивне. -/
theorem tM_injective (α β η : A) (hαβ : α ≠ β) : Function.Injective (tM α β η) := by
  intro x y hxy
  have h0 : dist (tM α β η x) (tM α β η y) = 0 := by rw [hxy, dist_self]
  rw [dist_tM α β η hαβ] at h0
  by_contra hne
  have hpos : 0 < Subit.dC x y := by
    have hex : ∃ n, x n ≠ y n := by
      by_contra h
      push_neg at h
      exact hne (funext h)
    unfold Subit.dC
    rw [dif_pos hex]
    positivity
  linarith


/-- Образ хребта Y := t[{α,β}^ℕ]; компактний. -/
theorem Y_isCompact (α β η : A) (hαβ : α ≠ β) : IsCompact (Set.range (tM α β η)) :=
  isCompact_range (tM_continuous α β η hαβ)

/-- Гомеоморфізм {α,β}^ℕ ≃ₜ Y := t[{α,β}^ℕ]. -/
noncomputable def tHomeo (α β η : A) (hαβ : α ≠ β) :
    (ℕ → Bool) ≃ₜ Set.range (tM α β η) := by
  let g : (ℕ → Bool) → Set.range (tM α β η) := fun x => ⟨tM α β η x, x, rfl⟩
  have hg : Continuous g := (tM_continuous α β η hαβ).subtype_mk _
  have hbij : Function.Bijective g := by
    refine ⟨fun x y h => tM_injective α β η hαβ (congrArg Subtype.val h), ?_⟩
    rintro ⟨y, x, hx⟩
    exact ⟨x, Subtype.ext hx⟩
  exact Continuous.homeoOfEquivCompactToT2 (f := Equiv.ofBijective g hbij) hg

theorem tHomeo_apply (α β η : A) (hαβ : α ≠ β) (x : ℕ → Bool) :
    (tHomeo α β η hαβ x : TreeM A) = tM α β η x := rfl

/-- Спряжений зсув на Y: T := t ∘ σ ∘ t⁻¹. -/
noncomputable def TY (α β η : A) (hαβ : α ≠ β) :
    Set.range (tM α β η) → Set.range (tM α β η) :=
  fun y => tHomeo α β η hαβ (Subit.shift ((tHomeo α β η hαβ).symm y))

theorem TY_continuous (α β η : A) (hαβ : α ≠ β) : Continuous (TY α β η hαβ) :=
  (tHomeo α β η hαβ).continuous.comp
    (Subit.W8Entropy.continuous_shift.comp (tHomeo α β η hαβ).symm.continuous)

theorem conj_TY (α β η : A) (hαβ : α ≠ β) (x : ℕ → Bool) :
    tHomeo α β η hαβ (Subit.shift x) = TY α β η hαβ (tHomeo α β η hαβ x) := by
  unfold TY
  rw [Homeomorph.symm_apply_apply]

end Subit.W8Spine
