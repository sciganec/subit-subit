import Subit.W8Tree
import Subit.W8GAttained
import Subit.W8GEntropy

/-!
# W8 на Tree∞ з довільними блоками n_k (G-варіант W8Tree)

Той самий шлях, що й `W8Tree`, але d := `W8G.dG n` з `hn : ∀ k, k+1 ≤ n k`
(нескінченність потребує `hmono : StrictMono n`; ATTAINED, NONMIN і h_top — лише `hn`).

* `attained_TY`, `omega_TY`, `sepNum_scale`, `htop_scale` — генеричні, з `Subit.W8Tree`.
* `infinite_TY`, `nonmin_TY`, `htop_TY_zero` — G-варіанти з d = dG n.
* `w8G_tree_summary` — підсумок на Y і на графі G.
-/

noncomputable section
namespace Subit.W8GTree
open Filter Set Topology Subit Subit.LemmaEY Subit.W8Spine Subit.OmegaGraph Subit.W8Tree

section Y

variable {A : Type*} [Finite A]

theorem infinite_TY (α β η : A) (hαβ : α ≠ β) (d : ℕ → Bool) (hinf : (omega shift d).Infinite) :
    (omega (TY α β η hαβ) (tHomeo α β η hαβ d)).Infinite := by
  rw [omega_TY]
  exact hinf.image (fun a _ b _ h => (tHomeo α β η hαβ).injective h)

theorem nonmin_TY (α β η : A) (hαβ : α ≠ β) (d : ℕ → Bool)
    (hnm : ¬ MinOn shift (omega shift d)) :
    ¬ MinOn (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ d)) := by
  intro hM
  apply hnm
  have h : ∀ y, (tHomeo α β η hαβ).symm (TY α β η hαβ y) =
      shift ((tHomeo α β η hαβ).symm y) := by
    intro y
    unfold TY
    simp
  have := minOn_conj (tHomeo α β η hαβ).symm (TY α β η hαβ) shift h _ hM
  rw [omega_TY, Set.image_image] at this
  simpa using this

theorem htop_TY_zero (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (α β η : A) (hαβ : α ≠ β) :
    htopOn (fun a b : Set.range (tM α β η) => dist a.1 b.1) (TY α β η hαβ)
      (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) (fun y hy =>
        omega_forward _ (TY_continuous α β η hαβ) _ ⟨y, hy, rfl⟩) = 0 := by
  set ωs := omega shift (W8G.dG n) with hωs
  set W := omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)) with hW
  have hWmaps : Set.MapsTo (TY α β η hαβ) W W := fun y hy =>
    omega_forward _ (TY_continuous α β η hαβ) _ ⟨y, hy, rfl⟩
  have hωmaps : Set.MapsTo (shift : (ℕ → Bool) → (ℕ → Bool)) ωs ωs :=
    fun y hy => omega_forward _ W8Entropy.continuous_shift _ ⟨y, hy, rfl⟩
  have hiff : ∀ a : ℕ → Bool, a ∈ ωs ↔ tHomeo α β η hαβ a ∈ W := by
    intro a
    rw [hW, omega_TY]
    exact (tHomeo α β η hαβ).injective.mem_set_image.symm
  let e : {a // a ∈ ωs} ≃ {b // b ∈ W} :=
    Equiv.subtypeEquiv (tHomeo α β η hαβ).toEquiv hiff
  have hiso : ∀ a b : {a // a ∈ ωs},
      (1 / 2 : ℝ) * Subit.dC a.1 b.1 = dist (e a).1.1 (e b).1.1 := by
    intro a b
    show (1 / 2 : ℝ) * Subit.dC a.1 b.1 = dist (tM α β η a.1) (tM α β η b.1)
    rw [dist_tM α β η hαβ]
    ring
  have hc : ∀ a : {a // a ∈ ωs}, e (⟨shift a.1, hωmaps a.2⟩ : {a // a ∈ ωs}) =
      (⟨TY α β η hαβ (e a).1, hWmaps (e a).2⟩ : {b // b ∈ W}) := by
    intro a
    apply Subtype.ext
    show tHomeo α β η hαβ (shift a.1) = TY α β η hαβ (tHomeo α β η hαβ a.1)
    exact conj_TY α β η hαβ a.1
  have hsep : ∀ (m : ℕ) (ε : ℝ),
      sepNum (fun a b : {a // a ∈ ωs} => (1 / 2 : ℝ) * Subit.dC a.1 b.1)
        (restrict shift ωs hωmaps) m ε =
      sepNum (fun a b : {b // b ∈ W} => dist a.1 b.1) (restrict (TY α β η hαβ) W hWmaps) m ε := by
    intro m ε
    exact sepNum_iso _ _ _ _ e hiso hc m ε
  have hEq : htop (fun a b : {a // a ∈ ωs} => (1 / 2 : ℝ) * Subit.dC a.1 b.1)
      (restrict shift ωs hωmaps) =
      htop (fun a b : {b // b ∈ W} => dist a.1 b.1) (restrict (TY α β η hαβ) W hWmaps) := by
    unfold htop
    simp only [hsep]
  show htop (fun a b : {b // b ∈ W} => dist a.1 b.1) (restrict (TY α β η hαβ) W hWmaps) = 0
  rw [← hEq]
  refine (htop_scale (1 / 2) (by norm_num) (fun a b : {a // a ∈ ωs} => Subit.dC a.1 b.1)
    (restrict shift ωs hωmaps)).trans ?_
  exact W8GEntropy.htop_omega_zero_G n hn

end Y

section Graph

variable {A : Type*} [Finite A]

theorem image_omegaG (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ)
        (TY_continuous α β η hαβ) '' omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) =
      omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)) := by
  have hconj := omega_conj
    (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))
    (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (TY α β η hαβ)
    (conj_graph (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ)
      (TY_continuous α β η hαβ) x0)
    (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))
  rw [graphHomeoY_gphPt] at hconj
  exact hconj

theorem mem_omegaG_iff (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A)
    (a : Gph (Set.range (tM α β η)) (TY α β η hαβ)) :
    a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) ↔
      graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) a ∈
        omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)) := by
  rw [← image_omegaG n hn α β η hαβ x0]
  constructor
  · intro h
    exact ⟨a, h, rfl⟩
  · rintro ⟨b, hb, hb'⟩
    rw [(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).injective hb'] at hb
    exact hb

theorem attained_graph (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)) ∈
      omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) := by
  rw [mem_omegaG_iff n hn α β η hαβ x0, graphHomeoY_gphPt]
  exact attained_TY α β η hαβ (W8G.dG n) (W8GAttained.attained_G n hn)

theorem infinite_graph (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (hmono : StrictMono n)
    (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))).Infinite := by
  apply Set.Infinite.of_image (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ)
    (TY α β η hαβ) (TY_continuous α β η hαβ))
  rw [image_omegaG n hn α β η hαβ x0]
  exact infinite_TY α β η hαβ (W8G.dG n) (W8GAttained.omega_infinite_G n hn hmono)

theorem w8_graph_zero (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    htopOn (fun a b : Gph (Set.range (tM α β η)) (TY α β η hαβ) => dist a.1 b.1)
      (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))))
      (fun y hy => omega_forward _ (Subit.OmegaGraph.DpY_continuous (Set.range (tM α β η))
        (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) x0) _ ⟨y, hy, rfl⟩) = 0 := by
  have hY := Y_isCompact α β η hαβ
  haveI : CompactSpace (Set.range (tM α β η)) := isCompact_iff_compactSpace.1 hY
  have hT := TY_continuous α β η hαβ
  have hiffG : ∀ a : Gph (Set.range (tM α β η)) (TY α β η hαβ),
      a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
          (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) ↔
      graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT a ∈
        omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)) := by
    intro a
    have hconj := omega_conj (graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT)
      (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (TY α β η hαβ)
      (conj_graph (Set.range (tM α β η)) hY (TY α β η hαβ) hT x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))
    rw [graphHomeoY_gphPt] at hconj
    rw [← hconj]
    constructor
    · intro h
      exact ⟨a, h, rfl⟩
    · rintro ⟨b, hb, hb'⟩
      rw [(graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT).injective hb'] at hb
      exact hb
  let eG : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))} ≃
      {b // b ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))} :=
    Equiv.subtypeEquiv (graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT).toEquiv hiffG
  have hWc : IsCompact (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) := omega_isCompact _ _
  obtain ⟨w0, hw0⟩ := omega_nonempty (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))
  haveI : Nonempty {b // b ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))} := ⟨⟨w0, hw0⟩⟩
  haveI : CompactSpace {b // b ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))} :=
    isCompact_iff_compactSpace.1 hWc
  have hωmaps : Set.MapsTo (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))))
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))) := fun y hy =>
    omega_forward _ (Subit.OmegaGraph.DpY_continuous (Set.range (tM α β η)) hY
      (TY α β η hαβ) hT x0) _ ⟨y, hy, rfl⟩
  have hWmaps : Set.MapsTo (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))
      (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) := fun y hy =>
    omega_forward _ hT _ ⟨y, hy, rfl⟩
  have hiso : ∀ a b : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))},
      dist a.1.1 b.1.1 = dmaxT (restrict (TY α β η hαβ)
        (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) hWmaps) (eG a) (eG b) := by
    intro a b
    exact Subit.OmegaGraph.dist_Gph_eq (Set.range (tM α β η)) hY (TY α β η hαβ) hT a.1 b.1
  have hc : ∀ a : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))},
      eG (restrict (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) _ hωmaps a) =
        restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) hWmaps (eG a) := by
    intro a
    apply Subtype.ext
    exact Subit.LemmaEY.conj_graph (Set.range (tM α β η)) hY (TY α β η hαβ) hT x0 a.1
  have hsep : ∀ (m : ℕ) (ε : ℝ),
      sepNum (fun a b : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
          (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))} => dist a.1.1 b.1.1)
        (restrict (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) _ hωmaps) m ε =
      sepNum (dmaxT (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) hWmaps))
        (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) hWmaps) m ε := by
    intro m ε
    exact sepNum_iso _ _ _ _ eG hiso hc m ε
  have hmax := htop_eq_of_maxT isCompact_univ.totallyBounded
    (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) hWmaps)
  have hEq : htop (fun a b : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))} => dist a.1.1 b.1.1)
      (restrict (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) _ hωmaps) =
      htop (dmaxT (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) hWmaps))
        (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) hWmaps) := by
    unfold htop
    simp only [hsep]
  exact (hEq.trans hmax).trans (htop_TY_zero n hn α β η hαβ)

theorem minOn_TY_of_graph (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A)
    (hM : MinOn (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))))) :
    MinOn (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) := by
  intro V' hV'W hV'ne hV'cl hV'inv
  have hVW : (⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V' ⊆ (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))) := by
    intro a ha
    rw [mem_omegaG_iff n hn α β η hαβ x0]
    exact hV'W ha
  have hVne : ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V').Nonempty := by
    obtain ⟨y, hy⟩ := hV'ne
    exact ⟨(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).symm y, by simpa using hy⟩
  have hVcl : IsClosed ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') := hV'cl.preimage (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).continuous
  have hVmaps : Set.MapsTo (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') := by
    intro a ha
    have hc := conj_graph (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) x0 a
    show (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)) ((DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) a) ∈ V'
    rw [hc]
    exact hV'inv ha
  have hVeq := hM ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') hVW hVne hVcl hVmaps
  apply Set.Subset.antisymm hV'W
  intro y hy
  have ha : (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).symm y ∈ (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))) := by
    rw [mem_omegaG_iff n hn α β η hαβ x0]
    simpa using hy
  rw [← hVeq] at ha
  simpa using ha

theorem nonmin_graph (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    ¬ MinOn (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))) :=
  fun hM => nonmin_TY α β η hαβ (W8G.dG n) (W8GAttained.nonmin_G n hn)
    (minOn_TY_of_graph n hn α β η hαβ x0 hM)

end Graph

/-- Підсумок W8 з довільними блоками на Tree∞ (рівень Y і графа G). -/
theorem w8G_tree_summary (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (hmono : StrictMono n)
    (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    tHomeo α β η hαβ (W8G.dG n) ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)) ∧
    (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))).Infinite ∧
    gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)) ∈
      omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) ∧
    (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))).Infinite ∧
    ¬ MinOn (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))) ∧
    ¬ MinOn (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n)))) ∧
    htopOn (fun a b : Gph (Set.range (tM α β η)) (TY α β η hαβ) => dist a.1 b.1)
      (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ (W8G.dG n))))
      (fun y hy => omega_forward _ (Subit.OmegaGraph.DpY_continuous (Set.range (tM α β η))
        (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) x0) _ ⟨y, hy, rfl⟩) = 0 :=
  ⟨attained_TY α β η hαβ (W8G.dG n) (W8GAttained.attained_G n hn),
   infinite_TY α β η hαβ (W8G.dG n) (W8GAttained.omega_infinite_G n hn hmono),
   attained_graph n hn α β η hαβ x0,
   infinite_graph n hn hmono α β η hαβ x0,
   nonmin_TY α β η hαβ (W8G.dG n) (W8GAttained.nonmin_G n hn),
   nonmin_graph n hn α β η hαβ x0,
   w8_graph_zero n hn α β η hαβ x0⟩

end Subit.W8GTree
end
