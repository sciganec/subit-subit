import Subit.W6Word

/-!
# W7, абстрактний шар: ω-границя слова d з трьома властивостями

Для довільного d : ℕ → Bool (α = `true`, β = `false`) нехай

* `hgap`: ββ-входження, що починаються пізно, розташовані далі одне від одного, ніж будь-яке фіксоване L;
* `hinf`: ββ-входження нескінченно багато (для кожного n є пара ββ-входжень, починаються ≥ n);
* `hpat`: кожне слово без ββ (`noBB`) з'являється в d на довільно великих позиціях.

Тоді доведено (без конкретної побудови d зі спеціфікації):
* `X_sub_omega`: X_W := {x : noBB x} ⊆ ω(d);
* `omega_le_one`: кожна точка ω(d) має не більше одного ββ-входження;
* `omega_nonattained`: σⁿd ∉ ω(d) для всіх n;
* `omega_infinite`: ω(d) нескінченна;
* `not_minOn_gen`: ω(d) не мінімальна.

Конкретне d зі спеціфікації (блоки α u_m ... ) перевіряється окремо (`W7Word.lean`).
-/

noncomputable section
namespace Subit.W7A
open Filter Topology Classical

/-- Слово без ββ: ніколи не буває двох β поспіль. -/
def noBB (x : Seq) : Prop := ∀ a, ¬ (x a = false ∧ x (a + 1) = false)

theorem omega_window_gen (d : ℕ → Bool) {y : Seq} (hy : y ∈ Subit.omega shift d) (L N : ℕ) :
    ∃ n, N ≤ n ∧ ∀ j < L, d (n + j) = y j := by
  have hcl : y ∈ closure (Set.range fun k => iter shift (N + k) d) :=
    Set.mem_iInter.1 hy N
  obtain ⟨z, hz, hzs⟩ := (mem_closure_iff.1 hcl) _ (Subit.W6.cyl_open y L) (fun j _ => rfl)
  obtain ⟨k, rfl⟩ := hzs
  refine ⟨N + k, by omega, fun j hj => ?_⟩
  have hzj : iter shift (N + k) d j = y j := hz j hj
  rw [iter_shift] at hzj
  rw [Nat.add_comm (N + k) j]
  exact hzj

/-- Два ββ-входження в одній точці ω(d) неможливі (через `hgap`). -/
theorem omega_le_one (d : ℕ → Bool)
    (hgap : ∀ L : ℕ, ∃ P : ℕ, ∀ a b : ℕ, P ≤ a → a < b → d a = false → d (a + 1) = false →
      d b = false → d (b + 1) = false → L < b - a)
    {y : Seq} (hy : y ∈ Subit.omega shift d) {a b : ℕ} (hab : a < b)
    (ha : y a = false) (ha1 : y (a + 1) = false) (hb : y b = false) (hb1 : y (b + 1) = false) :
    False := by
  obtain ⟨P, hP⟩ := hgap (b + 2)
  obtain ⟨p, hpN, hwin⟩ := omega_window_gen d hy (b + 2) P
  have e : ∀ j, j < b + 2 → d (p + j) = y j := fun j hj => hwin j hj
  have h1 := hP (p + a) (p + b) (by omega) (by omega)
    (by rw [e a (by omega)]; exact ha)
    (by rw [show p + a + 1 = p + (a + 1) by omega, e (a + 1) (by omega)]; exact ha1)
    (by rw [e b (by omega)]; exact hb)
    (by rw [show p + b + 1 = p + (b + 1) by omega, e (b + 1) (by omega)]; exact hb1)
  omega

/-- Точки ω(d) не мають двох ββ-входжень (загальна форма). -/
theorem omega_atmost_one_bb (d : ℕ → Bool)
    (hgap : ∀ L : ℕ, ∃ P : ℕ, ∀ a b : ℕ, P ≤ a → a < b → d a = false → d (a + 1) = false →
      d b = false → d (b + 1) = false → L < b - a)
    {y : Seq} (hy : y ∈ Subit.omega shift d) :
    ∀ a b, a < b → ¬ (y a = false ∧ y (a + 1) = false ∧ y b = false ∧ y (b + 1) = false) := by
  rintro a b hab ⟨ha, ha1, hb, hb1⟩
  exact omega_le_one d hgap hy hab ha ha1 hb hb1

/-- NONATTAINED для всіх n: σⁿd ∉ ω(d). -/
theorem omega_nonattained (d : ℕ → Bool)
    (hgap : ∀ L : ℕ, ∃ P : ℕ, ∀ a b : ℕ, P ≤ a → a < b → d a = false → d (a + 1) = false →
      d b = false → d (b + 1) = false → L < b - a)
    (hinf : ∀ n : ℕ, ∃ a b : ℕ, n ≤ a ∧ a < b ∧ d a = false ∧ d (a + 1) = false ∧
      d b = false ∧ d (b + 1) = false)
    (n : ℕ) : iter shift n d ∉ Subit.omega shift d := by
  intro hy
  obtain ⟨a, b, hna, hab, ha, ha1, hb, hb1⟩ := hinf n
  have key : ∀ j, iter shift n d j = d (j + n) := fun j => by rw [iter_shift]
  apply omega_le_one d hgap hy (show a - n < b - n by omega)
  · rw [key, show a - n + n = a by omega]; exact ha
  · rw [key, show a - n + 1 + n = a + 1 by omega]; exact ha1
  · rw [key, show b - n + n = b by omega]; exact hb
  · rw [key, show b - n + 1 + n = b + 1 by omega]; exact hb1

/-- X_W ⊆ ω(d): кожне ββ-вільне x з'являється в d на довільно великих позиціях. -/
theorem X_sub_omega (d : ℕ → Bool)
    (hpat : ∀ x : Seq, noBB x → ∀ L N : ℕ, ∃ p, N ≤ p ∧ ∀ j < L, d (p + j) = x j)
    {x : Seq} (hx : noBB x) : x ∈ Subit.omega shift d := by
  refine Set.mem_iInter.2 fun N => ?_
  refine Subit.W6.mem_closure_of_cyl fun L => ?_
  obtain ⟨p, hN, hwin⟩ := hpat x hx L N
  refine ⟨iter shift p d, ⟨p - N, ?_⟩, ?_⟩
  · show iter shift (N + (p - N)) d = iter shift p d
    rw [Nat.add_sub_of_le hN]
  · intro j hj
    rw [iter_shift]
    show d (j + p) = x j
    rw [Nat.add_comm]
    exact hwin j hj

theorem noBB_point (k : ℕ) : noBB (fun j : ℕ => decide (j ≠ k)) := by
  rintro a ⟨h1, h2⟩
  simp at h1 h2
  omega

/-- ω(d) нескінченна: точки αᵏβα^∞ (одне β) лежать в X_W ⊆ ω(d). -/
theorem omega_infinite (d : ℕ → Bool)
    (hpat : ∀ x : Seq, noBB x → ∀ L N : ℕ, ∃ p, N ≤ p ∧ ∀ j < L, d (p + j) = x j) :
    (Subit.omega shift d).Infinite := by
  refine Set.infinite_of_injective_forall_mem
    (f := fun k : ℕ => fun j : ℕ => decide (j ≠ k)) ?_ ?_
  · intro k1 k2 h
    by_contra hne
    have := congrFun h k1
    simp [hne] at this
  · intro k
    exact X_sub_omega d hpat (noBB_point k)

/-- ω(d) не мінімальна: α^∞ — власна замкнена інваріантна непорожня підмножина. -/
theorem not_minOn_gen (d : ℕ → Bool)
    (hpat : ∀ x : Seq, noBB x → ∀ L N : ℕ, ∃ p, N ≤ p ∧ ∀ j < L, d (p + j) = x j) :
    ¬ MinOn shift (Subit.omega shift d) := by
  intro hmin
  have hsub : Subit.W6.allT ⊆ Subit.omega shift d := by
    intro x hx
    refine X_sub_omega d hpat ?_
    intro a
    rintro ⟨h1, _⟩
    have h2 : x a = true := hx a
    rw [h2] at h1
    exact absurd h1 (by decide)
  have hne : Subit.W6.allT.Nonempty := ⟨fun _ => true, fun _ => rfl⟩
  have hmap : Set.MapsTo shift Subit.W6.allT Subit.W6.allT := by
    intro x hx
    simp only [Subit.W6.allT, Set.mem_setOf_eq, shift] at hx ⊢
    exact fun j => hx (j + 1)
  have heq := hmin Subit.W6.allT hsub hne Subit.W6.allT_closed hmap
  have hf0 : (fun j : ℕ => decide (j ≠ 0)) ∈ Subit.omega shift d :=
    X_sub_omega d hpat (noBB_point 0)
  rw [← heq] at hf0
  simp only [Subit.W6.allT, Set.mem_setOf_eq] at hf0
  have := hf0 0
  simp at this


/-- Кодування: блок i (довжина 2) — αα, якщо s i = false, і βα, якщо s i = true; далі α^∞. -/
def phi (n : ℕ) (s : Fin n → Bool) : Seq := fun j =>
  if h : j / 2 < n then (if j % 2 = 0 then !(s ⟨j / 2, h⟩) else true) else true

theorem phi_even (n : ℕ) (s : Fin n → Bool) (i : Fin n) :
    phi n s (2 * (i : ℕ)) = !(s i) := by
  have h : 2 * (i : ℕ) / 2 < n := by rw [Nat.mul_div_cancel_left _ (by norm_num)]; exact i.isLt
  have e : (⟨2 * (i : ℕ) / 2, h⟩ : Fin n) = i := Fin.ext (Nat.mul_div_cancel_left _ (by norm_num))
  unfold phi
  rw [dif_pos h, if_pos (Nat.mul_mod_right 2 _), e]

theorem phi_odd (n : ℕ) (s : Fin n → Bool) (i : Fin n) :
    phi n s (2 * (i : ℕ) + 1) = true := by
  have hi := i.isLt
  have h : (2 * (i : ℕ) + 1) / 2 < n := by omega
  unfold phi
  rw [dif_pos h, if_neg (by omega)]

theorem phi_false_even (n : ℕ) (s : Fin n → Bool) (a : ℕ) (h : phi n s a = false) :
    a % 2 = 0 := by
  by_contra hc
  unfold phi at h
  by_cases h1 : a / 2 < n
  · rw [dif_pos h1, if_neg hc] at h
    exact absurd h (by decide)
  · rw [dif_neg h1] at h
    exact absurd h (by decide)

theorem noBB_phi (n : ℕ) (s : Fin n → Bool) : noBB (phi n s) := by
  rintro a ⟨h1, h2⟩
  have e1 := phi_false_even n s a h1
  have e2 := phi_false_even n s (a + 1) h2
  omega

theorem phi_inj (n : ℕ) (s t : Fin n → Bool) (h : phi n s = phi n t) : s = t := by
  funext i
  have := congrFun h (2 * (i : ℕ))
  rw [phi_even, phi_even] at this
  simpa using this

/-- Розділена множина в ω має не більше 2^m точок (відображення в повний зсув). -/
theorem card_sep_le_sub (W : Set Seq) (hW : Set.MapsTo shift W W) (m : ℕ)
    (S : Finset ↥W)
    (hS : IsSep (fun a b : ↥W => Subit.dC a.1 b.1) (Subit.restrict shift W hW) m (3 / 4) S) :
    S.card ≤ 2 ^ m := by
  have hS' : IsSep Subit.dC shift m (3 / 4) (S.image Subtype.val) := by
    intro x hx y hy hxy
    obtain ⟨a, ha, rfl⟩ := Finset.mem_image.1 hx
    obtain ⟨b, hb, rfl⟩ := Finset.mem_image.1 hy
    have hab : a ≠ b := by rintro rfl; exact hxy rfl
    obtain ⟨i, hi, hd⟩ := hS a ha b hb hab
    have hd' : (3 / 4 : ℝ) < Subit.dC (iter (Subit.restrict shift W hW) i a).1
        (iter (Subit.restrict shift W hW) i b).1 := hd
    rw [Subit.W8Entropy.iter_restrict_val, Subit.W8Entropy.iter_restrict_val] at hd'
    exact ⟨i, hi, hd'⟩
  have := Subit.sep_card_le m 0 (3 / 4) (by norm_num) _ hS'
  rw [Finset.card_image_of_injective _ Subtype.val_injective] at this
  simpa using this

/-- Нижня оцінка: на ω(d) існує (2n, 3/4)-роздільна множина потужності 2^n. -/
theorem sepNum_sub_lower (d : ℕ → Bool)
    (hpat : ∀ x : Seq, noBB x → ∀ L N : ℕ, ∃ p, N ≤ p ∧ ∀ j < L, d (p + j) = x j) (n : ℕ) :
    2 ^ n ≤ Subit.sepNum (fun a b : ↥(Subit.omega shift d) => Subit.dC a.1 b.1)
      (Subit.restrict shift (Subit.omega shift d) (Subit.W8GEntropy.omega_maps_shift_gen d))
      (2 * n) (3 / 4) := by
  have hM := Subit.W8GEntropy.omega_maps_shift_gen d
  let F : (Fin n → Bool) → ↥(Subit.omega shift d) :=
    fun s => ⟨phi n s, X_sub_omega d hpat (noBB_phi n s)⟩
  have hFinj : Function.Injective F := fun s t h => phi_inj n s t (congrArg Subtype.val h)
  let S0 : Finset ↥(Subit.omega shift d) := (Finset.univ : Finset (Fin n → Bool)).image F
  have hS0 : IsSep (fun a b : ↥(Subit.omega shift d) => Subit.dC a.1 b.1)
      (Subit.restrict shift _ hM) (2 * n) (3 / 4) S0 := by
    intro x hx y hy hxy
    obtain ⟨s, -, rfl⟩ := Finset.mem_image.1 hx
    obtain ⟨t, -, rfl⟩ := Finset.mem_image.1 hy
    have hst : s ≠ t := fun h => hxy (congrArg F h)
    obtain ⟨i, hi⟩ := Function.ne_iff.1 hst
    refine ⟨2 * (i : ℕ), by have := i.isLt; omega, ?_⟩
    show (3 / 4 : ℝ) < Subit.dC (iter (Subit.restrict shift _ hM) (2 * (i : ℕ)) (F s)).1
      (iter (Subit.restrict shift _ hM) (2 * (i : ℕ)) (F t)).1
    rw [Subit.W8Entropy.iter_restrict_val, Subit.W8Entropy.iter_restrict_val]
    show (3 / 4 : ℝ) < Subit.dC (iter shift (2 * (i : ℕ)) (phi n s))
      (iter shift (2 * (i : ℕ)) (phi n t))
    have hcoord : (iter shift (2 * (i : ℕ)) (phi n s)) 0 ≠ (iter shift (2 * (i : ℕ)) (phi n t)) 0 := by
      rw [iter_shift, iter_shift]
      show phi n s (0 + 2 * (i : ℕ)) ≠ phi n t (0 + 2 * (i : ℕ))
      rw [Nat.zero_add, phi_even, phi_even]
      cases hs : s i <;> cases ht : t i <;> simp_all
    have h1 := Subit.dC_ge _ _ 0 hcoord
    norm_num at h1
    linarith
  have hcard : S0.card = 2 ^ n := by
    rw [Finset.card_image_of_injective _ hFinj, Finset.card_univ, Fintype.card_fun,
      Fintype.card_bool, Fintype.card_fin]
  have hbdd : BddAbove {k : ℕ | ∃ S : Finset ↥(Subit.omega shift d),
      IsSep (fun a b : ↥(Subit.omega shift d) => Subit.dC a.1 b.1)
        (Subit.restrict shift _ hM) (2 * n) (3 / 4) S ∧ S.card = k} := by
    refine ⟨2 ^ (2 * n), ?_⟩
    rintro k ⟨S, hS, rfl⟩
    exact card_sep_le_sub _ hM (2 * n) S hS
  unfold Subit.sepNum
  rw [← hcard]
  exact le_csSup hbdd ⟨S0, hS0, rfl⟩

/-- h_top(σ|ω(d)) ≥ (log 2)/2 > 0. -/
theorem htop_sub_pos (d : ℕ → Bool)
    (hpat : ∀ x : Seq, noBB x → ∀ L N : ℕ, ∃ p, N ≤ p ∧ ∀ j < L, d (p + j) = x j) :
    ((Real.log 2 / 2 : ℝ) : EReal) ≤
      Subit.htopOn Subit.dC shift (Subit.omega shift d) (Subit.W8GEntropy.omega_maps_shift_gen d) := by
  unfold Subit.htopOn Subit.htop
  refine le_trans ?_ (le_iSup _ ⟨3 / 4, by norm_num⟩)
  apply Filter.le_limsup_of_frequently_le
  · refine Filter.frequently_atTop.2 fun a => ⟨2 * (a + 1), by omega, ?_⟩
    have h := sepNum_sub_lower d hpat (a + 1)
    have hpos : (0 : ℝ) < ((2 * (a + 1) : ℕ) : ℝ) := by positivity
    have hlog : ((a + 1 : ℕ) : ℝ) * Real.log 2 ≤
        Real.log ((Subit.sepNum (fun a b : ↥(Subit.omega shift d) => Subit.dC a.1 b.1)
          (Subit.restrict shift _ (Subit.W8GEntropy.omega_maps_shift_gen d))
          (2 * (a + 1)) (3 / 4) : ℕ) : ℝ) := by
      rw [← Real.log_pow]
      apply Real.log_le_log (by positivity)
      exact_mod_cast h
    have hc : Real.log 2 / 2 * ((2 * (a + 1) : ℕ) : ℝ) = ((a + 1 : ℕ) : ℝ) * Real.log 2 := by
      push_cast; ring
    apply EReal.coe_le_coe_iff.2
    rw [le_div_iff₀ hpos]
    linarith
  · isBoundedDefault

theorem htop_sub_strict_pos (d : ℕ → Bool)
    (hpat : ∀ x : Seq, noBB x → ∀ L N : ℕ, ∃ p, N ≤ p ∧ ∀ j < L, d (p + j) = x j) :
    (0 : EReal) < Subit.htopOn Subit.dC shift (Subit.omega shift d)
      (Subit.W8GEntropy.omega_maps_shift_gen d) := by
  have hp : (0 : ℝ) < Real.log 2 / 2 := by
    have := Real.log_pos (by norm_num : (1 : ℝ) < 2); positivity
  exact lt_of_lt_of_le (by exact_mod_cast hp) (htop_sub_pos d hpat)

end Subit.W7A
end
