import Subit.W8GTree
import Subit.W6Word

/-!
# W6 на Tree∞ (NONATTAINED, NONMIN, нульова ентропія) — за зразком W8GTree

Слово d = `dW6` (блоки β α^{j+1}, позиції β — `bpos`). Тут доведено:
* `nonattained_TY`, `nonattained_graph`: d ∉ ω(d) переноситься на Y і на граф;
* `omega_infinite_W6`, `infinite_TY_W6`, `infinite_graph`: ω нескінченна;
* `nonmin_TY_W6`, `nonmin_graph`: неминімальність переноситься;
* `htop_TY_W6`, `w6_graph_zero`: нульова ентропія переноситься.

Генеричні `omega_TY`, `htop_scale`, `infinite_TY`, `nonmin_TY` — з `Subit.W8Tree` / `Subit.W8GTree`.
-/

noncomputable section
namespace Subit.W6Tree
open Filter Set Topology Subit Subit.LemmaEY Subit.W8Spine Subit.OmegaGraph Subit.W8Tree Subit.W6

section Y

variable {A : Type*} [Finite A]

omit [Finite A] in
theorem nonattained_TY (α β η : A) (hαβ : α ≠ β) (d : ℕ → Bool) (hd : d ∉ omega shift d) :
    tHomeo α β η hαβ d ∉ omega (TY α β η hαβ) (tHomeo α β η hαβ d) := by
  rw [omega_TY]
  rintro ⟨a, ha, hae⟩
  have e : a = d := (tHomeo α β η hαβ).injective hae
  exact hd (e ▸ ha)

omit [Finite A] in
theorem iter_TY_conj (α β η : A) (hαβ : α ≠ β) (d : ℕ → Bool) (n : ℕ) :
    (TY α β η hαβ)^[n] (tHomeo α β η hαβ d) = tHomeo α β η hαβ (iter shift n d) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [Function.iterate_succ_apply', ih]
    exact (conj_TY α β η hαβ (iter shift n d)).symm

omit [Finite A] in
/-- NONATTAINED для всіх n на Y: жодна точка орбіти x_n = Tⁿ(x₀) не лежить в ω(x₀). -/
theorem nonattained_TY_all (α β η : A) (hαβ : α ≠ β) (n : ℕ) :
    (TY α β η hαβ)^[n] (tHomeo α β η hαβ dW6) ∉ omega (TY α β η hαβ) (tHomeo α β η hαβ dW6) := by
  rw [iter_TY_conj, omega_TY]
  rintro ⟨a, ha, hae⟩
  have e : a = iter shift n dW6 := (tHomeo α β η hαβ).injective hae
  rw [e] at ha
  exact iter_not_mem_omega n ha

theorem omega_infinite_W6 : (omega shift dW6).Infinite := by
  refine Set.infinite_of_injective_forall_mem
    (f := fun k : ℕ => fun j : ℕ => decide (j ≠ k)) ?_ ?_
  · intro k1 k2 h
    by_contra hne
    have := congrFun h k1
    simp [hne] at this
  · intro k
    rw [omega_eq_Z0, Set.mem_setOf_eq]
    intro a b hab ha hb
    simp at ha hb
    omega

theorem nonattained_dW6 : dW6 ∉ omega shift dW6 := by
  have h := iter_not_mem_omega 0
  have e : iter shift 0 dW6 = dW6 := funext fun n => by
    simp [iter_shift]
  rwa [e] at h

omit [Finite A] in
theorem htop_TY_W6 (α β η : A) (hαβ : α ≠ β) :
    htopOn (fun a b : Set.range (tM α β η) => dist a.1 b.1) (TY α β η hαβ)
      (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) (fun y hy =>
        omega_forward _ (TY_continuous α β η hαβ) _ ⟨y, hy, rfl⟩) = 0 := by
  set ωs := omega shift dW6 with hωs
  set W := omega (TY α β η hαβ) (tHomeo α β η hαβ dW6) with hW
  have hWmaps : Set.MapsTo (TY α β η hαβ) W W := fun y hy =>
    omega_forward _ (TY_continuous α β η hαβ) _ ⟨y, hy, rfl⟩
  have hωmaps : Set.MapsTo (shift : (ℕ → Bool) → (ℕ → Bool)) ωs ωs :=
    fun y hy => omega_forward _ Subit.W8Entropy.continuous_shift _ ⟨y, hy, rfl⟩
  have hiff : ∀ a : ℕ → Bool, a ∈ ωs ↔ tHomeo α β η hαβ a ∈ W := by
    intro a
    rw [hW, omega_TY]
    exact (tHomeo α β η hαβ).injective.mem_set_image.symm
  let e : {a // a ∈ ωs} ≃ {b // b ∈ W} :=
    Equiv.subtypeEquiv (tHomeo α β η hαβ).toEquiv hiff
  have hiso : ∀ a b : {a // a ∈ ωs},
      (1 / 2 : ℝ) * Subit.dC a.1 b.1 = dist (e a).1.1 (e b).1.1 := by
    intro a b
    show (1 / 2 : ℝ) * Subit.dC a.1 b.1 = dist (tM α β η a.1) (tM α β η b.1)
    rw [dist_tM α β η hαβ]
    ring
  have hc : ∀ a : {a // a ∈ ωs}, e (⟨shift a.1, hωmaps a.2⟩ : {a // a ∈ ωs}) =
      (⟨TY α β η hαβ (e a).1, hWmaps (e a).2⟩ : {b // b ∈ W}) := by
    intro a
    apply Subtype.ext
    show tHomeo α β η hαβ (shift a.1) = TY α β η hαβ (tHomeo α β η hαβ a.1)
    exact conj_TY α β η hαβ a.1
  have hsep : ∀ (m : ℕ) (ε : ℝ),
      sepNum (fun a b : {a // a ∈ ωs} => (1 / 2 : ℝ) * Subit.dC a.1 b.1)
        (restrict shift ωs hωmaps) m ε =
      sepNum (fun a b : {b // b ∈ W} => dist a.1 b.1) (restrict (TY α β η hαβ) W hWmaps) m ε := by
    intro m ε
    exact sepNum_iso _ _ _ _ e hiso hc m ε
  have hEq : htop (fun a b : {a // a ∈ ωs} => (1 / 2 : ℝ) * Subit.dC a.1 b.1)
      (restrict shift ωs hωmaps) =
      htop (fun a b : {b // b ∈ W} => dist a.1 b.1) (restrict (TY α β η hαβ) W hWmaps) := by
    unfold htop
    simp only [hsep]
  show htop (fun a b : {b // b ∈ W} => dist a.1 b.1) (restrict (TY α β η hαβ) W hWmaps) = 0
  rw [← hEq]
  refine (htop_scale (1 / 2) (by norm_num) (fun a b : {a // a ∈ ωs} => Subit.dC a.1 b.1)
    (restrict shift ωs hωmaps)).trans ?_
  exact omega_zero_entropy_W6

end Y

section Graph

variable {A : Type*} [Finite A]

theorem image_omegaG (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ)
        (TY_continuous α β η hαβ) '' omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)) =
      omega (TY α β η hαβ) (tHomeo α β η hαβ dW6) := by
  have hconj := omega_conj
    (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))
    (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (TY α β η hαβ)
    (conj_graph (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ)
      (TY_continuous α β η hαβ) x0)
    (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))
  rw [graphHomeoY_gphPt] at hconj
  exact hconj

theorem mem_omegaG_iff (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A)
    (a : Gph (Set.range (tM α β η)) (TY α β η hαβ)) :
    a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)) ↔
      graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) a ∈
        omega (TY α β η hαβ) (tHomeo α β η hαβ dW6) := by
  rw [← image_omegaG α β η hαβ x0]
  constructor
  · intro h
    exact ⟨a, h, rfl⟩
  · rintro ⟨b, hb, hb'⟩
    rw [(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).injective hb'] at hb
    exact hb

theorem nonattained_graph (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6) ∉
      omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)) := by
  rw [mem_omegaG_iff α β η hαβ x0, graphHomeoY_gphPt]
  exact nonattained_TY α β η hαβ dW6 nonattained_dW6

theorem iter_DpY_conj (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) (n : ℕ)
    (a : Gph (Set.range (tM α β η)) (TY α β η hαβ)) :
    graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)
      ((DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)^[n] a) =
    (TY α β η hαβ)^[n] (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ)
      (TY_continuous α β η hαβ) a) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply',
      conj_graph (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) x0,
      ih]

/-- NONATTAINED для всіх n на графі G. -/
theorem nonattained_graph_all (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) (n : ℕ) :
    (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)^[n]
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)) ∉
      omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)) := by
  rw [mem_omegaG_iff α β η hαβ x0, iter_DpY_conj, graphHomeoY_gphPt]
  exact nonattained_TY_all α β η hαβ n

theorem infinite_graph (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))).Infinite := by
  apply Set.Infinite.of_image (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ)
    (TY α β η hαβ) (TY_continuous α β η hαβ))
  rw [image_omegaG α β η hαβ x0]
  exact Subit.W8GTree.infinite_TY α β η hαβ dW6 omega_infinite_W6

theorem minOn_TY_of_graph (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A)
    (hM : MinOn (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)))) :
    MinOn (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) := by
  intro V' hV'W hV'ne hV'cl hV'inv
  have hVW : (⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V' ⊆ (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))) := by
    intro a ha
    rw [mem_omegaG_iff α β η hαβ x0]
    exact hV'W ha
  have hVne : ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V').Nonempty := by
    obtain ⟨y, hy⟩ := hV'ne
    exact ⟨(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).symm y, by simpa using hy⟩
  have hVcl : IsClosed ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') := hV'cl.preimage (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).continuous
  have hVmaps : Set.MapsTo (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') := by
    intro a ha
    have hc := conj_graph (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) x0 a
    show (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)) ((DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) a) ∈ V'
    rw [hc]
    exact hV'inv ha
  have hVeq := hM ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') hVW hVne hVcl hVmaps
  apply Set.Subset.antisymm hV'W
  intro y hy
  have ha : (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).symm y ∈ (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))) := by
    rw [mem_omegaG_iff α β η hαβ x0]
    simpa using hy
  rw [← hVeq] at ha
  simpa using ha

theorem nonmin_graph (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    ¬ MinOn (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))) :=
  fun hM => Subit.W8GTree.nonmin_TY α β η hαβ dW6 not_minOn_omega
    (minOn_TY_of_graph α β η hαβ x0 hM)

theorem w6_graph_zero (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    htopOn (fun a b : Gph (Set.range (tM α β η)) (TY α β η hαβ) => dist a.1 b.1)
      (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)))
      (fun y hy => omega_forward _ (Subit.OmegaGraph.DpY_continuous (Set.range (tM α β η))
        (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) x0) _ ⟨y, hy, rfl⟩) = 0 := by
  have hY := Y_isCompact α β η hαβ
  haveI : CompactSpace (Set.range (tM α β η)) := isCompact_iff_compactSpace.1 hY
  have hT := TY_continuous α β η hαβ
  have hiffG : ∀ a : Gph (Set.range (tM α β η)) (TY α β η hαβ),
      a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
          (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)) ↔
      graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT a ∈
        omega (TY α β η hαβ) (tHomeo α β η hαβ dW6) := by
    intro a
    have hconj := omega_conj (graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT)
      (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (TY α β η hαβ)
      (conj_graph (Set.range (tM α β η)) hY (TY α β η hαβ) hT x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))
    rw [graphHomeoY_gphPt] at hconj
    rw [← hconj]
    constructor
    · intro h
      exact ⟨a, h, rfl⟩
    · rintro ⟨b, hb, hb'⟩
      rw [(graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT).injective hb'] at hb
      exact hb
  let eG : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))} ≃
      {b // b ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)} :=
    Equiv.subtypeEquiv (graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT).toEquiv hiffG
  have hWc : IsCompact (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) := omega_isCompact _ _
  obtain ⟨w0, hw0⟩ := omega_nonempty (TY α β η hαβ) (tHomeo α β η hαβ dW6)
  haveI : Nonempty {b // b ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)} := ⟨⟨w0, hw0⟩⟩
  haveI : CompactSpace {b // b ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)} :=
    isCompact_iff_compactSpace.1 hWc
  have hωmaps : Set.MapsTo (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)))
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))) := fun y hy =>
    omega_forward _ (Subit.OmegaGraph.DpY_continuous (Set.range (tM α β η)) hY
      (TY α β η hαβ) hT x0) _ ⟨y, hy, rfl⟩
  have hWmaps : Set.MapsTo (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6))
      (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) := fun y hy =>
    omega_forward _ hT _ ⟨y, hy, rfl⟩
  have hiso : ∀ a b : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))},
      dist a.1.1 b.1.1 = dmaxT (restrict (TY α β η hαβ)
        (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) hWmaps) (eG a) (eG b) := by
    intro a b
    exact Subit.OmegaGraph.dist_Gph_eq (Set.range (tM α β η)) hY (TY α β η hαβ) hT a.1 b.1
  have hc : ∀ a : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))},
      eG (restrict (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) _ hωmaps a) =
        restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) hWmaps (eG a) := by
    intro a
    apply Subtype.ext
    exact Subit.LemmaEY.conj_graph (Set.range (tM α β η)) hY (TY α β η hαβ) hT x0 a.1
  have hsep : ∀ (m : ℕ) (ε : ℝ),
      sepNum (fun a b : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
          (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))} => dist a.1.1 b.1.1)
        (restrict (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) _ hωmaps) m ε =
      sepNum (dmaxT (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) hWmaps))
        (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) hWmaps) m ε := by
    intro m ε
    exact sepNum_iso _ _ _ _ eG hiso hc m ε
  have hmax := htop_eq_of_maxT isCompact_univ.totallyBounded
    (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) hWmaps)
  have hEq : htop (fun a b : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))} => dist a.1.1 b.1.1)
      (restrict (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) _ hωmaps) =
      htop (dmaxT (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) hWmaps))
        (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) hWmaps) := by
    unfold htop
    simp only [hsep]
  exact (hEq.trans hmax).trans (htop_TY_W6 α β η hαβ)

end Graph

variable {A : Type*} [Finite A]

/-- Підсумок W6 на Tree∞ (рівень Y і графа G): NONATTAINED для всіх n, нескінченність,
неминімальність і нульова ентропія. -/
theorem w6_tree_summary (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    (∀ n : ℕ, (TY α β η hαβ)^[n] (tHomeo α β η hαβ dW6) ∉
      omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) ∧
    (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)).Infinite ∧
    ¬ MinOn (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) ∧
    htopOn (fun a b : Set.range (tM α β η) => dist a.1 b.1) (TY α β η hαβ)
      (omega (TY α β η hαβ) (tHomeo α β η hαβ dW6)) (fun y hy =>
        omega_forward _ (TY_continuous α β η hαβ) _ ⟨y, hy, rfl⟩) = 0 ∧
    (∀ n : ℕ, (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)^[n]
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)) ∉
      omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))) ∧
    (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))).Infinite ∧
    ¬ MinOn (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6))) ∧
    htopOn (fun a b : Gph (Set.range (tM α β η)) (TY α β η hαβ) => dist a.1 b.1)
      (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ dW6)))
      (fun y hy => omega_forward _ (Subit.OmegaGraph.DpY_continuous (Set.range (tM α β η))
        (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) x0) _ ⟨y, hy, rfl⟩) = 0 :=
  ⟨nonattained_TY_all α β η hαβ,
   Subit.W8GTree.infinite_TY α β η hαβ dW6 omega_infinite_W6,
   Subit.W8GTree.nonmin_TY α β η hαβ dW6 not_minOn_omega,
   htop_TY_W6 α β η hαβ,
   nonattained_graph_all α β η hαβ x0,
   infinite_graph α β η hαβ x0,
   nonmin_graph α β η hαβ x0,
   w6_graph_zero α β η hαβ x0⟩

end Subit.W6Tree
end
