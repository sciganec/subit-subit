import Subit.FullShift
import Subit.OmegaLimit
import Subit.D6
import Subit.W8GEntropy

/-!
# W6, крок 1: слово d = β α β α² β α³ … і ядро NONATTAINED

Конвенція: α = `true`, β = `false` (як у W8).
Блок j (j ≥ 0) — β α^{j+1}, довжина j+2; позиції β: `bpos j`.

Доведено тут:
* `bpos` строго зростає і `bpos i + (i+2) ≤ bpos j` для i < j;
* `omega_window`: x ∈ ω(d) ⇒ кожне вікно x з’являється в d на позиціях як завгодно великих;
* `omega_atmost_one_beta`: кожна точка ω(d) містить не більше одного β;
* `iter_not_mem_omega`: для всіх n, σⁿd ∉ ω(d) (ядро NONATTAINED).
-/

open Filter Topology Classical
namespace Subit.W6

/-- Позиція j-го β: bpos 0 = 0, bpos (j+1) = bpos j + (j+2). -/
def bpos : ℕ → ℕ
  | 0 => 0
  | j + 1 => bpos j + (j + 2)

/-- Нескінченне слово d: β (= `false`) на позиціях bpos j, α (= `true`) інакше. -/
noncomputable def dW6 (p : ℕ) : Bool := if ∃ j, bpos j = p then false else true

theorem bpos_succ (j : ℕ) : bpos (j + 1) = bpos j + (j + 2) := rfl

theorem bpos_strictMono : StrictMono bpos :=
  strictMono_nat_of_lt_succ fun j => by rw [bpos_succ]; omega

theorem le_bpos (j : ℕ) : j ≤ bpos j := by
  induction j with
  | zero => simp [bpos]
  | succ j ih => rw [bpos_succ]; omega

/-- Для i < j відстань між β з номерами i і j не менша за i+2. -/
theorem gap_ge {i j : ℕ} (h : i < j) : bpos i + (i + 2) ≤ bpos j := by
  have h1 : bpos (i + 1) ≤ bpos j := bpos_strictMono.monotone (Nat.succ_le_of_lt h)
  rw [bpos_succ] at h1
  exact h1

theorem dW6_eq_false {p : ℕ} (h : ∃ j, bpos j = p) : dW6 p = false := by
  unfold dW6; rw [if_pos h]

theorem dW6_eq_true {p : ℕ} (h : ¬ ∃ j, bpos j = p) : dW6 p = true := by
  unfold dW6; rw [if_neg h]

/-- Ідентифікація ω-вікон: x ∈ ω(d) ⇒ кожен префікс довжини L зустрічається в d на позиції ≥ N. -/
theorem cyl_open (x : Seq) (L : ℕ) : IsOpen {y : Seq | ∀ j < L, y j = x j} := by
  have e : {y : Seq | ∀ j < L, y j = x j} = ⋂ j ∈ Finset.range L, (fun y : Seq => y j) ⁻¹' {x j} := by
    ext y; simp [Finset.mem_range]
  rw [e]
  exact isOpen_biInter_finset fun j _ => (continuous_apply j).isOpen_preimage _ (isOpen_discrete _)

theorem omega_window {x : Seq} (hx : x ∈ Subit.omega shift dW6) (L N : ℕ) :
    ∃ n, N ≤ n ∧ ∀ j < L, dW6 (n + j) = x j := by
  have hcl : x ∈ closure (Set.range fun k => iter shift (N + k) dW6) :=
    Set.mem_iInter.1 hx N
  obtain ⟨y, hy, hys⟩ := (mem_closure_iff.1 hcl) _ (cyl_open x L) (fun j _ => rfl)
  obtain ⟨k, rfl⟩ := hys
  refine ⟨N + k, by omega, fun j hj => ?_⟩
  have hyj : iter shift (N + k) dW6 j = x j := hy j hj
  rw [iter_shift] at hyj
  rw [Nat.add_comm (N + k) j]
  exact hyj

/-- Ключова комбінаторна лема: точка ω(d) містить не більше одного β. -/
theorem omega_atmost_one_beta {x : Seq} (hx : x ∈ Subit.omega shift dW6) {a b : ℕ}
    (hab : a < b) (ha : x a = false) (hb : x b = false) : False := by
  obtain ⟨n, hN, hwin⟩ := omega_window hx (b + 1) (bpos (b + 1))
  have hA : dW6 (n + a) = false := by rw [hwin a (by omega)]; exact ha
  have hB : dW6 (n + b) = false := by rw [hwin b (by omega)]; exact hb
  have hiex : ∃ i, bpos i = n + a := by
    by_contra hc
    rw [dW6_eq_true hc] at hA
    exact Bool.noConfusion hA
  have hkex : ∃ k, bpos k = n + b := by
    by_contra hc
    rw [dW6_eq_true hc] at hB
    exact Bool.noConfusion hB
  obtain ⟨i, hi⟩ := hiex
  obtain ⟨k, hk⟩ := hkex
  have hik : i < k := by
    have : bpos i < bpos k := by rw [hi, hk]; omega
    exact bpos_strictMono.lt_iff_lt.1 this
  have hgap := gap_ge hik
  rw [hi, hk] at hgap
  -- звідси i + 2 ≤ b − a ≤ b, тобто i ≤ b
  have hi_le : i ≤ b := by omega
  -- але bpos i = n + a ≥ bpos (b+1), тож i ≥ b+1
  have hi_ge : b + 1 ≤ i := by
    by_contra hc
    have : bpos i ≤ bpos b := bpos_strictMono.monotone (by omega)
    have : bpos b < bpos (b + 1) := bpos_strictMono (Nat.lt_succ_self b)
    omega
  omega

/-- NONATTAINED-ядро: σⁿd ∉ ω(d) для всіх n. -/
theorem iter_not_mem_omega (n : ℕ) : iter shift n dW6 ∉ Subit.omega shift dW6 := by
  intro hx
  have hn1 : n ≤ bpos n := le_bpos n
  have hn2 : n ≤ bpos (n + 1) := by have := le_bpos (n + 1); omega
  have hlt : bpos n < bpos (n + 1) := bpos_strictMono (Nat.lt_succ_self n)
  have hA : iter shift n dW6 (bpos n - n) = false := by
    rw [iter_shift]
    show dW6 (bpos n - n + n) = false
    rw [show bpos n - n + n = bpos n by omega]
    exact dW6_eq_false ⟨n, rfl⟩
  have hB : iter shift n dW6 (bpos (n + 1) - n) = false := by
    rw [iter_shift]
    show dW6 (bpos (n + 1) - n + n) = false
    rw [show bpos (n + 1) - n + n = bpos (n + 1) by omega]
    exact dW6_eq_false ⟨n + 1, rfl⟩
  exact omega_atmost_one_beta hx (by omega) hA hB

/-! ## Крок 2: ω(d) = Z₀ і неминімальність -/

/-- Замкнений окіл: якщо кожен префікс довжини L точки x реалізується в S, то x ∈ closure S. -/
theorem mem_closure_of_cyl {S : Set Seq} {x : Seq}
    (h : ∀ L : ℕ, ∃ y ∈ S, ∀ j < L, y j = x j) : x ∈ closure S := by
  rw [mem_closure_iff]
  intro o ho hxo
  have hon : o ∈ nhds x := ho.mem_nhds hxo
  rw [nhds_pi, Filter.mem_pi] at hon
  obtain ⟨I, hI, t, ht, hsub⟩ := hon
  obtain ⟨M, hM⟩ := hI.bddAbove
  obtain ⟨y, hyS, hy⟩ := h (M + 1)
  have hyP : y ∈ Set.pi I t := by
    refine Set.mem_pi.2 fun i hi => ?_
    have hiM : i ≤ M := hM hi
    rw [hy i (by omega)]
    exact mem_of_mem_nhds (ht i)
  exact ⟨y, hsub hyP, hyS⟩

/-- Вікна для кожного L, N: будь-яке x з не більше ніж одним β реалізується в d на позиціях ≥ N. -/
theorem window_exists {x : Seq} (hx : ∀ a b, a < b → x a = false → x b = false → False)
    (L N : ℕ) : ∃ n, N ≤ n ∧ ∀ j < L, dW6 (n + j) = x j := by
  have btw : ∀ a q, bpos a < q → q < bpos (a + 1) → dW6 q = true := by
    intro a q h1 h2
    apply dW6_eq_true
    rintro ⟨i, hi⟩
    have e1 : a < i := bpos_strictMono.lt_iff_lt.1 (by rw [hi]; exact h1)
    have e2 : i < a + 1 := bpos_strictMono.lt_iff_lt.1 (by rw [hi]; exact h2)
    omega
  have hB := bpos_succ (N + L)
  have hB2 := bpos_succ (N + L + 1)
  have hle := le_bpos (N + L + 1)
  by_cases hf : ∃ p, p < L ∧ x p = false
  · obtain ⟨p, hpL, hp⟩ := hf
    refine ⟨bpos (N + L + 1) - p, by omega, fun j hj => ?_⟩
    rcases lt_trichotomy j p with hjp | hjp | hjp
    · have hxj : x j = true := by
        cases h : x j
        · exact (hx j p hjp h hp).elim
        · rfl
      rw [btw (N + L) (bpos (N + L + 1) - p + j) (by omega) (by omega), hxj]
    · rw [show bpos (N + L + 1) - p + j = bpos (N + L + 1) by omega, hjp, hp]
      exact dW6_eq_false ⟨N + L + 1, rfl⟩
    · have hxj : x j = true := by
        cases h : x j
        · exact (hx p j hjp hp h).elim
        · rfl
      rw [btw (N + L + 1) (bpos (N + L + 1) - p + j) (by omega) (by omega), hxj]
  · have htrue : ∀ j < L, x j = true := by
      intro j hj
      cases h : x j
      · exact (hf ⟨j, hj, h⟩).elim
      · rfl
    refine ⟨bpos (N + L + 1) + 1, by omega, fun j hj => ?_⟩
    rw [btw (N + L + 1) (bpos (N + L + 1) + 1 + j) (by omega) (by omega), htrue j hj]

/-- Z₀ ⊆ ω(d): кожна точка з не більше ніж одним β належить ω-границі. -/
theorem Z0_sub_omega {x : Seq} (hx : ∀ a b, a < b → x a = false → x b = false → False) :
    x ∈ Subit.omega shift dW6 := by
  refine Set.mem_iInter.2 fun N => ?_
  refine mem_closure_of_cyl fun L => ?_
  obtain ⟨n, hN, hwin⟩ := window_exists hx L N
  refine ⟨iter shift n dW6, ⟨n - N, ?_⟩, ?_⟩
  · show iter shift (N + (n - N)) dW6 = iter shift n dW6
    rw [Nat.add_sub_of_le hN]
  · intro j hj
    rw [iter_shift]
    show dW6 (j + n) = x j
    rw [Nat.add_comm]
    exact hwin j hj

/-- ω(d) = Z₀: ω-границя точно складається з точок із не більше ніж одним β. -/
theorem omega_eq_Z0 :
    Subit.omega shift dW6 = {x : Seq | ∀ a b, a < b → x a = false → x b = false → False} := by
  ext x
  constructor
  · intro hx a b hab ha hb
    exact omega_atmost_one_beta hx hab ha hb
  · intro hx
    exact Z0_sub_omega hx

/-- Множина α^∞ (усі true). -/
def allT : Set Seq := {x | ∀ j, x j = true}

theorem allT_closed : IsClosed allT := by
  have e : allT = ⋂ j, (fun x : Seq => x j) ⁻¹' {true} := by
    ext x
    simp [allT]
  rw [e]
  exact isClosed_iInter fun j => (isClosed_discrete _).preimage (continuous_apply j)

/-- ω(d) не є мінімальною: α^∞ — власна непуста замкнена інваріантна підмножина. -/
theorem not_minOn_omega : ¬ MinOn shift (Subit.omega shift dW6) := by
  intro hmin
  have hsub : allT ⊆ Subit.omega shift dW6 := by
    intro x hx
    rw [omega_eq_Z0, Set.mem_setOf_eq]
    intro a b hab ha hb
    simp [hx b] at hb
  have hne : allT.Nonempty := ⟨fun _ => true, fun _ => rfl⟩
  have hmap : Set.MapsTo shift allT allT := by
    intro x hx
    simp only [allT, Set.mem_setOf_eq, shift] at hx ⊢
    exact fun j => hx (j + 1)
  have heq := hmin allT hsub hne allT_closed hmap
  have hx0 : (fun n : ℕ => decide (n ≠ 0)) ∈ Subit.omega shift dW6 := by
    rw [omega_eq_Z0, Set.mem_setOf_eq]
    intro a b hab ha hb
    simp at ha hb
    omega
  rw [← heq] at hx0
  simp only [allT, Set.mem_setOf_eq] at hx0
  have := hx0 0
  simp at this

/-! ## Крок 3: нульова топологічна ентропія ω(d) -/

section ZeroEnt

open Subit.W8Entropy (iter_restrict_val htop_eq_zero_of_poly)

/-- Вікно довжини N у точці, що починається за bpos N, містить не більше одного β. -/
theorem window_word (p N : ℕ) (hp : bpos N + 1 ≤ p) :
    ∃ o, o ≤ N ∧ ∀ j < N, dW6 (p + j) = decide (j ≠ o) := by
  by_cases h : ∃ j < N, ∃ i, bpos i = p + j
  · obtain ⟨j, hj, i, hi⟩ := h
    have hiN : N < i := by
      by_contra hc
      have := bpos_strictMono.monotone (show i ≤ N by omega)
      omega
    refine ⟨j, by omega, fun j' hj' => ?_⟩
    by_cases hjj : j' = j
    · subst hjj
      rw [dW6_eq_false ⟨i, hi⟩]
      simp
    · have ht : dW6 (p + j') = true := by
        apply dW6_eq_true
        rintro ⟨k, hk⟩
        have hkN : N < k := by
          by_contra hc
          have := bpos_strictMono.monotone (show k ≤ N by omega)
          omega
        rcases lt_trichotomy i k with h1 | h1 | h1
        · have := gap_ge h1
          rw [hi, hk] at this
          omega
        · subst h1
          omega
        · have := gap_ge h1
          rw [hi, hk] at this
          omega
      rw [ht]
      simp [hjj]
  · refine ⟨N, le_refl N, fun j hj => ?_⟩
    have ht : dW6 (p + j) = true := by
      apply dW6_eq_true
      rintro ⟨i, hi⟩
      exact h ⟨j, hj, i, hi⟩
    rw [ht]
    simp [show j ≠ N by omega]

/-- Межа: B N = bpos N + 1 + (N + 1) — число слів довжини N у d. -/
def wB (N : ℕ) : ℕ := bpos N + 1 + (N + 1)

theorem word_count (N : ℕ) : ∃ T : Finset (List Bool),
    (∀ p : ℕ, List.ofFn (fun j : Fin N => dW6 (p + j)) ∈ T) ∧ T.card ≤ wB N := by
  refine ⟨(Finset.range (bpos N + 1)).image (fun p => List.ofFn (fun j : Fin N => dW6 (p + j)))
      ∪ (Finset.range (N + 1)).image
          (fun o => List.ofFn (fun j : Fin N => decide ((j : ℕ) ≠ o))), ?_, ?_⟩
  · intro p
    by_cases hp : p < bpos N + 1
    · exact Finset.mem_union_left _ (Finset.mem_image.2 ⟨p, Finset.mem_range.2 hp, rfl⟩)
    · obtain ⟨o, ho, hpo⟩ := window_word p N (by omega)
      refine Finset.mem_union_right _ (Finset.mem_image.2 ⟨o, Finset.mem_range.2 (by omega), ?_⟩)
      show List.ofFn (fun j : Fin N => decide ((j : ℕ) ≠ o))
        = List.ofFn (fun j : Fin N => dW6 (p + j))
      congr 1
      funext j
      exact (hpo j j.isLt).symm
  · unfold wB
    refine (Finset.card_union_le _ _).trans ?_
    exact add_le_add (Finset.card_image_le.trans (le_of_eq (Finset.card_range _)))
      (Finset.card_image_le.trans (le_of_eq (Finset.card_range _)))

theorem bpos_le_sq (j : ℕ) : bpos j ≤ (j + 1) ^ 2 := by
  induction j with
  | zero => simp [bpos]
  | succ j ih => rw [bpos_succ]; nlinarith

theorem wB_le (N : ℕ) (hN : 1 ≤ N) : wB N ≤ 7 * N ^ 2 := by
  have := bpos_le_sq N
  unfold wB
  nlinarith

/-- Копія `sepNum_restrict_le_gen` з довільною межею `B`. -/
theorem sepNum_restrict_le_B (d : ℕ → Bool) (W : Set (ℕ → Bool)) (hW : Set.MapsTo shift W W)
    (hfac : ∀ x ∈ W, ∀ L : ℕ, ∃ p : ℕ, ∀ j < L, x j = d (p + j))
    (B : ℕ → ℕ)
    (hT : ∀ N : ℕ, 1 ≤ N → ∃ T : Finset (List Bool),
      (∀ p : ℕ, List.ofFn (fun j : Fin N => d (p + j)) ∈ T) ∧ T.card ≤ B N)
    (K : ℕ) (ε : ℝ) (hK : (1 / 2 : ℝ) ^ K < ε) (n : ℕ) :
    sepNum (fun a b : W => Subit.dC a.1 b.1) (Subit.restrict shift W hW) n ε
      ≤ B (n + K + 1) := by
  refine Subit.sepNum_le _ fun S hS => ?_
  obtain ⟨T, hTm, hcard⟩ := hT (n + K + 1) (by omega)
  refine le_trans ?_ hcard
  refine Finset.card_le_card_of_injOn
    (fun a : W => List.ofFn (fun j : Fin (n + K + 1) => a.1 j)) ?_ ?_
  · intro a _
    obtain ⟨p, hp⟩ := hfac a.1 a.2 (n + K + 1)
    have e : List.ofFn (fun j : Fin (n + K + 1) => a.1 j)
        = List.ofFn (fun j : Fin (n + K + 1) => d (p + j)) := by
      congr 1
      funext j
      exact hp j j.isLt
    show List.ofFn (fun j : Fin (n + K + 1) => a.1 j) ∈ T
    rw [e]
    exact hTm p
  · intro a ha b hb hab
    by_contra hne
    obtain ⟨i, hi, hd⟩ := hS a ha b hb hne
    have hfun := List.ofFn_injective hab
    have hagree : ∀ j, j < n + K + 1 → a.1 j = b.1 j := fun j hj =>
      congrFun hfun ⟨j, hj⟩
    have hle : Subit.dC (iter shift i a.1) (iter shift i b.1) ≤ (1 / 2 : ℝ) ^ K := by
      apply Subit.dC_le
      intro m hm
      rw [iter_shift, iter_shift]
      exact hagree (m + i) (by omega)
    simp only [iter_restrict_val] at hd
    linarith

/-- Нульова ентропія, якщо число слів довжини N полиноміальне (загальна форма). -/
theorem htopOn_zero_B (d : ℕ → Bool) (W : Set (ℕ → Bool)) (hW : Set.MapsTo shift W W)
    (hfac : ∀ x ∈ W, ∀ L : ℕ, ∃ p : ℕ, ∀ j < L, x j = d (p + j))
    (B : ℕ → ℕ) (C : ℕ)
    (hB : ∀ N : ℕ, 1 ≤ N → B N ≤ C * N ^ 2)
    (hT : ∀ N : ℕ, 1 ≤ N → ∃ T : Finset (List Bool),
      (∀ p : ℕ, List.ofFn (fun j : Fin N => d (p + j)) ∈ T) ∧ T.card ≤ B N) :
    Subit.htopOn Subit.dC shift W hW = 0 := by
  unfold Subit.htopOn
  apply htop_eq_zero_of_poly
  intro ε hε
  obtain ⟨K, hK⟩ := exists_pow_lt_of_lt_one hε (by norm_num : (1 / 2 : ℝ) < 1)
  refine ⟨C * (K + 2) ^ 2, 2, fun n hn => ?_⟩
  have h1 := sepNum_restrict_le_B d W hW hfac B hT K ε hK n
  have h2 : n + K + 1 ≤ (K + 2) * n := by nlinarith
  calc _ ≤ B (n + K + 1) := h1
    _ ≤ C * (n + K + 1) ^ 2 := hB _ (by omega)
    _ ≤ C * ((K + 2) * n) ^ 2 := Nat.mul_le_mul_left C (Nat.pow_le_pow_left h2 2)
    _ = C * (K + 2) ^ 2 * n ^ 2 := by ring

/-- Головний результат кроку 3: ентропія зсуву на ω(d) дорівнює нулю. -/
theorem omega_zero_entropy_W6 :
    Subit.htopOn Subit.dC shift (Subit.omega shift dW6)
      (Subit.W8GEntropy.omega_maps_shift_gen dW6) = 0 :=
  htopOn_zero_B dW6 _ _ (fun _ hx L => Subit.W8GEntropy.prefix_mem_factor_gen dW6 hx L)
    wB 7 (fun N hN => wB_le N hN) (fun N _ => word_count N)

end ZeroEnt

/-- Явний опис (форма специфікації §11.6): ω(d) = {α^∞} ∪ {αᵏβα^∞ : k ≥ 0}. -/
theorem omega_eq_explicit :
    Subit.omega shift dW6 = {x : Seq | ∀ j, x j = true} ∪ {x : Seq | ∃ k : ℕ, x = fun j => decide (j ≠ k)} := by
  rw [omega_eq_Z0]
  ext x
  simp only [Set.mem_union, Set.mem_setOf_eq]
  constructor
  · intro hx
    by_cases h : ∃ k, x k = false
    · obtain ⟨k, hk⟩ := h
      right
      refine ⟨k, funext fun j => ?_⟩
      by_cases hjk : j = k
      · subst hjk
        simp [hk]
      · have hxj : x j = true := by
          cases h2 : x j
          · exfalso
            rcases Nat.lt_or_gt_of_ne hjk with h3 | h3
            · exact hx j k h3 h2 hk
            · exact hx k j h3 hk h2
          · rfl
        simp [hxj, hjk]
    · left
      intro j
      cases h2 : x j
      · exact absurd ⟨j, h2⟩ h
      · rfl
  · rintro (h | ⟨k, rfl⟩)
    · intro a b hab ha hb
      simp [h b] at hb
    · intro a b hab ha hb
      simp at ha hb
      omega

end Subit.W6
