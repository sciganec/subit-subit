import Subit.W7Abstract

/-!
# W7, конкретне слово d зі спеціфікації (§11.5/§11.6)

α = `true`, β = `false`. W — слова над {α, β} без підслова ββ.
u_m — конкатенація всіх слів з W довжини m, розділених α (`uF`).
Блок m (0-базований, відповідає u_{m+1} у спеціфікації): α u_{m+1} α ββ.
d := блоки підряд: α u₁ α ββ α u₂ α ββ …  (`Dr`, `dW7`).

Тут:
* `noBBl_chain`, `uF_chain`, `u_chain`: u_m не містить ββ;
* далі — позиції ββ (лише на межах блоків), зростання проміжків, появи шаблонів.
-/

noncomputable section
namespace Subit.W7W
open Classical

/-- Допустима пара для ланцюжка: не дві β поспіль. -/
def bbOK (x y : Bool) : Prop := ¬ (x = false ∧ y = false)

/-- Усі слова довжини m над {true, false}. -/
def allW : ℕ → List (List Bool)
  | 0 => [[]]
  | m + 1 => (allW m).flatMap (fun w => [true :: w, false :: w])

/-- Логічна перевірка «без ββ». -/
def noBBl : List Bool → Bool
  | false :: false :: _ => false
  | _ :: t => noBBl t
  | [] => true

/-- Слова довжини m без ββ (слова з W). -/
def wl (m : ℕ) : List (List Bool) := (allW m).filter noBBl

/-- Конкатенація слів, розділених α (= true). -/
def uF : List (List Bool) → List Bool
  | [] => []
  | [w] => w
  | w :: w' :: ws => w ++ true :: uF (w' :: ws)

/-- u_m: конкатенація всіх слів з W довжини m, розділених α. -/
def u (m : ℕ) : List Bool := uF (wl m)

/-- Блок m: α u_{m+1} α ββ (0-базований; спеціфікаційний номер — m+1). -/
def blk (m : ℕ) : List Bool := true :: (u (m + 1) ++ [true, false, false])

/-- Префікс з K блоків. -/
def Dr : ℕ → List Bool
  | 0 => []
  | K + 1 => Dr K ++ blk K

/-- Нескінченне слово d (позиція p). -/
def dW7 (p : ℕ) : Bool := (Dr (p + 1)).getD p true

theorem noBBl_chain : ∀ w : List Bool, noBBl w = true → List.IsChain bbOK w := by
  intro w
  induction w with
  | nil => intros; exact List.isChain_nil
  | cons x t ih =>
    intro h
    cases t with
    | nil => exact List.isChain_singleton x
    | cons y t' =>
      have hxy : bbOK x y := by
        intro hc
        obtain ⟨rfl, rfl⟩ := hc
        simp [noBBl] at h
      have h' : noBBl (y :: t') = true := by
        cases x <;> cases y <;> simp_all [noBBl, bbOK]
      refine List.isChain_cons.2 ⟨fun z hz => ?_, ih h'⟩
      simp at hz
      subst hz
      exact hxy

theorem uF_chain : ∀ ws : List (List Bool), (∀ w ∈ ws, List.IsChain bbOK w) →
    List.IsChain bbOK (uF ws) := by
  intro ws
  induction ws with
  | nil => intros; exact List.isChain_nil
  | cons w ws ih =>
    intro hw
    cases ws with
    | nil => simpa [uF] using hw w (by simp)
    | cons w' ws' =>
      have hwc := hw w (by simp)
      have hrest := ih (fun v hv => hw v (by simp [hv]))
      show List.IsChain bbOK (w ++ true :: uF (w' :: ws'))
      refine List.isChain_append.2 ⟨hwc, List.isChain_cons.2 ⟨fun y _ => by simp [bbOK], hrest⟩,
        fun x _ y hy => ?_⟩
      simp at hy
      subst hy
      simp [bbOK]

theorem wl_chain (m : ℕ) : ∀ w ∈ wl m, List.IsChain bbOK w :=
  fun w hw => noBBl_chain w (List.mem_filter.1 hw).2

theorem u_chain (m : ℕ) : List.IsChain bbOK (u m) := uF_chain _ (wl_chain m)

theorem len_blk (m : ℕ) : (blk m).length = (u (m + 1)).length + 4 := by
  simp only [blk, List.length_cons, List.length_append, List.length_nil]

theorem len_Dr_succ (K : ℕ) :
    (Dr (K + 1)).length = (Dr K).length + (u (K + 1)).length + 4 := by
  simp only [Dr, List.length_append, len_blk]
  omega

theorem four_mul_le_len_Dr : ∀ K : ℕ, 4 * K ≤ (Dr K).length
  | 0 => by simp [Dr]
  | K + 1 => by
      have ih := four_mul_le_len_Dr K
      rw [len_Dr_succ]
      omega

theorem Dr_prefix {K K' : ℕ} (h : K ≤ K') : Dr K <+: Dr K' := by
  induction K', h using Nat.le_induction with
  | base => exact List.prefix_refl _
  | succ n _ ih =>
      refine ih.trans ?_
      simp only [Dr]
      exact List.prefix_append _ _

theorem getD_Dr_stable {K K' p : ℕ} (hK : K ≤ K') (hp : p < (Dr K).length) :
    (Dr K').getD p true = (Dr K).getD p true := by
  obtain ⟨t, ht⟩ := Dr_prefix hK
  rw [← ht, List.getD_append _ _ _ _ hp]

theorem dW7_eq {K p : ℕ} (hp : p < (Dr K).length) : dW7 p = (Dr K).getD p true := by
  have hp1 : p < (Dr (p + 1)).length := by
    have := four_mul_le_len_Dr (p + 1)
    omega
  unfold dW7
  rcases le_total K (p + 1) with h | h
  · exact getD_Dr_stable h hp
  · exact (getD_Dr_stable h hp1).symm

theorem dW7_block {m p : ℕ} (h1 : (Dr m).length ≤ p)
    (h2 : p < (Dr m).length + (u (m + 1)).length + 4) :
    dW7 p = (blk m).getD (p - (Dr m).length) true := by
  have hp : p < (Dr (m + 1)).length := by
    rw [len_Dr_succ]; omega
  rw [dW7_eq hp]
  simp only [Dr]
  rw [List.getD_append_right _ _ _ _ h1]

theorem exists_block : ∀ K p : ℕ, p < (Dr K).length →
    ∃ m, (Dr m).length ≤ p ∧ p < (Dr (m + 1)).length
  | 0, p, h => by simp [Dr] at h
  | K + 1, p, h => by
      by_cases hp : p < (Dr K).length
      · exact exists_block K p hp
      · exact ⟨K, by omega, h⟩

theorem blk_zero (m : ℕ) : (blk m).getD 0 true = true := by
  simp [blk]

theorem blk_succ (m i : ℕ) (hi : i < (u (m + 1)).length) :
    (blk m).getD (i + 1) true = (u (m + 1)).getD i true := by
  simp only [blk, List.getD_cons_succ]
  exact List.getD_append _ _ _ _ hi

theorem blk_b1 (m : ℕ) : (blk m).getD ((u (m + 1)).length + 1) true = true := by
  simp only [blk, List.getD_cons_succ]
  rw [List.getD_append_right _ _ _ _ (show (u (m + 1)).length ≤ (u (m + 1)).length from le_rfl)]
  simp

theorem blk_b2 (m : ℕ) : (blk m).getD ((u (m + 1)).length + 2) true = false := by
  simp only [blk, List.getD_cons_succ]
  rw [List.getD_append_right _ _ _ _ (show (u (m + 1)).length ≤ (u (m + 1)).length + 1 by omega)]
  simp

theorem blk_b3 (m : ℕ) : (blk m).getD ((u (m + 1)).length + 3) true = false := by
  simp only [blk, List.getD_cons_succ]
  rw [List.getD_append_right _ _ _ _ (show (u (m + 1)).length ≤ (u (m + 1)).length + 2 by omega)]
  simp

theorem u_noBB (m j : ℕ) :
    ¬ ((u m).getD j true = false ∧ (u m).getD (j + 1) true = false) := by
  rintro ⟨h1, h2⟩
  by_cases hj : j + 1 < (u m).length
  · have hc := (List.isChain_iff_getElem.mp (u_chain m)) j hj
    have e1 : (u m).getD j true = (u m)[j]'(by omega) := List.getD_eq_getElem _ _ _
    have e2 : (u m).getD (j + 1) true = (u m)[j + 1] := List.getD_eq_getElem _ _ _
    exact hc ⟨by rw [← e1]; exact h1, by rw [← e2]; exact h2⟩
  · have h3 : (u m).getD (j + 1) true = true := by
      rw [List.getD_eq_default]
      omega
    rw [h3] at h2
    exact absurd h2 (by decide)

theorem blk_bb (m i : ℕ) (hi : i < (u (m + 1)).length + 4)
    (h1 : (blk m).getD i true = false) (h2 : (blk m).getD (i + 1) true = false) :
    i = (u (m + 1)).length + 2 := by
  rcases (show i = 0 ∨ (1 ≤ i ∧ i < (u (m + 1)).length) ∨ i = (u (m + 1)).length ∨
      i = (u (m + 1)).length + 1 ∨ i = (u (m + 1)).length + 2 ∨
      i = (u (m + 1)).length + 3 by omega) with h | h | h | h | h | h
  · subst h
    rw [blk_zero] at h1
    exact absurd h1 (by decide)
  · obtain ⟨j, rfl⟩ : ∃ j, i = j + 1 := ⟨i - 1, by omega⟩
    rw [blk_succ m j (by omega)] at h1
    by_cases hj : j + 1 < (u (m + 1)).length
    · rw [blk_succ m (j + 1) hj] at h2
      exact (u_noBB (m + 1) j ⟨h1, h2⟩).elim
    · have e : j + 1 + 1 = (u (m + 1)).length + 1 := by omega
      rw [e, blk_b1] at h2
      exact absurd h2 (by decide)
  · subst h
    rw [blk_b1] at h2
    exact absurd h2 (by decide)
  · subst h
    rw [blk_b1] at h1
    exact absurd h1 (by decide)
  · exact h
  · subst h
    have h3 : (blk m).getD ((u (m + 1)).length + 3 + 1) true = true := by
      rw [List.getD_eq_default]
      simp [len_blk]
    rw [h3] at h2
    exact absurd h2 (by decide)

def aBB (m : ℕ) : ℕ := (Dr m).length + (u (m + 1)).length + 2

theorem dW7_bb_iff (p : ℕ) :
    (dW7 p = false ∧ dW7 (p + 1) = false) ↔ ∃ m, p = aBB m := by
  constructor
  · rintro ⟨h1, h2⟩
    have hp : p < (Dr (p + 1)).length := by
      have := four_mul_le_len_Dr (p + 1)
      omega
    obtain ⟨m, hm1, hm2⟩ := exists_block (p + 1) p hp
    rw [len_Dr_succ] at hm2
    have hd1 := dW7_block hm1 hm2
    by_cases hq : p + 1 < (Dr m).length + (u (m + 1)).length + 4
    · have hd2 := dW7_block (m := m) (by omega) hq
      rw [hd1] at h1
      rw [hd2, show p + 1 - (Dr m).length = p - (Dr m).length + 1 by omega] at h2
      have hi := blk_bb m (p - (Dr m).length) (by omega) h1 h2
      exact ⟨m, by unfold aBB; omega⟩
    · have hq' : p + 1 = (Dr (m + 1)).length := by
        rw [len_Dr_succ]; omega
      have h3 : dW7 (p + 1) = true := by
        rw [dW7_block (m := m + 1) (by omega) (by omega),
          show p + 1 - (Dr (m + 1)).length = 0 by omega, blk_zero]
      rw [h3] at h2
      exact absurd h2 (by decide)
  · rintro ⟨m, rfl⟩
    have h1 : (Dr m).length ≤ aBB m := by unfold aBB; omega
    have h2 : aBB m < (Dr m).length + (u (m + 1)).length + 4 := by unfold aBB; omega
    have h3 : (Dr m).length ≤ aBB m + 1 := by unfold aBB; omega
    have h4 : aBB m + 1 < (Dr m).length + (u (m + 1)).length + 4 := by unfold aBB; omega
    have e1 : aBB m - (Dr m).length = (u (m + 1)).length + 2 := by unfold aBB; omega
    have e2 : aBB m + 1 - (Dr m).length = (u (m + 1)).length + 3 := by unfold aBB; omega
    constructor
    · rw [dW7_block h1 h2, e1, blk_b2]
    · rw [dW7_block h3 h4, e2, blk_b3]

theorem rep_mem_allW : ∀ n : ℕ, List.replicate n true ∈ allW n
  | 0 => by simp [allW]
  | n + 1 => by
      simp only [allW, List.mem_flatMap]
      exact ⟨List.replicate n true, rep_mem_allW n, by simp [List.replicate_succ]⟩

theorem noBBl_rep : ∀ n : ℕ, noBBl (List.replicate n true) = true
  | 0 => rfl
  | n + 1 => by
      simp only [List.replicate_succ, noBBl]
      exact noBBl_rep n

theorem len_le_uF : ∀ (ws : List (List Bool)) (w : List Bool), w ∈ ws →
    w.length ≤ (uF ws).length
  | [], _, h => absurd h (by simp)
  | [v], w, h => by
      simp at h
      subst h
      simp [uF]
  | v :: v' :: ws, w, h => by
      simp only [uF, List.length_append, List.length_cons]
      rcases List.mem_cons.1 h with rfl | h'
      · omega
      · have := len_le_uF (v' :: ws) w h'
        omega

theorem bl_ge (m : ℕ) : m + 1 ≤ (u (m + 1)).length := by
  have hmem : List.replicate (m + 1) true ∈ wl (m + 1) :=
    List.mem_filter.2 ⟨rep_mem_allW (m + 1), noBBl_rep _⟩
  have := len_le_uF (wl (m + 1)) _ hmem
  simp only [List.length_replicate] at this
  exact this

theorem aBB_succ (m : ℕ) : aBB (m + 1) = aBB m + (u (m + 1 + 1)).length + 4 := by
  unfold aBB
  rw [len_Dr_succ]
  omega

theorem aBB_strictMono : StrictMono aBB :=
  strictMono_nat_of_lt_succ (fun m => by rw [aBB_succ]; omega)

theorem aBB_ge (m : ℕ) : m ≤ aBB m := by
  unfold aBB
  have := four_mul_le_len_Dr m
  omega

theorem hgap_dW7 : ∀ L : ℕ, ∃ P : ℕ, ∀ a b : ℕ, P ≤ a → a < b → dW7 a = false →
    dW7 (a + 1) = false → dW7 b = false → dW7 (b + 1) = false → L < b - a := by
  intro L
  refine ⟨aBB L, fun a b hPa hab ha1 ha2 hb1 hb2 => ?_⟩
  obtain ⟨m, rfl⟩ := (dW7_bb_iff a).1 ⟨ha1, ha2⟩
  obtain ⟨m', rfl⟩ := (dW7_bb_iff b).1 ⟨hb1, hb2⟩
  have hLm : L ≤ m := aBB_strictMono.le_iff_le.1 hPa
  have hmm : m < m' := aBB_strictMono.lt_iff_lt.1 hab
  have h1 := aBB_strictMono.monotone (show m + 1 ≤ m' from hmm)
  have h2 := aBB_succ m
  have h3 := bl_ge (m + 1)
  omega

theorem hinf_dW7 : ∀ n : ℕ, ∃ a b : ℕ, n ≤ a ∧ a < b ∧ dW7 a = false ∧ dW7 (a + 1) = false ∧
    dW7 b = false ∧ dW7 (b + 1) = false := by
  intro n
  obtain ⟨h1, h2⟩ := (dW7_bb_iff (aBB n)).2 ⟨n, rfl⟩
  obtain ⟨h3, h4⟩ := (dW7_bb_iff (aBB (n + 1))).2 ⟨n + 1, rfl⟩
  exact ⟨aBB n, aBB (n + 1), aBB_ge n, aBB_strictMono (Nat.lt_succ_self n), h1, h2, h3, h4⟩

theorem chain_noBBl : ∀ w : List Bool, List.IsChain bbOK w → noBBl w = true
  | [], _ => rfl
  | [x], _ => by cases x <;> rfl
  | x :: y :: t, h => by
      obtain ⟨hxy, ht⟩ := List.isChain_cons.1 h
      have hxy' : bbOK x y := hxy y (by simp)
      have ih := chain_noBBl (y :: t) ht
      cases x <;> cases y <;> simp_all [noBBl, bbOK]

theorem mem_allW : ∀ (n : ℕ) (w : List Bool), w.length = n → w ∈ allW n
  | 0, w, h => by
      cases w with
      | nil => simp [allW]
      | cons a t => simp at h
  | n + 1, w, h => by
      cases w with
      | nil => simp at h
      | cons a t =>
          have ht : t ∈ allW n := mem_allW n t (by simpa using h)
          simp only [allW, List.mem_flatMap]
          refine ⟨t, ht, ?_⟩
          cases a <;> simp

theorem head_rep_true : ∀ (k : ℕ) (b : Bool), b ∈ (List.replicate k true).head? → b = true
  | 0, b, h => by simp at h
  | k + 1, b, h => by simpa [List.replicate_succ] using h

theorem uF_infix : ∀ (ws : List (List Bool)) (w : List Bool), w ∈ ws →
    ∃ s t : List Bool, uF ws = s ++ w ++ t
  | [], _, h => absurd h (by simp)
  | [v], w, h => by
      simp at h
      subst h
      exact ⟨[], [], by simp [uF]⟩
  | v :: v' :: ws, w, h => by
      rcases List.mem_cons.1 h with h0 | h'
      · rw [h0]
        exact ⟨[], true :: uF (v' :: ws), by simp [uF]⟩
      · obtain ⟨s, t, hst⟩ := uF_infix (v' :: ws) w h'
        refine ⟨v ++ true :: s, t, ?_⟩
        simp only [uF, hst]
        simp

def wordX (x : Seq) (L M : ℕ) : List Bool :=
  List.map x (List.range L) ++ List.replicate (M + 1 - L) true

theorem dW7_pattern (x : Seq) (hx : Subit.W7A.noBB x) (L M : ℕ) (hLM : L ≤ M) :
    ∃ p, M ≤ p ∧ ∀ j < L, dW7 (p + j) = x j := by
  have hlen : (wordX x L M).length = M + 1 := by
    unfold wordX
    simp only [List.length_append, List.length_map, List.length_range, List.length_replicate]
    omega
  have hxs : List.IsChain bbOK (List.map x (List.range L)) := by
    rw [List.isChain_iff_getElem]
    intro i hi
    simp only [List.getElem_map, List.getElem_range]
    unfold bbOK
    exact hx i
  have hchain : List.IsChain bbOK (wordX x L M) := by
    unfold wordX
    refine List.isChain_append.2 ⟨hxs, ?_, ?_⟩
    · rw [List.isChain_iff_getElem]
      intro i hi
      simp [bbOK]
    · intro a _ b hb
      rw [head_rep_true _ _ hb]
      simp [bbOK]
  have hwl : wordX x L M ∈ wl (M + 1) :=
    List.mem_filter.2 ⟨mem_allW _ _ hlen, chain_noBBl _ hchain⟩
  obtain ⟨s, t, hst⟩ := uF_infix (wl (M + 1)) _ hwl
  have hu : u (M + 1) = s ++ wordX x L M ++ t := hst
  refine ⟨(Dr M).length + 1 + s.length, ?_, ?_⟩
  · have := four_mul_le_len_Dr M
    omega
  · intro j hj
    have hjW : j < (wordX x L M).length := by omega
    have hb : (u (M + 1)).length = s.length + (wordX x L M).length + t.length := by
      rw [hu]
      simp only [List.length_append]
    have hlt : (Dr M).length + 1 + s.length + j < (Dr M).length + (u (M + 1)).length + 4 := by
      omega
    have hge : (Dr M).length ≤ (Dr M).length + 1 + s.length + j := by omega
    have hpos : (Dr M).length + 1 + s.length + j - (Dr M).length = s.length + j + 1 := by
      omega
    rw [dW7_block hge hlt, hpos, blk_succ M (s.length + j) (by omega), hu]
    rw [List.getD_append (s ++ wordX x L M) t true (s.length + j)
      (by simp only [List.length_append]; omega)]
    rw [List.getD_append_right s (wordX x L M) true (s.length + j)
      (show s.length ≤ s.length + j by omega)]
    rw [show s.length + j - s.length = j by omega]
    have hmapLen : j < (List.map x (List.range L)).length := by
      simp only [List.length_map, List.length_range]
      omega
    unfold wordX
    rw [List.getD_append _ _ _ _ hmapLen]
    rw [List.getD_eq_getElem _ _ hmapLen]
    simp

theorem hpat_dW7 : ∀ x : Seq, Subit.W7A.noBB x →
    ∀ L N : ℕ, ∃ p, N ≤ p ∧ ∀ j < L, dW7 (p + j) = x j := by
  intro x hx L N
  obtain ⟨p, hp, hj⟩ := dW7_pattern x hx L (N + L) (by omega)
  exact ⟨p, by omega, hj⟩

/-- Перевірка застосовності: `have`-виклики абстрактних теорем з W7A з гіпотезами
`hgap_dW7`, `hinf_dW7`, `hpat_dW7` елаборуються для `dW7`. Сама по собі не є
математичним твердженням; результати — у `Subit.W7A.*` з підстановкою `dW7`. -/
theorem dW7_applicability : True := by
  have _h1 := Subit.W7A.omega_nonattained dW7 hgap_dW7 hinf_dW7
  have _h2 := Subit.W7A.omega_infinite dW7 hpat_dW7
  have _h3 := Subit.W7A.not_minOn_gen dW7 hpat_dW7
  have _h4 := Subit.W7A.htop_sub_strict_pos dW7 hpat_dW7
  trivial

end Subit.W7W
end
