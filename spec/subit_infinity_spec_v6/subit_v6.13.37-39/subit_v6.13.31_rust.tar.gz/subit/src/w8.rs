//! Перевірка оцінки складності з W8 (специфікація v6.13.1): для слова
//! d = lim w_k, w_0 = β, w_{k+1} = w_k α^{n_k} w_k, n_k = k+1, на префіксі
//! p_d(N) ≤ 2(2N+1)(N+2)(N+3). Це перевірка на префіксі, не доведення.

use std::collections::HashSet;

/// Префікс слова d довжини не менше `min_len` (символи: `false` = α, `true` = β).
pub fn w8_prefix(min_len: usize) -> Vec<bool> {
    let mut w = vec![true];
    let mut k = 0usize;
    while w.len() < min_len {
        let mut next = w.clone();
        next.extend(std::iter::repeat_n(false, k + 1));
        next.extend(w.iter().copied());
        w = next;
        k += 1;
    }
    w
}

/// Кількість різних підслів довжини `n` у `word`.
pub fn factor_count(word: &[bool], n: usize) -> usize {
    if n == 0 || n > word.len() {
        return 0;
    }
    let mut seen: HashSet<&[bool]> = HashSet::new();
    for w in word.windows(n) {
        seen.insert(w);
    }
    seen.len()
}

/// Оцінка з W8: 2(2N+1)(N+2)(N+3).
pub fn w8_bound(n: usize) -> usize {
    2 * (2 * n + 1) * (n + 2) * (n + 3)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn w8_complexity_bound_on_prefix() {
        let word = w8_prefix(1 << 15);
        for n in 1..=100 {
            let p = factor_count(&word, n);
            assert!(p <= w8_bound(n), "N = {n}: p = {p} > {}", w8_bound(n));
        }
    }

    #[test]
    fn w8_prefix_starts_with_w1() {
        // w_1 = β α β; префікс починається з w_0 = β
        let w = w8_prefix(10);
        assert!(w[0]);
    }
}
