//! §2: SUBIT⁺ — скінченна динаміка з правилом у стані: D₀(s, ρ) = (ρ(s), g₀(ρ, s)).

use crate::orbit::Dynamics;

/// Правило ρ : S₀ → S₀ (таблиця з 64 значень-кодів).
pub type Rule = [u8; 64];

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum PlusError {
    /// ℛ_fin має бути непорожньою.
    EmptyRules,
    /// Довжини `rules` і `g` різні.
    LengthMismatch,
    /// Значення правила поза [0, 64).
    BadRuleValue,
    /// g₀ повертає індекс правила поза ℛ_fin.
    BadRuleIndex,
    /// Автомат має більше 64 станів.
    TooManyStates,
    /// δ виходить за межі, або ι не ін'єктивна / виходить за S₀.
    BadAutomaton,
}

/// SUBIT⁺: правила й метаеволюція `g[r][s]` (індекс нового правила).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Plus {
    rules: Vec<Rule>,
    g: Vec<[u16; 64]>,
}

impl Plus {
    pub fn new(rules: Vec<Rule>, g: Vec<[u16; 64]>) -> Result<Plus, PlusError> {
        if rules.is_empty() {
            return Err(PlusError::EmptyRules);
        }
        if rules.len() != g.len() {
            return Err(PlusError::LengthMismatch);
        }
        if rules.iter().any(|r| r.iter().any(|&v| v >= 64)) {
            return Err(PlusError::BadRuleValue);
        }
        if g.iter()
            .any(|row| row.iter().any(|&i| usize::from(i) >= rules.len()))
        {
            return Err(PlusError::BadRuleIndex);
        }
        Ok(Plus { rules, g })
    }

    pub fn num_rules(&self) -> usize {
        self.rules.len()
    }

    /// Індекс розширеного стану (s, r) у Q₀ = S₀ × ℛ_fin: r·64 + s.
    pub fn encode(s: u8, r: usize) -> usize {
        r * 64 + usize::from(s)
    }
    pub fn decode(q: usize) -> (u8, usize) {
        ((q % 64) as u8, q / 64)
    }

    /// D₀(s, ρ) = (ρ(s), g₀(ρ, s)).
    pub fn step_pair(&self, s: u8, r: usize) -> (u8, usize) {
        (
            self.rules[r][usize::from(s)],
            usize::from(self.g[r][usize::from(s)]),
        )
    }

    /// A4: автономний автомат (Q, δ) з #Q ≤ 64 і ін'єкцією ι : Q → S₀ вкладається в SUBIT⁺
    /// з єдиним правилом ρ(ι q) = ι(δ q); поза образом ρ(s) = s₀ = 0 (довільно).
    pub fn embed_automaton(delta: &[usize], iota: &[u8]) -> Result<Plus, PlusError> {
        let n = delta.len();
        if n > 64 {
            return Err(PlusError::TooManyStates);
        }
        if iota.len() != n || delta.iter().any(|&d| d >= n) || iota.iter().any(|&c| c >= 64) {
            return Err(PlusError::BadAutomaton);
        }
        let mut seen = [false; 64];
        for &c in iota {
            if seen[usize::from(c)] {
                return Err(PlusError::BadAutomaton);
            }
            seen[usize::from(c)] = true;
        }
        let mut rho: Rule = [0; 64];
        for (q, &dq) in delta.iter().enumerate() {
            rho[usize::from(iota[q])] = iota[dq];
        }
        Plus::new(vec![rho], vec![[0u16; 64]])
    }
}

impl Plus {
    /// A4 для 1 ≤ n ≤ 64^63 (версія з мітками; у v6.12 — «довільного n», застаріло з v6.13.25). Нехай t — найменше таке, що 64^t ≥ k,
    /// де k = ⌈n/m⌉, m = 64 − t. Стан q кодується як (s, ℓ) = (q mod m, q div m); правило ℓ
    /// задає ρ_ℓ(q mod m) = (δq) mod m, а на останніх t значеннях S₀ записує мітку ℓ у базі 64.
    /// Оскільки мітки різні, ρ_ℓ попарно різні як функції, тож ℛ_fin є множиною з k елементів.
    /// Тоді D₀(ι q) = ι(δ q) для q < n, де ι q := encode(q mod m, q div m).
    pub fn embed_any(delta: &[usize]) -> Result<Plus, PlusError> {
        let n = delta.len();
        if n == 0 || delta.iter().any(|&d| d >= n) {
            return Err(PlusError::BadAutomaton);
        }
        let mut t = 0usize;
        let (m, k) = loop {
            let m = 64 - t;
            let k = n.div_ceil(m);
            if 64usize.pow(t as u32) >= k {
                break (m, k);
            }
            t += 1;
        };
        let mut rules = vec![[0u8; 64]; k];
        let mut g = vec![[0u16; 64]; k];
        for (q, &dq) in delta.iter().enumerate() {
            let (l, s) = (q / m, q % m);
            rules[l][s] = (dq % m) as u8;
            g[l][s] = (dq / m) as u16;
        }
        for (l, rule) in rules.iter_mut().enumerate() {
            for j in 0..t {
                rule[64 - t + j] = ((l / 64usize.pow(j as u32)) % 64) as u8;
            }
        }
        Plus::new(rules, g)
    }

    /// Індекс ι(q) = encode(q mod m, q div m) для вкладення A4 з `embed_any`.
    pub fn embed_index(q: usize, n: usize) -> usize {
        let mut t = 0usize;
        let m = loop {
            let m = 64 - t;
            if 64usize.pow(t as u32) >= n.div_ceil(m) {
                break m;
            }
            t += 1;
        };
        Plus::encode((q % m) as u8, q / m)
    }
}

impl Dynamics for Plus {
    fn size(&self) -> usize {
        64 * self.rules.len()
    }
    fn step(&self, q: usize) -> usize {
        let (s, r) = Plus::decode(q);
        let (s2, r2) = self.step_pair(s, r);
        Plus::encode(s2, r2)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::orbit::{classify_exact, iterate, TableDyn};
    use crate::rng::Rng;

    /// E1: SUBIT⁺ — автономний автомат із 64·#ℛ станами; тотальність D₀.
    #[test]
    fn e1_total_automaton() {
        let mut rng = Rng::new(3);
        for _ in 0..50 {
            let nr = 1 + rng.below(4);
            let rules: Vec<Rule> = (0..nr)
                .map(|_| std::array::from_fn(|_| rng.below(64) as u8))
                .collect();
            let g: Vec<[u16; 64]> = (0..nr)
                .map(|_| std::array::from_fn(|_| rng.below(nr) as u16))
                .collect();
            let p = Plus::new(rules, g).unwrap();
            assert_eq!(p.size(), 64 * nr);
            for q in 0..p.size() {
                assert!(p.step(q) < p.size());
            }
        }
    }

    #[test]
    fn validation() {
        assert_eq!(Plus::new(vec![], vec![]), Err(PlusError::EmptyRules));
        assert_eq!(
            Plus::new(vec![[0; 64]], vec![]),
            Err(PlusError::LengthMismatch)
        );
        assert_eq!(
            Plus::new(vec![[64; 64]], vec![[0; 64]]),
            Err(PlusError::BadRuleValue)
        );
        assert_eq!(
            Plus::new(vec![[0; 64]], vec![[1; 64]]),
            Err(PlusError::BadRuleIndex)
        );
    }

    /// A4: траєкторії автомата й образу в SUBIT⁺ збігаються (індукція за n перевіряється для n ≤ 3·|Q|).
    #[test]
    fn a4_embedding_random() {
        let mut rng = Rng::new(11);
        for _ in 0..200 {
            let n = 1 + rng.below(64);
            let delta: Vec<usize> = (0..n).map(|_| rng.below(n)).collect();
            // ін'єкція ι : випадкова перестановка перших n із 64
            let mut codes: Vec<u8> = (0..64).collect();
            for i in (1..64).rev() {
                codes.swap(i, rng.below(i + 1));
            }
            let iota: Vec<u8> = codes[..n].to_vec();
            let p = Plus::embed_automaton(&delta, &iota).unwrap();
            let aut = TableDyn(delta.clone());
            for q in 0..n {
                for k in 0..(3 * n) {
                    let (s, r) = Plus::decode(iterate(&p, Plus::encode(iota[q], 0), k));
                    assert_eq!(r, 0);
                    assert_eq!(s, iota[iterate(&aut, q, k)]);
                }
            }
            // класифікація образу збігається з класифікацією автомата
            for (q, &c) in iota.iter().enumerate() {
                let a = classify_exact(&aut, q);
                let b = classify_exact(&p, Plus::encode(c, 0));
                assert_eq!((a.m, a.p), (b.m, b.p));
            }
        }
    }

    #[test]
    fn a4_rejects_bad_input() {
        assert_eq!(
            Plus::embed_automaton(&[0; 65], &[0; 65]),
            Err(PlusError::TooManyStates)
        );
        assert_eq!(
            Plus::embed_automaton(&[0, 1], &[5, 5]),
            Err(PlusError::BadAutomaton)
        );
        assert_eq!(
            Plus::embed_automaton(&[2], &[0]),
            Err(PlusError::BadAutomaton)
        );
    }
}

#[cfg(test)]
mod tests_any_size {
    use super::*;
    use crate::rng::Rng;

    /// A4 для 1 ≤ n ≤ 64^63: ι — ін'єкція, D₀∘ι = ι∘δ, ρ_ℓ попарно різні (ℛ_fin — множина).
    fn check(delta: &[usize]) {
        let n = delta.len();
        let p = Plus::embed_any(delta).expect("валідний автомат");
        let mut idx: Vec<usize> = (0..n).map(|q| Plus::embed_index(q, n)).collect();
        for (q, &dq) in delta.iter().enumerate() {
            assert_eq!(p.step(idx[q]), idx[dq], "n={n} q={q}");
        }
        idx.sort_unstable();
        idx.dedup();
        assert_eq!(idx.len(), n, "ι не ін'єктивна при n={n}");
        for a in 0..p.rules.len() {
            for b in (a + 1)..p.rules.len() {
                assert_ne!(
                    p.rules[a], p.rules[b],
                    "правила {a} і {b} збіглися при n={n}"
                );
            }
        }
    }

    #[test]
    fn a4_embedding_any_size() {
        let mut rng = Rng::new(20261019);
        for &n in &[1usize, 2, 63, 64, 65, 100, 128, 129, 200, 300] {
            for _ in 0..20 {
                let delta: Vec<usize> = (0..n).map(|_| rng.below(n)).collect();
                check(&delta);
            }
        }
    }

    /// Контрприклад для версії без міток: циклічний зсув на 128 станах.
    #[test]
    fn a4_cyclic_shift_regression() {
        for &n in &[128usize, 129, 4096] {
            let delta: Vec<usize> = (0..n).map(|q| (q + 1) % n).collect();
            check(&delta);
        }
    }

    #[test]
    fn a4_any_size_rejects_bad_input() {
        assert_eq!(Plus::embed_any(&[]), Err(PlusError::BadAutomaton));
        assert_eq!(Plus::embed_any(&[0, 2]), Err(PlusError::BadAutomaton));
    }
}
