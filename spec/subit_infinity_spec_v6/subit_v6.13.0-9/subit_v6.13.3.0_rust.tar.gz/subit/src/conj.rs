//! Твердження 7.8 (Q19) і скінченний аналог Q28b (v6.13.3).
//!
//! Об'єкт SUBIT_full на скінченних множинах: S = {0..ns}, ℛ = {0..nr}, `ev[r][s]` — значення
//! правила r на стані s, `g[r][s]` — значення g(ρ, s). Динаміка D(s, ρ) = (ev[ρ][s], g[ρ][s]).
//! Перевіряємо: (а) морфізм SUBIT_full спряжує динаміки; (б) приклад з різними g, що
//! ізоморфні; (в) скінченний аналог Q28b: g∞(κ_c, s) = κ_{T(c)} дає інваріантну P.

/// Скінченний об'єкт SUBIT_full.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FinObj {
    pub ns: usize,
    pub nr: usize,
    pub ev: Vec<Vec<usize>>, // ev[r][s]
    pub g: Vec<Vec<usize>>, // g[r][s]
}

impl FinObj {
    pub fn new(ns: usize, nr: usize, ev: Vec<Vec<usize>>, g: Vec<Vec<usize>>) -> Self {
        assert_eq!(ev.len(), nr);
        assert_eq!(g.len(), nr);
        FinObj { ns, nr, ev, g }
    }

    /// Динаміка D(s, ρ) := (ρ(s), g(ρ, s)).
    pub fn d(&self, s: usize, r: usize) -> (usize, usize) {
        (self.ev[r][s], self.g[r][s])
    }
}

/// Морфізм SUBIT_full: умови 7.2 і 7.3.
pub fn is_morphism(x: &FinObj, y: &FinObj, fs: &[usize], fr: &[usize]) -> bool {
    for r in 0..x.nr {
        for s in 0..x.ns {
            if fs[x.ev[r][s]] != y.ev[fr[r]][fs[s]] {
                return false;
            }
            if fr[x.g[r][s]] != y.g[fr[r]][fs[s]] {
                return false;
            }
        }
    }
    true
}

/// Ізоморфізм: пара морфізмів з тотожними композиціями на кожній компоненті.
pub fn is_iso(x: &FinObj, y: &FinObj, fs: &[usize], fr: &[usize], bs: &[usize], br: &[usize]) -> bool {
    is_morphism(x, y, fs, fr)
        && is_morphism(y, x, bs, br)
        && (0..x.ns).all(|s| bs[fs[s]] == s)
        && (0..x.nr).all(|r| br[fr[r]] == r)
        && (0..y.ns).all(|s| fs[bs[s]] == s)
        && (0..y.nr).all(|r| fr[br[r]] == r)
}

/// Спряження: Φ(s, ρ) := (fs[s], fr[ρ]) з D_Y∘Φ = Φ∘D_X.
pub fn is_conjugacy(x: &FinObj, y: &FinObj, fs: &[usize], fr: &[usize]) -> bool {
    (0..x.ns).all(|s| {
        (0..x.nr).all(|r| {
            let (ns_, nr_) = x.d(s, r);
            let lhs = y.d(fs[s], fr[r]);
            let rhs = (fs[ns_], fr[nr_]);
            lhs == rhs
        })
    })
}

/// Усі відображення {0..n} → {0..m} (для вичерпного перебору малих випадків).
pub fn all_maps(n: usize, m: usize) -> Vec<Vec<usize>> {
    let total = m.pow(n as u32);
    (0..total)
        .map(|mut k| {
            (0..n)
                .map(|_| {
                    let v = k % m;
                    k /= m;
                    v
                })
                .collect()
        })
        .collect()
}

/// Скінченний аналог Q28b. S = {0..n}, Y = S, T — підстановка (сюр'єктивна на Y=S),
/// ℛ_Y = {κ_c : c ∈ S} (κ_c(s) = c), g∞(κ_c, s) := κ_{T(c)}.
/// Повертає об'єкт і множину P = {(c, κ_{T(c)})} як пари (стан, правило).
pub fn q28b_finite(t: &[usize]) -> (FinObj, Vec<(usize, usize)>) {
    let n = t.len();
    // правила: індекс r = c; ev[r][s] = c; g[r][s] = T(c)
    let ev: Vec<Vec<usize>> = (0..n).map(|c| vec![c; n]).collect();
    let g: Vec<Vec<usize>> = (0..n).map(|c| vec![t[c]; n]).collect();
    let obj = FinObj::new(n, n, ev, g);
    let p: Vec<(usize, usize)> = (0..n).map(|c| (c, t[c])).collect();
    (obj, p)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Приклад Q19: S = ℛ = {0,1}, ev[r][s] = r, g_X ≡ 0 (ρ_a), g_Y ≡ 1 (ρ_b).
    fn objs() -> (FinObj, FinObj) {
        let ev = vec![vec![0, 0], vec![1, 1]];
        let gx = vec![vec![0, 0], vec![0, 0]];
        let gy = vec![vec![1, 1], vec![1, 1]];
        (FinObj::new(2, 2, ev.clone(), gx), FinObj::new(2, 2, ev, gy))
    }

    #[test]
    fn q19_example_is_iso_with_different_g() {
        let (x, y) = objs();
        assert_ne!(x.g, y.g);
        let swap = vec![1, 0];
        assert!(is_iso(&x, &y, &swap, &swap, &swap, &swap));
        assert!(is_conjugacy(&x, &y, &swap, &swap));
    }

    #[test]
    fn q19_identity_is_not_iso_for_different_g() {
        let (x, y) = objs();
        let id = vec![0, 1];
        assert!(!is_morphism(&x, &y, &id, &id));
    }

    /// (а) Вичерпно для |S| = |ℛ| ≤ 2: кожен морфізм-ізоморфізм є спряженням.
    #[test]
    fn iso_implies_conjugacy_exhaustive_small() {
        for ns in 1..=2 {
            for nr in 1..=2 {
                let mut objects = Vec::new();
                for ev in all_maps_grid(nr, ns, ns) {
                    for g in all_maps_grid(nr, ns, nr) {
                        objects.push(FinObj::new(ns, nr, ev.clone(), g));
                    }
                }
                for x in &objects {
                    for y in &objects {
                        for fs in all_maps(ns, ns) {
                            for fr in all_maps(nr, nr) {
                                for bs in all_maps(ns, ns) {
                                    for br in all_maps(nr, nr) {
                                        if is_iso(x, y, &fs, &fr, &bs, &br) {
                                            assert!(is_conjugacy(x, y, &fs, &fr));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /// Матриця ev або g: nr рядків по ns стовпців із значеннями в {0..m}.
    fn all_maps_grid(nr: usize, ns: usize, m: usize) -> Vec<Vec<Vec<usize>>> {
        let flat = all_maps(nr * ns, m);
        flat.into_iter()
            .map(|v| v.chunks(ns).map(|c| c.to_vec()).collect())
            .collect()
    }

    /// (б) Скінченний аналог Q28b: для всіх перестановок T на {0..n}, n ≤ 4,
    /// P = {(c, κ_{T(c)})} інваріантна, і D(x) = x лише там, де T(c) = c.
    #[test]
    fn q28b_finite_invariant_set() {
        for n in 1..=4 {
            for t in all_maps(n, n) {
                // T — сюр'єкція (на скінченному Y = S це перестановка)
                let mut seen = vec![false; n];
                for &v in &t {
                    seen[v] = true;
                }
                if seen.iter().any(|&b| !b) {
                    continue;
                }
                let (obj, p) = q28b_finite(&t);
                for &(c, r) in &p {
                    // D(c, κ_r) = (κ_r(c), g(κ_r, c)) = (r, κ_{T(r)})
                    let (s1, r1) = obj.d(c, r);
                    assert_eq!(s1, r);
                    assert!(p.contains(&(s1, r1)), "P не інваріантна");
                    if t[c] != c {
                        assert_ne!((s1, r1), (c, r), "неподвижна точка там, де T(c) ≠ c");
                    }
                }
            }
        }
    }

    /// (в) Скінченний аналог: умова Q28b не порушує D4 (g не дорівнює π_R при T ≠ id).
    #[test]
    fn q28b_finite_is_not_pi_r_when_t_nontrivial() {
        let t = vec![1, 0];
        let (obj, _) = q28b_finite(&t);
        let pi_r = |r: usize| r;
        assert!((0..obj.nr).any(|r| obj.g[r][0] != pi_r(r)));
    }
}
