//! Min_D(P) для скінченних систем (§4.3, Означення 4.3.1) і перевірка C3(a), C3(c) (§4.5).
//!
//! Для скінченних P передумови (Π1) і (Π3) виконані автоматично; перевіряється (Π2): D[P] = P.
//! MINIMAL означає: немає власної непорожньої Q ⊊ P з D[Q] ⊆ Q (перебір усіх Q).

use crate::orbit::Dynamics;
use crate::sets::{img, Set};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum MinStatus {
    NotApplicable,
    Minimal,
    NonMinimal,
}

/// Min_D(P) для скінченної P (перебір усіх підмножин; придатно для малих систем).
pub fn min_status<D: Dynamics>(d: &D, p: &Set) -> MinStatus {
    if !p.iter().any(|&b| b) || img(d, p) != *p {
        return MinStatus::NotApplicable;
    }
    let members: Vec<usize> = (0..d.size()).filter(|&x| p[x]).collect();
    let k = members.len();
    for mask in 1..((1usize << k) - 1) {
        let mut q = vec![false; d.size()];
        for (i, &x) in members.iter().enumerate() {
            if mask >> i & 1 == 1 {
                q[x] = true;
            }
        }
        let invariant = img(d, &q).iter().zip(q.iter()).all(|(&im, &qq)| !im || qq);
        if invariant {
            return MinStatus::NonMinimal;
        }
    }
    MinStatus::Minimal
}

/// P — одна періодична орбіта: D циклічно переставляє P (за умови D[P] ⊆ P).
pub fn is_single_cycle<D: Dynamics>(d: &D, p: &Set) -> bool {
    let members: Vec<usize> = (0..d.size()).filter(|&x| p[x]).collect();
    let k = members.len();
    if k == 0 {
        return false;
    }
    let x0 = members[0];
    let mut seen = vec![false; d.size()];
    let mut cur = x0;
    for _ in 0..k {
        if !p[cur] || seen[cur] {
            return false;
        }
        seen[cur] = true;
        cur = d.step(cur);
    }
    cur == x0
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::orbit::TableDyn;
    use crate::sets::{inclusion_type, orbit_type, Inclusion, OrbitType};

    /// Усі відображення f: {0..n-1} → {0..n-1} і всі непорожні P ⊆ S, n ≤ 4.
    fn for_all_systems(max_n: usize, mut check: impl FnMut(&TableDyn, &Set)) {
        for n in 1..=max_n {
            for code in 0..n.pow(n as u32) {
                let table: Vec<usize> = (0..n).map(|i| (code / n.pow(i as u32)) % n).collect();
                let d = TableDyn(table);
                for mask in 1..(1usize << n) {
                    let p: Set = (0..n).map(|i| mask >> i & 1 == 1).collect();
                    check(&d, &p);
                }
            }
        }
    }

    #[test]
    fn minimal_iff_single_cycle_exhaustive() {
        for_all_systems(4, |d, p| {
            let s = min_status(d, p);
            if img(d, p) != *p {
                assert_eq!(s, MinStatus::NotApplicable, "d={:?} p={:?}", d.0, p);
            } else {
                let minimal = s == MinStatus::Minimal;
                assert_eq!(minimal, is_single_cycle(d, p), "d={:?} p={:?}", d.0, p);
            }
        });
    }

    /// C3(c): Min = MINIMAL ⇒ OrbitType ∈ {INVARIANT_FIXED, INVARIANT_DYNAMIC}.
    #[test]
    fn c3c_minimal_implies_invariant_exhaustive() {
        for_all_systems(4, |d, p| {
            if min_status(d, p) == MinStatus::Minimal {
                let t = orbit_type(d, p);
                assert!(
                    t == OrbitType::InvFixed || t == OrbitType::InvDynamic,
                    "d={:?} p={:?} type={:?}",
                    d.0,
                    p,
                    t
                );
            }
        });
    }

    /// C3(a): InclusionType = EQUAL_IMAGE ⇔ OrbitType ∈ {INVARIANT_FIXED, INVARIANT_DYNAMIC}.
    #[test]
    fn c3a_equal_image_iff_invariant_exhaustive() {
        for_all_systems(4, |d, p| {
            let equal = inclusion_type(d, p) == Inclusion::EqualImage;
            let t = orbit_type(d, p);
            let invariant = t == OrbitType::InvFixed || t == OrbitType::InvDynamic;
            assert_eq!(equal, invariant, "d={:?} p={:?}", d.0, p);
        });
    }

    #[test]
    fn examples() {
        // 2-цикл: мінімальна
        let cyc = TableDyn(vec![1, 0]);
        assert_eq!(min_status(&cyc, &vec![true, true]), MinStatus::Minimal);
        // нерухома точка плюс 2-цикл: неминімальна (власна Q = {2})
        let d = TableDyn(vec![1, 0, 2]);
        assert_eq!(
            min_status(&d, &vec![true, true, true]),
            MinStatus::NonMinimal
        );
        // P = {0,1} — лише 2-цикл, мінімальна
        assert_eq!(min_status(&d, &vec![true, true, false]), MinStatus::Minimal);
        // D[P] ≠ P: NOT_APPLICABLE, а не NON_MINIMAL
        let e = TableDyn(vec![1, 1]);
        assert_eq!(min_status(&e, &vec![true, false]), MinStatus::NotApplicable);
        assert_ne!(min_status(&e, &vec![true, false]), MinStatus::NonMinimal);
    }
}
