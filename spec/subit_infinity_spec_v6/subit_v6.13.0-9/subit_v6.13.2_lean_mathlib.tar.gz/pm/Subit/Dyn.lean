import Subit.CatSub
import Mathlib.CategoryTheory.Functor.FullyFaithful
/-!
# SUBIT-∞ v6.11.5 — K2 у SUBIT_full, категорія Dyn (8.1) і вкладення K5 (8.6)
-/
open CategoryTheory CategoryTheory.Limits
namespace Subit.CatSub

/-- K2 у SUBIT_full: 1 — термінальний (R одноточкова, тож g-умова тривіальна). -/
theorem K2_full : Nonempty (IsTerminal (fullObj term)) :=
  ⟨IsTerminal.ofUniqueHom
    (fun X => (⟨toTerm X.toObj, fun ρ s => Subtype.ext
      (Set.eq_of_mem_singleton (toTerm X.toObj |>.fR _).2 |>.trans
        (Set.eq_of_mem_singleton (term.g _ _).2).symm)⟩ : SFObj.mk X.toObj ⟶ fullObj term))
    (fun X φ => by
      apply SFHom.ext
      · funext s; rfl
      · funext r
        apply Subtype.ext
        exact (Set.eq_of_mem_singleton (φ.toHom.fR r).2).trans
          (Set.eq_of_mem_singleton (toTerm X.toObj |>.fR r).2).symm)⟩

/-! ## Dyn -/

structure DynObj where
  S : Type
  f : S → S

structure DynHom (X Y : DynObj) where
  φ : X.S → Y.S
  comm : ∀ s, φ (X.f s) = Y.f (φ s)

@[ext] theorem DynHom.ext {X Y : DynObj} {a b : DynHom X Y} (h : a.φ = b.φ) : a = b := by
  cases a; cases b; simp at h; subst h; rfl

/-- Означення 8.1: Dyn — категорія. -/
instance : Category DynObj where
  Hom := DynHom
  id X := ⟨id, fun _ => rfl⟩
  comp a b := ⟨b.φ ∘ a.φ, fun s => by
    show b.φ (a.φ (_)) = _
    rw [a.comm, b.comm]; rfl⟩
  id_comp _ := rfl
  comp_id _ := rfl
  assoc _ _ _ := rfl

/-- Dyn₊: повна підкатегорія з непорожніми S. -/
structure DynPlus where
  toDyn : DynObj
  hS : Nonempty toDyn.S

instance : Category DynPlus where
  Hom X Y := DynHom X.toDyn Y.toDyn
  id X := ⟨id, fun _ => rfl⟩
  comp a b := ⟨b.φ ∘ a.φ, fun s => by
    show b.φ (a.φ (_)) = _
    rw [a.comm, b.comm]; rfl⟩
  id_comp _ := rfl
  comp_id _ := rfl
  assoc _ _ _ := rfl

/-- K5: E(S, f) = (S, {f}, g_f), g_f(f, s) = f. -/
def Eobj (X : DynPlus) : SObj where
  S := X.toDyn.S
  hS := X.hS
  R := {X.toDyn.f}
  hR := ⟨_, rfl⟩
  g := fun r _ => r

instance (X : DynPlus) : Subsingleton (Eobj X).R :=
  ⟨fun a b => Subtype.ext ((Set.eq_of_mem_singleton a.2).trans (Set.eq_of_mem_singleton b.2).symm)⟩

def EhomS {X Y : DynPlus} (a : X ⟶ Y) : Eobj X ⟶ Eobj Y :=
  ⟨a.φ, fun _ => ⟨Y.toDyn.f, rfl⟩, fun ρ s => by
    have : ρ.1 = X.toDyn.f := Set.eq_of_mem_singleton ρ.2
    show a.φ (ρ.1 s) = Y.toDyn.f (a.φ s)
    rw [this]; exact a.comm s⟩

/-- K5: функтор E : Dyn₊ → SUBIT. -/
def E : DynPlus ⥤ SObj where
  obj := Eobj
  map a := EhomS a
  map_id _ := SHom.ext rfl (funext fun _ => Subsingleton.elim _ _)
  map_comp _ _ := SHom.ext rfl (funext fun _ => Subsingleton.elim _ _)

/-- ... і Dyn₊ → SUBIT_full (умова 7.3 тривіальна, бо ℛ одноелементна). -/
def EF : DynPlus ⥤ SFObj where
  obj X := fullObj (Eobj X)
  map a := ⟨EhomS a, fun _ _ => Subsingleton.elim _ _⟩
  map_id _ := SFHom.ext rfl (funext fun _ => Subsingleton.elim _ _)
  map_comp _ _ := SFHom.ext rfl (funext fun _ => Subsingleton.elim _ _)

/-- K5: E вірний. -/
instance : E.Faithful where
  map_injective {X Y} a b h := by
    apply DynHom.ext
    have := congrArg SHom.fS h
    exact this

/-- K5: E повний. -/
instance : E.Full where
  map_surjective {X Y} ψ := by
    let φ : X.toDyn.S → Y.toDyn.S := ψ.fS
    have hc : ∀ s, φ (X.toDyn.f s) = Y.toDyn.f (φ s) := by
      intro s
      have h := ψ.comm ⟨X.toDyn.f, rfl⟩ s
      have h2 : (ψ.fR ⟨X.toDyn.f, rfl⟩).1 = Y.toDyn.f := Set.eq_of_mem_singleton (ψ.fR _).2
      rw [h2] at h; exact h
    have hsub : ∀ a b : (Eobj Y).R, a = b := fun a b => Subsingleton.elim a b
    exact ⟨⟨φ, hc⟩, SHom.ext rfl (funext fun r => hsub _ _)⟩

instance : EF.Faithful where
  map_injective {X Y} a b h := by
    apply DynHom.ext
    have := congrArg (fun t => t.toHom.fS) h
    exact this

instance : EF.Full where
  map_surjective {X Y} ψ := by
    obtain ⟨a, ha⟩ := (inferInstance : E.Full).map_surjective (ψ.toHom : E.obj X ⟶ E.obj Y)
    exact ⟨a, SFHom.ext (congrArg SHom.fS ha) (congrArg SHom.fR ha)⟩

end Subit.CatSub
