import Mathlib.Order.Heyting.Basic
import Mathlib.Order.Fin.Basic
import Mathlib.Data.Set.Finite.Basic
import Mathlib.GroupTheory.OrderOfElement
import Mathlib.Data.ENat.Basic
import Mathlib.Data.ENat.Lattice
import Subit.D6
import Subit.Sets
import Subit.Omega
/-!
# SUBIT-∞ v6.11.5 — дискретний залишок I: Гейтінг Ω (повністю), C3, C4a, χ_U (8.3–8.4)
-/
open Classical
namespace Subit

/-! ## C6 повністю: Ω = Fin 6 є алгеброю Гейтінга, з → як у означенні 5.7 -/

/-- Ω — шестиелементний ланцюг (0 = CHAOTIC_set, …, 5 = INVARIANT_FIXED). -/
abbrev Om := Fin 6

/-- Імплікація Mathlib збігається з означенням 5.7: a → b = ⊤, якщо a ≤ b, інакше b. -/
theorem Om_himp (a b : Om) : a ⇨ b = if a ≤ b then ⊤ else b := by decide +revert

/-- Узгодженість із Nat-моделлю `imp` (Omega.lean). -/
theorem Om_himp_imp (a b : Om) : ((a ⇨ b : Om) : ℕ) = imp a b := by
  revert a b; decide

theorem Om_heyting_adjunction (a b c : Om) : a ⊓ c ≤ b ↔ c ≤ a ⇨ b := by
  rw [le_himp_iff, inf_comm]

/-- Виключене третє не виконується в Ω. -/
theorem Om_no_excluded_middle : ∃ a : Om, a ⊔ aᶜ ≠ ⊤ := ⟨1, by decide⟩

/-! ## C3 -/

section C3
variable {α : Type*}

theorem imgN_of_eq (D : α → α) (P : α → Prop) (h : ∀ y, img D P y ↔ P y) (n : ℕ) :
    imgN D n P = P := by
  induction n with
  | zero => rfl
  | succ n ih =>
    show img D (imgN D n P) = P
    rw [ih]; exact funext fun y => propext (h y)

/-- C3(а): InclusionType = EQUAL_IMAGE ⇔ OrbitType ∈ {INVARIANT_FIXED, INVARIANT_DYNAMIC}. -/
theorem C3a (D : α → α) (P : α → Prop) :
    EQ_IMAGE D P ↔ OTpred D P .invFixed ∨ OTpred D P .invDynamic := by
  constructor
  · intro h
    have hμ : Mu D P 0 := by
      refine ⟨⟨1, by omega, ?_⟩, fun m hm => absurd hm (by omega)⟩
      rw [imgN_of_eq D P h 1, imgN_zero]
    by_cases hf : ∀ x, P x → D x = x
    · exact Or.inl ⟨hμ, h, hf⟩
    · refine Or.inr ⟨hμ, h, ?_⟩
      exact Classical.byContradiction fun hn =>
        hf fun x hx => Classical.byContradiction fun hd => hn ⟨x, hx, hd⟩
  · rintro (h | h) <;> exact h.2.1

/-- Тотожне відображення на P: D x = x для x ∈ P ⇒ EQ_IMAGE. -/
theorem EQ_of_fixed (D : α → α) (P : α → Prop) (h : ∀ x, P x → D x = x) : EQ_IMAGE D P :=
  fun y => ⟨fun ⟨x, hx, hxy⟩ => by rw [← hxy, h x hx]; exact hx,
    fun hy => ⟨y, hy, h y hy⟩⟩

end C3

/-- Ентропія тотожного відображення дорівнює 0 (для довільної функції відстані). -/
theorem iter_id {X : Type*} (n : ℕ) (x : X) : iter (id : X → X) n x = x := by
  induction n with
  | zero => rfl
  | succ n ih => simp [iter, ih]

theorem htop_id {X : Type*} (d : X → X → ℝ) : htop d (id : X → X) = 0 := by
  apply htop_eq_zero_of_bound
  intro ε _
  refine ⟨max 1 (sepNum d id 1 ε), fun n => ?_⟩
  rcases Nat.eq_zero_or_pos n with rfl | hn
  · refine le_trans (sepNum_le 1 ?_) (le_max_left _ _)
    intro S hS
    by_contra hlt
    simp only [not_le] at hlt
    obtain ⟨x, hx, y, hy, hxy⟩ := Finset.one_lt_card.1 hlt
    obtain ⟨i, hi, _⟩ := hS x hx y hy hxy
    omega
  · refine le_trans ?_ (le_max_right _ _)
    have hiff : ∀ S : Finset X, IsSep d (id : X → X) n ε S ↔ IsSep d (id : X → X) 1 ε S := by
      intro S
      constructor
      · intro h x hx y hy hxy
        obtain ⟨i, _, hi⟩ := h x hx y hy hxy
        exact ⟨0, by omega, by simpa [iter_id] using hi⟩
      · intro h x hx y hy hxy
        obtain ⟨i, _, hi⟩ := h x hx y hy hxy
        exact ⟨0, hn, by simpa [iter_id] using hi⟩
    have : sepNum d (id : X → X) n ε = sepNum d (id : X → X) 1 ε := by
      unfold sepNum
      congr 1
      ext k
      simp only [Set.mem_setOf_eq, hiff]
    rw [this]

end Subit
