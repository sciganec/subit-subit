import Subit.Tree
/-!
# SUBIT-∞ — точна формула d_S (етап 1 дорожньої карти)

Для f ≠ g: d_S(f,g) = 2^(−m), де m — мінімальна довжина адреси розбіжності
(r_addr у термінах Rust-крейта). Теорема не потребує скінченності A.
-/
namespace Subit
open Filter Set

variable {A : Type*}

/-- Точна рівність: для f ≠ g значення d_S дорівнює 2^(−m), де m — найменша довжина
адреси розбіжності; така адреса існує і є мінімальною серед усіх розбіжностей. -/
theorem dS_eq_pow_minlen (f g : Pos → Lab A) (hfg : f ≠ g) :
    ∃ m : ℕ, dS f g = (1 / 2 : ℝ) ^ m ∧
      (∃ σ : Pos, σ.length = m ∧ f σ ≠ g σ) ∧
      ∀ τ : Pos, f τ ≠ g τ → m ≤ τ.length := by
  classical
  have hex : ∃ σ : Pos, f σ ≠ g σ := by
    by_contra h
    simp only [not_exists, not_not] at h
    exact hfg (funext h)
  obtain ⟨σ0, h0⟩ := hex
  have hn : ∃ n : ℕ, ∃ σ : Pos, σ.length = n ∧ f σ ≠ g σ :=
    ⟨σ0.length, σ0, rfl, h0⟩
  obtain ⟨σ, hσlen, hσ⟩ := Nat.find_spec hn
  have hmin : ∀ τ : Pos, f τ ≠ g τ → Nat.find hn ≤ τ.length :=
    fun τ hτ => Nat.find_min' hn ⟨τ, rfl, hτ⟩
  refine ⟨Nat.find hn, le_antisymm ?_ ?_, ⟨σ, hσlen, hσ⟩, fun τ hτ => hmin τ hτ⟩
  · apply Real.iSup_le _ (by positivity)
    rintro ⟨τ, hτ⟩
    exact pow_le_pow_of_le_one (by norm_num) (by norm_num) (hmin τ hτ)
  · have := le_dS hσ
    rw [hσlen] at this
    exact this

end Subit
