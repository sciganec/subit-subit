import Subit.Basic
/-!
# SUBIT-∞ v6.11.2 — етап 2b: класифікація множин (C1, C2) і C3(a)

Множини — предикати `α → Prop`; D[P] — образ. Без Mathlib.
-/
namespace Subit

variable {α : Type _}

/-- D[P]. -/
def img (D : α → α) (P : α → Prop) : α → Prop := fun y => ∃ x, P x ∧ D x = y

/-- Dⁿ[P]. -/
def imgN (D : α → α) (n : Nat) (P : α → Prop) : α → Prop := iter (img D) n P

theorem imgN_zero (D : α → α) (P : α → Prop) : imgN D 0 P = P := rfl
theorem imgN_one (D : α → α) (P : α → Prop) : imgN D 1 P = img D P := rfl

/-! ## §4.2 InclusionType (C2) -/

def EQ_IMAGE (D : α → α) (P : α → Prop) : Prop := ∀ y, img D P y ↔ P y
def DISJOINT_IMAGE (D : α → α) (P : α → Prop) : Prop := ∀ y, ¬(img D P y ∧ P y)
def STRICT_SUBIMAGE (D : α → α) (P : α → Prop) : Prop :=
  (∀ y, img D P y → P y) ∧ ¬ EQ_IMAGE D P
def STRICT_SUPERIMAGE (D : α → α) (P : α → Prop) : Prop :=
  (∀ y, P y → img D P y) ∧ ¬ EQ_IMAGE D P
def OVERLAP_NONCOMP (D : α → α) (P : α → Prop) : Prop :=
  ¬ EQ_IMAGE D P ∧ ¬ DISJOINT_IMAGE D P ∧ ¬ STRICT_SUBIMAGE D P ∧ ¬ STRICT_SUPERIMAGE D P

/-- C2 (вичерпність): для довільної P виконується хоча б один клас. -/
theorem C2_exhaustive (D : α → α) (P : α → Prop) :
    EQ_IMAGE D P ∨ DISJOINT_IMAGE D P ∨ STRICT_SUBIMAGE D P ∨ STRICT_SUPERIMAGE D P ∨
      OVERLAP_NONCOMP D P := by
  by_cases h1 : EQ_IMAGE D P
  · exact Or.inl h1
  by_cases h2 : DISJOINT_IMAGE D P
  · exact Or.inr (Or.inl h2)
  by_cases h3 : STRICT_SUBIMAGE D P
  · exact Or.inr (Or.inr (Or.inl h3))
  by_cases h4 : STRICT_SUPERIMAGE D P
  · exact Or.inr (Or.inr (Or.inr (Or.inl h4)))
  exact Or.inr (Or.inr (Or.inr (Or.inr ⟨h1, h2, h3, h4⟩)))

/-- C2 (взаємна виключність) для непорожніх P. -/
theorem C2_exclusive (D : α → α) (P : α → Prop) (hne : ∃ x, P x) :
    ¬(EQ_IMAGE D P ∧ DISJOINT_IMAGE D P) ∧
    ¬(EQ_IMAGE D P ∧ STRICT_SUBIMAGE D P) ∧
    ¬(EQ_IMAGE D P ∧ STRICT_SUPERIMAGE D P) ∧
    ¬(EQ_IMAGE D P ∧ OVERLAP_NONCOMP D P) ∧
    ¬(DISJOINT_IMAGE D P ∧ STRICT_SUBIMAGE D P) ∧
    ¬(DISJOINT_IMAGE D P ∧ STRICT_SUPERIMAGE D P) ∧
    ¬(DISJOINT_IMAGE D P ∧ OVERLAP_NONCOMP D P) ∧
    ¬(STRICT_SUBIMAGE D P ∧ STRICT_SUPERIMAGE D P) ∧
    ¬(STRICT_SUBIMAGE D P ∧ OVERLAP_NONCOMP D P) ∧
    ¬(STRICT_SUPERIMAGE D P ∧ OVERLAP_NONCOMP D P) := by
  obtain ⟨x, hx⟩ := hne
  have hDx : img D P (D x) := ⟨x, hx, rfl⟩
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro ⟨he, hd⟩; exact hd _ ⟨hDx, (he _).1 hDx⟩
  · intro ⟨he, hs⟩; exact hs.2 he
  · intro ⟨he, hs⟩; exact hs.2 he
  · intro ⟨he, ho⟩; exact ho.1 he
  · intro ⟨hd, hs⟩; exact hd _ ⟨hDx, hs.1 _ hDx⟩
  · intro ⟨hd, hs⟩; exact hd _ ⟨hs.1 _ hx, hx⟩
  · intro ⟨hd, ho⟩; exact ho.2.1 hd
  · intro ⟨hs, hs'⟩; exact hs.2 (fun y => ⟨hs.1 y, hs'.1 y⟩)
  · intro ⟨hs, ho⟩; exact ho.2.2.1 hs
  · intro ⟨hs, ho⟩; exact ho.2.2.2 hs

/-! ## §4.1 OrbitType (C1) -/

/-- μ(P) = m: перший m, з якого образи повторюються (Dⁿ[P] = Dᵐ[P] при деякому n > m). -/
def Mu (D : α → α) (P : α → Prop) (μ : Nat) : Prop :=
  (∃ n, μ < n ∧ imgN D n P = imgN D μ P) ∧ ∀ m, m < μ → ∀ n, m < n → imgN D n P ≠ imgN D m P

theorem Mu_unique (D : α → α) (P : α → Prop) {μ μ' : Nat} (h : Mu D P μ) (h' : Mu D P μ') :
    μ = μ' := by
  obtain ⟨⟨n, hn, he⟩, hmin⟩ := h
  obtain ⟨⟨n', hn', he'⟩, hmin'⟩ := h'
  refine Classical.byContradiction fun hne => ?_
  rcases Nat.lt_or_gt_of_ne hne with hlt | hlt
  · exact hmin' μ hlt n hn he
  · exact hmin μ' hlt n' hn' he'

theorem Mu_exists (D : α → α) (P : α → Prop) (h : ∃ m n, m < n ∧ imgN D n P = imgN D m P) :
    ∃ μ, Mu D P μ := by
  obtain ⟨μ, ⟨n, hn, he⟩, hmin⟩ := exists_min_nat (fun m => ∃ n, m < n ∧ imgN D n P = imgN D m P)
    (by obtain ⟨m, n, hn, he⟩ := h; exact ⟨m, n, hn, he⟩)
  refine ⟨μ, ⟨n, hn, he⟩, ?_⟩
  intro m hm n' hn' he'
  have := hmin m ⟨n', hn', he'⟩
  omega

inductive OT | invFixed | invDynamic | periodicSet | eventuallyFixed | eventuallyPeriodic | aperiodic
  deriving DecidableEq, Repr

/-- Означення шести класів (див. §4.1). -/
def OTpred (D : α → α) (P : α → Prop) : OT → Prop
  | .invFixed => Mu D P 0 ∧ (∀ y, img D P y ↔ P y) ∧ ∀ x, P x → D x = x
  | .invDynamic => Mu D P 0 ∧ (∀ y, img D P y ↔ P y) ∧ ∃ x, P x ∧ D x ≠ x
  | .periodicSet => Mu D P 0 ∧ ¬ (∀ y, img D P y ↔ P y)
  | .eventuallyFixed => ∃ μ, 1 ≤ μ ∧ Mu D P μ ∧ imgN D (μ + 1) P = imgN D μ P
  | .eventuallyPeriodic => ∃ μ, 1 ≤ μ ∧ Mu D P μ ∧ imgN D (μ + 1) P ≠ imgN D μ P
  | .aperiodic => ¬ ∃ μ, Mu D P μ

/-- C1 (існування): кожна P належить хоча б одному класу. -/
theorem C1_exists (D : α → α) (P : α → Prop) : ∃ c, OTpred D P c := by
  by_cases hA : ∃ μ, Mu D P μ
  · obtain ⟨μ, hμ⟩ := hA
    by_cases h0 : μ = 0
    · subst h0
      by_cases hE : ∀ y, img D P y ↔ P y
      · by_cases hF : ∀ x, P x → D x = x
        · exact ⟨.invFixed, hμ, hE, hF⟩
        · refine ⟨.invDynamic, hμ, hE, ?_⟩
          exact Classical.byContradiction fun hn =>
            hF fun x hx => Classical.byContradiction fun hd => hn ⟨x, hx, hd⟩
      · exact ⟨.periodicSet, hμ, hE⟩
    · by_cases hE : imgN D (μ + 1) P = imgN D μ P
      · exact ⟨.eventuallyFixed, μ, by omega, hμ, hE⟩
      · exact ⟨.eventuallyPeriodic, μ, by omega, hμ, hE⟩
  · exact ⟨.aperiodic, hA⟩

theorem mu0_ev (D : α → α) (P : α → Prop) (R : Nat → Prop) (h : Mu D P 0)
    (h' : ∃ μ, 1 ≤ μ ∧ Mu D P μ ∧ R μ) : False := by
  obtain ⟨μ, h1, hm, _⟩ := h'
  have := Mu_unique D P h hm
  omega

theorem ev_ev (D : α → α) (P : α → Prop)
    (h : ∃ μ, 1 ≤ μ ∧ Mu D P μ ∧ imgN D (μ + 1) P = imgN D μ P)
    (h' : ∃ μ, 1 ≤ μ ∧ Mu D P μ ∧ imgN D (μ + 1) P ≠ imgN D μ P) : False := by
  obtain ⟨μ, _, hm, he⟩ := h
  obtain ⟨μ', _, hm', hne⟩ := h'
  have := Mu_unique D P hm hm'
  subst this
  exact hne he

/-- C1 (єдиність): класи попарно не перетинаються. -/
theorem C1_unique (D : α → α) (P : α → Prop) (c c' : OT)
    (h : OTpred D P c) (h' : OTpred D P c') : c = c' := by
  cases c <;> cases c' <;> simp only [OTpred] at h h' <;> first
    | rfl
    | (exfalso; exact h' ⟨0, h.1⟩)
    | (exfalso; exact h ⟨0, h'.1⟩)
    | (exfalso; obtain ⟨μ, _, hm, _⟩ := h; exact h' ⟨μ, hm⟩)
    | (exfalso; obtain ⟨μ, _, hm, _⟩ := h'; exact h ⟨μ, hm⟩)
    | (exfalso; exact mu0_ev D P _ h.1 h')
    | (exfalso; exact mu0_ev D P _ h'.1 h)
    | (exfalso; exact ev_ev D P h h')
    | (exfalso; exact ev_ev D P h' h)
    | (exfalso; obtain ⟨x, hx, hd⟩ := h'.2.2; exact hd (h.2.2 x hx))
    | (exfalso; obtain ⟨x, hx, hd⟩ := h.2.2; exact hd (h'.2.2 x hx))
    | (exfalso; exact h'.2 h.2.1)
    | (exfalso; exact h.2 h'.2.1)

/-- C1: кожна P належить рівно одному з шести класів. -/
theorem C1 (D : α → α) (P : α → Prop) : ∃ c, OTpred D P c ∧ ∀ c', OTpred D P c' → c' = c := by
  obtain ⟨c, hc⟩ := C1_exists D P
  exact ⟨c, hc, fun c' hc' => C1_unique D P c' c hc' hc⟩

end Subit
