import Subit.Dyn
import Mathlib.CategoryTheory.SingleObj
import Mathlib.CategoryTheory.Equivalence
import Mathlib.CategoryTheory.Types.Basic
import Mathlib.Algebra.Group.TypeTags.Basic
import Mathlib.Algebra.Group.Nat.TypeTags
/-!
# SUBIT-∞ v6.11.5 — K4: Dyn ≌ Fun(Bℕ, Set), Bℕ = одно-об'єктна категорія моноїда (ℕ, +, 0)
-/
open CategoryTheory
namespace Subit.CatSub

abbrev Bn := SingleObj (Multiplicative ℕ)

/-- Єдиний об'єкт Bℕ. -/
abbrev st : Bn := SingleObj.star (Multiplicative ℕ)

theorem tyext {A B : Type} {f g : A ⟶ B} (h : ∀ a, f a = g a) : f = g := by
  ext a; exact h a

/-- Значення стрілки Bℕ як елемент моноїда. -/
def val {x y : Bn} (f : x ⟶ y) : Multiplicative ℕ := f

theorem val_comp {x y z : Bn} (f : x ⟶ y) (g : y ⟶ z) : val (f ≫ g) = val g * val f := rfl

/-- Стрілка n : * ⟶ * у Bℕ. -/
abbrev arr (n : ℕ) : st ⟶ st := (Multiplicative.ofAdd n : Multiplicative ℕ)

/-- Dyn → Fun(Bℕ, Set): n ↦ fⁿ. -/
def dynToFun : DynObj ⥤ (Bn ⥤ Type) where
  obj X :=
    { obj := fun _ => X.S
      map := fun n => TypeCat.ofHom (X.f^[Multiplicative.toAdd (val n)])
      map_id := fun _ => tyext fun s => rfl
      map_comp := fun {_ _ _} a b => tyext fun s => by
        show X.f^[Multiplicative.toAdd (val (a ≫ b))] s = X.f^[Multiplicative.toAdd (val b)] (X.f^[Multiplicative.toAdd (val a)] s)
        rw [val_comp, toAdd_mul, ← Function.iterate_add_apply] }
  map {X Y} a :=
    { app := fun _ => TypeCat.ofHom a.φ
      naturality := fun {_ _} n => tyext fun s => by
        show a.φ (X.f^[Multiplicative.toAdd (val n)] s) = Y.f^[Multiplicative.toAdd (val n)] (a.φ s)
        exact Function.Semiconj.iterate_right a.comm _ s }
  map_id _ := rfl
  map_comp _ _ := rfl

instance : dynToFun.Faithful where
  map_injective {X Y} a b h := by
    apply DynHom.ext
    have := congrArg (fun η => (η.app st : X.S → Y.S)) h
    exact this

instance : dynToFun.Full where
  map_surjective {X Y} η := by
    refine ⟨⟨fun s => η.app st s, fun s => ?_⟩, ?_⟩
    · have := congrArg (fun h : (dynToFun.obj X).obj st ⟶ (dynToFun.obj Y).obj st => (h : X.S → Y.S) s)
        (η.naturality (arr 1))
      exact this
    · apply NatTrans.ext; funext _; apply tyext; intro s; rfl

/-- Дія n ↦ H.map(n) — ітерація H.map(1). -/
theorem map_iter (H : Bn ⥤ Type) (n : ℕ) (s : H.obj st) :
    H.map (arr n) s = (fun t => H.map (arr 1) t)^[n] s := by
  induction n generalizing s with
  | zero =>
    have : H.map (arr 0) = 𝟙 _ := H.map_id _
    rw [this]; rfl
  | succ n ih =>
    have h1 : arr (n + 1) = arr 1 ≫ arr n := by
      show _ = Multiplicative.ofAdd n * Multiplicative.ofAdd 1
      rw [← ofAdd_add]
    rw [Function.iterate_succ_apply, h1, H.map_comp]
    exact ih _

/-- Істотна сюр'єктивність: функтор H ≅ F(H(*), H(1)). -/
instance : dynToFun.EssSurj where
  mem_essImage H := by
    refine ⟨⟨H.obj st, fun t => H.map (arr 1) t⟩, ⟨?_⟩⟩
    refine NatIso.ofComponents (fun Y => Iso.refl (H.obj Y)) ?_
    intro _ _ n
    refine tyext fun s => ?_
    show (fun t => H.map (arr 1) t)^[Multiplicative.toAdd (val n)] s = H.map n s
    exact (map_iter H (Multiplicative.toAdd (val n)) s).symm

/-- K4: Dyn ≌ Fun(Bℕ, Set). -/
instance : dynToFun.IsEquivalence where

noncomputable def dynEquiv : DynObj ≌ (Bn ⥤ Type) := dynToFun.asEquivalence

end Subit.CatSub
