import Subit.Entropy
/-!
# SUBIT-∞ v6.11.3 — етап 3b: лема 4.6 (ентропія повного зсуву = log 2)
-/
open Filter Classical
namespace Subit

abbrev Seq := ℕ → Bool

def shift (x : Seq) : Seq := fun n => x (n + 1)

theorem iter_shift (i : ℕ) (x : Seq) : iter shift i x = fun n => x (n + i) := by
  induction i with
  | zero => rfl
  | succ i ih =>
    show shift (iter shift i x) = _
    rw [ih]; funext n; simp [shift, Nat.add_assoc, Nat.add_comm 1 i]

open Classical in
/-- d_C(x,y) = 2^{-k}, k — перший індекс розбіжності; 0, якщо x = y. -/
noncomputable def dC (x y : Seq) : ℝ :=
  if h : ∃ n, x n ≠ y n then (1 / 2 : ℝ) ^ (Nat.find h) else 0

theorem dC_le (x y : Seq) (k : ℕ) (h : ∀ i < k, x i = y i) : dC x y ≤ (1 / 2 : ℝ) ^ k := by
  unfold dC
  split
  · rename_i hex
    have : k ≤ Nat.find hex := by
      by_contra hlt
      exact Nat.find_spec hex (h _ (by omega))
    exact pow_le_pow_of_le_one (by norm_num) (by norm_num) this
  · positivity

theorem dC_ge (x y : Seq) (k : ℕ) (h : x k ≠ y k) : (1 / 2 : ℝ) ^ k ≤ dC x y := by
  unfold dC
  have hex : ∃ n, x n ≠ y n := ⟨k, h⟩
  rw [dif_pos hex]
  exact pow_le_pow_of_le_one (by norm_num) (by norm_num) (Nat.find_min' hex h)

/-! ### Оцінки s(n, ε) -/

/-- Нижня оцінка: існує (n, 3/4)-роздільна множина потужності 2ⁿ. -/
theorem exists_sep_two_pow (n : ℕ) :
    ∃ S : Finset Seq, IsSep dC shift n (3 / 4) S ∧ S.card = 2 ^ n := by
  let rep : (Fin n → Bool) → Seq := fun w i => if h : i < n then w ⟨i, h⟩ else false
  have hinj : Function.Injective rep := by
    intro w w' hww
    funext j
    have := congrFun hww j.val
    simpa [rep, j.isLt] using this
  refine ⟨Finset.univ.image rep, ?_, ?_⟩
  · intro x hx y hy hxy
    obtain ⟨w, -, rfl⟩ := Finset.mem_image.1 hx
    obtain ⟨w', -, rfl⟩ := Finset.mem_image.1 hy
    have hne : w ≠ w' := fun h => hxy (by rw [h])
    obtain ⟨k, hk⟩ := Function.ne_iff.1 hne
    refine ⟨k.val, k.isLt, ?_⟩
    have h1 : (1 / 2 : ℝ) ^ 0 ≤ dC (iter shift k.val (rep w)) (iter shift k.val (rep w')) := by
      apply dC_ge _ _ 0
      simp [iter_shift, rep, k.isLt, hk]
    norm_num at h1 ⊢
    linarith
  · rw [Finset.card_image_of_injective _ hinj]
    simp

/-- Верхня оцінка: якщо (1/2)^(L+1) < ε, то будь-яка (n,ε)-роздільна множина має ≤ 2^(n+L) точок. -/
theorem sep_card_le (n L : ℕ) (ε : ℝ) (hL : (1 / 2 : ℝ) ^ (L + 1) < ε) (S : Finset Seq)
    (hS : IsSep dC shift n ε S) : S.card ≤ 2 ^ (n + L) := by
  let pref : Seq → (Fin (n + L) → Bool) := fun x j => x j.val
  have hinj : Set.InjOn pref (S : Set Seq) := by
    intro x hx y hy hxy
    by_contra hne
    obtain ⟨i, hi, hd⟩ := hS x hx y hy hne
    have hle : dC (iter shift i x) (iter shift i y) ≤ (1 / 2 : ℝ) ^ (L + 1) := by
      apply dC_le
      intro m hm
      simp only [iter_shift]
      have := congrFun hxy ⟨m + i, by omega⟩
      exact this
    linarith
  have := Finset.card_le_card_of_injOn pref (fun x _ => Finset.mem_univ _) hinj
  simpa using this

theorem sepNum_full_le (n L : ℕ) (ε : ℝ) (hL : (1 / 2 : ℝ) ^ (L + 1) < ε) :
    sepNum dC shift n ε ≤ 2 ^ (n + L) :=
  sepNum_le _ (fun S hS => sep_card_le n L ε hL S hS)

theorem sepNum_full_three_quarters (n : ℕ) : sepNum dC shift n (3 / 4) = 2 ^ n := by
  have hup : sepNum dC shift n (3 / 4) ≤ 2 ^ (n + 0) :=
    sepNum_full_le n 0 (3 / 4) (by norm_num)
  obtain ⟨S, hS, hc⟩ := exists_sep_two_pow n
  have hlow := le_sepNum (2 ^ (n + 0)) (fun S hS => sep_card_le n 0 (3 / 4) (by norm_num) S hS) S hS
  simp at hup
  omega

/-! ### h_top(σ) = log 2 -/

theorem log_nat_le {k m : ℕ} (hm : 0 < m) (h : k ≤ m) : Real.log k ≤ Real.log m := by
  rcases Nat.eq_zero_or_pos k with rfl | hk
  · simp; exact Real.log_nonneg (by exact_mod_cast hm)
  · exact Real.log_le_log (by exact_mod_cast hk) (by exact_mod_cast h)

/-- Нижня оцінка: h_top(σ) ≥ log 2. -/
theorem htop_full_ge : ((Real.log 2 : ℝ) : EReal) ≤ htop dC shift := by
  unfold htop
  refine le_trans ?_ (le_iSup _ ⟨3 / 4, by norm_num⟩)
  have hev : (fun n : ℕ => ((Real.log (sepNum dC shift n (3 / 4)) / n : ℝ) : EReal))
      =ᶠ[atTop] fun _ => ((Real.log 2 : ℝ) : EReal) := by
    filter_upwards [eventually_ge_atTop 1] with n hn
    simp only [sepNum_full_three_quarters]
    have hn' : (n : ℝ) ≠ 0 := by positivity
    congr 1
    rw [Nat.cast_pow, Real.log_pow]
    push_cast
    field_simp
  rw [limsup_congr hev, limsup_const]

/-- Верхня оцінка: h_top(σ) ≤ log 2. -/
theorem htop_full_le : htop dC shift ≤ ((Real.log 2 : ℝ) : EReal) := by
  unfold htop
  refine iSup_le fun ⟨ε, hε⟩ => ?_
  obtain ⟨L, hL⟩ := exists_pow_lt_of_lt_one hε (by norm_num : (1 / 2 : ℝ) < 1)
  have hL' : (1 / 2 : ℝ) ^ (L + 1) < ε := by
    have : (1 / 2 : ℝ) ^ (L + 1) ≤ (1 / 2 : ℝ) ^ L :=
      pow_le_pow_of_le_one (by norm_num) (by norm_num) (Nat.le_succ L)
    linarith
  -- для будь-якого c > log 2 члени послідовності зрештою ≤ c
  refine le_of_forall_gt_imp_ge_of_dense fun c hc => ?_
  induction c using EReal.rec with
  | bot => exact absurd hc (by simp)
  | top => exact le_top
  | coe r =>
    have hr : Real.log 2 < r := by exact_mod_cast hc
    have ht : Tendsto (fun n : ℕ => (1 + (L : ℝ) / n) * Real.log 2) atTop
        (nhds ((1 + 0) * Real.log 2)) :=
      ((tendsto_const_nhds.add (tendsto_const_div_atTop_nhds_zero_nat (L : ℝ))).mul
        tendsto_const_nhds)
    have hev : ∀ᶠ n : ℕ in atTop, (1 + (L : ℝ) / n) * Real.log 2 < r :=
      ht.eventually (gt_mem_nhds (by simpa using hr))
    have hbound : ∀ᶠ n : ℕ in atTop,
        ((Real.log (sepNum dC shift n ε) / n : ℝ) : EReal) ≤ (r : EReal) := by
      filter_upwards [hev, eventually_ge_atTop 1] with n hn hn1
      have hnpos : (0 : ℝ) < n := by exact_mod_cast hn1
      have h1 : Real.log (sepNum dC shift n ε) ≤ Real.log ((2 : ℕ) ^ (n + L) : ℕ) :=
        log_nat_le (by positivity) (sepNum_full_le n L ε hL')
      have h2 : Real.log (((2 : ℕ) ^ (n + L) : ℕ) : ℝ) = ((n : ℝ) + L) * Real.log 2 := by
        rw [Nat.cast_pow, Real.log_pow]; push_cast; ring
      have h3 : Real.log (sepNum dC shift n ε) / n ≤ (1 + (L : ℝ) / n) * Real.log 2 := by
        rw [div_le_iff₀ hnpos]
        have : (1 + (L : ℝ) / n) * Real.log 2 * n = ((n : ℝ) + L) * Real.log 2 := by
          field_simp
        rw [this]; linarith
      exact_mod_cast le_trans h3 hn.le
    exact limsup_le_of_le (by isBoundedDefault) hbound

/-- Лема 4.6: h_top(σ) = log 2 для повного зсуву з метрикою d_C. -/
theorem lemma_4_6 : htop dC shift = ((Real.log 2 : ℝ) : EReal) :=
  le_antisymm htop_full_le htop_full_ge

end Subit
