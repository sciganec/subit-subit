import Subit.D6
/-!
# SUBIT-∞ v6.11.4 — лема E (абстрактне ядро): спряження зберігає ω-границю, мінімальність,
досяжність і (за рівномірної неперервності) ентропію; граф G = {(c, T c)} спряжений із T.

Формалізовано АБСТРАКЦІЮ леми E: D(c, c') = (c', T c') на Y × Y (константні правила κ_c
ототожнено з точками c ∈ Y). Сам D∞ на S∞ × ℛ₀ тут не будується.
-/
open Filter Set Classical
namespace Subit

section Conj
variable {X Y : Type*} [TopologicalSpace X] [TopologicalSpace Y]

omit [TopologicalSpace X] [TopologicalSpace Y] in
theorem iter_conj (e : X → Y) (D : X → X) (T : Y → Y) (h : ∀ x, e (D x) = T (e x))
    (n : ℕ) (x : X) : e (iter D n x) = iter T n (e x) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    show e (D (iter D n x)) = T (iter T n (e x))
    rw [h, ih]

private theorem img_tail (e : X ≃ₜ Y) (D : X → X) (T : Y → Y) (h : ∀ x, e (D x) = T (e x))
    (x : X) (N : ℕ) :
    e '' closure (Set.range fun k => iter D (N + k) x) =
      closure (Set.range fun k => iter T (N + k) (e x)) := by
  rw [e.image_closure]
  congr 1
  ext w; constructor
  · rintro ⟨_, ⟨k, rfl⟩, rfl⟩; exact ⟨k, (iter_conj e D T h _ x).symm⟩
  · rintro ⟨k, rfl⟩; exact ⟨_, ⟨k, rfl⟩, iter_conj e D T h _ x⟩

/-- Гомеоморфне спряження переносить ω-границю. -/
theorem omega_conj (e : X ≃ₜ Y) (D : X → X) (T : Y → Y) (h : ∀ x, e (D x) = T (e x)) (x : X) :
    e '' omega D x = omega T (e x) := by
  ext y
  constructor
  · rintro ⟨z, hz, rfl⟩
    refine Set.mem_iInter.2 fun N => ?_
    have hz' := Set.mem_iInter.1 hz N
    have : e '' closure (Set.range fun k => iter D (N + k) x) =
        closure (Set.range fun k => iter T (N + k) (e x)) := img_tail e D T h x N
    rw [← this]; exact ⟨z, hz', rfl⟩
  · intro hy
    refine ⟨e.symm y, ?_, e.apply_symm_apply y⟩
    refine Set.mem_iInter.2 fun N => ?_
    have hy' := Set.mem_iInter.1 hy N
    have : e '' closure (Set.range fun k => iter D (N + k) x) =
        closure (Set.range fun k => iter T (N + k) (e x)) := img_tail e D T h x N
    rw [← this] at hy'
    obtain ⟨z, hz, hzy⟩ := hy'
    have : z = e.symm y := by rw [← hzy]; simp
    rw [← this]; exact hz

/-- Досяжність зберігається: xₙ ∈ ω(x) ⇔ e(xₙ) ∈ ω(e x). -/
theorem attained_conj (e : X ≃ₜ Y) (D : X → X) (T : Y → Y) (h : ∀ x, e (D x) = T (e x))
    (x : X) (n : ℕ) :
    iter D n x ∈ omega D x ↔ iter T n (e x) ∈ omega T (e x) := by
  rw [← omega_conj e D T h x, ← iter_conj e D T h n x]
  exact e.injective.mem_set_image.symm

/-- Мінімальність зберігається гомеоморфним спряженням. -/
theorem minOn_conj (e : X ≃ₜ Y) (D : X → X) (T : Y → Y) (h : ∀ x, e (D x) = T (e x))
    (W : Set X) (hM : MinOn D W) : MinOn T (e '' W) := by
  intro V hVW hVne hVc hVinv
  have hsub : e.symm '' V ⊆ W := by
    rintro _ ⟨v, hv, rfl⟩
    obtain ⟨w, hw, hwv⟩ := hVW hv
    rw [← hwv]; simpa using hw
  have hinv : Set.MapsTo D (e.symm '' V) (e.symm '' V) := by
    rintro _ ⟨v, hv, rfl⟩
    refine ⟨T v, hVinv hv, ?_⟩
    apply e.injective
    rw [h]; simp
  have hcl : IsClosed (e.symm '' V) := e.symm.isClosedMap _ hVc
  have := hM _ hsub (hVne.image _) hcl hinv
  have h2 : e '' (e.symm '' V) = e '' W := by rw [this]
  rwa [← Set.image_comp, show (⇑e ∘ ⇑e.symm) = id from funext e.apply_symm_apply, Set.image_id] at h2

end Conj

section Ent
variable {X Y : Type*}

private theorem log_nat_mono {a b : ℕ} (h : a ≤ b) : Real.log a ≤ Real.log b := by
  rcases Nat.eq_zero_or_pos a with rfl | ha
  · simp; exact Real.log_natCast_nonneg b
  · exact Real.log_le_log (by exact_mod_cast ha) (by exact_mod_cast h)

/-- Фактор-нерівність: h_top(T) ≤ h_top(D), якщо e сюр'єктивне, напівспряжує і рівномірно неперервне
(у формі: d_Y(e a, e b) > ε ⇒ d_X(a, b) > δ), а (n,δ)-роздільні множини в X мають обмежену потужність. -/
theorem htop_le_of_semiconj (dX : X → X → ℝ) (dY : Y → Y → ℝ) (D : X → X) (T : Y → Y)
    (e : X → Y) (hs : Function.Surjective e) (hc : ∀ x, e (D x) = T (e x))
    (huc : ∀ ε : ℝ, 0 < ε → ∃ δ : ℝ, 0 < δ ∧ ∀ a b, ε < dY (e a) (e b) → δ < dX a b)
    (hbdd : ∀ n (δ : ℝ), ∃ B : ℕ, ∀ S : Finset X, IsSep dX D n δ S → S.card ≤ B) :
    htop dY T ≤ htop dX D := by
  have key : ∀ n (ε δ : ℝ), (∀ a b, ε < dY (e a) (e b) → δ < dX a b) →
      sepNum dY T n ε ≤ sepNum dX D n δ := by
    intro n ε δ hδ
    by_cases hb : BddAbove {k | ∃ S : Finset Y, IsSep dY T n ε S ∧ S.card = k}
    · obtain ⟨S, hS, hcard⟩ := Nat.sSup_mem (s := {k | ∃ S : Finset Y, IsSep dY T n ε S ∧ S.card = k})
        ⟨0, ∅, by intro x hx; simp at hx, rfl⟩ hb
      obtain ⟨B, hB⟩ := hbdd n δ
      let s : Y → X := Function.surjInv hs
      have hsec : ∀ y, e (s y) = y := Function.surjInv_eq hs
      have hinj : Function.Injective s := fun a b hab => by rw [← hsec a, ← hsec b, hab]
      have hsepS : IsSep dX D n δ (S.image s) := by
        intro x hx y hy hxy
        obtain ⟨a, ha, rfl⟩ := Finset.mem_image.1 hx
        obtain ⟨b, hb', rfl⟩ := Finset.mem_image.1 hy
        have hab : a ≠ b := fun h => hxy (by rw [h])
        obtain ⟨i, hi, hsep⟩ := hS a ha b hb' hab
        refine ⟨i, hi, hδ _ _ ?_⟩
        rw [iter_conj e D T hc, iter_conj e D T hc, hsec, hsec]; exact hsep
      have : (S.image s).card = S.card := Finset.card_image_of_injective _ hinj
      calc sepNum dY T n ε = S.card := hcard.symm
        _ = (S.image s).card := this.symm
        _ ≤ sepNum dX D n δ := le_sepNum B hB _ hsepS
    · unfold sepNum
      rw [Nat.sSup_of_not_bddAbove hb]; exact Nat.zero_le _
  unfold htop
  refine iSup_le fun ⟨ε, hε⟩ => ?_
  obtain ⟨δ, hδ, hδ'⟩ := huc ε hε
  refine le_trans ?_ (le_iSup _ (⟨δ, hδ⟩ : {δ : ℝ // 0 < δ}))
  apply limsup_le_limsup _ (by isBoundedDefault) (by isBoundedDefault)
  refine Eventually.of_forall fun n => ?_
  have h1 := log_nat_mono (key n ε δ hδ')
  exact EReal.coe_le_coe_iff.2 (div_le_div_of_nonneg_right h1 (Nat.cast_nonneg n))

end Ent

section GraphModel
variable {Y : Type*} [TopologicalSpace Y]

/-- Граф G = {(c, T c)} ⊆ Y × Y. -/
def Gr (T : Y → Y) : Set (Y × Y) := {p | p.2 = T p.1}

/-- D(c, c') = (c', T c'): абстракція D∞(c, κ_{c'}) = (c', κ_{T c'}). -/
def Dmod (T : Y → Y) (p : Y × Y) : Y × Y := (p.2, T p.2)

omit [TopologicalSpace Y] in
/-- Лема E, п. 2: D[G] ⊆ G; D[G] = G, якщо T сюр'єктивна. -/
theorem Dm_mapsTo (T : Y → Y) : Set.MapsTo (Dmod T) (Gr T) (Gr T) := by
  rintro ⟨c, d⟩ (h : d = T c)
  show T d = T d
  rfl

omit [TopologicalSpace Y] in
theorem Dm_image (T : Y → Y) (hT : Function.Surjective T) : Dmod T '' Gr T = Gr T := by
  apply Set.Subset.antisymm
  · rintro _ ⟨p, hp, rfl⟩; exact Dm_mapsTo T hp
  · rintro ⟨d, d'⟩ (h : d' = T d)
    obtain ⟨c, hc⟩ := hT d
    refine ⟨(c, d), (hc.symm : d = T c), ?_⟩
    simp [Dmod, h]

/-- Лема E, п. 2: pr₁ : G → Y — гомеоморфізм і спряжує D|G з T. -/
def grHomeo (T : Y → Y) (hT : Continuous T) : Gr T ≃ₜ Y where
  toFun p := p.1.1
  invFun c := ⟨(c, T c), rfl⟩
  left_inv := by
    rintro ⟨⟨c, d⟩, h⟩
    have h' : d = T c := h
    subst h'
    rfl
  right_inv _ := rfl
  continuous_toFun := continuous_fst.comp continuous_subtype_val
  continuous_invFun := by
    refine Continuous.subtype_mk ?_ _
    exact continuous_id.prodMk hT

theorem grHomeo_conj (T : Y → Y) (hT : Continuous T) (p : Gr T) :
    grHomeo T hT ⟨Dmod T p.1, Dm_mapsTo T p.2⟩ = T (grHomeo T hT p) := by
  obtain ⟨⟨c, d⟩, h⟩ := p
  show d = T c
  exact h

end GraphModel

end Subit
