/-!
# SUBIT-∞ v6.11.2 — формалізація, етап 1 (дискретне ядро)

Покриває: A1–A3 (алфавіт, S₀, code6 — бієкція), ітерації, P1–P3 (точкова класифікація
для скінченних систем), A4 (вкладення автомата). Без Mathlib, без `sorry`, без `axiom`.
-/
namespace Subit

/-! ## §1. Алфавіт і S₀ -/

/-- A = {00,01,10,11}: пара бітів. -/
abbrev A := Bool × Bool
/-- S₀ = A³ (64 стани). -/
abbrev S0 := A × A × A

def b2n (b : Bool) : Nat := if b then 1 else 0

/-- code6(s) = 32 b₁ + 16 b₂ + 8 b₃ + 4 b₄ + 2 b₅ + b₆. -/
def code6 (s : S0) : Nat :=
  32 * b2n s.1.1 + 16 * b2n s.1.2 + 8 * b2n s.2.1.1 + 4 * b2n s.2.1.2
    + 2 * b2n s.2.2.1 + b2n s.2.2.2

/-- Обернене відображення: двійковий запис числа. -/
def decode6 (n : Nat) : S0 :=
  ((n / 32 % 2 == 1, n / 16 % 2 == 1), (n / 8 % 2 == 1, n / 4 % 2 == 1),
    (n / 2 % 2 == 1, n % 2 == 1))

theorem decode_code (s : S0) : decode6 (code6 s) = s := by
  obtain ⟨⟨b1, b2⟩, ⟨b3, b4⟩, ⟨b5, b6⟩⟩ := s
  cases b1 <;> cases b2 <;> cases b3 <;> cases b4 <;> cases b5 <;> cases b6 <;> decide

theorem code_lt (s : S0) : code6 s < 64 := by
  obtain ⟨⟨b1, b2⟩, ⟨b3, b4⟩, ⟨b5, b6⟩⟩ := s
  cases b1 <;> cases b2 <;> cases b3 <;> cases b4 <;> cases b5 <;> cases b6 <;> decide

theorem code_decode (n : Nat) (h : n < 64) : code6 (decode6 n) = n := by
  revert n; decide

/-- A3: code6 — бієкція S₀ → {0,…,63}. -/
theorem A3_injective : ∀ s t : S0, code6 s = code6 t → s = t := by
  intro s t h
  rw [← decode_code s, ← decode_code t, h]

theorem A3_surjective : ∀ n, n < 64 → ∃ s : S0, code6 s = n :=
  fun n h => ⟨decode6 n, code_decode n h⟩

theorem A3 : (∀ s : S0, code6 s < 64) ∧ (∀ s t : S0, code6 s = code6 t → s = t) ∧
    (∀ n, n < 64 → ∃ s : S0, code6 s = n) :=
  ⟨code_lt, A3_injective, A3_surjective⟩

/-! ## Ітерації -/

/-- Dⁿ(x). -/
def iter {α : Type _} (D : α → α) : Nat → α → α
  | 0, x => x
  | n + 1, x => D (iter D n x)

theorem iter_add {α : Type _} (D : α → α) (m n : Nat) (x : α) :
    iter D (m + n) x = iter D m (iter D n x) := by
  induction m with
  | zero => simp [iter]
  | succ m ih => rw [Nat.succ_add]; simp [iter, ih]

theorem iter_succ' {α : Type _} (D : α → α) (n : Nat) (x : α) :
    iter D (n + 1) x = iter D n (D x) := by
  have := iter_add D n 1 x
  simpa [iter] using this

/-! ## Принцип Діріхле (власний доказ, без Mathlib) -/

theorem pigeon : ∀ (N n : Nat) (f : Nat → Nat),
    (∀ i, i < n → f i < N) → (∀ i j, i < n → j < n → f i = f j → i = j) → n ≤ N := by
  intro N
  induction N with
  | zero =>
    intro n f hlt _
    cases n with
    | zero => exact Nat.le_refl _
    | succ n => exact absurd (hlt 0 (Nat.succ_pos n)) (Nat.not_lt_zero _)
  | succ N ih =>
    intro n f hlt hinj
    cases n with
    | zero => exact Nat.zero_le _
    | succ m =>
      -- a := f m ; τ обмінює a і N
      obtain ⟨a, hadef⟩ : ∃ a, a = f m := ⟨_, rfl⟩
      obtain ⟨τ, hτ⟩ : ∃ τ : Nat → Nat, ∀ x, τ x = if x = a then N else if x = N then a else x :=
        ⟨_, fun _ => rfl⟩
      have ha : a < N + 1 := hadef ▸ hlt m (Nat.lt_succ_self m)
      have τlt : ∀ x, x < N + 1 → τ x < N + 1 := by
        intro x hx
        by_cases h1 : x = a <;> by_cases h3 : x = N <;> by_cases h5 : N = a <;>
          simp [hτ, h1, h3, h5] <;> omega
      have τeqN : ∀ x, τ x = N ↔ x = a := by
        intro x
        by_cases h1 : x = a <;> by_cases h3 : x = N <;> by_cases h5 : N = a <;>
          simp [hτ, h1, h3, h5] <;> omega
      have τinj : ∀ x y, x < N + 1 → y < N + 1 → τ x = τ y → x = y := by
        intro x y hx hy h
        by_cases h1 : x = a <;> by_cases h2 : y = a <;> by_cases h3 : x = N <;>
          by_cases h4 : y = N <;> by_cases h5 : N = a <;>
          simp [hτ, h1, h2, h3, h4, h5] at h <;> omega
      have key := ih m (fun i => τ (f i)) ?_ ?_
      · omega
      · intro i hi
        have hne : f i ≠ a := by
          intro h
          have := hinj i m (Nat.lt_succ_of_lt hi) (Nat.lt_succ_self m) (h.trans hadef)
          omega
        have h1 : τ (f i) < N + 1 := τlt _ (hlt i (Nat.lt_succ_of_lt hi))
        have h2 : τ (f i) ≠ N := fun h => hne ((τeqN _).1 h)
        omega
      · intro i j hi hj h
        exact hinj i j (Nat.lt_succ_of_lt hi) (Nat.lt_succ_of_lt hj)
          (τinj _ _ (hlt i (Nat.lt_succ_of_lt hi)) (hlt j (Nat.lt_succ_of_lt hj)) h)

/-- Повтор серед перших N+1 значень, якщо їх кодування < N. -/
theorem exists_repeat {α : Type _} (D : α → α) (enc : α → Nat) (N : Nat)
    (hbound : ∀ x, enc x < N) (x : α)
    (henc : ∀ a b, enc a = enc b → a = b) :
    ∃ i j, i < j ∧ j ≤ N ∧ iter D i x = iter D j x := by
  refine Classical.byContradiction fun hcon => ?_
  have : N + 1 ≤ N := by
    apply pigeon N (N + 1) (fun i => enc (iter D i x))
    · intro i _; exact hbound _
    · intro i j hi hj h
      have h' := henc _ _ h
      refine Classical.byContradiction fun hne => ?_
      rcases Nat.lt_or_gt_of_ne hne with hlt | hlt
      · exact hcon ⟨i, j, hlt, by omega, h'⟩
      · exact hcon ⟨j, i, hlt, by omega, h'.symm⟩
  omega

/-! ## §3.1 Точкова класифікація -/

/-- Rep D x m p : p ≥ 1 і D^{m+p}(x) = D^m(x). -/
def Rep {α : Type _} (D : α → α) (x : α) (m p : Nat) : Prop :=
  1 ≤ p ∧ iter D (m + p) x = iter D m x

/-- (m, p) — мінімальні дані: m мінімальне серед усіх повторів, p мінімальне при цьому m. -/
def IsMin {α : Type _} (D : α → α) (x : α) (m p : Nat) : Prop :=
  Rep D x m p ∧ (∀ m' p', Rep D x m' p' → m ≤ m') ∧ (∀ p', Rep D x m p' → p ≤ p')

theorem exists_min_nat (P : Nat → Prop) (h : ∃ n, P n) : ∃ n, P n ∧ ∀ k, P k → n ≤ k := by
  obtain ⟨n, hn⟩ := h
  induction n using Nat.strongRecOn with
  | _ n ih =>
    by_cases hex : ∃ k, k < n ∧ P k
    · obtain ⟨k, hk, hPk⟩ := hex
      exact ih k hk hPk
    · refine ⟨n, hn, ?_⟩
      intro k hk
      refine Classical.byContradiction fun hlt => ?_
      exact hex ⟨k, by omega, hk⟩

/-- Єдиність мінімальних даних. -/
theorem IsMin_unique {α : Type _} {D : α → α} {x : α} {m p m' p' : Nat}
    (h : IsMin D x m p) (h' : IsMin D x m' p') : m = m' ∧ p = p' := by
  obtain ⟨r, hm, hp⟩ := h
  obtain ⟨r', hm', hp'⟩ := h'
  have e1 : m = m' := Nat.le_antisymm (hm m' p' r') (hm' m p r)
  subst e1
  exact ⟨rfl, Nat.le_antisymm (hp p' r') (hp' p r)⟩

/-- Існування мінімальних даних, якщо повтор взагалі є. -/
theorem IsMin_exists {α : Type _} (D : α → α) (x : α) (h : ∃ m p, Rep D x m p) :
    ∃ m p, IsMin D x m p := by
  obtain ⟨m, hm0, hm1⟩ := exists_min_nat (fun m => ∃ p, Rep D x m p) (by
    obtain ⟨m, p, hr⟩ := h; exact ⟨m, p, hr⟩)
  obtain ⟨p0, hp0⟩ := hm0
  obtain ⟨p, hp, hpmin⟩ := exists_min_nat (fun p => Rep D x m p) ⟨p0, hp0⟩
  exact ⟨m, p, hp, fun m' p' r => hm1 m' ⟨p', r⟩, hpmin⟩

/-- P1: у скінченній системі (кодування в [0,N)) повтор існує, і m ≤ N. -/
theorem P1 {α : Type _} (D : α → α) (enc : α → Nat) (N : Nat) (hbound : ∀ x, enc x < N)
    (henc : ∀ a b, enc a = enc b → a = b) (x : α) :
    ∃ m p, IsMin D x m p := by
  apply IsMin_exists
  obtain ⟨i, j, hij, _, he⟩ := exists_repeat D enc N hbound x henc
  exact ⟨i, j - i, by omega, by
    have : i + (j - i) = j := by omega
    rw [this]; exact he.symm⟩

/-- Класи §3.1. -/
inductive Cls
  | fixed
  | periodic (p : Nat)
  | preperiodic (m p : Nat)
  deriving DecidableEq, Repr

def clsOf (m p : Nat) : Cls :=
  if m = 0 then (if p = 1 then Cls.fixed else Cls.periodic p) else Cls.preperiodic m p

/-- P2: три класи взаємовиключні й вичерпні (за значеннями m, p ≥ 1). -/
theorem P2 (m p : Nat) (hp : 1 ≤ p) :
    ((m = 0 ∧ p = 1) ∨ (m = 0 ∧ 2 ≤ p) ∨ 1 ≤ m) ∧
    ¬((m = 0 ∧ p = 1) ∧ (m = 0 ∧ 2 ≤ p)) ∧
    ¬((m = 0 ∧ p = 1) ∧ 1 ≤ m) ∧ ¬((m = 0 ∧ 2 ≤ p) ∧ 1 ≤ m) := by
  omega

theorem clsOf_fixed (m p : Nat) : clsOf m p = Cls.fixed ↔ (m = 0 ∧ p = 1) := by
  by_cases hm : m = 0 <;> by_cases hp : p = 1 <;> simp [clsOf, hm, hp]
theorem clsOf_periodic (m p q : Nat) (hp : 1 ≤ p) :
    clsOf m p = Cls.periodic q ↔ (m = 0 ∧ 2 ≤ p ∧ q = p) := by
  by_cases hm : m = 0 <;> by_cases hp1 : p = 1 <;> simp [clsOf, hm, hp1] <;> omega
theorem clsOf_pre (m p m' q : Nat) :
    clsOf m p = Cls.preperiodic m' q ↔ (1 ≤ m ∧ m' = m ∧ q = p) := by
  by_cases hm : m = 0 <;> by_cases hp1 : p = 1 <;> simp [clsOf, hm, hp1] <;> omega

/-! ## P3: точний режим -/

/-- Перший повтор: n₀ — найменше n, для якого D^n(x) = D^k(x) при деякому k < n. -/
def FirstRepeat {α : Type _} (D : α → α) (x : α) (k n : Nat) : Prop :=
  k < n ∧ iter D n x = iter D k x ∧ (∀ i j, i < j → j < n → iter D i x ≠ iter D j x)

/-- Із першого повтору (k, n) випливають мінімальні дані (m, p) = (k, n − k). -/
theorem P3_correct {α : Type _} (D : α → α) (x : α) (k n : Nat)
    (h : FirstRepeat D x k n) : IsMin D x k (n - k) := by
  obtain ⟨hkn, heq, hdist⟩ := h
  -- всі стани після k лежать серед D^i(x), k ≤ i < n
  have cyc : ∀ j, k ≤ j → ∃ i, k ≤ i ∧ i < n ∧ iter D j x = iter D i x := by
    intro j
    induction j using Nat.strongRecOn with
    | _ j ih =>
      intro hj
      by_cases hjn : j < n
      · exact ⟨j, hj, hjn, rfl⟩
      · have e : iter D j x = iter D (k + (j - n)) x := by
          have h1 : iter D ((j - n) + n) x = iter D (j - n) (iter D n x) := iter_add D (j - n) n x
          have h2 : iter D ((j - n) + k) x = iter D (j - n) (iter D k x) := iter_add D (j - n) k x
          rw [heq] at h1
          have e1 : j = (j - n) + n := by omega
          have e2 : k + (j - n) = (j - n) + k := by omega
          rw [e2, h2, ← h1]
          exact congrArg (fun t => iter D t x) e1
        have hlt : k + (j - n) < j := by omega
        obtain ⟨i, h1, h2, h3⟩ := ih (k + (j - n)) hlt (by omega)
        exact ⟨i, h1, h2, e.trans h3⟩
  have hrep : Rep D x k (n - k) := by
    refine ⟨by omega, ?_⟩
    have : k + (n - k) = n := by omega
    rw [this]; exact heq
  refine ⟨hrep, ?_, ?_⟩
  · -- мінімальність m
    intro m' p' hr
    obtain ⟨hp', hrep'⟩ := hr
    refine Classical.byContradiction fun hlt => ?_
    have hm : m' < k := by omega
    have hper : iter D p' (iter D m' x) = iter D m' x := by
      have := iter_add D p' m' x
      rw [Nat.add_comm] at hrep'
      rw [← this]; exact hrep'
    have per : ∀ t, iter D (p' * t) (iter D m' x) = iter D m' x := by
      intro t
      induction t with
      | zero => simp [iter]
      | succ t ih =>
        have e : p' * (t + 1) = p' * t + p' := by rw [Nat.mul_succ]
        rw [e, iter_add, hper, ih]
    obtain ⟨i, h1, h2, h3⟩ := cyc (p' * n + m') (by
      have : n ≤ p' * n := Nat.le_mul_of_pos_left n hp'
      omega)
    have hj : iter D (p' * n + m') x = iter D m' x := by
      rw [iter_add]; exact per n
    exact hdist m' i (by omega) h2 (hj.symm.trans h3)
  · intro p' hr
    obtain ⟨hp', hrep'⟩ := hr
    refine Classical.byContradiction fun hlt => ?_
    have : k + p' < n := by omega
    exact hdist k (k + p') (by omega) this hrep'.symm

/-- P3 (точний режим): перший повтор існує й настає не пізніше кроку N;
гілка RESOURCE_EXCEEDED недосяжна. -/
theorem P3_exists {α : Type _} (D : α → α) (enc : α → Nat) (N : Nat)
    (hbound : ∀ x, enc x < N) (henc : ∀ a b, enc a = enc b → a = b) (x : α) :
    ∃ k n, FirstRepeat D x k n ∧ n ≤ N := by
  obtain ⟨i, j, hij, hjN, he⟩ := exists_repeat D enc N hbound x henc
  obtain ⟨n, ⟨k, hkn, hk⟩, hmin⟩ := exists_min_nat (fun n => ∃ k, k < n ∧ iter D n x = iter D k x)
    ⟨j, i, hij, he.symm⟩
  refine ⟨k, n, ⟨hkn, hk, ?_⟩, ?_⟩
  · intro a b hab hbn heq
    exact absurd (hmin b ⟨a, hab, heq.symm⟩) (by omega)
  · exact Nat.le_trans (hmin j ⟨i, hij, he.symm⟩) hjN

/-- Повний висновок P3: m, p з означення збігаються з даними першого повтору. -/
theorem P3 {α : Type _} (D : α → α) (enc : α → Nat) (N : Nat)
    (hbound : ∀ x, enc x < N) (henc : ∀ a b, enc a = enc b → a = b) (x : α) :
    ∃ m p, IsMin D x m p ∧ m + p ≤ N := by
  obtain ⟨k, n, hfr, hn⟩ := P3_exists D enc N hbound henc x
  refine ⟨k, n - k, P3_correct D x k n hfr, ?_⟩
  have := hfr.1
  omega

/-! ## §2. SUBIT⁺ і A4 -/

/-- Розширений стан (s, ρ) із правилом у стані; ρ задається індексом r : R. -/
structure Plus (R : Type _) where
  rule : R → S0 → S0
  g : R → S0 → R

/-- D₀(s, ρ) = (ρ(s), g₀(ρ, s)). -/
def Plus.D {R : Type _} (P : Plus R) (z : S0 × R) : S0 × R :=
  (P.rule z.2 z.1, P.g z.2 z.1)

/-- A4: автономний автомат (Q, δ) з ін'єкцією ι : Q → S₀ (тобто |Q| ≤ 64) вкладається в SUBIT⁺
з одним правилом: траєкторії збігаються. -/
theorem A4 {Q : Type _} (δ : Q → Q) (ι : Q → S0) (hι : ∀ a b, ι a = ι b → a = b) :
    ∃ P : Plus Unit, ∀ (n : Nat) (q : Q),
      iter P.D n (ι q, ()) = (ι (iter δ n q), ()) := by
  classical
  let ρ : S0 → S0 := fun s => if h : ∃ q, ι q = s then ι (δ (Classical.choose h)) else s
  have hρ : ∀ q, ρ (ι q) = ι (δ q) := by
    intro q
    have h : ∃ q', ι q' = ι q := ⟨q, rfl⟩
    have hc : Classical.choose h = q := hι _ _ (Classical.choose_spec h)
    simp only [ρ, dif_pos h, hc]
  refine ⟨⟨fun _ => ρ, fun _ _ => ()⟩, ?_⟩
  intro n
  induction n with
  | zero => intro q; rfl
  | succ n ih =>
    intro q
    have e : iter (Plus.D ⟨fun _ => ρ, fun _ _ => ()⟩) (n + 1) (ι q, ()) =
        iter (Plus.D ⟨fun _ => ρ, fun _ _ => ()⟩) n (ι (δ q), ()) := by
      rw [iter_succ']
      congr 1
      simp [Plus.D, hρ]
    rw [e, ih (δ q), iter_succ']

end Subit
