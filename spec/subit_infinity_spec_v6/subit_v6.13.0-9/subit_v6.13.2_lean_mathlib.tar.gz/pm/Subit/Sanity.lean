import Subit
/-!
# Перевірки нетривіальності (non-vacuity) для рецензента

Мета: показати, що означення й гіпотези ключових тверджень не порожні й не вироджені
(тобто що теореми не «істинні лише тому, що умови ніколи не виконуються»).
-/
open Subit
namespace Subit.Sanity

/-- Tree∞: єдиний листок у корені — дерево. -/
example : IsTree (fun σ : Pos => if σ = [] then Lab.leaf true else Lab.none) where
  t1 := by simp
  t2 := by intro σ h; split_ifs at h
  t3 := by
    intro σ a h i
    by_cases hσ : σ = []
    · subst hσ; simp
    · simp [hσ] at h
  t4 := by
    intro σ h τ
    by_cases hσ : σ = []
    · subst hσ; simp at h
    · have : σ ++ τ ≠ [] := fun h' => hσ (List.append_eq_nil_iff.1 h').1
      simp [this]

/-- Константа none — не дерево (порушено T1). -/
example : ¬ IsTree (fun _ : Pos => (Lab.none : Lab Bool)) := fun h => h.t1 rfl

/-- d_S розрізняє: різні корені дають відстань 1. -/
example : dS (fun _ : Pos => Lab.leaf true) (fun _ => Lab.leaf false) = 1 := by
  apply le_antisymm
  · apply Real.iSup_le _ (by norm_num)
    rintro ⟨σ, _⟩; exact pow_le_one₀ (by norm_num) (by norm_num)
  · have := le_dS (f := fun _ : Pos => Lab.leaf true) (g := fun _ => Lab.leaf false) (σ := []) (by simp)
    simpa using this

/-- Ентропія повного зсуву ненульова: гіпотеза «h_top > 0» у C3(б) досяжна. -/
example : (0 : EReal) < htop dC shift := by
  rw [lemma_4_6]
  exact_mod_cast Real.log_pos (by norm_num)

/-- C4a: непорожній випадок — перестановка двох точок. -/
example : Set.BijOn (fun i : Fin 2 => i + 1) Set.univ Set.univ ∧
    ∀ x ∈ (Set.univ : Set (Fin 2)), ∃ p, 0 < p ∧ iter (fun i : Fin 2 => i + 1) p x = x := by
  have := C4a (fun i : Fin 2 => i + 1) Set.univ Set.finite_univ (by
    ext y; simp; fin_cases y <;> simp)
  exact this

/-- D6: для тотожного відображення точкового простору ω = {*} належить класу FIXED. -/
example : holds (id : Unit → Unit) (omega (id : Unit → Unit) ()) (0 : EReal) TCls.FIXED := by
  refine ⟨(), ?_⟩
  ext y
  have hne : (omega (id : Unit → Unit) ()).Nonempty := omega_nonempty _ _
  obtain ⟨z, hz⟩ := hne
  simp only [Set.mem_singleton_iff]
  exact ⟨fun _ => trivial, fun _ => by cases y; cases z; exact hz⟩

/-- P3: приклади виконання алгоритму. -/
example : p3 cyc3 0 3 = PRes.computed 0 3 := by decide

end Subit.Sanity
