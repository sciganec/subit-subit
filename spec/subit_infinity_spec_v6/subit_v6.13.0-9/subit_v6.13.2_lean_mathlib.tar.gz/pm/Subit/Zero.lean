import Subit.FullShift
/-!
# SUBIT-∞ v6.11.3 — етап 3c: C7 (скінченні системи) і D3 (нерозтягувальні відображення)
Обидва — наслідки загальної леми: якщо s(n, ε) обмежене рівномірно за n, то h_top = 0.
-/
open Filter Classical
namespace Subit

section
variable {X : Type*}

theorem sepNum_nonneg_term (d : X → X → ℝ) (T : X → X) (n : ℕ) (ε : ℝ) :
    0 ≤ Real.log (sepNum d T n ε) / n := by
  apply div_nonneg
  · rcases Nat.eq_zero_or_pos (sepNum d T n ε) with h | h
    · rw [h]; simp
    · exact Real.log_nonneg (by exact_mod_cast h)
  · positivity

/-- Якщо для кожного ε > 0 величини s(n, ε) обмежені рівномірно за n, то h_top = 0. -/
theorem htop_eq_zero_of_bound (d : X → X → ℝ) (T : X → X)
    (hB : ∀ ε : ℝ, 0 < ε → ∃ B : ℕ, ∀ n, sepNum d T n ε ≤ B) : htop d T = 0 := by
  unfold htop
  apply le_antisymm
  · refine iSup_le fun ⟨ε, hε⟩ => ?_
    obtain ⟨B, hB'⟩ := hB ε hε
    refine le_of_forall_gt_imp_ge_of_dense fun c hc => ?_
    induction c using EReal.rec with
    | bot => exact absurd hc (by simp)
    | top => exact le_top
    | coe r =>
      have hr : (0 : ℝ) < r := by exact_mod_cast hc
      have ht := tendsto_const_div_atTop_nhds_zero_nat (Real.log (max B 1))
      have hev : ∀ᶠ n : ℕ in atTop, Real.log (max B 1) / n < r := ht.eventually (gt_mem_nhds hr)
      have hbound : ∀ᶠ n : ℕ in atTop,
          ((Real.log (sepNum d T n ε) / n : ℝ) : EReal) ≤ (r : EReal) := by
        filter_upwards [hev, eventually_ge_atTop 1] with n hn hn1
        have hnpos : (0 : ℝ) < n := by exact_mod_cast hn1
        have h1 : Real.log (sepNum d T n ε) ≤ Real.log (max B 1 : ℕ) := by
          apply log_nat_le (by positivity)
          exact le_trans (hB' n) (le_max_left _ _)
        have h2 : Real.log (sepNum d T n ε) / n ≤ Real.log (max B 1) / n := by
          apply div_le_div_of_nonneg_right _ hnpos.le
          simpa using h1
        exact_mod_cast le_trans h2 hn.le
      exact limsup_le_of_le (by isBoundedDefault) hbound
  · refine le_trans ?_ (le_iSup _ ⟨1, one_pos⟩)
    have : (fun _ : ℕ => (0 : EReal)) ≤ᶠ[atTop]
        fun n : ℕ => ((Real.log (sepNum d T n 1) / n : ℝ) : EReal) :=
      Eventually.of_forall fun n => EReal.coe_nonneg.2 (sepNum_nonneg_term d T n 1)
    have := limsup_le_limsup this (by isBoundedDefault) (by isBoundedDefault)
    simpa using this

/-- C7: на скінченному просторі h_top = 0 для довільного відображення й довільної d. -/
theorem C7 [Finite X] (d : X → X → ℝ) (T : X → X) : htop d T = 0 := by
  apply htop_eq_zero_of_bound
  intro ε _
  refine ⟨Nat.card X, fun n => sepNum_le _ fun S _ => ?_⟩
  letI := Fintype.ofFinite X
  rw [Nat.card_eq_fintype_card]
  exact Finset.card_le_univ S

end

/-- D3: нерозтягувальне відображення цілком обмеженого метричного простору має h_top = 0. -/
theorem D3 {X : Type*} [MetricSpace X] (hX : TotallyBounded (Set.univ : Set X)) (T : X → X)
    (hT : ∀ x y, dist (T x) (T y) ≤ dist x y) : htop (fun x y => dist x y) T = 0 := by
  have hiter : ∀ i x y, dist (iter T i x) (iter T i y) ≤ dist x y := by
    intro i
    induction i with
    | zero => intro x y; exact le_rfl
    | succ i ih => intro x y; exact le_trans (hT _ _) (ih x y)
  apply htop_eq_zero_of_bound
  intro ε hε
  obtain ⟨t, htfin, hcov⟩ := Metric.totallyBounded_iff.1 hX (ε / 2) (by positivity)
  haveI := htfin.fintype
  refine ⟨t.toFinset.card, fun n => sepNum_le _ fun S hS => ?_⟩
  -- ε-роздільність: різні точки S віддалені більш ніж на ε
  have hsep : ∀ x ∈ S, ∀ y ∈ S, x ≠ y → ε < dist x y := by
    intro x hx y hy hxy
    obtain ⟨i, _, hi⟩ := hS x hx y hy hxy
    exact lt_of_lt_of_le hi (hiter i x y)
  -- відображення x ↦ центр покриття
  have hmem : ∀ x : X, ∃ c ∈ t, x ∈ Metric.ball c (ε / 2) := by
    intro x
    have := hcov (Set.mem_univ x)
    simpa [Set.mem_iUnion] using this
  choose f hf1 hf2 using hmem
  have hinj : Set.InjOn (fun x => (⟨f x, hf1 x⟩ : t)) (S : Set X) := by
    intro x hx y hy hxy
    by_contra hne
    have hfxy : f x = f y := by simpa using congrArg Subtype.val hxy
    have h1 := Metric.mem_ball.1 (hf2 x)
    have h2 := Metric.mem_ball.1 (hf2 y)
    rw [← hfxy] at h2
    have h3 := dist_triangle x (f x) y
    rw [dist_comm (f x) y] at h3
    have h4 := hsep x hx y hy hne
    linarith
  have := Finset.card_le_card_of_injOn (fun x => (⟨f x, hf1 x⟩ : t)) (fun x _ => Finset.mem_univ _) hinj
  simpa using this

end Subit
