import Mathlib.CategoryTheory.Category.Basic
import Mathlib.CategoryTheory.Functor.FullyFaithful
import Mathlib.CategoryTheory.Limits.Shapes.BinaryProducts
import Mathlib.CategoryTheory.Limits.Shapes.Terminal
/-!
# SUBIT-∞ v6.11.5 — категорії SUBIT / SUBIT_full у підмножинній моделі (ℛ ⊆ S^S) — K1, K2, K3, K5

Об'єкт X = (S, ℛ, g): S ≠ ∅, ℛ ⊆ S^S непорожня, g : ℛ × S → ℛ. Це точна модель означення 7.1
(на відміну від індексної моделі `Cat.lean`). Категорії задано як екземпляри `CategoryTheory.Category`
з Mathlib, тож K1 (закони) — це перевірка полів екземпляра.
-/
open CategoryTheory CategoryTheory.Limits
namespace Subit.CatSub

structure SObj where
  S : Type
  hS : Nonempty S
  R : Set (S → S)
  hR : R.Nonempty
  g : R → S → R

/-- Означення 7.2: φ_S(ρ(s)) = (φ_ℛ ρ)(φ_S s). -/
structure SHom (X Y : SObj) where
  fS : X.S → Y.S
  fR : X.R → Y.R
  comm : ∀ (ρ : X.R) (s : X.S), fS (ρ.1 s) = (fR ρ).1 (fS s)

@[ext] theorem SHom.ext {X Y : SObj} {φ ψ : SHom X Y} (h1 : φ.fS = ψ.fS) (h2 : φ.fR = ψ.fR) :
    φ = ψ := by
  cases φ; cases ψ; simp at h1 h2; subst h1; subst h2; rfl

def SHom.comp' {X Y Z : SObj} (φ : SHom X Y) (ψ : SHom Y Z) : SHom X Z :=
  ⟨ψ.fS ∘ φ.fS, ψ.fR ∘ φ.fR, by
    intro ρ s
    show ψ.fS (φ.fS (ρ.1 s)) = (ψ.fR (φ.fR ρ)).1 (ψ.fS (φ.fS s))
    rw [φ.comm, ψ.comm]⟩

/-- K1: SUBIT — категорія. -/
instance : Category SObj where
  Hom := SHom
  id _ := ⟨id, id, fun _ _ => rfl⟩
  comp φ ψ := SHom.comp' φ ψ
  id_comp _ := rfl
  comp_id _ := rfl
  assoc _ _ _ := rfl

/-- SUBIT_full: ті самі об'єкти, морфізми додатково задовольняють
φ_ℛ(g_X(ρ,s)) = g_Y(φ_ℛ ρ, φ_S s) (означення 7.3). -/
structure SFObj where
  toObj : SObj

structure SFHom (X Y : SFObj) where
  toHom : SHom X.toObj Y.toObj
  commG : ∀ (ρ : X.toObj.R) (s : X.toObj.S),
    toHom.fR (X.toObj.g ρ s) = Y.toObj.g (toHom.fR ρ) (toHom.fS s)

@[ext] theorem SFHom.ext {X Y : SFObj} {φ ψ : SFHom X Y} (h1 : φ.toHom.fS = ψ.toHom.fS)
    (h2 : φ.toHom.fR = ψ.toHom.fR) : φ = ψ := by
  cases φ with | mk φ0 φg => cases ψ with | mk ψ0 ψg =>
    have := SHom.ext (φ := φ0) (ψ := ψ0) h1 h2
    subst this; rfl

def SFHom.comp' {X Y Z : SFObj} (φ : SFHom X Y) (ψ : SFHom Y Z) : SFHom X Z :=
  ⟨SHom.comp' φ.toHom ψ.toHom, by
    intro ρ s
    show ψ.toHom.fR (φ.toHom.fR (X.toObj.g ρ s)) =
      Z.toObj.g (ψ.toHom.fR (φ.toHom.fR ρ)) (ψ.toHom.fS (φ.toHom.fS s))
    rw [φ.commG, ψ.commG]⟩

/-- K1: SUBIT_full — категорія (широка підкатегорія SUBIT). -/
instance : Category SFObj where
  Hom := SFHom
  id _ := ⟨⟨id, id, fun _ _ => rfl⟩, fun _ _ => rfl⟩
  comp φ ψ := SFHom.comp' φ ψ
  id_comp _ := SFHom.ext rfl rfl
  comp_id _ := SFHom.ext rfl rfl
  assoc _ _ _ := SFHom.ext rfl rfl

/-! ### K2: термінальний об'єкт 1 = ({∗}, {id}, g_triv) -/

def term : SObj where
  S := Unit
  hS := ⟨()⟩
  R := {id}
  hR := ⟨id, rfl⟩
  g := fun r _ => r

def toTerm (X : SObj) : X ⟶ term :=
  ⟨fun _ => (), fun _ => ⟨id, rfl⟩, fun _ _ => rfl⟩

theorem K2 : Nonempty (IsTerminal term) :=
  ⟨IsTerminal.ofUniqueHom toTerm fun X φ => by
    apply SHom.ext
    · funext s; rfl
    · funext r
      apply Subtype.ext
      exact (Set.eq_of_mem_singleton (φ.fR r).2).trans
        (Set.eq_of_mem_singleton (toTerm X |>.fR r).2).symm⟩

/-! ### K3: добуток ρ ⊠ σ (потрібна непорожність S_X, S_Y для однозначності розкладу) -/

section Prod
variable (X Y : SObj)

/-- ℛ_{X×Y} = {ρ ⊠ σ : ρ ∈ ℛ_X, σ ∈ ℛ_Y}. -/
def boxSet : Set (X.S × Y.S → X.S × Y.S) :=
  {r | ∃ ρ ∈ X.R, ∃ σ ∈ Y.R, r = fun p => (ρ p.1, σ p.2)}

variable {X Y}

theorem decEx (r : boxSet X Y) :
    ∃ ρ : X.R, ∃ σ : Y.R, r.1 = fun p => (ρ.1 p.1, σ.1 p.2) := by
  obtain ⟨ρ, hρ, σ, hσ, h⟩ := r.2
  exact ⟨⟨ρ, hρ⟩, ⟨σ, hσ⟩, h⟩

/-- Розклад r = ρ ⊠ σ (вибір). -/
noncomputable def dec1 (r : boxSet X Y) : X.R := Classical.choose (decEx r)
noncomputable def dec2 (r : boxSet X Y) : Y.R := Classical.choose (Classical.choose_spec (decEx r))

theorem dec_spec (r : boxSet X Y) : r.1 = fun p => ((dec1 r).1 p.1, (dec2 r).1 p.2) :=
  Classical.choose_spec (Classical.choose_spec (decEx r))

/-- Однозначність розкладу (використовує S_Y ≠ ∅). -/
theorem dec1_eq (r : boxSet X Y) (ρ : X.R) (σ : Y.R)
    (h : r.1 = fun p => (ρ.1 p.1, σ.1 p.2)) : dec1 r = ρ := by
  obtain ⟨y0⟩ := Y.hS
  apply Subtype.ext; funext x
  have h1 := congrArg Prod.fst (congrFun (dec_spec r) (x, y0))
  have h2 := congrArg Prod.fst (congrFun h (x, y0))
  exact h1.symm.trans h2 |>.symm.symm

theorem dec2_eq (r : boxSet X Y) (ρ : X.R) (σ : Y.R)
    (h : r.1 = fun p => (ρ.1 p.1, σ.1 p.2)) : dec2 r = σ := by
  obtain ⟨x0⟩ := X.hS
  apply Subtype.ext; funext y
  have h1 := congrArg Prod.snd (congrFun (dec_spec r) (x0, y))
  have h2 := congrArg Prod.snd (congrFun h (x0, y))
  exact h1.symm.trans h2 |>.symm.symm

/-- Добуток X × Y у підмножинній моделі. -/
noncomputable def prodObj (X Y : SObj) : SObj where
  S := X.S × Y.S
  hS := ⟨(Classical.choice X.hS, Classical.choice Y.hS)⟩
  R := boxSet X Y
  hR := by
    obtain ⟨ρ, hρ⟩ := X.hR
    obtain ⟨σ, hσ⟩ := Y.hR
    exact ⟨_, ρ, hρ, σ, hσ, rfl⟩
  g := fun r p =>
    ⟨fun q => ((X.g (dec1 r) p.1).1 q.1, (Y.g (dec2 r) p.2).1 q.2),
      _, (X.g (dec1 r) p.1).2, _, (Y.g (dec2 r) p.2).2, rfl⟩

noncomputable def prX (X Y : SObj) : prodObj X Y ⟶ X :=
  ⟨Prod.fst, dec1, fun r s => by
    show (r.1 s).1 = ((dec1 r).1) s.1
    rw [dec_spec r]⟩

noncomputable def prY (X Y : SObj) : prodObj X Y ⟶ Y :=
  ⟨Prod.snd, dec2, fun r s => by
    show (r.1 s).2 = ((dec2 r).1) s.2
    rw [dec_spec r]⟩

/-- Пара ⟨u, v⟩. -/
def liftS {Z : SObj} (u : Z ⟶ X) (v : Z ⟶ Y) : Z ⟶ prodObj X Y :=
  ⟨fun z => (u.fS z, v.fS z),
   fun ρ => ⟨fun p => ((u.fR ρ).1 p.1, (v.fR ρ).1 p.2),
     _, (u.fR ρ).2, _, (v.fR ρ).2, rfl⟩,
   fun ρ s => by
    show (u.fS (ρ.1 s), v.fS (ρ.1 s)) = ((u.fR ρ).1 (u.fS s), (v.fR ρ).1 (v.fS s))
    rw [u.comm, v.comm]⟩

theorem liftS_fst {Z : SObj} (u : Z ⟶ X) (v : Z ⟶ Y) : liftS u v ≫ prX X Y = u := by
  apply SHom.ext
  · rfl
  · funext ρ
    apply Subtype.ext
    show (dec1 ((liftS u v).fR ρ)).1 = (u.fR ρ).1
    exact congrArg Subtype.val (dec1_eq _ (u.fR ρ) (v.fR ρ) rfl)

theorem liftS_snd {Z : SObj} (u : Z ⟶ X) (v : Z ⟶ Y) : liftS u v ≫ prY X Y = v := by
  apply SHom.ext
  · rfl
  · funext ρ
    apply Subtype.ext
    show (dec2 ((liftS u v).fR ρ)).1 = (v.fR ρ).1
    exact congrArg Subtype.val (dec2_eq _ (u.fR ρ) (v.fR ρ) rfl)

theorem liftS_unique {Z : SObj} (u : Z ⟶ X) (v : Z ⟶ Y) (w : Z ⟶ prodObj X Y)
    (h1 : w ≫ prX X Y = u) (h2 : w ≫ prY X Y = v) : w = liftS u v := by
  have a1 : ∀ z, (w.fS z).1 = u.fS z := fun z => congrFun (congrArg SHom.fS h1) z
  have a2 : ∀ z, (w.fS z).2 = v.fS z := fun z => congrFun (congrArg SHom.fS h2) z
  have b1 : ∀ ρ, dec1 (w.fR ρ) = u.fR ρ := fun ρ => congrFun (congrArg SHom.fR h1) ρ
  have b2 : ∀ ρ, dec2 (w.fR ρ) = v.fR ρ := fun ρ => congrFun (congrArg SHom.fR h2) ρ
  apply SHom.ext
  · funext z; exact Prod.ext (a1 z) (a2 z)
  · funext ρ
    apply Subtype.ext
    show (w.fR ρ).1 = fun p => ((u.fR ρ).1 p.1, (v.fR ρ).1 p.2)
    rw [dec_spec (w.fR ρ), b1, b2]
    rfl

/-- K3: X × Y — добуток у SUBIT. -/
noncomputable def prodIsLimit (X Y : SObj) : IsLimit (BinaryFan.mk (prX X Y) (prY X Y)) :=
  BinaryFan.IsLimit.mk _ (fun u v => liftS u v) (fun u v => liftS_fst u v)
    (fun u v => liftS_snd u v) (fun u v w h1 h2 => liftS_unique u v w h1 h2)

/-! ### K3 у SUBIT_full: проєкції й пара g-сумісні, єдиність успадковується -/

theorem prX_commG (X Y : SObj) (r : (prodObj X Y).R) (p : (prodObj X Y).S) :
    (prX X Y).fR ((prodObj X Y).g r p) = X.g ((prX X Y).fR r) ((prX X Y).fS p) := by
  show dec1 ((prodObj X Y).g r p) = X.g (dec1 r) p.1
  exact dec1_eq _ _ (Y.g (dec2 r) p.2) rfl

theorem prY_commG (X Y : SObj) (r : (prodObj X Y).R) (p : (prodObj X Y).S) :
    (prY X Y).fR ((prodObj X Y).g r p) = Y.g ((prY X Y).fR r) ((prY X Y).fS p) := by
  show dec2 ((prodObj X Y).g r p) = Y.g (dec2 r) p.2
  exact dec2_eq _ (X.g (dec1 r) p.1) _ rfl

@[reducible] def fullObj (X : SObj) : SFObj := ⟨X⟩

noncomputable def prXF (X Y : SObj) : fullObj (prodObj X Y) ⟶ fullObj X :=
  ⟨prX X Y, prX_commG X Y⟩
noncomputable def prYF (X Y : SObj) : fullObj (prodObj X Y) ⟶ fullObj Y :=
  ⟨prY X Y, prY_commG X Y⟩

/-- Пара ⟨u, v⟩ у SUBIT_full: умова g-сумісності. -/
noncomputable def liftF {Z X Y : SObj} (u : fullObj Z ⟶ fullObj X) (v : fullObj Z ⟶ fullObj Y) :
    fullObj Z ⟶ fullObj (prodObj X Y) :=
  ⟨liftS u.toHom v.toHom, fun (ρ : Z.R) (s : Z.S) => by
    have e1 := dec1_eq ((liftS u.toHom v.toHom).fR ρ) (u.toHom.fR ρ) (v.toHom.fR ρ) rfl
    have e2 := dec2_eq ((liftS u.toHom v.toHom).fR ρ) (u.toHom.fR ρ) (v.toHom.fR ρ) rfl
    have c1 : u.toHom.fR (Z.g ρ s) = X.g (u.toHom.fR ρ) (u.toHom.fS s) := u.commG ρ s
    have c2 : v.toHom.fR (Z.g ρ s) = Y.g (v.toHom.fR ρ) (v.toHom.fS s) := v.commG ρ s
    have goal : ∀ q : X.S × Y.S,
        ((u.toHom.fR (Z.g ρ s)).1 q.1, (v.toHom.fR (Z.g ρ s)).1 q.2) =
        ((X.g (dec1 ((liftS u.toHom v.toHom).fR ρ)) (u.toHom.fS s)).1 q.1,
         (Y.g (dec2 ((liftS u.toHom v.toHom).fR ρ)) (v.toHom.fS s)).1 q.2) := by
      intro q; rw [e1, e2, c1, c2]
    apply Subtype.ext
    funext q
    exact goal q⟩

/-- K3 у SUBIT_full: X × Y — добуток. -/
noncomputable def prodIsLimitFull (X Y : SObj) :
    IsLimit (BinaryFan.mk (prXF X Y) (prYF X Y)) :=
  BinaryFan.IsLimit.mk _ (fun u v => liftF u v)
    (fun u v => SFHom.ext (congrArg SHom.fS (liftS_fst u.toHom v.toHom))
      (congrArg SHom.fR (liftS_fst u.toHom v.toHom)))
    (fun u v => SFHom.ext (congrArg SHom.fS (liftS_snd u.toHom v.toHom))
      (congrArg SHom.fR (liftS_snd u.toHom v.toHom)))
    (fun u v w h1 h2 => by
      have := liftS_unique u.toHom v.toHom w.toHom (congrArg SFHom.toHom h1) (congrArg SFHom.toHom h2)
      exact SFHom.ext (congrArg SHom.fS this) (congrArg SHom.fR this))

end Prod

end Subit.CatSub
