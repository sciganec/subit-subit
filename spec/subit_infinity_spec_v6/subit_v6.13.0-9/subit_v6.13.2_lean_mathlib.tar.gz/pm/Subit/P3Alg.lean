import Subit.Basic
/-!
# SUBIT-∞ v6.11.5 — P3 (точний режим) як конкретний алгоритм із відображенням `visited`, і P3′

Алгоритм §3.1.3: цикл n = 0,…,N (N+1 ітерацій); `visited` — асоціативний список (стан, n);
гілка RESOURCE_EXCEEDED — вичерпання циклу без повтору.
-/
namespace Subit

section Alg
variable {α : Type _} [DecidableEq α]

inductive PRes
  | computed (m p : Nat)
  | exceeded
  deriving DecidableEq, Repr

/-- Пошук у `visited`. -/
def look (vis : List (α × Nat)) (s : α) : Option Nat :=
  (vis.find? (fun q => decide (q.1 = s))).map Prod.snd

/-- Цикл алгоритму: n — поточний крок, k — скільки ітерацій лишилось, s — стан ŝₙ. -/
def go (D : α → α) : Nat → Nat → α → List (α × Nat) → PRes
  | _, 0, _, _ => .exceeded
  | n, k + 1, s, vis =>
    match look vis s with
    | some m => .computed m (n - m)
    | none => go D (n + 1) k (D s) ((s, n) :: vis)

/-- P3: для n = 0, …, N. -/
def p3 (D : α → α) (s0 : α) (N : Nat) : PRes := go D 0 (N + 1) s0 []

/-- Список `visited` після n кроків. -/
def visList (D : α → α) (s0 : α) : Nat → List (α × Nat)
  | 0 => []
  | n + 1 => (iter D n s0, n) :: visList D s0 n

theorem look_none (D : α → α) (s0 : α) (n : Nat) (s : α) :
    look (visList D s0 n) s = none ↔ ∀ i, i < n → iter D i s0 ≠ s := by
  induction n with
  | zero => simp [look, visList]
  | succ n ih =>
    unfold look at *
    simp only [visList, List.find?_cons]
    by_cases h : iter D n s0 = s
    · simp [h]
      exact ⟨n, by omega, h⟩
    · simp only [h, decide_false]
      rw [ih]
      constructor
      · intro hh i hi
        by_cases hin : i = n
        · subst hin; exact h
        · exact hh i (by omega)
      · intro hh i hi; exact hh i (by omega)

theorem look_some (D : α → α) (s0 : α) (n i : Nat) (s : α) (hi : i < n) (his : iter D i s0 = s)
    (huniq : ∀ j, j < n → iter D j s0 = s → j = i) :
    look (visList D s0 n) s = some i := by
  induction n with
  | zero => omega
  | succ n ih =>
    unfold look at *
    simp only [visList, List.find?_cons]
    by_cases h : iter D n s0 = s
    · have := huniq n (by omega) h
      subst this
      simp [h]
    · simp only [h, decide_false]
      have hin : i < n := by
        by_cases e : i = n
        · subst e; exact absurd his h
        · omega
      exact ih hin (fun j hj hjs => huniq j (by omega) hjs)

/-- Корисність: повторів до кроку n немає. -/
def NoRep (D : α → α) (s0 : α) (n : Nat) : Prop :=
  ∀ i j, i < j → j < n → iter D i s0 ≠ iter D j s0

theorem go_computed (D : α → α) (s0 : α) (kk nn : Nat) (hfr : FirstRepeat D s0 kk nn) :
    ∀ k n, n ≤ nn → nn < n + k →
      go D n k (iter D n s0) (visList D s0 n) = .computed kk (nn - kk) := by
  intro k
  induction k with
  | zero => intro n _ h; omega
  | succ k ih =>
    intro n hn hnk
    obtain ⟨hkn, heq, hdist⟩ := hfr
    rcases Nat.lt_or_ge n nn with hlt | hge
    · -- n < nn: запису немає
      have hnone : look (visList D s0 n) (iter D n s0) = none := by
        rw [look_none]
        intro i hi he
        exact hdist i n hi hlt he
      show (match look (visList D s0 n) (iter D n s0) with
        | some m => PRes.computed m (n - m)
        | none => go D (n + 1) k (D (iter D n s0)) ((iter D n s0, n) :: visList D s0 n)) = _
      rw [hnone]
      exact ih (n + 1) (by omega) (by omega)
    · have hn' : n = nn := by omega
      subst hn'
      have hs : look (visList D s0 n) (iter D n s0) = some kk := by
        apply look_some D s0 n kk _ hkn heq.symm
        intro j hj hjs
        refine Classical.byContradiction fun hne => ?_
        rcases Nat.lt_or_gt_of_ne hne with h1 | h1
        · exact hdist j kk h1 hkn (hjs.trans heq)
        · exact hdist kk j h1 hj (heq.symm.trans hjs.symm)
      show (match look (visList D s0 n) (iter D n s0) with
        | some m => PRes.computed m (n - m)
        | none => go D (n + 1) k (D (iter D n s0)) ((iter D n s0, n) :: visList D s0 n)) = _
      rw [hs]

theorem go_exceeded (D : α → α) (s0 : α) :
    ∀ k n, NoRep D s0 n → (∀ kk nn, FirstRepeat D s0 kk nn → n + k ≤ nn) →
      go D n k (iter D n s0) (visList D s0 n) = .exceeded := by
  intro k
  induction k with
  | zero => intro n _ _; rfl
  | succ k ih =>
    intro n hd hno
    have hnone : look (visList D s0 n) (iter D n s0) = none := by
      rw [look_none]
      intro i hi he
      have := hno i n ⟨hi, he.symm, hd⟩
      omega
    show (match look (visList D s0 n) (iter D n s0) with
      | some m => PRes.computed m (n - m)
      | none => go D (n + 1) k (D (iter D n s0)) ((iter D n s0, n) :: visList D s0 n)) = _
    rw [hnone]
    apply ih (n + 1)
    · intro i j hij hj
      by_cases hjn : j = n
      · subst hjn
        have := (look_none D s0 j (iter D j s0)).1 hnone i hij
        exact this
      · exact hd i j hij (by omega)
    · intro kk nn hfr
      have := hno kk nn hfr
      omega

/-- P3 (алгоритм): якщо перший повтор (k, n) існує і n ≤ N, результат — COMPUTED(k, n − k). -/
theorem p3_computed (D : α → α) (s0 : α) (N kk nn : Nat) (hfr : FirstRepeat D s0 kk nn)
    (hn : nn ≤ N) : p3 D s0 N = .computed kk (nn - kk) :=
  go_computed D s0 kk nn hfr (N + 1) 0 (Nat.zero_le _) (by omega)

/-- P3′: якщо повтору в межах N нема, результат — RESOURCE_EXCEEDED. -/
theorem p3_exceeded (D : α → α) (s0 : α) (N : Nat)
    (h : ¬ ∃ kk nn, FirstRepeat D s0 kk nn ∧ nn ≤ N) : p3 D s0 N = .exceeded := by
  apply go_exceeded D s0 (N + 1) 0
  · intro i j hij hj; omega
  · intro kk nn hfr
    refine Classical.byContradiction fun hlt => ?_
    exact h ⟨kk, nn, hfr, by omega⟩

/-- P3 (повна коректність у скінченній системі): алгоритм завершується з COMPUTED(m, p),
де (m, p) — мінімальні дані з означення 3.1; RESOURCE_EXCEEDED недосяжна. -/
theorem p3_correct_finite (D : α → α) (enc : α → Nat) (N : Nat) (hbound : ∀ x, enc x < N)
    (henc : ∀ a b, enc a = enc b → a = b) (s0 : α) :
    ∃ m p, p3 D s0 N = .computed m p ∧ IsMin D s0 m p ∧ m + p ≤ N := by
  obtain ⟨k, n, hfr, hn⟩ := P3_exists D enc N hbound henc s0
  refine ⟨k, n - k, p3_computed D s0 N k n hfr hn, P3_correct D s0 k n hfr, ?_⟩
  have := hfr.1; omega

/-- Цикл як список станів. -/
def orbit (D : α → α) (s : α) : Nat → List α
  | 0 => []
  | p + 1 => s :: orbit D (D s) p

omit [DecidableEq α] in
theorem orbit_eq (D : α → α) (s : α) (p : Nat) :
    orbit D s p = (List.range p).map (fun i => iter D i s) := by
  induction p generalizing s with
  | zero => rfl
  | succ p ih =>
    rw [orbit, ih, List.range_succ_eq_map, List.map_cons, List.map_map]
    simp only [iter, Function.comp_def]
    congr 1
    apply List.map_congr_left
    intro i _
    exact (iter_succ' D i s).symm

end Alg

/-! ## P3′: бюджетований режим — приклад досяжності RESOURCE_EXCEEDED -/

/-- 3-цикл на Fin 3: i ↦ i + 1. -/
def cyc3 : Fin 3 → Fin 3 := fun i => i + 1

/-- N_max = 1 < #Q₀ = 3: гілка RESOURCE_EXCEEDED досяжна. -/
theorem p3'_reachable : p3 cyc3 0 1 = .exceeded := by decide

/-- ...але недостатній горизонт не гарантує її: для нерухомої точки повтор знаходиться раніше. -/
theorem p3'_not_always : p3 (id : Fin 3 → Fin 3) 0 1 = .computed 0 1 := by decide

end Subit
