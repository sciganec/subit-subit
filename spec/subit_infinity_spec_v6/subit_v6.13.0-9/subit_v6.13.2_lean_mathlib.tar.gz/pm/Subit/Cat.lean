import Subit.Basic
/-!
# SUBIT-∞ v6.11.2 — етап 2d: категорії SUBIT / SUBIT_full (K1, K2, K3)

УВАГА (розбіжність із текстом специфікації): правила тут задано **індексною моделлю** —
тип індексів `R` і функція обчислення `eval : R → S → S` (не обов'язково ін'єктивна),
а не підмножиною ℛ ⊆ S^S. Це узагальнення; у ньому добуток — пари індексів, тож умова
«S непорожні» для однозначності розкладу ρ ⊠ σ не потрібна. Формалізація підмножинної
моделі (ін'єктивний eval) не виконана.
-/
namespace Subit

structure Obj where
  S : Type
  R : Type
  eval : R → S → S
  g : R → S → R

structure Hom (X Y : Obj) where
  fS : X.S → Y.S
  fR : X.R → Y.R
  /-- φ_S(ρ(s)) = (φ_R ρ)(φ_S s) -/
  comm : ∀ ρ s, fS (X.eval ρ s) = Y.eval (fR ρ) (fS s)

/-- SUBIT_full: додатково φ_R(g_X(ρ,s)) = g_Y(φ_R ρ, φ_S s). -/
structure HomFull (X Y : Obj) extends Hom X Y where
  commG : ∀ ρ s, fR (X.g ρ s) = Y.g (fR ρ) (fS s)

def Hom.id (X : Obj) : Hom X X := ⟨fun s => s, fun r => r, fun _ _ => rfl⟩

def Hom.comp {X Y Z : Obj} (ψ : Hom Y Z) (φ : Hom X Y) : Hom X Z :=
  ⟨fun s => ψ.fS (φ.fS s), fun r => ψ.fR (φ.fR r), by
    intro ρ s
    show ψ.fS (φ.fS (X.eval ρ s)) = Z.eval (ψ.fR (φ.fR ρ)) (ψ.fS (φ.fS s))
    rw [φ.comm, ψ.comm]⟩

def HomFull.id (X : Obj) : HomFull X X := ⟨Hom.id X, fun _ _ => rfl⟩

def HomFull.comp {X Y Z : Obj} (ψ : HomFull Y Z) (φ : HomFull X Y) : HomFull X Z :=
  ⟨Hom.comp ψ.toHom φ.toHom, by
    intro ρ s
    show ψ.fR (φ.fR (X.g ρ s)) = Z.g (ψ.fR (φ.fR ρ)) (ψ.fS (φ.fS s))
    rw [φ.commG, ψ.commG]⟩

/-- K1: закони категорії (рівність морфізмів — покомпонентна; доведення пруф-ірелевантністю). -/
theorem Hom.ext {X Y : Obj} {φ ψ : Hom X Y} (h1 : φ.fS = ψ.fS) (h2 : φ.fR = ψ.fR) : φ = ψ := by
  cases φ; cases ψ; simp at h1 h2; subst h1; subst h2; rfl

theorem K1_id_comp {X Y : Obj} (φ : Hom X Y) : Hom.comp (Hom.id Y) φ = φ := Hom.ext rfl rfl
theorem K1_comp_id {X Y : Obj} (φ : Hom X Y) : Hom.comp φ (Hom.id X) = φ := Hom.ext rfl rfl
theorem K1_assoc {W X Y Z : Obj} (χ : Hom Y Z) (ψ : Hom X Y) (φ : Hom W X) :
    Hom.comp χ (Hom.comp ψ φ) = Hom.comp (Hom.comp χ ψ) φ := Hom.ext rfl rfl

theorem HomFull.ext {X Y : Obj} {φ ψ : HomFull X Y} (h1 : φ.fS = ψ.fS) (h2 : φ.fR = ψ.fR) :
    φ = ψ := by
  cases φ with | mk φ0 φg => cases ψ with | mk ψ0 ψg =>
    have := Hom.ext (φ := φ0) (ψ := ψ0) h1 h2
    subst this; rfl

theorem K1_full_id_comp {X Y : Obj} (φ : HomFull X Y) :
    HomFull.comp (HomFull.id Y) φ = φ := HomFull.ext rfl rfl
theorem K1_full_comp_id {X Y : Obj} (φ : HomFull X Y) :
    HomFull.comp φ (HomFull.id X) = φ := HomFull.ext rfl rfl
theorem K1_full_assoc {W X Y Z : Obj} (χ : HomFull Y Z) (ψ : HomFull X Y) (φ : HomFull W X) :
    HomFull.comp χ (HomFull.comp ψ φ) = HomFull.comp (HomFull.comp χ ψ) φ := HomFull.ext rfl rfl

/-! ### K2: термінальний об'єкт -/

def Term : Obj := ⟨Unit, Unit, fun _ s => s, fun r _ => r⟩

def toTerm (X : Obj) : Hom X Term := ⟨fun _ => (), fun _ => (), fun _ _ => rfl⟩

theorem K2 (X : Obj) : ∀ φ : Hom X Term, φ = toTerm X :=
  fun φ => Hom.ext (funext fun _ => rfl) (funext fun _ => rfl)

def toTermFull (X : Obj) : HomFull X Term := ⟨toTerm X, fun _ _ => rfl⟩

theorem K2_full (X : Obj) : ∀ φ : HomFull X Term, φ = toTermFull X :=
  fun φ => HomFull.ext (funext fun _ => rfl) (funext fun _ => rfl)

/-! ### K3: добуток -/

def Prod (X Y : Obj) : Obj :=
  ⟨X.S × Y.S, X.R × Y.R, fun r s => (X.eval r.1 s.1, Y.eval r.2 s.2),
    fun r s => (X.g r.1 s.1, Y.g r.2 s.2)⟩

def prX (X Y : Obj) : Hom (Prod X Y) X := ⟨fun s => s.1, fun r => r.1, fun _ _ => rfl⟩
def prY (X Y : Obj) : Hom (Prod X Y) Y := ⟨fun s => s.2, fun r => r.2, fun _ _ => rfl⟩

def pair {Z X Y : Obj} (u : Hom Z X) (v : Hom Z Y) : Hom Z (Prod X Y) :=
  ⟨fun z => (u.fS z, v.fS z), fun r => (u.fR r, v.fR r), by
    intro ρ s
    show (u.fS (Z.eval ρ s), v.fS (Z.eval ρ s)) =
      (X.eval (u.fR ρ) (u.fS s), Y.eval (v.fR ρ) (v.fS s))
    rw [u.comm, v.comm]⟩

theorem K3_fst {Z X Y : Obj} (u : Hom Z X) (v : Hom Z Y) : Hom.comp (prX X Y) (pair u v) = u :=
  Hom.ext rfl rfl
theorem K3_snd {Z X Y : Obj} (u : Hom Z X) (v : Hom Z Y) : Hom.comp (prY X Y) (pair u v) = v :=
  Hom.ext rfl rfl

/-- K3 (єдиність): будь-який w з pr∘w = u, pr∘w = v дорівнює pair u v. -/
theorem K3_unique {Z X Y : Obj} (u : Hom Z X) (v : Hom Z Y) (w : Hom Z (Prod X Y))
    (h1 : Hom.comp (prX X Y) w = u) (h2 : Hom.comp (prY X Y) w = v) : w = pair u v := by
  have a1 : ∀ z, (w.fS z).1 = u.fS z := fun z => congrFun (congrArg Hom.fS h1) z
  have a2 : ∀ z, (w.fS z).2 = v.fS z := fun z => congrFun (congrArg Hom.fS h2) z
  have b1 : ∀ r, (w.fR r).1 = u.fR r := fun r => congrFun (congrArg Hom.fR h1) r
  have b2 : ∀ r, (w.fR r).2 = v.fR r := fun r => congrFun (congrArg Hom.fR h2) r
  refine Hom.ext (funext fun z => ?_) (funext fun r => ?_)
  · exact Prod.ext (a1 z) (a2 z)
  · exact Prod.ext (b1 r) (b2 r)

/-- Проєкції — морфізми SUBIT_full (g-сумісні). -/
def prXFull (X Y : Obj) : HomFull (Prod X Y) X := ⟨prX X Y, fun _ _ => rfl⟩
def prYFull (X Y : Obj) : HomFull (Prod X Y) Y := ⟨prY X Y, fun _ _ => rfl⟩

def pairFull {Z X Y : Obj} (u : HomFull Z X) (v : HomFull Z Y) : HomFull Z (Prod X Y) :=
  ⟨pair u.toHom v.toHom, by
    intro ρ s
    show (u.fR (Z.g ρ s), v.fR (Z.g ρ s)) = (X.g (u.fR ρ) (u.fS s), Y.g (v.fR ρ) (v.fS s))
    rw [u.commG, v.commG]⟩

end Subit
