import Subit.OmegaLimit
/-!
# SUBIT-∞ v6.11.4 — D6: шість класів ω-границі розбивають усі траєкторії
-/
open Filter Classical
namespace Subit

section Ent
variable {X : Type*}

theorem htop_nonneg (d : X → X → ℝ) (T : X → X) : 0 ≤ htop d T := by
  unfold htop
  refine le_trans ?_ (le_iSup _ ⟨1, one_pos⟩)
  have : (fun _ : ℕ => (0 : EReal)) ≤ᶠ[atTop]
      fun n : ℕ => ((Real.log (sepNum d T n 1) / n : ℝ) : EReal) :=
    Eventually.of_forall fun n => EReal.coe_nonneg.2 (sepNum_nonneg_term d T n 1)
  have := limsup_le_limsup this (by isBoundedDefault) (by isBoundedDefault)
  simpa using this

/-- Звуження D на інваріантну множину W. -/
def restrict (D : X → X) (W : Set X) (hW : Set.MapsTo D W W) : W → W :=
  fun a => ⟨D a.1, hW a.2⟩

/-- Ентропія D|W щодо відстані d. -/
noncomputable def htopOn (d : X → X → ℝ) (D : X → X) (W : Set X) (hW : Set.MapsTo D W W) : EReal :=
  htop (fun a b : W => d a.1 b.1) (restrict D W hW)

theorem htopOn_finite (d : X → X → ℝ) (D : X → X) (W : Set X) (hW : Set.MapsTo D W W)
    (hf : W.Finite) : htopOn d D W hW = 0 := by
  haveI : Finite W := hf.to_subtype
  exact C7 _ _

end Ent

section TCls
variable {X : Type*} [TopologicalSpace X]

/-- Мінімальність: єдина непорожня замкнена інваріантна підмножина — сама W. -/
def MinOn (D : X → X) (W : Set X) : Prop :=
  ∀ V : Set X, V ⊆ W → V.Nonempty → IsClosed V → Set.MapsTo D V V → V = W

inductive TCls | FIXED | PERIODIC | MIN_ZERO | MIN_POS | NONMIN_ZERO | NONMIN_POS

/-- Умова класу (з таблиці 11.3); `h` — ентропія звуження. -/
def holds (D : X → X) (W : Set X) (h : EReal) : TCls → Prop
  | .FIXED => ∃ p, W = {p}
  | .PERIODIC => W.Finite ∧ W.Nontrivial
  | .MIN_ZERO => W.Infinite ∧ MinOn D W ∧ h = 0
  | .MIN_POS => W.Infinite ∧ MinOn D W ∧ 0 < h
  | .NONMIN_ZERO => W.Infinite ∧ ¬ MinOn D W ∧ h = 0
  | .NONMIN_POS => W.Infinite ∧ ¬ MinOn D W ∧ 0 < h

/-- D6 (чиста частина): якщо W ≠ ∅, h ≥ 0 і скінченна W має h = 0,
то рівно один із шести класів виконується. -/
theorem D6_abstract (D : X → X) (W : Set X) (h : EReal) (hne : W.Nonempty) (h0 : 0 ≤ h)
    (hfin : W.Finite → h = 0) : ∃! c : TCls, holds D W h c := by
  have hcases : ∃ c, holds D W h c := by
    by_cases hF : W.Finite
    · rcases hne.exists_eq_singleton_or_nontrivial with ⟨p, hp⟩ | hn
      · exact ⟨.FIXED, p, hp⟩
      · exact ⟨.PERIODIC, hF, hn⟩
    · have hI : W.Infinite := hF
      by_cases hM : MinOn D W <;> rcases h0.eq_or_lt with hz | hp
      · exact ⟨.MIN_ZERO, hI, hM, hz.symm⟩
      · exact ⟨.MIN_POS, hI, hM, hp⟩
      · exact ⟨.NONMIN_ZERO, hI, hM, hz.symm⟩
      · exact ⟨.NONMIN_POS, hI, hM, hp⟩
  obtain ⟨c, hc⟩ := hcases
  refine ⟨c, hc, fun c' hc' => ?_⟩
  -- єдиність: розбір пар
  have key : ∀ a b : TCls, holds D W h a → holds D W h b → a = b := by
    intro a b ha hb
    cases a <;> cases b <;> simp only [holds] at ha hb <;>
      first
      | rfl
      | (exfalso
         first
         | (obtain ⟨p, rfl⟩ := ha
            first
            | exact Set.not_nontrivial_singleton hb.2
            | exact hb.1 (Set.finite_singleton p))
         | (obtain ⟨p, rfl⟩ := hb
            first
            | exact Set.not_nontrivial_singleton ha.2
            | exact ha.1 (Set.finite_singleton p))
         | exact hb.1 ha.1
         | exact ha.1 hb.1
         | simp_all)
  exact key c' c hc' hc

end TCls


section Traj
variable {X : Type*} [TopologicalSpace X] [CompactSpace X] [T2Space X]

omit [T2Space X] in
/-- D6: для неперервного D на компакті ω(x) попадає рівно в один із шести класів
(ентропія звуження — щодо довільної функції відстані d). -/
theorem D6 (d : X → X → ℝ) (D : X → X) (hD : Continuous D) (x : X) :
    ∃ hW : Set.MapsTo D (omega D x) (omega D x),
      ∃! c : TCls, holds D (omega D x) (htopOn d D (omega D x) hW) c := by
  have hW : Set.MapsTo D (omega D x) (omega D x) := fun y hy => omega_forward D hD x ⟨y, hy, rfl⟩
  refine ⟨hW, D6_abstract D _ _ (omega_nonempty D x) (htop_nonneg _ _) (htopOn_finite d D _ hW)⟩

end Traj

end Subit
