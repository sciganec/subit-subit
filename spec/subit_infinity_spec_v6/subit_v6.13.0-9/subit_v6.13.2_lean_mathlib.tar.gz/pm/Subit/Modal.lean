import Subit.Basic
/-!
# SUBIT-∞ v6.11.2 — етап 2c: модальна логіка §6.1 (M1: 14 аксіом, M2/M6)

LTL-подібна семантика над довільною динамікою D : α → α.
-/
namespace Subit

variable {α : Type _} (D : α → α)

def mX (U : α → Prop) (x : α) : Prop := U (D x)
def mDia (U : α → Prop) (x : α) : Prop := ∃ n, U (iter D n x)
def mDiaP (U : α → Prop) (x : α) : Prop := ∃ n, 1 ≤ n ∧ U (iter D n x)
def mBox (U : α → Prop) (x : α) : Prop := ∀ n, U (iter D n x)
/-- ↺U := ∃ k > 1, Dᵏ x ∈ U. -/
def mRec (U : α → Prop) (x : α) : Prop := ∃ k, 1 < k ∧ U (iter D k x)

variable {D}

theorem X1 (U : α → Prop) (x : α) : mX D U x → mDiaP D U x :=
  fun h => ⟨1, Nat.le_refl _, h⟩

theorem X2 (U V : α → Prop) (x : α) : (mX D U x ∧ mX D V x) ↔ mX D (fun y => U y ∧ V y) x :=
  Iff.rfl

theorem X3 (U V : α → Prop) (x : α) : (mX D U x ∨ mX D V x) ↔ mX D (fun y => U y ∨ V y) x :=
  Iff.rfl

theorem D1 (U : α → Prop) (x : α) : mDia D U x ↔ (U x ∨ mX D (mDia D U) x) := by
  constructor
  · rintro ⟨n, hn⟩
    cases n with
    | zero => exact Or.inl hn
    | succ n => exact Or.inr ⟨n, by rw [← iter_succ']; exact hn⟩
  · rintro (h | ⟨n, hn⟩)
    · exact ⟨0, h⟩
    · exact ⟨n + 1, by rw [iter_succ']; exact hn⟩

theorem D2 (U : α → Prop) (x : α) : mDiaP D U x ↔ mX D (mDia D U) x := by
  constructor
  · rintro ⟨n, hn, h⟩
    obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
    exact ⟨m, by rw [← iter_succ']; exact h⟩
  · rintro ⟨n, hn⟩
    exact ⟨n + 1, by omega, by rw [iter_succ']; exact hn⟩

theorem D3 (U : α → Prop) (x : α) : mDia D U x ↔ (U x ∨ mDiaP D U x) := by
  constructor
  · rintro ⟨n, hn⟩
    cases n with
    | zero => exact Or.inl hn
    | succ n => exact Or.inr ⟨n + 1, by omega, hn⟩
  · rintro (h | ⟨n, _, hn⟩)
    · exact ⟨0, h⟩
    · exact ⟨n, hn⟩

theorem B1 (U : α → Prop) (x : α) : mBox D U x ↔ (U x ∧ mX D (mBox D U) x) := by
  constructor
  · intro h
    exact ⟨h 0, fun n => by rw [← iter_succ']; exact h (n + 1)⟩
  · rintro ⟨h0, h1⟩ n
    cases n with
    | zero => exact h0
    | succ n => rw [iter_succ']; exact h1 n

theorem B2 (U : α → Prop) (x : α) : mBox D U x → U x := fun h => h 0

theorem B3 (U : α → Prop) (x : α) : mBox D U x → mX D (mBox D U) x :=
  fun h => ((B1 U x).1 h).2

theorem B4 (U : α → Prop) (x : α) : mBox D U x → mDia D U x := fun h => ⟨0, h 0⟩

theorem B5 (U V : α → Prop) (x : α) :
    mBox D (fun y => U y → V y) x → (mBox D U x → mBox D V x) :=
  fun h hu n => h n (hu n)

theorem R1 (U : α → Prop) (x : α) : mRec D U x ↔ mDiaP D (mX D U) x := by
  constructor
  · rintro ⟨k, hk, h⟩
    obtain ⟨m, rfl⟩ : ∃ m, k = m + 1 := ⟨k - 1, by omega⟩
    exact ⟨m, by omega, h⟩
  · rintro ⟨n, hn, h⟩
    exact ⟨n + 1, by omega, h⟩

theorem R2 (U : α → Prop) (x : α) : mRec D U x → mDiaP D U x :=
  fun ⟨k, hk, h⟩ => ⟨k, by omega, h⟩

/-- M4 (класична семантика): ◇U ↔ ¬□¬U. -/
theorem M4 (U : α → Prop) (x : α) : mDia D U x ↔ ¬ mBox D (fun y => ¬ U y) x := by
  constructor
  · rintro ⟨n, hn⟩ hb
    exact hb n hn
  · intro h
    refine Classical.byContradiction fun hn => h fun n hu => hn ⟨n, hu⟩

/-- M2/M6: □U → ↺U. -/
theorem M2 (U : α → Prop) (x : α) : mBox D U x → mRec D U x :=
  fun h => ⟨2, by omega, h 2⟩

end Subit
