import Subit.HexData
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.Basic
import Mathlib.Order.Basic
/-!
# SUBIT-∞ v6.11.5 — Додаток А (таблиця гексаграм) і відповідність Belnap (означення 1.1)
-/
namespace Subit

/-! ## Гексаграми -/

/-- Реверс 6-бітного слова (b₁ — старший біт). -/
def rev6 (v : Nat) : Nat :=
  (v % 2) * 32 + (v / 2 % 2) * 16 + (v / 4 % 2) * 8 + (v / 8 % 2) * 4 + (v / 16 % 2) * 2 + (v / 32 % 2)

def code_of (n : Nat) : Nat := ((hexTable.find? (fun r => r.1 == n)).map (fun r => r.2.2)).getD 64

/-- 64 рядки, номери 1…64 по порядку. -/
theorem hex_numbers : hexTable.map (·.1) = List.range' 1 64 := by decide

/-- Гліф номера n — кодова точка U+4DC0 + n − 1 (блок «Hexagram Symbols»). -/
theorem hex_glyphs : ∀ r ∈ hexTable, r.2.1 = 0x4DC0 + r.1 - 1 := by decide

/-- Коди — 64 різні числа з [0, 64). -/
theorem hex_codes_nodup : (hexTable.map (·.2.2)).Nodup := by decide
theorem hex_codes_lt : ∀ r ∈ hexTable, r.2.2 < 64 := by decide

/-- Усі 64 коди збігаються з матрицею Вень-вана: код = 8·(нижня триграма) + (верхня). -/
theorem hex_matrix : kwMatrix.length = 64 ∧
    ∀ e ∈ kwMatrix, code_of e.2.2 = 8 * e.1 + e.2.1 := by decide

/-- Незалежна структурна перевірка послідовності Вень-вана: кожна пара (2k−1, 2k) —
реверс або доповнення (інверсія) одна одної. -/
theorem hex_pairs : ∀ k, k < 32 →
    code_of (2 * k + 2) = rev6 (code_of (2 * k + 1)) ∨
    code_of (2 * k + 2) = 63 - code_of (2 * k + 1) := by decide

/-! ## Белнап (означення 1.1) -/

inductive Bel | T | B | F | N deriving DecidableEq, Repr

/-- Таблиця A1: 10 = T, 11 = B, 01 = F, 00 = N (перший біт — «свідчення істинності»,
другий — «свідчення хибності»). -/
def belnap : Bool × Bool → Bel
  | (true, false) => .T
  | (true, true) => .B
  | (false, true) => .F
  | (false, false) => .N

theorem belnap_bijective : Function.Bijective belnap := by
  constructor
  · intro a b h; revert a b; decide
  · intro y; cases y
    · exact ⟨(true, false), rfl⟩
    · exact ⟨(true, true), rfl⟩
    · exact ⟨(false, true), rfl⟩
    · exact ⟨(false, false), rfl⟩

/-- Порядок істинності: x ≤ₜ y ⇔ x₁ ≤ y₁ ∧ x₂ ≥ y₂; порядок інформації: обидва ≤. -/
def leT (x y : Bool × Bool) : Prop := x.1 ≤ y.1 ∧ y.2 ≤ x.2
def leK (x y : Bool × Bool) : Prop := x.1 ≤ y.1 ∧ x.2 ≤ y.2

instance (x y : Bool × Bool) : Decidable (leT x y) := by unfold leT; infer_instance
instance (x y : Bool × Bool) : Decidable (leK x y) := by unfold leK; infer_instance

/-- Мапа із Bel у біти (обернена до `belnap`). -/
def unbel : Bel → Bool × Bool
  | .T => (true, false) | .B => (true, true) | .F => (false, true) | .N => (false, false)

def ltT (x y : Bel) : Prop := leT (unbel x) (unbel y) ∧ x ≠ y
def ltK (x y : Bel) : Prop := leK (unbel x) (unbel y) ∧ x ≠ y

instance (x y : Bel) : Decidable (ltT x y) := by unfold ltT; infer_instance
instance (x y : Bel) : Decidable (ltK x y) := by unfold ltK; infer_instance

/-- Порядок істинності — частковий порядок. -/
theorem leT_partial : (∀ x, leT x x) ∧ (∀ x y, leT x y → leT y x → x = y) ∧
    (∀ x y z, leT x y → leT y z → leT x z) := by decide
theorem leK_partial : (∀ x, leK x x) ∧ (∀ x y, leK x y → leK y x → x = y) ∧
    (∀ x y z, leK x y → leK y z → leK x z) := by decide

/-- Твердження 1.1: F < N < T, F < B < T (істинність); N < F < B, N < T < B (інформація);
N, B непорівнянні за істинністю; F, T — за інформацією. -/
theorem belnap_orders :
    ltT .F .N ∧ ltT .N .T ∧ ltT .F .B ∧ ltT .B .T ∧
    ltK .N .F ∧ ltK .F .B ∧ ltK .N .T ∧ ltK .T .B ∧
    ¬ leT (unbel .N) (unbel .B) ∧ ¬ leT (unbel .B) (unbel .N) ∧
    ¬ leK (unbel .F) (unbel .T) ∧ ¬ leK (unbel .T) (unbel .F) := by decide

/-- Заданий у таблиці порядок істинності — рівно F < N, B < T (жодних зайвих порівнянь). -/
theorem belnap_t_exact : ∀ x y : Bel, ltT x y ↔
    ((x = .F ∧ (y = .N ∨ y = .B ∨ y = .T)) ∨ ((x = .N ∨ x = .B) ∧ y = .T)) := by
  intro x y; cases x <;> cases y <;> decide
theorem belnap_k_exact : ∀ x y : Bel, ltK x y ↔
    ((x = .N ∧ (y = .F ∨ y = .T ∨ y = .B)) ∨ ((x = .F ∨ x = .T) ∧ y = .B)) := by
  intro x y; cases x <;> cases y <;> decide

end Subit
