import Subit.Basic
/-!
# SUBIT-∞ v6.11.2 — етап 2a: алгебра Ω (C6), контрмодель M3, метрика d_Ω_traj

Ω — 6-ланцюг, елементи кодуються числами 0..5:
0 = CHAOTIC_set (⊥) < 1 = APERIODIC_NON_CHAOTIC < 2 = EVENTUALLY_PERIODIC
< 3 = PERIODIC_SET < 4 = INVARIANT_DYNAMIC < 5 = INVARIANT_FIXED (⊤).
-/
namespace Subit

/-- a → b := ⊤, якщо a ≤ b, інакше b. -/
def imp (a b : Nat) : Nat := if a ≤ b then 5 else b
/-- ¬a := a → ⊥. -/
def neg (a : Nat) : Nat := imp a 0

/-- C6: min(a,c) ≤ b ⇔ c ≤ (a → b) — спряженість Гейтінга. -/
theorem C6_adjunction : ∀ a, a < 6 → ∀ b, b < 6 → ∀ c, c < 6 →
    (Nat.min a c ≤ b ↔ c ≤ imp a b) := by decide

theorem C6_imp_lt : ∀ a, a < 6 → ∀ b, b < 6 → imp a b < 6 := by decide

/-- Виключене третє не виконується: існує a < 6 із max(a, ¬a) ≠ ⊤. -/
theorem C6_no_excluded_middle : ∃ a, a < 6 ∧ Nat.max a (neg a) ≠ 5 := ⟨1, by decide, by decide⟩

/-! ### M3: контрмодель до M4 у гейтінговій семантиці -/

/-- K = Bool: a = false, b = true; D(a) = b, D(b) = b. -/
def Dm : Bool → Bool := fun _ => true
/-- U(a) = EVENTUALLY_PERIODIC = 2, U(b) = ⊥ = 0. -/
def Um : Bool → Nat := fun x => if x then 0 else 2

def IsLub (f : Nat → Nat) (v : Nat) : Prop := (∀ n, f n ≤ v) ∧ ∀ w, (∀ n, f n ≤ w) → v ≤ w
def IsGlb (f : Nat → Nat) (v : Nat) : Prop := (∀ n, v ≤ f n) ∧ ∀ w, (∀ n, w ≤ f n) → w ≤ v

theorem Dm_iter (n : Nat) : iter Dm (n + 1) false = true := by
  induction n with
  | zero => rfl
  | succ n _ => simp [iter, Dm]

/-- (◇_H U)(a) = 2. -/
theorem M3_diamond : IsLub (fun n => Um (iter Dm n false)) 2 := by
  refine ⟨?_, ?_⟩
  · intro n; cases n with
    | zero => simp [iter, Um]
    | succ n => show Um (iter Dm (n + 1) false) ≤ 2; rw [Dm_iter]; simp [Um]
  · intro w hw; simpa [iter, Um] using hw 0

/-- (□_H ¬_H U)(a) = ⊥ = 0. -/
theorem M3_box : IsGlb (fun n => neg (Um (iter Dm n false))) 0 := by
  refine ⟨fun n => Nat.zero_le _, ?_⟩
  intro w hw
  have := hw 0
  simpa [iter, Um, neg, imp] using this

/-- M3: (¬_H □_H ¬_H U)(a) = ⊤ ≠ EVENTUALLY_PERIODIC = (◇_H U)(a). -/
theorem M3 : neg 0 = 5 ∧ neg 0 ≠ 2 := by decide

/-! ### d_Ω_traj: відстань Геммінга на 12 кодах -/

inductive Sz | one | finMany | inf deriving DecidableEq, Repr
inductive Mn | na | min | nonmin deriving DecidableEq, Repr
inductive En | zero | pos deriving DecidableEq, Repr
inductive Att | att | nonatt deriving DecidableEq, Repr

structure Code where
  sz : Sz
  mn : Mn
  en : En
  att : Att
  deriving DecidableEq, Repr

def bit (b : Bool) : Nat := if b then 1 else 0

/-- Відстань Геммінга: кількість координат, у яких коди різняться. -/
def ham (x y : Code) : Nat :=
  bit (decide (x.sz ≠ y.sz)) + bit (decide (x.mn ≠ y.mn)) + bit (decide (x.en ≠ y.en))
    + bit (decide (x.att ≠ y.att))

/-- Шість класів S(τ) × Att. -/
def codes : List Code :=
  [ ⟨.one, .na, .zero, .att⟩,      ⟨.one, .na, .zero, .nonatt⟩,
    ⟨.finMany, .na, .zero, .att⟩,  ⟨.finMany, .na, .zero, .nonatt⟩,
    ⟨.inf, .min, .zero, .att⟩,     ⟨.inf, .min, .zero, .nonatt⟩,
    ⟨.inf, .min, .pos, .att⟩,      ⟨.inf, .min, .pos, .nonatt⟩,
    ⟨.inf, .nonmin, .zero, .att⟩,  ⟨.inf, .nonmin, .zero, .nonatt⟩,
    ⟨.inf, .nonmin, .pos, .att⟩,   ⟨.inf, .nonmin, .pos, .nonatt⟩ ]

theorem codes_length : codes.length = 12 := by decide
theorem codes_nodup : codes.Nodup := by decide

theorem ham_self : ∀ x ∈ codes, ham x x = 0 := by decide
theorem ham_symm : ∀ x ∈ codes, ∀ y ∈ codes, ham x y = ham y x := by decide
theorem ham_zero_iff : ∀ x ∈ codes, ∀ y ∈ codes, ham x y = 0 → x = y := by decide
theorem ham_tri : ∀ x ∈ codes, ∀ y ∈ codes, ∀ z ∈ codes, ham x z ≤ ham x y + ham y z := by decide

end Subit
