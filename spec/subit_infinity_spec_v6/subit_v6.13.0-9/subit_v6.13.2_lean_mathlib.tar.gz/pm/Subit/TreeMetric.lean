import Subit.Tree
import Mathlib.Topology.ClusterPt
import Mathlib.Topology.Compactness.Compact
/-!
# SUBIT-∞ v6.11.7 — T5 (метрична частина): цілковита обмеженість і повнота Tree∞ у d_S

Елементарні форми без побудови `MetricSpace`-екземпляра: цілковита обмеженість як існування
скінченної ε-сітки, повнота як збіжність кожної d_S-послідовності Коші. Обидві виведені з
компактності у топології добутку та з `dS_nhds_basis`.
-/
namespace Subit
open Filter Topology Set

variable {A : Type*} [Finite A]

omit [Finite A] in
/-- Кулі d_S є відкритими в топології Tree∞ (скінченне число координат). -/
theorem ball_isOpen (f : Tree A) (n : ℕ) :
    IsOpen {g : Tree A | dS f.1 g.1 < (1 / 2 : ℝ) ^ n} := by
  have hfin := finite_len_le n
  have heq : {g : Tree A | dS f.1 g.1 < (1 / 2 : ℝ) ^ n} =
      ⋂ σ ∈ {σ : Pos | σ.length ≤ n}, (fun g : Tree A => g.1 σ) ⁻¹' {f.1 σ} := by
    ext g
    simp only [Set.mem_setOf_eq, Set.mem_iInter, Set.mem_preimage, Set.mem_singleton_iff]
    rw [dS_lt_iff]
    exact ⟨fun h σ hσ => (h σ hσ).symm, fun h σ hσ => (h σ hσ).symm⟩
  rw [heq]
  exact hfin.isOpen_biInter fun σ _ =>
    (isOpen_discrete _).preimage ((continuous_apply σ).comp continuous_subtype_val)

/-- T5 (цілковита обмеженість): для кожного ε > 0 існує скінченна ε-сітка в d_S. -/
theorem tree_totallyBounded (ε : ℝ) (hε : 0 < ε) :
    ∃ F : Finset (Tree A), ∀ f : Tree A, ∃ g ∈ F, dS f.1 g.1 < ε := by
  obtain ⟨n, hn⟩ := exists_pow_lt_of_lt_one hε (by norm_num : (1 / 2 : ℝ) < 1)
  obtain ⟨t, ht⟩ := (isCompact_univ (X := Tree A)).elim_finite_subcover
    (fun f : Tree A => {g : Tree A | dS f.1 g.1 < (1 / 2 : ℝ) ^ n})
    (fun f => ball_isOpen f n)
    (fun g _ => Set.mem_iUnion.2 ⟨g, by
      show dS g.1 g.1 < (1 / 2 : ℝ) ^ n
      rw [(dS_eq_zero_iff _ _).2 rfl]
      positivity⟩)
  refine ⟨t, fun f => ?_⟩
  obtain ⟨g, hg, hfg⟩ := Set.mem_iUnion₂.1 (ht (Set.mem_univ f))
  refine ⟨g, hg, ?_⟩
  have h1 : dS g.1 f.1 < (1 / 2 : ℝ) ^ n := hfg
  rw [dS_comm]
  exact lt_trans h1 hn

/-- T5 (повнота): кожна d_S-послідовність Коші збігається до точки Tree∞. -/
theorem tree_complete (u : ℕ → Tree A)
    (hu : ∀ ε > 0, ∃ N, ∀ m ≥ N, ∀ k ≥ N, dS (u m).1 (u k).1 < ε) :
    ∃ x : Tree A, ∀ ε > 0, ∃ N, ∀ k ≥ N, dS (u k).1 x.1 < ε := by
  obtain ⟨x, -, hx⟩ := (isCompact_univ (X := Tree A)).exists_mapClusterPt
    (f := atTop) (u := u) (le_principal_iff.2 univ_mem)
  refine ⟨x, fun ε hε => ?_⟩
  obtain ⟨N, hN⟩ := hu ε hε
  obtain ⟨m, hm⟩ := exists_pow_lt_of_lt_one hε (by norm_num : (1 / 2 : ℝ) < 1)
  have hnhd : {g : Tree A | dS x.1 g.1 < (1 / 2 : ℝ) ^ m} ∈ 𝓝 x := by
    apply (ball_isOpen x m).mem_nhds
    show dS x.1 x.1 < (1 / 2 : ℝ) ^ m
    rw [(dS_eq_zero_iff _ _).2 rfl]
    positivity
  obtain ⟨k, hkN, hk⟩ := frequently_atTop.1 (mapClusterPt_iff_frequently.1 hx _ hnhd) N
  refine ⟨N, fun n hn => ?_⟩
  have h1 : dS (u n).1 (u k).1 < ε := hN n hn k hkN
  have h2 : dS x.1 (u k).1 < ε := lt_trans hk hm
  calc dS (u n).1 x.1 ≤ max (dS (u n).1 (u k).1) (dS (u k).1 x.1) := dS_ultra _ _ _
    _ < ε := max_lt h1 (by rw [dS_comm]; exact h2)

end Subit
