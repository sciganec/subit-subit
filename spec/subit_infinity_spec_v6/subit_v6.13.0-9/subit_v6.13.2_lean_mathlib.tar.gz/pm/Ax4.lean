import Subit
#print axioms Subit.C3b
#print axioms Subit.C3c
#print axioms Subit.C4a
#print axioms Subit.subobjEquiv
#print axioms Subit.Om_heyting_adjunction
#print axioms Subit.hex_matrix
#print axioms Subit.hex_pairs
#print axioms Subit.belnap_t_exact
#print axioms Subit.p3_correct_finite
#print axioms Subit.p3'_not_always
#print axioms Subit.CatSub.K2
#print axioms Subit.CatSub.K2_full
#print axioms Subit.CatSub.prodIsLimit
#print axioms Subit.CatSub.prodIsLimitFull
#print axioms Subit.CatSub.dynEquiv
