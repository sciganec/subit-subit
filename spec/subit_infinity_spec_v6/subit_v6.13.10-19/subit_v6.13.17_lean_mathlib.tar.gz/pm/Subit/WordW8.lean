import Mathlib.Data.List.Basic

/-!
# G9, крок 1: слово d з конструкції W8

Кодування: α ↦ `true`, β ↦ `false`. w₀ := β, w_{k+1} := w_k α^{k+1} w_k (n_k = k+1).
d := lim w_k, тобто d i := (w_k)[i] для будь-якого k з i < |w_k|.

Формалізовано: означення `wd`, довжина ≥ k+1, префіксність w_k ⊑ w_{k+1}, і коректність
означення d (незалежність від k). Комбінаторна частина (фактор-складність) — далі.
-/

namespace Subit.W8

/-- Скінченні наближення w_k. -/
def wd : ℕ → List Bool
  | 0 => [false]
  | k + 1 => wd k ++ List.replicate (k + 1) true ++ wd k

theorem length_wd_ge (k : ℕ) : k + 1 ≤ (wd k).length := by
  induction k with
  | zero => simp [wd]
  | succ k ih =>
    simp only [wd, List.length_append, List.length_replicate]
    omega

theorem wd_prefix (k : ℕ) : wd k <+: wd (k + 1) := by
  simp only [wd]
  exact (List.prefix_append _ _).trans (List.prefix_append _ _)

theorem wd_prefix_le {k m : ℕ} (h : k ≤ m) : wd k <+: wd m := by
  obtain ⟨j, rfl⟩ := Nat.exists_eq_add_of_le h
  clear h
  induction j with
  | zero => exact List.prefix_refl _
  | succ j ih => exact ih.trans (wd_prefix (k + j))

/-- Значення d у позиції i: з будь-якого наближення, яке містить позицію i. -/
def dW (i : ℕ) : Bool := (wd (i + 1)).getD i false

theorem getD_eq_of_prefix {l₁ l₂ : List Bool} (h : l₁ <+: l₂) {i : ℕ} (hi : i < l₁.length) :
    l₁.getD i false = l₂.getD i false := by
  obtain ⟨t, rfl⟩ := h
  rw [List.getD_eq_getElem?_getD, List.getD_eq_getElem?_getD, List.getElem?_append_left hi]

theorem dW_eq (k i : ℕ) (hi : i < (wd k).length) : dW i = (wd k).getD i false := by
  by_cases h : i + 1 ≤ k
  · have hp := wd_prefix_le h
    exact getD_eq_of_prefix hp (by have := length_wd_ge (i + 1); omega)
  · have hp := wd_prefix_le (show k ≤ i + 1 by omega)
    exact (getD_eq_of_prefix hp hi).symm

end Subit.W8
