import Subit
#print axioms Subit.lemma_4_6
#print axioms Subit.C7
#print axioms Subit.D3
#print axioms Subit.D1
