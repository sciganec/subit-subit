import Mathlib.Topology.Compactness.Compact
import Mathlib.Topology.Constructions
import Mathlib.Topology.Separation.Hausdorff
import Mathlib.Topology.Order
import Mathlib.Topology.DiscreteSubset
import Mathlib.Data.Real.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Real
/-!
# SUBIT-∞ v6.11.4 — Tree∞ (§9): умови (T1)–(T4), ультраметрика d_S (T3), оцінка піддерев (T4),
компактність (T5).

Pos = List (Fin 3) (перша літера — перша у списку), мітки Lab A = none | node | leaf a.
`dS f g` задається як sup_{σ: f σ ≠ g σ} 2^{-|σ|} (= 2^{-r_addr}, див. `dS_spec`).
-/
open Set
namespace Subit

abbrev Pos := List (Fin 3)

inductive Lab (A : Type*) | none | node | leaf (a : A)
  deriving DecidableEq

instance {A : Type*} : TopologicalSpace (Lab A) := ⊥
instance {A : Type*} : DiscreteTopology (Lab A) := ⟨rfl⟩

instance {A : Type*} [Finite A] : Finite (Lab A) :=
  Finite.of_injective
    (fun l : Lab A => match l with
      | .none => (Option.none : Option (Option A))
      | .node => Option.some Option.none
      | .leaf a => Option.some (Option.some a))
    (by intro a b h; cases a <;> cases b <;> simp at h ⊢ <;> exact h)

section Defs
variable {A : Type*}

/-- Умови (T1)–(T4) означення 9.1. -/
structure IsTree (f : Pos → Lab A) : Prop where
  t1 : f [] ≠ .none
  t2 : ∀ σ, f σ = .node → ∀ i, f (σ ++ [i]) ≠ .none
  t3 : ∀ σ a, f σ = .leaf a → ∀ i, f (σ ++ [i]) = .none
  t4 : ∀ σ, f σ = .none → ∀ τ, f (σ ++ τ) = .none

/-- d_S(f,g) = sup {2^{-|σ|} : f σ ≠ g σ} (0, якщо f = g). -/
noncomputable def dS (f g : Pos → Lab A) : ℝ :=
  ⨆ σ : {σ : Pos // f σ ≠ g σ}, (1 / 2 : ℝ) ^ σ.1.length

private theorem bdd (f g : Pos → Lab A) :
    BddAbove (range fun σ : {σ : Pos // f σ ≠ g σ} => (1 / 2 : ℝ) ^ σ.1.length) :=
  ⟨1, by rintro _ ⟨σ, rfl⟩; exact pow_le_one₀ (by norm_num) (by norm_num)⟩

theorem dS_nonneg (f g : Pos → Lab A) : 0 ≤ dS f g :=
  Real.iSup_nonneg fun _ => by positivity

theorem dS_comm (f g : Pos → Lab A) : dS f g = dS g f := by
  unfold dS
  have : (fun σ : {σ : Pos // f σ ≠ g σ} => (1 / 2 : ℝ) ^ σ.1.length) =
      (fun σ : {σ : Pos // g σ ≠ f σ} => (1 / 2 : ℝ) ^ σ.1.length) ∘
        (Equiv.subtypeEquivRight fun σ => ne_comm).toFun := rfl
  rw [this]
  exact (Equiv.subtypeEquivRight fun σ => ne_comm).iSup_comp
    (g := fun σ : {σ : Pos // g σ ≠ f σ} => (1 / 2 : ℝ) ^ σ.1.length)

/-- Доданий вигляд: якщо σ — розбіжність, то 2^{-|σ|} ≤ d_S. -/
theorem le_dS {f g : Pos → Lab A} {σ : Pos} (h : f σ ≠ g σ) :
    (1 / 2 : ℝ) ^ σ.length ≤ dS f g :=
  le_ciSup (bdd f g) ⟨σ, h⟩

/-- d_S = 0 ⇔ f = g. -/
theorem dS_eq_zero_iff (f g : Pos → Lab A) : dS f g = 0 ↔ f = g := by
  constructor
  · intro h
    funext σ
    by_contra hne
    have := le_dS hne
    rw [h] at this
    have : (0 : ℝ) < (1 / 2) ^ σ.length := by positivity
    linarith
  · rintro rfl
    unfold dS
    haveI : IsEmpty {σ : Pos // f σ ≠ f σ} := ⟨fun ⟨_, h⟩ => h rfl⟩
    exact Real.iSup_of_isEmpty _

/-- (T3) Ультраметрична нерівність. -/
theorem dS_ultra (f g h : Pos → Lab A) : dS f h ≤ max (dS f g) (dS g h) := by
  apply Real.iSup_le _ (le_trans (dS_nonneg f g) (le_max_left _ _))
  rintro ⟨σ, hσ⟩
  by_cases hfg : f σ = g σ
  · have : g σ ≠ h σ := fun e => hσ (hfg.trans e)
    exact le_trans (le_dS this) (le_max_right _ _)
  · exact le_trans (le_dS hfg) (le_max_left _ _)

/-- Характеристика кулі: d_S(f,g) < 2^{-n} ⇔ f, g збігаються на всіх адресах довжини ≤ n. -/
theorem dS_lt_iff (f g : Pos → Lab A) (n : ℕ) :
    dS f g < (1 / 2 : ℝ) ^ n ↔ ∀ σ : Pos, σ.length ≤ n → f σ = g σ := by
  constructor
  · intro h σ hσ
    by_contra hne
    have h1 := le_dS hne
    have h2 : (1 / 2 : ℝ) ^ n ≤ (1 / 2) ^ σ.length :=
      pow_le_pow_of_le_one (by norm_num) (by norm_num) hσ
    linarith
  · intro h
    have hpos : (0 : ℝ) < (1 / 2) ^ (n + 1) := by positivity
    have : dS f g ≤ (1 / 2 : ℝ) ^ (n + 1) := by
      apply Real.iSup_le _ hpos.le
      rintro ⟨σ, hσ⟩
      have : n < σ.length := by
        by_contra hle
        exact hσ (h σ (not_lt.1 hle))
      exact pow_le_pow_of_le_one (by norm_num) (by norm_num) this
    calc dS f g ≤ (1 / 2 : ℝ) ^ (n + 1) := this
      _ < (1 / 2) ^ n := by
        rw [pow_succ]; have : (0 : ℝ) < (1 / 2) ^ n := by positivity
        linarith

/-- Піддерево f_i(τ) := f(i·τ). -/
def sub (i : Fin 3) (f : Pos → Lab A) : Pos → Lab A := fun τ => f (i :: τ)

/-- (T4) d_S(f_i, g_i) ≤ 2·d_S(f, g). -/
theorem dS_sub (i : Fin 3) (f g : Pos → Lab A) : dS (sub i f) (sub i g) ≤ 2 * dS f g := by
  apply Real.iSup_le _ (by have := dS_nonneg f g; positivity)
  rintro ⟨τ, hτ⟩
  have h1 := le_dS (f := f) (g := g) (σ := i :: τ) hτ
  simp only [List.length_cons, pow_succ] at h1
  linarith [h1]

end Defs

section Topo
variable {A : Type*} [Finite A]

/-- Адреси довжини ≤ n утворюють скінченну множину. -/
theorem finite_len_le (n : ℕ) : {σ : Pos | σ.length ≤ n}.Finite := by
  induction n with
  | zero =>
    apply (Set.finite_singleton ([] : Pos)).subset
    intro σ hσ; simp at hσ; simp [hσ]
  | succ n ih =>
    have : {σ : Pos | σ.length ≤ n + 1} ⊆
        {σ : Pos | σ.length ≤ n} ∪ (fun p : Fin 3 × Pos => p.1 :: p.2) '' ({p | True} ×ˢ {σ : Pos | σ.length ≤ n}) := by
      intro σ hσ
      cases σ with
      | nil => left; simp
      | cons a t => right; exact ⟨(a, t), ⟨trivial, by simpa using hσ⟩, rfl⟩
    exact ((ih.union ((Set.toFinite _).prod ih |>.image _))).subset this

/-- T5 (метризація): кулі d_S — базис околів у топології добутку. -/
theorem dS_nhds_basis (f : Pos → Lab A) :
    (nhds f).HasBasis (fun _ : ℕ => True) (fun n => {g | dS f g < (1 / 2 : ℝ) ^ n}) := by
  refine ⟨fun U => ?_⟩
  constructor
  · intro hU
    rw [nhds_pi, Filter.mem_pi] at hU
    obtain ⟨I, hI, t, ht, hsub⟩ := hU
    obtain ⟨n, hn⟩ := (hI.image List.length).bddAbove
    refine ⟨n, trivial, fun g hg => hsub ?_⟩
    intro σ hσ
    have hlen : σ.length ≤ n := hn ⟨σ, hσ, rfl⟩
    have := (dS_lt_iff f g n).1 hg σ hlen
    have hmem : f σ ∈ t σ := mem_of_mem_nhds (ht σ)
    simpa [← this] using hmem
  · rintro ⟨n, -, hn⟩
    have : {g : Pos → Lab A | dS f g < (1 / 2 : ℝ) ^ n} ∈ nhds f := by
      have hset : {g : Pos → Lab A | dS f g < (1 / 2 : ℝ) ^ n} =
          ⋂ σ ∈ {σ : Pos | σ.length ≤ n}, {g | g σ ∈ ({f σ} : Set (Lab A))} := by
        ext g
        simp only [mem_setOf_eq, mem_iInter, mem_singleton_iff]
        rw [dS_lt_iff]
        constructor
        · intro h σ hσ; exact (h σ hσ).symm
        · intro h σ hσ; exact (h σ hσ).symm
      rw [hset]
      refine (Filter.biInter_mem (finite_len_le n)).2 fun σ _ => ?_
      exact (continuous_apply σ).continuousAt.preimage_mem_nhds
        ((isOpen_discrete ({f σ} : Set (Lab A))).mem_nhds rfl)
    exact Filter.mem_of_superset this hn

end Topo

section Compact
variable {A : Type*} [Finite A]

private theorem closed1 (σ : Pos) (P : Lab A → Prop) :
    IsClosed {f : Pos → Lab A | P (f σ)} :=
  (isClosed_discrete {a | P a}).preimage (continuous_apply σ)

private theorem closed2 (σ σ' : Pos) (Q : Lab A → Lab A → Prop) :
    IsClosed {f : Pos → Lab A | Q (f σ) (f σ')} := by
  have h1 : IsClosed {p : Lab A × Lab A | Q p.1 p.2} := isClosed_discrete _
  have h2 : Continuous (fun f : Pos → Lab A => (f σ, f σ')) :=
    (continuous_apply σ).prodMk (continuous_apply σ')
  exact h1.preimage h2

theorem isClosed_tree : IsClosed {f : Pos → Lab A | IsTree f} := by
  have : {f : Pos → Lab A | IsTree f} =
      {f | f [] ≠ .none} ∩
      (⋂ σ : Pos, ⋂ i : Fin 3, {f | f σ = .node → f (σ ++ [i]) ≠ .none}) ∩
      (⋂ σ : Pos, ⋂ a : A, ⋂ i : Fin 3, {f | f σ = .leaf a → f (σ ++ [i]) = .none}) ∩
      (⋂ σ : Pos, ⋂ τ : Pos, {f | f σ = .none → f (σ ++ τ) = .none}) := by
    ext f
    simp only [mem_setOf_eq, mem_inter_iff, mem_iInter]
    constructor
    · intro h
      exact ⟨⟨⟨h.t1, fun σ i hn => h.t2 σ hn i⟩, fun σ a i hl => h.t3 σ a hl i⟩,
        fun σ τ hn => h.t4 σ hn τ⟩
    · rintro ⟨⟨⟨a, b⟩, c⟩, d⟩
      exact ⟨a, fun σ hn i => b σ i hn, fun σ a' hl i => c σ a' i hl, fun σ hn τ => d σ τ hn⟩
  rw [this]
  refine ((closed1 [] (fun a => a ≠ .none)).inter ?_ |>.inter ?_ |>.inter ?_)
  · exact isClosed_iInter fun σ => isClosed_iInter fun i =>
      closed2 σ (σ ++ [i]) (fun a b => a = .node → b ≠ .none)
  · exact isClosed_iInter fun σ => isClosed_iInter fun a => isClosed_iInter fun i =>
      closed2 σ (σ ++ [i]) (fun x b => x = .leaf a → b = .none)
  · exact isClosed_iInter fun σ => isClosed_iInter fun τ =>
      closed2 σ (σ ++ τ) (fun a b => a = .none → b = .none)

/-- Tree∞ як підпростір добутку Pos → Lab A. -/
def Tree (A : Type*) := {f : Pos → Lab A // IsTree f}

instance : TopologicalSpace (Tree A) := instTopologicalSpaceSubtype

/-- (T5, компактність) Tree∞ компактний у топології добутку. -/
instance : CompactSpace (Tree A) :=
  isCompact_iff_compactSpace.1 (isClosed_tree.isCompact)

end Compact

end Subit
