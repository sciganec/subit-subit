import Subit.Zero
import Mathlib.Topology.Compactness.Compact
import Mathlib.Topology.Separation.Hausdorff
/-!
# SUBIT-∞ v6.11.3 — етап 3d: ω-границя (D1) і шість класів траєкторій (D6)
-/
open Filter Classical
namespace Subit

section D1
variable {X : Type*} [TopologicalSpace X] [CompactSpace X] [T2Space X]

/-- ω(x) = ⋂_N cl{ Dⁿ x : n ≥ N }. -/
def omega (D : X → X) (x : X) : Set X :=
  ⋂ N : ℕ, closure (Set.range fun k => iter D (N + k) x)

theorem omega_isClosed (D : X → X) (x : X) : IsClosed (omega D x) :=
  isClosed_iInter fun _ => isClosed_closure

theorem omega_isCompact (D : X → X) (x : X) : IsCompact (omega D x) :=
  (omega_isClosed D x).isCompact

private theorem tail_subset (D : X → X) (x : X) (N : ℕ) :
    closure (Set.range fun k => iter D ((N + 1) + k) x) ⊆
      closure (Set.range fun k => iter D (N + k) x) := by
  apply closure_mono
  rintro _ ⟨k, rfl⟩
  exact ⟨k + 1, by simp [Nat.add_assoc, Nat.add_comm 1 k]⟩

/-- D1 (непорожність). -/
theorem omega_nonempty (D : X → X) (x : X) : (omega D x).Nonempty := by
  apply IsCompact.nonempty_iInter_of_sequence_nonempty_isCompact_isClosed
    (fun N => closure (Set.range fun k => iter D (N + k) x))
  · intro N; exact tail_subset D x N
  · intro N; exact ⟨iter D (N + 0) x, subset_closure ⟨0, rfl⟩⟩
  · exact isClosed_closure.isCompact
  · intro N; exact isClosed_closure

/-- D1 (D[ω] ⊆ ω). -/
theorem omega_forward (D : X → X) (hD : Continuous D) (x : X) :
    D '' omega D x ⊆ omega D x := by
  rintro _ ⟨y, hy, rfl⟩
  refine Set.mem_iInter.2 fun N => ?_
  have hy' := Set.mem_iInter.1 hy (N)
  have : D y ∈ closure (Set.range fun k => iter D ((N + 1) + k) x) := by
    apply map_mem_closure hD hy'
    rintro _ ⟨k, rfl⟩
    exact ⟨k, by show iter D ((N + 1) + k) x = D (iter D (N + k) x); rw [show (N + 1) + k = (N + k) + 1 by omega]; rfl⟩
  exact tail_subset D x N this

/-- D1 (ω ⊆ D[ω]). -/
theorem omega_backward (D : X → X) (hD : Continuous D) (x : X) :
    omega D x ⊆ D '' omega D x := by
  intro y hy
  -- C_N = { z ∈ cl{x_{N+k}} | D z = y } — непорожні, замкнені, вкладені
  let S : ℕ → Set X := fun N => closure (Set.range fun k => iter D (N + k) x)
  let C : ℕ → Set X := fun N => S N ∩ D ⁻¹' {y}
  have hne : ∀ N, (C N).Nonempty := by
    intro N
    have hy1 : y ∈ closure (Set.range fun k => iter D ((N + 1) + k) x) :=
      Set.mem_iInter.1 hy (N + 1)
    have himg : (D '' closure (Set.range fun k => iter D (N + k) x)) =
        closure (D '' Set.range fun k => iter D (N + k) x) := by
      apply le_antisymm
      · exact image_closure_subset_closure_image hD
      · apply closure_minimal (Set.image_mono subset_closure)
        exact (isClosed_closure.isCompact.image hD).isClosed
    have hrange : (D '' Set.range fun k => iter D (N + k) x) =
        Set.range fun k => iter D ((N + 1) + k) x := by
      ext z; constructor
      · rintro ⟨_, ⟨k, rfl⟩, rfl⟩
        exact ⟨k, by show iter D ((N + 1) + k) x = D (iter D (N + k) x); rw [show (N + 1) + k = (N + k) + 1 by omega]; rfl⟩
      · rintro ⟨k, rfl⟩
        exact ⟨_, ⟨k, rfl⟩, by show D (iter D (N + k) x) = iter D ((N + 1) + k) x; rw [show (N + 1) + k = (N + k) + 1 by omega]; rfl⟩
    rw [hrange] at himg
    have : y ∈ D '' closure (Set.range fun k => iter D (N + k) x) := by rw [himg]; exact hy1
    obtain ⟨z, hz, hzy⟩ := this
    exact ⟨z, hz, hzy⟩
  have hmono : ∀ N, C (N + 1) ⊆ C N := fun N z hz => ⟨tail_subset D x N hz.1, hz.2⟩
  have hclosed : ∀ N, IsClosed (C N) :=
    fun N => isClosed_closure.inter (isClosed_singleton.preimage hD)
  obtain ⟨z, hz⟩ := IsCompact.nonempty_iInter_of_sequence_nonempty_isCompact_isClosed C hmono hne
    (hclosed 0).isCompact hclosed
  have hz1 : z ∈ omega D x := Set.mem_iInter.2 fun N => (Set.mem_iInter.1 hz N).1
  have hz2 : D z = y := (Set.mem_iInter.1 hz 0).2
  exact ⟨z, hz1, hz2⟩

/-- D1: ω(x) непорожня, компактна, D[ω(x)] = ω(x). -/
theorem D1 (D : X → X) (hD : Continuous D) (x : X) :
    (omega D x).Nonempty ∧ IsCompact (omega D x) ∧ D '' omega D x = omega D x :=
  ⟨omega_nonempty D x, omega_isCompact D x,
    Set.Subset.antisymm (omega_forward D hD x) (omega_backward D hD x)⟩

end D1

end Subit
