import Subit
#print axioms Subit.D6
#print axioms Subit.dS_ultra
#print axioms Subit.dS_sub
#print axioms Subit.dS_lt_iff
#print axioms Subit.dS_nhds_basis
#print axioms Subit.isClosed_tree
#print axioms Subit.instCompactSpaceTree
#print axioms Subit.omega_conj
#print axioms Subit.minOn_conj
#print axioms Subit.attained_conj
#print axioms Subit.htop_le_of_semiconj
#print axioms Subit.Dm_image
#print axioms Subit.grHomeo_conj
