//! §9: Tree∞ як регулярні дерева. Дерево задає скінченний автомат: стан q має мітку out[q]
//! ∈ {None, Node, Leaf(a)} і дітей child[q][i], i = 0,1,2 (адреси 1,2,3 у специфікації ↦ 0,1,2).
//! Мітка за адресою σ — out[стан після читання σ від кореня]. Усі твердження про дерево —
//! точні, бо зводяться до обходу досяжних пар станів.

use std::collections::{HashSet, VecDeque};

#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
pub enum Lab {
    None,
    Node,
    Leaf(u8),
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Reg {
    pub out: Vec<Lab>,
    pub child: Vec<[usize; 3]>,
    pub root: usize,
}

/// Досяжні стани з кореня.
fn reachable(t: &Reg, from: usize) -> Vec<usize> {
    let mut seen = vec![false; t.out.len()];
    let mut stack = vec![from];
    let mut order = Vec::new();
    seen[from] = true;
    while let Some(q) = stack.pop() {
        order.push(q);
        for &c in &t.child[q] {
            if !seen[c] {
                seen[c] = true;
                stack.push(c);
            }
        }
    }
    order
}

/// T1–T4 (§9.1) для досяжних станів. Точно, бо умови залежать лише від міток станів.
pub fn is_tree(t: &Reg) -> bool {
    if t.out[t.root] == Lab::None {
        return false; // T1
    }
    for q in reachable(t, t.root) {
        match t.out[q] {
            Lab::Node => {
                // T2: діти мають мітку ≠ None
                if t.child[q].iter().any(|&c| t.out[c] == Lab::None) {
                    return false;
                }
            }
            Lab::Leaf(_) => {
                // T3: діти мають мітку None
                if t.child[q].iter().any(|&c| t.out[c] != Lab::None) {
                    return false;
                }
            }
            Lab::None => {
                // T4: піддерево всюди None — діти мають мітку None (далі індукцією)
                if t.child[q].iter().any(|&c| t.out[c] != Lab::None) {
                    return false;
                }
            }
        }
    }
    true
}

/// r_addr(f, g) = min{|σ| : f(σ) ≠ g(σ)}, або None, якщо f = g. Точно: BFS по парах станів
/// (пару, що повторилася, не розкриваємо: її перше розходження вже знайдено на меншій глибині).
pub fn r_addr(f: &Reg, g: &Reg) -> Option<usize> {
    let mut visited: HashSet<(usize, usize)> = HashSet::new();
    let mut queue: VecDeque<(usize, usize, usize)> = VecDeque::new();
    queue.push_back((f.root, g.root, 0));
    visited.insert((f.root, g.root));
    while let Some((p, q, d)) = queue.pop_front() {
        if f.out[p] != g.out[q] {
            return Some(d);
        }
        for i in 0..3 {
            let pair = (f.child[p][i], g.child[q][i]);
            if visited.insert(pair) {
                queue.push_back((pair.0, pair.1, d + 1));
            }
        }
    }
    None
}

/// d_S(f, g) = 2^{−r_addr}; 0, якщо f = g.
pub fn d_s(f: &Reg, g: &Reg) -> f64 {
    match r_addr(f, g) {
        None => 0.0,
        Some(r) => 0.5f64.powi(r as i32),
    }
}

/// ρ_a(f) = node(f, leaf a, leaf a): нові стани — корінь, листок a, нульовий стан.
pub fn rho(f: &Reg, a: u8) -> Reg {
    let n = f.out.len();
    // індекси: старі стани 0..n; n = корінь; n+1 = leaf(a); n+2 = None
    let mut out = f.out.clone();
    let mut child = f.child.clone();
    out.push(Lab::Node);
    child.push([f.root, n + 1, n + 1]);
    out.push(Lab::Leaf(a));
    child.push([n + 2, n + 2, n + 2]);
    out.push(Lab::None);
    child.push([n + 2, n + 2, n + 2]);
    Reg {
        out,
        child,
        root: n,
    }
}

/// Нерухома точка ρ_a: один стан Node з дітьми (self, leaf a, leaf a).
pub fn rho_fixed_point(a: u8) -> Reg {
    Reg {
        out: vec![Lab::Node, Lab::Leaf(a), Lab::None],
        child: vec![[0, 1, 1], [2, 2, 2], [2, 2, 2]],
        root: 0,
    }
}

/// Приклад: повне потрійне дерево з мітками leaf/None для тестів.
pub fn leaf_tree(a: u8) -> Reg {
    Reg {
        out: vec![Lab::Leaf(a), Lab::None],
        child: vec![[1, 1, 1], [1, 1, 1]],
        root: 0,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rng::Rng;

    /// Випадковий регулярний автомат: стани з мітками; діти Node-станів — не None,
    /// діти Leaf/None-станів — None. Повертає None, якщо не задовольняє T1–T4.
    fn random_tree(rng: &mut Rng) -> Option<Reg> {
        let k = 2 + rng.below(4);
        // стан 0 — None-стан (для дітей Leaf/None); решта — Node або Leaf
        let mut out = vec![Lab::None];
        for _ in 1..k {
            out.push(if rng.coin() {
                Lab::Node
            } else {
                Lab::Leaf(rng.below(3) as u8)
            });
        }
        let none_states: Vec<usize> = (0..k).filter(|&q| out[q] == Lab::None).collect();
        let node_states: Vec<usize> = (0..k).filter(|&q| out[q] != Lab::None).collect();
        let mut child = Vec::new();
        for &o in &out {
            let c: [usize; 3] = match o {
                Lab::Node => [0; 3].map(|_| node_states[rng.below(node_states.len())]),
                _ => [0; 3].map(|_| none_states[rng.below(none_states.len())]),
            };
            child.push(c);
        }
        let t = Reg {
            out,
            child,
            root: node_states[rng.below(node_states.len())],
        };
        is_tree(&t).then_some(t)
    }

    fn random_trees(rng: &mut Rng, count: usize) -> Vec<Reg> {
        let mut v = Vec::new();
        while v.len() < count {
            if let Some(t) = random_tree(rng) {
                v.push(t);
            }
        }
        v
    }

    /// T1–T4 виконані для побудованих дерев; порушення виявляються.
    #[test]
    fn tree_conditions() {
        assert!(is_tree(&rho_fixed_point(0)));
        assert!(is_tree(&leaf_tree(1)));
        // T1: корінь None
        let bad = Reg {
            out: vec![Lab::None],
            child: vec![[0; 3]],
            root: 0,
        };
        assert!(!is_tree(&bad));
        // T2: node з дитиною None
        let bad2 = Reg {
            out: vec![Lab::Node, Lab::None],
            child: vec![[1, 1, 1], [1, 1, 1]],
            root: 0,
        };
        assert!(!is_tree(&bad2));
    }

    /// d_S — ультраметрика (точно для випадкових регулярних дерев) і d_S(f,g) = 0 ⇔ f = g.
    #[test]
    fn d_s_ultrametric_exact() {
        let mut rng = Rng::new(61);
        let ts = random_trees(&mut rng, 25);
        // невироджена вибірка: є пари з 0 < d_S < 1
        assert!(ts
            .iter()
            .any(|f| ts.iter().any(|g| d_s(f, g) > 0.0 && d_s(f, g) < 1.0)));
        for f in &ts {
            for g in &ts {
                assert_eq!(d_s(f, g) == 0.0, r_addr(f, g).is_none());
                assert_eq!(d_s(f, g), d_s(g, f));
                for h in &ts {
                    assert!(d_s(f, h) <= d_s(f, g).max(d_s(g, h)) + 1e-15);
                }
            }
        }
    }

    /// T4-оцінка піддерев: d_S(f_i, g_i) ≤ 2·d_S(f, g) — тут перевіряємо через r_addr зсув:
    /// якщо f і g розходяться на адресі σ довжини r, то піддерева розходяться на довжині r−1.
    #[test]
    fn subtree_bound_via_shift() {
        let mut rng = Rng::new(67);
        let ts = random_trees(&mut rng, 20);
        for f in &ts {
            for g in &ts {
                if let Some(r) = r_addr(f, g) {
                    for i in 0..3 {
                        let fi = Reg {
                            root: f.child[f.root][i],
                            ..f.clone()
                        };
                        let gi = Reg {
                            root: g.child[g.root][i],
                            ..g.clone()
                        };
                        if f.out[f.root] == Lab::Node && g.out[g.root] == Lab::Node {
                            if let Some(ri) = r_addr(&fi, &gi) {
                                assert!(ri + 1 >= r, "r(f_i,g_i) ≥ r − 1");
                            }
                        }
                    }
                }
            }
        }
    }

    /// Стискання: d_S(ρ_a f, ρ_a g) = ½·d_S(f, g) точно.
    #[test]
    fn rho_contracts_by_half() {
        let mut rng = Rng::new(71);
        let ts = random_trees(&mut rng, 15);
        for f in &ts {
            for g in &ts {
                let (rf, rg) = (rho(f, 1), rho(g, 1));
                assert!(is_tree(&rf));
                assert!((d_s(&rf, &rg) - 0.5 * d_s(f, g)).abs() < 1e-15);
            }
        }
    }

    /// Нерухома точка ρ_a: ітерації збігаються з p_a з оцінкою d(xₙ, p) ≤ 2^{−n}.
    #[test]
    fn rho_fixed_point_converges() {
        let p = rho_fixed_point(1);
        assert_eq!(d_s(&rho(&p, 1), &p), 0.0, "p — нерухома точка");
        let mut x = leaf_tree(1);
        for n in 1..=12 {
            x = rho(&x, 1);
            let d = d_s(&x, &p);
            assert!(d <= 0.5f64.powi(n) + 1e-15, "n = {n}: d = {d}");
        }
    }
}
