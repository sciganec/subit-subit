//! Одометр (додавання 1 на 2-адичних цілих) — нескінченна мінімальна система.
//! Точні твердження (кінцеві обчислення за колом Z/2^d):
//! - ω(x) = Z₂ для кожного x (орбіта повертається до кожного циліндра глибини d з періодом 2^d);
//! - D[ω] = ω (сюр'єктивність);
//! - клас MIN_ZERO × ATTAINED (ентропія 0 — числовий доказ через лінійну складність).

/// Образ при одометрі на Z/2^d (наближення 2-адичного простору до глибини d).
pub fn step_mod(x: u64, d: u32) -> u64 {
    (x + 1) & ((1u64 << d) - 1)
}

/// Перевірка ω = Z₂ на глибині d: кожен циліндр [r]_d відвідується нескінченно часто.
/// Точно: t ↦ t mod 2^d періодичне з періодом 2^d, тож кожен r ∈ Z/2^d зустрічається
/// серед t ∈ [0, 2^d) і далі з періодом 2^d.
pub fn omega_is_whole_space_at_depth(d: u32) -> bool {
    let m = 1u64 << d;
    let mut seen = vec![false; m as usize];
    let mut x = 0u64;
    for _ in 0..m {
        seen[x as usize] = true;
        x = step_mod(x, d);
    }
    seen.iter().all(|&b| b)
}

/// Кількість різних n-блоків символічного коду орбіти 0 за розбиттям на циліндри глибини k:
/// a_t = t mod 2^k (номер циліндра, якому належить t). Послідовність (a_t) періодична з
/// періодом 2^k, тож блоків не більше 2^k для кожного n. Це лише числова перевірка
/// для цього розбиття; h_top = 0 виходить з еквіцентинуальності одометра (відома теорема:
/// еквіцентинуальні системи мають нульову ентропію), а не з цього підрахунку.
pub fn block_count_for_cylinder_coding(n: usize, k: u32, length: u64) -> usize {
    use std::collections::HashSet;
    let a: Vec<u64> = (0..length + n as u64).map(|t| t % (1u64 << k)).collect();
    let mut blocks: HashSet<&[u64]> = HashSet::new();
    for t in 0..length as usize {
        blocks.insert(&a[t..t + n]);
    }
    blocks.len()
}

#[cfg(test)]
mod tests {
    use super::*;

    /// ω = Z₂: для глибин 1…14 кожен циліндр відвідується.
    #[test]
    fn omega_whole_space() {
        for d in 1..=14 {
            assert!(omega_is_whole_space_at_depth(d), "d = {d}");
        }
    }

    /// D[ω] = ω: одометр на Z/2^d сюр'єктивний (бієкція).
    #[test]
    fn surjective_mod() {
        for d in 1..=10 {
            let m = 1u64 << d;
            let mut img: Vec<u64> = (0..m).map(|x| step_mod(x, d)).collect();
            img.sort_unstable();
            assert_eq!(img, (0..m).collect::<Vec<u64>>());
        }
    }

    /// Числова перевірка: для розбиття на циліндри глибини k кількість n-блоків ≤ 2^k.
    #[test]
    fn cylinder_coding_complexity_bounded() {
        for k in 1..=5u32 {
            for n in 1..=12 {
                let c = block_count_for_cylinder_coding(n, k, 1 << 12);
                assert!(c <= 1usize << k, "k = {k}, n = {n}: {c} блоків");
            }
        }
    }

    /// Клас MIN_ZERO × ATTAINED у кодах §11.3: ω нескінченна, мінімальна, ентропія 0, ATTAINED.
    #[test]
    fn class_code_min_zero_attained() {
        use crate::traj::{Att, Code, Ent, Min, SClass, Size};
        let c = SClass::MinZero.code(Att::Attained);
        assert_eq!(
            c,
            Code {
                size: Size::Inf,
                min: Min::Min,
                ent: Ent::Zero,
                att: Att::Attained
            }
        );
    }
}
