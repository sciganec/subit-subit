//! §4.1–4.2 для скінченних систем: множини — булеві вектори над станами; D[P] — образ.

use crate::orbit::Dynamics;
use std::collections::HashMap;

/// Підмножина скінченного простору станів 0..n.
pub type Set = Vec<bool>;

/// D[P].
pub fn img<D: Dynamics>(d: &D, p: &Set) -> Set {
    let mut out = vec![false; d.size()];
    for x in 0..d.size() {
        if p[x] {
            out[d.step(x)] = true;
        }
    }
    out
}

/// Dⁿ[P].
pub fn img_n<D: Dynamics>(d: &D, n: usize, p: &Set) -> Set {
    let mut cur = p.clone();
    for _ in 0..n {
        cur = img(d, &cur);
    }
    cur
}

/// μ(P) і π(P) для скінченної системи (μ завжди скінченне за принципом Діріхле).
/// Обчислено через перший повтор у послідовності P, D[P], D²[P], …
pub fn mu_pi<D: Dynamics>(d: &D, p: &Set) -> (usize, usize) {
    let mut seen: HashMap<Set, usize> = HashMap::new();
    let mut cur = p.clone();
    let mut k = 0usize;
    loop {
        if let Some(&j) = seen.get(&cur) {
            return (j, k - j);
        }
        seen.insert(cur.clone(), k);
        cur = img(d, &cur);
        k += 1;
    }
}

/// Клас OrbitType (§4.1). `Aperiodic` для скінченних систем недосяжний (μ < ∞).
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum OrbitType {
    InvFixed,
    InvDynamic,
    PeriodicSet,
    EventuallyFixed,
    EventuallyPeriodic,
    Aperiodic,
}

/// Класифікація непорожньої P (§4.1, C1).
pub fn orbit_type<D: Dynamics>(d: &D, p: &Set) -> OrbitType {
    assert!(p.iter().any(|&b| b), "OrbitType визначено для непорожніх P");
    let (mu, pi) = mu_pi(d, p);
    if mu == 0 {
        if img(d, p) == *p {
            let fixed = (0..d.size()).all(|x| !p[x] || d.step(x) == x);
            if fixed {
                OrbitType::InvFixed
            } else {
                OrbitType::InvDynamic
            }
        } else {
            OrbitType::PeriodicSet
        }
    } else if pi == 1 {
        OrbitType::EventuallyFixed
    } else {
        OrbitType::EventuallyPeriodic
    }
}

/// InclusionType (§4.2, C2) для непорожньої P.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Inclusion {
    EqualImage,
    DisjointImage,
    StrictSubimage,
    StrictSuperimage,
    OverlappingNoncomparable,
}

pub fn inclusion_type<D: Dynamics>(d: &D, p: &Set) -> Inclusion {
    let im = img(d, p);
    if im == *p {
        return Inclusion::EqualImage;
    }
    let inter = (0..d.size()).any(|x| im[x] && p[x]);
    if !inter {
        return Inclusion::DisjointImage;
    }
    let im_sub_p = (0..d.size()).all(|x| !im[x] || p[x]);
    if im_sub_p {
        return Inclusion::StrictSubimage;
    }
    let p_sub_im = (0..d.size()).all(|x| !p[x] || im[x]);
    if p_sub_im {
        return Inclusion::StrictSuperimage;
    }
    Inclusion::OverlappingNoncomparable
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::orbit::TableDyn;
    use crate::rng::Rng;

    fn set_of(n: usize, xs: &[usize]) -> Set {
        let mut s = vec![false; n];
        for &x in xs {
            s[x] = true;
        }
        s
    }

    /// Приклад із §5.5 (PERIODIC_SET): 4-цикл a→b→c→d→a, P = {a, c}.
    #[test]
    fn periodic_set_example() {
        let d = TableDyn(vec![1, 2, 3, 0]); // a=0,b=1,c=2,d=3
        let p = set_of(4, &[0, 2]);
        assert_eq!(img(&d, &p), set_of(4, &[1, 3]));
        assert_eq!(img_n(&d, 2, &p), p);
        assert_eq!(mu_pi(&d, &p), (0, 2));
        assert_eq!(orbit_type(&d, &p), OrbitType::PeriodicSet);
    }

    /// Класи на прикладах: нерухома точка, інваріантна динаміка, передперіод.
    #[test]
    fn class_examples() {
        let id = TableDyn(vec![0, 1, 2]);
        assert_eq!(orbit_type(&id, &set_of(3, &[1])), OrbitType::InvFixed);
        let sw = TableDyn(vec![1, 0]);
        assert_eq!(orbit_type(&sw, &set_of(2, &[0, 1])), OrbitType::InvDynamic);
        let tail = TableDyn(vec![0, 0, 1]); // 2→1→0, 0 фіксована
        assert_eq!(
            orbit_type(&tail, &set_of(3, &[2])),
            OrbitType::EventuallyFixed
        );
        // 4→3→0→1→2→0: передперіод 4→3→0, цикл 0→1→2 (π = 3) для P = {4}
        let cyc = TableDyn(vec![1, 2, 0, 0, 3]);
        assert_eq!(
            orbit_type(&cyc, &set_of(5, &[4])),
            OrbitType::EventuallyPeriodic
        );
    }

    /// Перевірка mu_pi проти означення перебором (μ — найменше m з повтором, π — період).
    #[test]
    fn mu_pi_matches_definition() {
        let mut rng = Rng::new(5);
        for _ in 0..300 {
            let n = 1 + rng.below(6);
            let d = TableDyn((0..n).map(|_| rng.below(n)).collect());
            let p = set_of(n, &(0..n).filter(|_| rng.coin()).collect::<Vec<_>>());
            if !p.iter().any(|&b| b) {
                continue;
            }
            let (mu, pi) = mu_pi(&d, &p);
            let horizon = 2usize.pow(n as u32) + 2;
            // μ: найменше m, для якого ∃ n > m з Dⁿ[P] = Dᵐ[P]
            let mut mu_b = None;
            'outer: for m in 0..horizon {
                for k in (m + 1)..(m + horizon) {
                    if img_n(&d, k, &p) == img_n(&d, m, &p) {
                        mu_b = Some(m);
                        break 'outer;
                    }
                }
            }
            assert_eq!(Some(mu), mu_b);
            // π: найменше k ≥ 1 з D^{μ+k}[P] = D^μ[P]
            let pi_b = (1..horizon)
                .find(|&k| img_n(&d, mu + k, &p) == img_n(&d, mu, &p))
                .unwrap();
            assert_eq!(pi, pi_b);
        }
    }

    /// C2: п'ять класів вичерпні; для непорожніх P рівно один виконується.
    #[test]
    fn inclusion_exclusive_exhaustive() {
        let mut rng = Rng::new(9);
        for _ in 0..300 {
            let n = 1 + rng.below(6);
            let d = TableDyn((0..n).map(|_| rng.below(n)).collect());
            let p = set_of(n, &(0..n).filter(|_| rng.coin()).collect::<Vec<_>>());
            if !p.iter().any(|&b| b) {
                continue;
            }
            let c = inclusion_type(&d, &p);
            // перевірка виключності: клас однозначно визначений (функція), тож достатньо,
            // щоб обране значення відповідало своїй умові
            let im = img(&d, &p);
            match c {
                Inclusion::EqualImage => assert!(im == p),
                Inclusion::DisjointImage => assert!(!(0..n).any(|x| im[x] && p[x])),
                Inclusion::StrictSubimage => assert!((0..n).all(|x| !im[x] || p[x]) && im != p),
                Inclusion::StrictSuperimage => assert!((0..n).all(|x| !p[x] || im[x]) && im != p),
                Inclusion::OverlappingNoncomparable => {
                    assert!(im != p);
                    assert!((0..n).any(|x| im[x] && p[x]));
                    assert!((0..n).any(|x| im[x] && !p[x]));
                    assert!((0..n).any(|x| p[x] && !im[x]));
                }
            }
        }
    }
}
