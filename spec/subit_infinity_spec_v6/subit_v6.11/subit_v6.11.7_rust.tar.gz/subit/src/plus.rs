//! §2: SUBIT⁺ — скінченна динаміка з правилом у стані: D₀(s, ρ) = (ρ(s), g₀(ρ, s)).

use crate::orbit::Dynamics;

/// Правило ρ : S₀ → S₀ (таблиця з 64 значень-кодів).
pub type Rule = [u8; 64];

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum PlusError {
    /// ℛ_fin має бути непорожньою.
    EmptyRules,
    /// Довжини `rules` і `g` різні.
    LengthMismatch,
    /// Значення правила поза [0, 64).
    BadRuleValue,
    /// g₀ повертає індекс правила поза ℛ_fin.
    BadRuleIndex,
    /// Автомат має більше 64 станів.
    TooManyStates,
    /// δ виходить за межі, або ι не ін'єктивна / виходить за S₀.
    BadAutomaton,
}

/// SUBIT⁺: правила й метаеволюція `g[r][s]` (індекс нового правила).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Plus {
    rules: Vec<Rule>,
    g: Vec<[u16; 64]>,
}

impl Plus {
    pub fn new(rules: Vec<Rule>, g: Vec<[u16; 64]>) -> Result<Plus, PlusError> {
        if rules.is_empty() {
            return Err(PlusError::EmptyRules);
        }
        if rules.len() != g.len() {
            return Err(PlusError::LengthMismatch);
        }
        if rules.iter().any(|r| r.iter().any(|&v| v >= 64)) {
            return Err(PlusError::BadRuleValue);
        }
        if g.iter()
            .any(|row| row.iter().any(|&i| usize::from(i) >= rules.len()))
        {
            return Err(PlusError::BadRuleIndex);
        }
        Ok(Plus { rules, g })
    }

    pub fn num_rules(&self) -> usize {
        self.rules.len()
    }

    /// Індекс розширеного стану (s, r) у Q₀ = S₀ × ℛ_fin: r·64 + s.
    pub fn encode(s: u8, r: usize) -> usize {
        r * 64 + usize::from(s)
    }
    pub fn decode(q: usize) -> (u8, usize) {
        ((q % 64) as u8, q / 64)
    }

    /// D₀(s, ρ) = (ρ(s), g₀(ρ, s)).
    pub fn step_pair(&self, s: u8, r: usize) -> (u8, usize) {
        (
            self.rules[r][usize::from(s)],
            usize::from(self.g[r][usize::from(s)]),
        )
    }

    /// A4: автономний автомат (Q, δ) з #Q ≤ 64 і ін'єкцією ι : Q → S₀ вкладається в SUBIT⁺
    /// з єдиним правилом ρ(ι q) = ι(δ q); поза образом ρ(s) = s₀ = 0 (довільно).
    pub fn embed_automaton(delta: &[usize], iota: &[u8]) -> Result<Plus, PlusError> {
        let n = delta.len();
        if n > 64 {
            return Err(PlusError::TooManyStates);
        }
        if iota.len() != n || delta.iter().any(|&d| d >= n) || iota.iter().any(|&c| c >= 64) {
            return Err(PlusError::BadAutomaton);
        }
        let mut seen = [false; 64];
        for &c in iota {
            if seen[usize::from(c)] {
                return Err(PlusError::BadAutomaton);
            }
            seen[usize::from(c)] = true;
        }
        let mut rho: Rule = [0; 64];
        for (q, &dq) in delta.iter().enumerate() {
            rho[usize::from(iota[q])] = iota[dq];
        }
        Plus::new(vec![rho], vec![[0u16; 64]])
    }
}

impl Dynamics for Plus {
    fn size(&self) -> usize {
        64 * self.rules.len()
    }
    fn step(&self, q: usize) -> usize {
        let (s, r) = Plus::decode(q);
        let (s2, r2) = self.step_pair(s, r);
        Plus::encode(s2, r2)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::orbit::{classify_exact, iterate, TableDyn};
    use crate::rng::Rng;

    /// E1: SUBIT⁺ — автономний автомат із 64·#ℛ станами; тотальність D₀.
    #[test]
    fn e1_total_automaton() {
        let mut rng = Rng::new(3);
        for _ in 0..50 {
            let nr = 1 + rng.below(4);
            let rules: Vec<Rule> = (0..nr)
                .map(|_| std::array::from_fn(|_| rng.below(64) as u8))
                .collect();
            let g: Vec<[u16; 64]> = (0..nr)
                .map(|_| std::array::from_fn(|_| rng.below(nr) as u16))
                .collect();
            let p = Plus::new(rules, g).unwrap();
            assert_eq!(p.size(), 64 * nr);
            for q in 0..p.size() {
                assert!(p.step(q) < p.size());
            }
        }
    }

    #[test]
    fn validation() {
        assert_eq!(Plus::new(vec![], vec![]), Err(PlusError::EmptyRules));
        assert_eq!(
            Plus::new(vec![[0; 64]], vec![]),
            Err(PlusError::LengthMismatch)
        );
        assert_eq!(
            Plus::new(vec![[64; 64]], vec![[0; 64]]),
            Err(PlusError::BadRuleValue)
        );
        assert_eq!(
            Plus::new(vec![[0; 64]], vec![[1; 64]]),
            Err(PlusError::BadRuleIndex)
        );
    }

    /// A4: траєкторії автомата й образу в SUBIT⁺ збігаються (індукція за n перевіряється для n ≤ 3·|Q|).
    #[test]
    fn a4_embedding_random() {
        let mut rng = Rng::new(11);
        for _ in 0..200 {
            let n = 1 + rng.below(64);
            let delta: Vec<usize> = (0..n).map(|_| rng.below(n)).collect();
            // ін'єкція ι : випадкова перестановка перших n із 64
            let mut codes: Vec<u8> = (0..64).collect();
            for i in (1..64).rev() {
                codes.swap(i, rng.below(i + 1));
            }
            let iota: Vec<u8> = codes[..n].to_vec();
            let p = Plus::embed_automaton(&delta, &iota).unwrap();
            let aut = TableDyn(delta.clone());
            for q in 0..n {
                for k in 0..(3 * n) {
                    let (s, r) = Plus::decode(iterate(&p, Plus::encode(iota[q], 0), k));
                    assert_eq!(r, 0);
                    assert_eq!(s, iota[iterate(&aut, q, k)]);
                }
            }
            // класифікація образу збігається з класифікацією автомата
            for (q, &c) in iota.iter().enumerate() {
                let a = classify_exact(&aut, q);
                let b = classify_exact(&p, Plus::encode(c, 0));
                assert_eq!((a.m, a.p), (b.m, b.p));
            }
        }
    }

    #[test]
    fn a4_rejects_bad_input() {
        assert_eq!(
            Plus::embed_automaton(&[0; 65], &[0; 65]),
            Err(PlusError::TooManyStates)
        );
        assert_eq!(
            Plus::embed_automaton(&[0, 1], &[5, 5]),
            Err(PlusError::BadAutomaton)
        );
        assert_eq!(
            Plus::embed_automaton(&[2], &[0]),
            Err(PlusError::BadAutomaton)
        );
    }
}
