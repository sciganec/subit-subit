//! Час входу χ_U для інваріантних підоб'єктів (§8.3–8.4) і контрприклад для неінваріантних
//! (застереження 8.5). Скінченні системи: S = {0, …, n−1}, f: S → S, U ⊆ S.

/// Інваріантність: f[U] ⊆ U.
pub fn is_invariant(f: &[usize], u: &[bool]) -> bool {
    (0..f.len()).all(|x| !u[x] || u[f[x]])
}

/// χ_U(x) = min{ n ≥ 0 : fⁿ(x) ∈ U }, або `None` (∞), якщо U не досягається.
pub fn chi(f: &[usize], u: &[bool], x: usize) -> Option<usize> {
    let mut cur = x;
    for n in 0..=f.len() {
        if u[cur] {
            return Some(n);
        }
        cur = f[cur];
    }
    None
}

/// Перевірка Твердження 8.4(a) для інваріантного U: χ_U(f(x)) = max(χ_U(x) − 1, 0), з ∞ − 1 = ∞.
pub fn chi_step_holds(f: &[usize], u: &[bool], x: usize) -> bool {
    let lhs = chi(f, u, f[x]);
    let rhs = chi(f, u, x).map(|n| n.saturating_sub(1));
    lhs == rhs
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Вичерпно для всіх f: S → S і всіх U ⊆ S, |S| ≤ 4.
    #[test]
    fn chi_step_for_invariant_u_exhaustive() {
        for n in 1..=4usize {
            let total = n.pow(n as u32);
            for code in 0..total {
                let f: Vec<usize> = (0..n).map(|i| (code / n.pow(i as u32)) % n).collect();
                for mask in 0..(1usize << n) {
                    let u: Vec<bool> = (0..n).map(|i| mask >> i & 1 == 1).collect();
                    if !is_invariant(&f, &u) {
                        continue;
                    }
                    for x in 0..n {
                        assert!(chi_step_holds(&f, &u, x), "n={n} f={f:?} U={u:?} x={x}");
                    }
                }
            }
        }
    }

    /// Застереження 8.5: для неінваріантного U формула не еквіваріантна.
    #[test]
    fn chi_fails_for_non_invariant_u() {
        let f = [1usize, 1];
        let u = [true, false];
        assert!(!is_invariant(&f, &u));
        assert_eq!(chi(&f, &u, 0), Some(0));
        assert_eq!(chi(&f, &u, 1), None);
        // max(χ(0) − 1, 0) = 0, але χ(f(0)) = χ(1) = ∞
        assert!(!chi_step_holds(&f, &u, 0));
    }
}
