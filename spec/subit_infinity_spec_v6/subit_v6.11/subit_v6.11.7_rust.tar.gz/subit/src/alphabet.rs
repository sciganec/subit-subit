//! §1: алфавіт A (4 літери, Белнап) і простір S₀ = A³ (64 стани), code6.

/// Значення Белнапа.
#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
pub enum Belnap {
    T,
    B,
    F,
    N,
}

impl Belnap {
    /// Порядок істинності: F < N < T і F < B < T (N, B непорівнянні).
    pub fn leq_truth(self, o: Belnap) -> bool {
        self == o || self == Belnap::F || o == Belnap::T
    }
    /// Порядок інформації: N < F < B і N < T < B (F, T непорівнянні).
    pub fn leq_info(self, o: Belnap) -> bool {
        self == o || self == Belnap::N || o == Belnap::B
    }
}

/// Літера алфавіту A: два біти (b₁ — «свідчення істинності», b₂ — «свідчення хибності»).
#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash, PartialOrd, Ord)]
pub struct Letter(u8);

impl Letter {
    pub const ALL: [Letter; 4] = [Letter(0), Letter(1), Letter(2), Letter(3)];

    /// Літера за двійковим кодом 0..=3 (`10` = 2 = T, `11` = 3 = B, `01` = 1 = F, `00` = 0 = N).
    pub fn from_code(c: u8) -> Option<Letter> {
        (c < 4).then_some(Letter(c))
    }
    pub fn from_bits(hi: bool, lo: bool) -> Letter {
        Letter((u8::from(hi) << 1) | u8::from(lo))
    }
    pub fn code(self) -> u8 {
        self.0
    }
    pub fn bits(self) -> (bool, bool) {
        (self.0 & 2 != 0, self.0 & 1 != 0)
    }
    pub fn belnap(self) -> Belnap {
        match self.0 {
            2 => Belnap::T,
            3 => Belnap::B,
            1 => Belnap::F,
            _ => Belnap::N,
        }
    }
    pub fn who(self) -> &'static str {
        ["THEY", "YOU", "ME", "WE"][self.0 as usize]
    }
    pub fn place(self) -> &'static str {
        ["NORTH", "WEST", "EAST", "SOUTH"][self.0 as usize]
    }
    pub fn when(self) -> &'static str {
        ["WINTER", "AUTUMN", "SPRING", "SUMMER"][self.0 as usize]
    }
}

/// Стан S₀ = A × A × A.
#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
pub struct S0(pub Letter, pub Letter, pub Letter);

impl S0 {
    /// code6(s) = 32·b₁ + 16·b₂ + 8·b₃ + 4·b₄ + 2·b₅ + b₆ ∈ [0, 63].
    pub fn code6(self) -> u8 {
        16 * self.0.code() + 4 * self.1.code() + self.2.code()
    }
    /// Обернене до `code6`; `None` поза [0, 63].
    pub fn from_code6(n: u8) -> Option<S0> {
        (n < 64).then_some(S0(Letter(n / 16 % 4), Letter(n / 4 % 4), Letter(n % 4)))
    }
    pub fn all() -> impl Iterator<Item = S0> {
        (0u8..64).map(|n| S0::from_code6(n).expect("n < 64"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A3: code6 — бієкція S₀ → {0..63}.
    #[test]
    fn a3_bijection() {
        let mut seen = [false; 64];
        for s in S0::all() {
            let c = s.code6() as usize;
            assert!(c < 64);
            assert!(!seen[c]);
            seen[c] = true;
            assert_eq!(S0::from_code6(c as u8), Some(s));
        }
        assert!(seen.iter().all(|&b| b));
        assert_eq!(S0::from_code6(64), None);
    }

    /// Приклади зі специфікації: 101010 = ME/EAST/SPRING = 42; 111111 = 63; 010001 = 17.
    #[test]
    fn spec_examples() {
        let s = S0(
            Letter::from_bits(true, false),
            Letter::from_bits(true, false),
            Letter::from_bits(true, false),
        );
        assert_eq!(s.code6(), 42);
        assert_eq!(
            (s.0.who(), s.0.place(), s.0.when()),
            ("ME", "EAST", "SPRING")
        );
        let t = S0(
            Letter::from_bits(true, true),
            Letter::from_bits(true, true),
            Letter::from_bits(true, true),
        );
        assert_eq!(t.code6(), 63);
        let u = S0(
            Letter::from_bits(false, true),
            Letter::from_bits(false, false),
            Letter::from_bits(false, true),
        );
        assert_eq!(u.code6(), 17);
        assert_eq!(
            (u.0.who(), u.1.place(), u.2.when()),
            ("YOU", "NORTH", "AUTUMN")
        );
    }

    /// Таблиця A1.
    #[test]
    fn a1_table() {
        assert_eq!(Letter::from_bits(true, false).belnap(), Belnap::T);
        assert_eq!(Letter::from_bits(true, true).belnap(), Belnap::B);
        assert_eq!(Letter::from_bits(false, true).belnap(), Belnap::F);
        assert_eq!(Letter::from_bits(false, false).belnap(), Belnap::N);
    }

    /// Порядки Белнапа збігаються з формулами x ≤ₜ y ⇔ x₁ ≤ y₁ ∧ y₂ ≤ x₂, x ≤ₖ y ⇔ x₁ ≤ y₁ ∧ x₂ ≤ y₂
    /// і з переліком у специфікації.
    #[test]
    fn belnap_orders_match_bits() {
        for x in Letter::ALL {
            for y in Letter::ALL {
                let (x1, x2) = x.bits();
                let (y1, y2) = y.bits();
                assert_eq!(x.belnap().leq_truth(y.belnap()), x1 <= y1 && y2 <= x2);
                assert_eq!(x.belnap().leq_info(y.belnap()), x1 <= y1 && x2 <= y2);
            }
        }
        use Belnap::*;
        assert!(F.leq_truth(N) && N.leq_truth(T) && F.leq_truth(B) && B.leq_truth(T));
        assert!(!N.leq_truth(B) && !B.leq_truth(N));
        assert!(N.leq_info(F) && F.leq_info(B) && N.leq_info(T) && T.leq_info(B));
        assert!(!F.leq_info(T) && !T.leq_info(F));
    }
}
