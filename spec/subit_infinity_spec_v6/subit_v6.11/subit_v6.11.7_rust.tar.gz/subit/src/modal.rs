//! §6.1: LTL-подібна семантика і 14 аксіом M1 (класична семантика) на скінченних системах.
//! Квантори по n беруться в межах горизонту H = 2·#Q + 2: для скінченної системи
//! послідовність Dⁿ(x) має передперіод + період ≤ #Q, тож хвіст повторює початок.

/// Предикат над станами: вектор булевих значень.
pub type Pred = Vec<bool>;

fn horizon(n: usize) -> usize {
    2 * n + 2
}

fn orbit_at(d: &[usize], x: usize, k: usize) -> usize {
    let mut s = x;
    for _ in 0..k {
        s = d[s];
    }
    s
}

/// X U : x ↦ U(D x).
pub fn x_(d: &[usize], u: &Pred) -> Pred {
    (0..d.len()).map(|s| u[d[s]]).collect()
}

/// ◇U : ∃n ≥ 0.
pub fn dia(d: &[usize], u: &Pred) -> Pred {
    let h = horizon(d.len());
    (0..d.len())
        .map(|x| (0..h).any(|k| u[orbit_at(d, x, k)]))
        .collect()
}

/// ◇⁺U : ∃n ≥ 1.
pub fn dia_p(d: &[usize], u: &Pred) -> Pred {
    let h = horizon(d.len());
    (0..d.len())
        .map(|x| (1..h).any(|k| u[orbit_at(d, x, k)]))
        .collect()
}

/// □U : ∀n ≥ 0.
pub fn bx(d: &[usize], u: &Pred) -> Pred {
    let h = horizon(d.len());
    (0..d.len())
        .map(|x| (0..h).all(|k| u[orbit_at(d, x, k)]))
        .collect()
}

/// ↺U : ∃k > 1.
pub fn rec(d: &[usize], u: &Pred) -> Pred {
    let h = horizon(d.len());
    (0..d.len())
        .map(|x| (2..h).any(|k| u[orbit_at(d, x, k)]))
        .collect()
}

pub fn and(a: &Pred, b: &Pred) -> Pred {
    a.iter().zip(b).map(|(x, y)| *x && *y).collect()
}
pub fn or(a: &Pred, b: &Pred) -> Pred {
    a.iter().zip(b).map(|(x, y)| *x || *y).collect()
}
pub fn not(a: &Pred) -> Pred {
    a.iter().map(|x| !x).collect()
}
pub fn imp(a: &Pred, b: &Pred) -> Pred {
    or(&not(a), b)
}
pub fn iff(a: &Pred, b: &Pred) -> Pred {
    and(&imp(a, b), &imp(b, a))
}
/// Значущість формули: істинна у всіх станах.
pub fn valid(p: &Pred) -> bool {
    p.iter().all(|&b| b)
}

/// Аксіоми M1 (14 штук), кожна у вигляді предиката над станами; `valid` — перевірка тавтології.
pub fn m1_axioms(d: &[usize], u: &Pred, v: &Pred) -> Vec<(&'static str, Pred)> {
    let xu = x_(d, u);
    let xv = x_(d, v);
    let dia_u = dia(d, u);
    let box_u = bx(d, u);
    vec![
        ("X1", imp(&xu, &dia_p(d, u))),
        ("X2", iff(&and(&xu, &xv), &x_(d, &and(u, v)))),
        ("X3", iff(&or(&xu, &xv), &x_(d, &or(u, v)))),
        ("D1", iff(&dia_u, &or(u, &x_(d, &dia_u)))),
        ("D2", iff(&dia_p(d, u), &x_(d, &dia_u))),
        ("D3", iff(&dia_u, &or(u, &dia_p(d, u)))),
        ("B1", iff(&box_u, &and(u, &x_(d, &box_u)))),
        ("B2", imp(&box_u, u)),
        ("B3", imp(&box_u, &x_(d, &box_u))),
        ("B4", imp(&box_u, &dia_u)),
        ("B5", imp(&bx(d, &imp(u, v)), &imp(&box_u, &bx(d, v)))),
        ("R1", iff(&rec(d, u), &dia_p(d, &xu))),
        ("R2", imp(&rec(d, u), &dia_p(d, u))),
        ("M4", iff(&dia_u, &not(&bx(d, &not(u))))),
    ]
}

/// Гейтінгова контрмодель M3 (§6.2): у семантиці Ω формула M4 хибна.
pub fn m3_counterexample_holds() -> bool {
    use crate::omega::Om;
    // K = {a=0, b=1}, D(a)=b, D(b)=b; U(a)=EVENTUALLY_PERIODIC, U(b)=CHAOTIC_set
    let d = [1usize, 1usize];
    let u = [Om::EventuallyPeriodic, Om::ChaoticSet];
    let h = 4;
    let dia_h = |x: usize| (0..h).fold(Om::BOTTOM, |acc, k| acc.join(u[orbit_at(&d, x, k)]));
    let neg_u: Vec<Om> = u.iter().map(|a| a.negate()).collect();
    let box_neg = |x: usize| (0..h).fold(Om::TOP, |acc, k| acc.meet(neg_u[orbit_at(&d, x, k)]));
    // ¬_H □_H ¬_H U (a)
    let rhs = box_neg(0).negate();
    dia_h(0) != rhs
}

#[cfg(test)]
mod tests {
    use super::*;

    fn all_dynamics(n: usize) -> Vec<Vec<usize>> {
        let total = n.pow(n as u32);
        (0..total)
            .map(|mut code| {
                (0..n)
                    .map(|_| {
                        let v = code % n;
                        code /= n;
                        v
                    })
                    .collect()
            })
            .collect()
    }

    fn all_preds(n: usize) -> Vec<Pred> {
        (0..(1usize << n))
            .map(|m| (0..n).map(|i| m >> i & 1 == 1).collect())
            .collect()
    }

    /// M1: усі 14 аксіом — тавтології для всіх динамік і всіх пар предикатів на n ≤ 3.
    #[test]
    fn m1_exhaustive_small() {
        for n in 1..=3 {
            for d in all_dynamics(n) {
                for u in all_preds(n) {
                    for v in all_preds(n) {
                        for (name, p) in m1_axioms(&d, &u, &v) {
                            assert!(
                                valid(&p),
                                "аксіома {name} не тавтологія: d={d:?} u={u:?} v={v:?}"
                            );
                        }
                    }
                }
            }
        }
    }

    /// M1 на більших системах (вибірка детермінованим генератором).
    #[test]
    fn m1_random_larger() {
        let mut rng = crate::rng::Rng::new(21);
        for _ in 0..400 {
            let n = 4 + rng.below(5);
            let d: Vec<usize> = (0..n).map(|_| rng.below(n)).collect();
            let u: Pred = (0..n).map(|_| rng.coin()).collect();
            let v: Pred = (0..n).map(|_| rng.coin()).collect();
            for (name, p) in m1_axioms(&d, &u, &v) {
                assert!(valid(&p), "аксіома {name}");
            }
        }
    }

    /// M2: □U → ↺U (історична мітка §6.1.2).
    #[test]
    fn m2_box_implies_rec() {
        for n in 1..=3 {
            for d in all_dynamics(n) {
                for u in all_preds(n) {
                    assert!(valid(&imp(&bx(&d, &u), &rec(&d, &u))));
                }
            }
        }
    }

    /// M3/M4 у гейтінговій семантиці: контрмодель існує.
    #[test]
    fn m3_godel_counterexample() {
        assert!(m3_counterexample_holds());
    }

    /// Просте сумісне «відчуття» M4 у класичній семантиці: ◇U ↔ ¬□¬U.
    #[test]
    fn m4_classical_example() {
        let d = [1usize, 1usize];
        let u: Pred = vec![true, false];
        assert!(valid(&iff(&dia(&d, &u), &not(&bx(&d, &not(&u))))));
    }
}
