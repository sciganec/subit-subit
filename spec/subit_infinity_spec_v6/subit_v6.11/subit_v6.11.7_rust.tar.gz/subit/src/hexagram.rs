//! Додаток А: таблиця 64 гексаграм. Перевірки: номери 1…64, гліфи U+4DC0…U+4DFF, коди
//! різні й < 64, код = 8·(код нижньої триграми) + код верхньої, де коди триграм —
//! (111, 100, 010, 001, 000, 011, 101, 110) за індексом у порядку Вень-вана.
//! Семантичного відображення гексаграм на білаттис тут немає (НЕ ПІДТВЕРДЖЕНО).

use crate::hexagram_data::HEX_TABLE;

/// Матриця Вень-вана M[нижня][верхня] — номер гексаграми.
pub const WEN_MATRIX: [[u8; 8]; 8] = [
    [1, 34, 5, 26, 11, 9, 14, 43],
    [25, 51, 3, 27, 24, 42, 21, 17],
    [6, 40, 29, 4, 7, 59, 64, 47],
    [33, 62, 39, 52, 15, 53, 56, 31],
    [12, 16, 8, 23, 2, 20, 35, 45],
    [44, 32, 48, 18, 46, 57, 50, 28],
    [13, 55, 63, 22, 36, 37, 30, 49],
    [10, 54, 60, 41, 19, 61, 38, 58],
];

/// 3-бітний код триграми за індексом рядка/стовпця матриці.
pub const TRIGRAM_BITS: [u8; 8] = [7, 4, 2, 1, 0, 3, 5, 6];

/// Очікуваний 6-бітний код для гексаграми з матриці.
pub fn expected_code(lower: usize, upper: usize) -> u8 {
    TRIGRAM_BITS[lower] * 8 + TRIGRAM_BITS[upper]
}

/// Код гексаграми за номером.
pub fn code_of(number: u8) -> Option<u8> {
    HEX_TABLE.iter().find(|r| r.0 == number).map(|r| r.2)
}

/// Повна перевірка таблиці; повертає перелік порушень (порожній — усе гаразд).
pub fn check_table() -> Vec<String> {
    let mut errs = Vec::new();
    if HEX_TABLE.len() != 64 {
        errs.push(format!("очікувалось 64 рядки, є {}", HEX_TABLE.len()));
    }
    let mut numbers: Vec<u8> = HEX_TABLE.iter().map(|r| r.0).collect();
    numbers.sort_unstable();
    if numbers != (1..=64).collect::<Vec<u8>>() {
        errs.push("номери не є 1…64".into());
    }
    for &(n, glyph, code) in HEX_TABLE.iter() {
        if u32::from(glyph) != 0x4DC0 + u32::from(n) - 1 {
            errs.push(format!("гліф №{n} не відповідає U+4DC0 + №−1"));
        }
        if code >= 64 {
            errs.push(format!("код №{n} поза [0,64)"));
        }
    }
    let mut codes: Vec<u8> = HEX_TABLE.iter().map(|r| r.2).collect();
    codes.sort_unstable();
    codes.dedup();
    if codes.len() != 64 {
        errs.push("коди не різні".into());
    }
    for (lo, row) in WEN_MATRIX.iter().enumerate() {
        for (up, &n) in row.iter().enumerate() {
            match code_of(n) {
                Some(c) if c == expected_code(lo, up) => {}
                Some(c) => errs.push(format!(
                    "№{n}: код {c} ≠ очікуваний {}",
                    expected_code(lo, up)
                )),
                None => errs.push(format!("№{n} відсутній у таблиці")),
            }
        }
    }
    errs
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn table_matches_wen_matrix() {
        assert_eq!(check_table(), Vec::<String>::new());
    }

    /// Приклад зі специфікації: гексаграма №63 має код 101010 = 42.
    #[test]
    fn spec_example_63() {
        assert_eq!(code_of(63), Some(42));
    }

    /// Матриця Вень-вана — перестановка 1…64.
    #[test]
    fn matrix_is_permutation() {
        let mut v: Vec<u8> = WEN_MATRIX.iter().flatten().copied().collect();
        v.sort_unstable();
        assert_eq!(v, (1..=64).collect::<Vec<u8>>());
    }
}
