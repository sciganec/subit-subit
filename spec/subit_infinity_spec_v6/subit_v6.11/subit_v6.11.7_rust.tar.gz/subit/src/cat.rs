//! §7 у скінченному вигляді: об'єкти SUBIT і SUBIT_full (|S| ≥ 1, ℛ — список різних функцій
//! S → S за індексами, g : ℛ × S → ℛ). Перевірки K1 (закони), K2 (термінальний), K3 (добуток)
//! — повним перебором морфізмів на малих об'єктах.

use crate::rng::Rng;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Obj {
    pub n: usize,
    /// rules[r][s] — значення правила r у стані s.
    pub rules: Vec<Vec<usize>>,
    /// g[r][s] — індекс нового правила.
    pub g: Vec<Vec<usize>>,
}

impl Obj {
    pub fn new(n: usize, rules: Vec<Vec<usize>>, g: Vec<Vec<usize>>) -> Option<Obj> {
        let ok = n >= 1
            && !rules.is_empty()
            && rules
                .iter()
                .all(|r| r.len() == n && r.iter().all(|&v| v < n))
            && g.len() == rules.len()
            && g.iter()
                .all(|row| row.len() == n && row.iter().all(|&i| i < rules.len()))
            && (0..rules.len()).all(|a| (a + 1..rules.len()).all(|b| rules[a] != rules[b]));
        ok.then_some(Obj { n, rules, g })
    }

    pub fn term() -> Obj {
        Obj {
            n: 1,
            rules: vec![vec![0]],
            g: vec![vec![0]],
        }
    }
}

/// Морфізм: fs : S_X → S_Y, fr : ℛ_X → ℛ_Y (індекси).
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Hom {
    pub fs: Vec<usize>,
    pub fr: Vec<usize>,
}

/// Умова 7.2 (і 7.3 для повного варіанта).
pub fn is_hom(x: &Obj, y: &Obj, h: &Hom, full: bool) -> bool {
    let rules_ok = (0..x.rules.len())
        .all(|r| (0..x.n).all(|s| h.fs[x.rules[r][s]] == y.rules[h.fr[r]][h.fs[s]]));
    let g_ok = !full
        || (0..x.rules.len()).all(|r| (0..x.n).all(|s| h.fr[x.g[r][s]] == y.g[h.fr[r]][h.fs[s]]));
    rules_ok && g_ok
}

pub fn compose(f: &Hom, h: &Hom) -> Hom {
    // f ∘ h
    Hom {
        fs: h.fs.iter().map(|&s| f.fs[s]).collect(),
        fr: h.fr.iter().map(|&r| f.fr[r]).collect(),
    }
}

pub fn identity(x: &Obj) -> Hom {
    Hom {
        fs: (0..x.n).collect(),
        fr: (0..x.rules.len()).collect(),
    }
}

/// Усі морфізми X → Y (повний перебір).
pub fn all_homs(x: &Obj, y: &Obj, full: bool) -> Vec<Hom> {
    let mut out = Vec::new();
    let ns = y.n.pow(x.n as u32);
    let nr = y.rules.len().pow(x.rules.len() as u32);
    for a in 0..ns {
        let fs: Vec<usize> = (0..x.n).map(|i| a / y.n.pow(i as u32) % y.n).collect();
        for b in 0..nr {
            let fr: Vec<usize> = (0..x.rules.len())
                .map(|i| b / y.rules.len().pow(i as u32) % y.rules.len())
                .collect();
            let h = Hom { fs: fs.clone(), fr };
            if is_hom(x, y, &h, full) {
                out.push(h);
            }
        }
    }
    out
}

/// Добуток X × Y: стани — пари (a, b) ↦ a·|Y| + b; правила — пари (i, j) ↦ i·|ℛ_Y| + j.
pub fn product(x: &Obj, y: &Obj) -> Obj {
    let (nx, ny) = (x.n, y.n);
    let (rx, ry) = (x.rules.len(), y.rules.len());
    let n = nx * ny;
    let mut rules = Vec::new();
    let mut g = Vec::new();
    for i in 0..rx {
        for j in 0..ry {
            rules.push(
                (0..n)
                    .map(|st| {
                        let (a, b) = (st / ny, st % ny);
                        x.rules[i][a] * ny + y.rules[j][b]
                    })
                    .collect::<Vec<_>>(),
            );
            g.push(
                (0..n)
                    .map(|st| {
                        let (a, b) = (st / ny, st % ny);
                        x.g[i][a] * ry + y.g[j][b]
                    })
                    .collect::<Vec<_>>(),
            );
        }
    }
    Obj::new(n, rules, g).expect("добуток об'єктів є об'єктом")
}

/// Проєкції добутку.
pub fn proj_x(x: &Obj, y: &Obj) -> Hom {
    let ny = y.n;
    let ry = y.rules.len();
    let _ = x;
    Hom {
        fs: (0..x.n * y.n).map(|st| st / ny).collect(),
        fr: (0..x.rules.len() * ry).map(|r| r / ry).collect(),
    }
}
pub fn proj_y(x: &Obj, y: &Obj) -> Hom {
    let ny = y.n;
    let ry = y.rules.len();
    let _ = x;
    Hom {
        fs: (0..x.n * y.n).map(|st| st % ny).collect(),
        fr: (0..x.rules.len() * ry).map(|r| r % ry).collect(),
    }
}

/// Спарювання u : Z → X, v : Z → Y у морфізм Z → X × Y.
pub fn pair(_x: &Obj, y: &Obj, u: &Hom, v: &Hom) -> Hom {
    let ny = y.n;
    let ry = y.rules.len();
    Hom {
        fs: (0..u.fs.len()).map(|z| u.fs[z] * ny + v.fs[z]).collect(),
        fr: (0..u.fr.len()).map(|t| u.fr[t] * ry + v.fr[t]).collect(),
    }
}

/// Випадковий малий об'єкт (ℛ — різні функції).
pub fn random_obj(rng: &mut Rng) -> Obj {
    loop {
        let n = 1 + rng.below(2);
        let k = 1 + rng.below(3);
        let mut rules: Vec<Vec<usize>> = Vec::new();
        for _ in 0..k {
            let r: Vec<usize> = (0..n).map(|_| rng.below(n)).collect();
            if !rules.contains(&r) {
                rules.push(r);
            }
        }
        let g: Vec<Vec<usize>> = rules
            .iter()
            .map(|_| (0..n).map(|_| rng.below(rules.len())).collect())
            .collect();
        if let Some(o) = Obj::new(n, rules, g) {
            return o;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// K1: тотожні й асоціативність на всіх морфізмах малих випадкових об'єктів.
    #[test]
    fn k1_category_laws() {
        let mut rng = Rng::new(41);
        for _ in 0..40 {
            let (a, b, c) = (
                random_obj(&mut rng),
                random_obj(&mut rng),
                random_obj(&mut rng),
            );
            for full in [false, true] {
                for f in all_homs(&a, &b, full) {
                    assert_eq!(compose(&identity(&b), &f), f);
                    assert_eq!(compose(&f, &identity(&a)), f);
                    for g in all_homs(&b, &c, full) {
                        let gf = compose(&g, &f);
                        assert!(is_hom(&a, &c, &gf, full));
                    }
                }
            }
        }
    }

    /// K2: термінальний об'єкт 1 = ({∗}, {id}, g_triv); єдиний морфізм X → 1.
    #[test]
    fn k2_terminal() {
        let t = Obj::term();
        let mut rng = Rng::new(43);
        for _ in 0..60 {
            let x = random_obj(&mut rng);
            for full in [false, true] {
                let homs = all_homs(&x, &t, full);
                assert_eq!(homs.len(), 1, "має бути рівно один морфізм у 1");
            }
        }
    }

    /// K3: добуток — проєкції є морфізмами; спарювання є морфізмом і єдине з цією властивістю
    /// (перебором усіх морфізмів Z → X × Y).
    #[test]
    fn k3_product_universal() {
        let mut rng = Rng::new(47);
        for _ in 0..25 {
            let x = random_obj(&mut rng);
            let y = random_obj(&mut rng);
            let p = product(&x, &y);
            for full in [false, true] {
                let px = proj_x(&x, &y);
                let py = proj_y(&x, &y);
                assert!(is_hom(&p, &x, &px, full));
                assert!(is_hom(&p, &y, &py, full));
                let z = random_obj(&mut rng);
                for u in all_homs(&z, &x, full) {
                    for v in all_homs(&z, &y, full) {
                        let w = pair(&x, &y, &u, &v);
                        assert!(is_hom(&z, &p, &w, full), "спарювання — морфізм");
                        assert_eq!(compose(&px, &w), u);
                        assert_eq!(compose(&py, &w), v);
                        let uniq = all_homs(&z, &p, full)
                            .into_iter()
                            .filter(|h| compose(&px, h) == u && compose(&py, h) == v)
                            .count();
                        assert_eq!(uniq, 1, "єдиність спарювання");
                    }
                }
            }
        }
    }
}
