//! §3.1: точкова класифікація (P1, P2, P3 точний режим, P3′ бюджетований режим).

use std::collections::HashMap;

/// Скінченна детермінована динаміка на станах 0..size().
pub trait Dynamics {
    fn size(&self) -> usize;
    fn step(&self, s: usize) -> usize;
}

/// Динаміка, задана таблицею переходів.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TableDyn(pub Vec<usize>);

impl Dynamics for TableDyn {
    fn size(&self) -> usize {
        self.0.len()
    }
    fn step(&self, s: usize) -> usize {
        self.0[s]
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum PointClass {
    Fixed,
    Periodic(usize),
    Preperiodic(usize, usize),
}

/// Орбіта: m — довжина передперіоду, p — період, `states` = (x₀, …, x_{m+p−1}).
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct Orbit {
    pub m: usize,
    pub p: usize,
    pub states: Vec<usize>,
}

impl Orbit {
    pub fn class(&self) -> PointClass {
        match (self.m, self.p) {
            (0, 1) => PointClass::Fixed,
            (0, p) => PointClass::Periodic(p),
            (m, p) => PointClass::Preperiodic(m, p),
        }
    }
    pub fn cycle(&self) -> &[usize] {
        &self.states[self.m..]
    }
    pub fn preperiod(&self) -> &[usize] {
        &self.states[..self.m]
    }
}

/// Результат бюджетованого режиму. `ResourceExceeded` — **не класифікація**.
#[derive(Clone, PartialEq, Eq, Debug)]
pub enum Budgeted {
    Computed(Orbit),
    ResourceExceeded { horizon: usize, depth: usize },
}

/// Цикл алгоритму §3.1.3: n = 0, …, n_max; `visited` — відображення стан ↦ крок.
pub fn classify_budgeted<D: Dynamics>(d: &D, s0: usize, n_max: usize) -> Budgeted {
    let mut visited: HashMap<usize, usize> = HashMap::new();
    let mut seq: Vec<usize> = Vec::new();
    let mut s = s0;
    for n in 0..=n_max {
        if let Some(&m) = visited.get(&s) {
            let p = n - m;
            seq.truncate(m + p);
            return Budgeted::Computed(Orbit { m, p, states: seq });
        }
        visited.insert(s, n);
        seq.push(s);
        s = d.step(s);
    }
    Budgeted::ResourceExceeded {
        horizon: n_max,
        depth: visited.len(),
    }
}

/// Точний режим (P3): n_max = #Q₀; гілка `ResourceExceeded` недосяжна за принципом Діріхле.
pub fn classify_exact<D: Dynamics>(d: &D, s0: usize) -> Orbit {
    match classify_budgeted(d, s0, d.size()) {
        Budgeted::Computed(o) => o,
        Budgeted::ResourceExceeded { .. } => {
            unreachable!("принцип Діріхле: повтор настає не пізніше n = #Q₀")
        }
    }
}

/// Dⁿ(s).
pub fn iterate<D: Dynamics>(d: &D, mut s: usize, n: usize) -> usize {
    for _ in 0..n {
        s = d.step(s);
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rng::Rng;

    fn random_table(rng: &mut Rng, n: usize) -> TableDyn {
        TableDyn((0..n).map(|_| rng.below(n)).collect())
    }

    /// Означення m, p: найменше m, для якого ∃p ≥ 1 : D^{m+p} = D^m, потім найменше p.
    fn brute_mp(d: &TableDyn, s0: usize) -> (usize, usize) {
        let n = d.size();
        for m in 0..=n {
            for p in 1..=n {
                if iterate(d, s0, m + p) == iterate(d, s0, m) {
                    return (m, p);
                }
            }
        }
        panic!("P1: m, p існують");
    }

    /// P1–P3: алгоритм збігається з означенням, m + p ≤ #Q₀.
    #[test]
    fn p3_matches_definition_random() {
        let mut rng = Rng::new(7);
        for _ in 0..500 {
            let n = 1 + rng.below(30);
            let d = random_table(&mut rng, n);
            for s0 in 0..n {
                let o = classify_exact(&d, s0);
                assert_eq!((o.m, o.p), brute_mp(&d, s0));
                assert!(o.m + o.p <= n);
                assert_eq!(o.states.len(), o.m + o.p);
                for (i, &x) in o.states.iter().enumerate() {
                    assert_eq!(x, iterate(&d, s0, i));
                }
                // цикл замкнений
                let c = o.cycle();
                for i in 0..c.len() {
                    assert_eq!(d.step(c[i]), c[(i + 1) % c.len()]);
                }
            }
        }
    }

    /// P2: три класи вичерпні й виключні.
    #[test]
    fn p2_classes() {
        let d = TableDyn(vec![1, 2, 0, 3, 3, 4]);
        assert_eq!(classify_exact(&d, 0).class(), PointClass::Periodic(3));
        assert_eq!(classify_exact(&d, 3).class(), PointClass::Fixed);
        assert_eq!(classify_exact(&d, 5).class(), PointClass::Preperiodic(2, 1));
    }

    /// P3′: за малого бюджету RESOURCE_EXCEEDED досяжна; повторів може не бути в межах горизонту.
    #[test]
    fn p3_prime_budget() {
        let cyc = TableDyn(vec![1, 2, 0]);
        assert_eq!(
            classify_budgeted(&cyc, 0, 1),
            Budgeted::ResourceExceeded {
                horizon: 1,
                depth: 2
            }
        );
        // але не для кожної системи: нерухома точка знаходиться за один крок
        let fix = TableDyn(vec![0, 1, 2]);
        assert!(
            matches!(classify_budgeted(&fix, 0, 1), Budgeted::Computed(o) if o.class() == PointClass::Fixed)
        );
        // з бюджетом #Q₀ завжди COMPUTED
        assert!(matches!(
            classify_budgeted(&cyc, 0, 3),
            Budgeted::Computed(_)
        ));
    }
}
