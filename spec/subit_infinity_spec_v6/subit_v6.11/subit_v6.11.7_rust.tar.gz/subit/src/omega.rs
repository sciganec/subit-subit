//! §5: 6-ланцюг Ω — алгебра Гейтінга.

/// Ω: CHAOTIC_set < APERIODIC_NON_CHAOTIC < EVENTUALLY_PERIODIC < PERIODIC_SET
/// < INVARIANT_DYNAMIC < INVARIANT_FIXED.
#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash, PartialOrd, Ord)]
pub enum Om {
    ChaoticSet = 0,
    AperiodicNonChaotic = 1,
    EventuallyPeriodic = 2,
    PeriodicSet = 3,
    InvariantDynamic = 4,
    InvariantFixed = 5,
}

impl Om {
    pub const ALL: [Om; 6] = [
        Om::ChaoticSet,
        Om::AperiodicNonChaotic,
        Om::EventuallyPeriodic,
        Om::PeriodicSet,
        Om::InvariantDynamic,
        Om::InvariantFixed,
    ];
    pub const BOTTOM: Om = Om::ChaoticSet;
    pub const TOP: Om = Om::InvariantFixed;

    /// ∧ = min.
    pub fn meet(self, o: Om) -> Om {
        self.min(o)
    }
    /// ∨ = max.
    pub fn join(self, o: Om) -> Om {
        self.max(o)
    }
    /// a → b := ⊤, якщо a ≤ b, інакше b.
    pub fn imp(self, b: Om) -> Om {
        if self <= b {
            Om::TOP
        } else {
            b
        }
    }
    /// ¬a := a → ⊥.
    pub fn negate(self) -> Om {
        self.imp(Om::BOTTOM)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// C6: min(a, c) ≤ b ⇔ c ≤ (a → b) для всіх a, b, c.
    #[test]
    fn heyting_adjunction() {
        for a in Om::ALL {
            for b in Om::ALL {
                for c in Om::ALL {
                    assert_eq!(a.meet(c) <= b, c <= a.imp(b), "{a:?} {b:?} {c:?}");
                }
            }
        }
    }

    /// Ґраткові закони й межі.
    #[test]
    fn lattice_laws() {
        for a in Om::ALL {
            assert_eq!(a.meet(Om::TOP), a);
            assert_eq!(a.join(Om::BOTTOM), a);
            for b in Om::ALL {
                assert_eq!(a.meet(b), b.meet(a));
                assert_eq!(a.join(b), b.join(a));
                assert_eq!(a.meet(a.join(b)), a);
                assert_eq!(a.join(a.meet(b)), a);
            }
        }
    }

    /// Виключене третє не виконується; ¬⊥ = ⊤; ¬a = ⊥ для a > ⊥.
    #[test]
    fn no_excluded_middle() {
        assert_eq!(Om::BOTTOM.negate(), Om::TOP);
        for a in Om::ALL.into_iter().filter(|&a| a != Om::BOTTOM) {
            assert_eq!(a.negate(), Om::BOTTOM);
        }
        assert!(Om::ALL.iter().any(|&a| a.join(a.negate()) != Om::TOP));
        assert_eq!(
            Om::EventuallyPeriodic.join(Om::EventuallyPeriodic.negate()),
            Om::EventuallyPeriodic
        );
    }
}
