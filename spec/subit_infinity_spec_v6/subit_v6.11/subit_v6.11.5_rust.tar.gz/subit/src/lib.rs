//! Скінченний рівень SUBIT-∞ (специфікація v6.11.5): A1–A4, SUBIT⁺, P1–P3/P3′, C1–C3, Ω,
//! модальна семантика §6, категорія скінченних об'єктів §7, d_Ω_traj, Додаток А.
//!
//! Це реалізація скінченних тверджень; нескінченний рівень (S∞, ω-границі, ентропія) тут не
//! реалізується. Ентропія скінченних множин дорівнює 0 (C7), тому `ChaosStatus::Chaotic`
//! у цьому крейті недосяжний.

pub mod alphabet;
pub mod cat;
pub mod hexagram;
pub mod modal;
pub mod omega;
pub mod orbit;
pub mod plus;
pub mod rng;
pub mod sets;
pub mod traj;

mod hexagram_data;
