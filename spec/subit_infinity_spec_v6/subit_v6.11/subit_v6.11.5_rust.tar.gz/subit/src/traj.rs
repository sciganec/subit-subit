//! §11 для скінченних систем: ω-границя, класи S(τ), ChaosStatus (C7), ATTAINED, d_Ω_traj.
//! Нескінченні ω-границі (MIN_*, NONMIN_*) у скінченних системах недосяжні; їхні коди
//! беруться з таблиці §11.3 і використовуються лише в метриці d_Ω_traj.

use crate::orbit::{iterate, Dynamics};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Size {
    One,
    FinMany,
    Inf,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Min {
    Na,
    Min,
    NonMin,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Ent {
    Zero,
    Pos,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Att {
    Attained,
    NonAttained,
}

/// Код класу §11.3: (розмір, Min, ентропія, Att). Роль діагностична.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Code {
    pub size: Size,
    pub min: Min,
    pub ent: Ent,
    pub att: Att,
}

/// Шість класів S(τ) (таблиця §11.3).
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum SClass {
    Fixed,
    Periodic,
    MinZero,
    MinPos,
    NonMinZero,
    NonMinPos,
}

impl SClass {
    pub const ALL: [SClass; 6] = [
        SClass::Fixed,
        SClass::Periodic,
        SClass::MinZero,
        SClass::MinPos,
        SClass::NonMinZero,
        SClass::NonMinPos,
    ];

    pub fn base_code(self) -> (Size, Min, Ent) {
        match self {
            SClass::Fixed => (Size::One, Min::Na, Ent::Zero),
            SClass::Periodic => (Size::FinMany, Min::Na, Ent::Zero),
            SClass::MinZero => (Size::Inf, Min::Min, Ent::Zero),
            SClass::MinPos => (Size::Inf, Min::Min, Ent::Pos),
            SClass::NonMinZero => (Size::Inf, Min::NonMin, Ent::Zero),
            SClass::NonMinPos => (Size::Inf, Min::NonMin, Ent::Pos),
        }
    }

    /// Код класу з урахуванням ATTAINED/NONATTAINED.
    pub fn code(self, att: Att) -> Code {
        let (size, min, ent) = self.base_code();
        Code {
            size,
            min,
            ent,
            att,
        }
    }
}

/// Усі 12 кодів (6 × 2), попарно різні.
pub fn all_codes() -> Vec<Code> {
    SClass::ALL
        .iter()
        .flat_map(|c| [c.code(Att::Attained), c.code(Att::NonAttained)])
        .collect()
}

/// d_Ω_traj: відстань Геммінга між кодами (кількість координат, що відрізняються).
pub fn ham(a: &Code, b: &Code) -> u32 {
    u32::from(a.size != b.size)
        + u32::from(a.min != b.min)
        + u32::from(a.ent != b.ent)
        + u32::from(a.att != b.att)
}

/// ω-границя орбіти x у скінченній системі — множина станів циклу (sorted).
pub fn omega_cycle<D: Dynamics>(d: &D, x: usize) -> Vec<usize> {
    let mut seen: Vec<Option<usize>> = vec![None; d.size()];
    let mut seq: Vec<usize> = Vec::new();
    let mut s = x;
    loop {
        if let Some(j) = seen[s] {
            let mut cyc = seq[j..].to_vec();
            cyc.sort_unstable();
            return cyc;
        }
        seen[s] = Some(seq.len());
        seq.push(s);
        s = d.step(s);
    }
}

/// Клас ω-границі в скінченній системі (FIXED або PERIODIC).
pub fn finite_class<D: Dynamics>(d: &D, x: usize) -> SClass {
    if omega_cycle(d, x).len() == 1 {
        SClass::Fixed
    } else {
        SClass::Periodic
    }
}

/// ATTAINED ⇔ ∃n : xₙ ∈ ω(τ). Для скінченних систем завжди виконано (хвіст орбіти лежить у циклі).
pub fn attained<D: Dynamics>(d: &D, x: usize) -> Att {
    let cyc = omega_cycle(d, x);
    for n in 0..=d.size() {
        if cyc.binary_search(&iterate(d, x, n)).is_ok() {
            return Att::Attained;
        }
    }
    Att::NonAttained
}

/// ChaosStatus у скінченній системі: C7 — ентропія 0, тож лише NON_CHAOTIC.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Chaos {
    NonChaotic,
}

pub fn chaos_status_finite() -> Chaos {
    Chaos::NonChaotic
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::orbit::TableDyn;
    use crate::rng::Rng;

    /// 12 кодів попарно різні; d_Ω_traj — метрика (симетрія, нуль ⇔ рівність, трикутник).
    #[test]
    fn codes_and_hamming_metric() {
        let codes = all_codes();
        assert_eq!(codes.len(), 12);
        for i in 0..12 {
            for j in 0..12 {
                assert_eq!(codes[i] == codes[j], i == j);
                assert_eq!(ham(&codes[i], &codes[j]), ham(&codes[j], &codes[i]));
                assert_eq!(ham(&codes[i], &codes[j]) == 0, i == j);
                for k in 0..12 {
                    assert!(
                        ham(&codes[i], &codes[k])
                            <= ham(&codes[i], &codes[j]) + ham(&codes[j], &codes[k])
                    );
                }
            }
        }
    }

    /// Класи скінченних ω-границь і ATTAINED для випадкових систем.
    #[test]
    fn finite_classes_and_attained() {
        let mut rng = Rng::new(31);
        for _ in 0..300 {
            let n = 1 + rng.below(12);
            let d = TableDyn((0..n).map(|_| rng.below(n)).collect());
            for x in 0..n {
                let c = finite_class(&d, x);
                let cyc = omega_cycle(&d, x);
                assert_eq!(c == SClass::Fixed, cyc.len() == 1);
                // ω-границя інваріантна: D[ω] = ω
                let mut img: Vec<usize> = cyc.iter().map(|&s| d.step(s)).collect();
                img.sort_unstable();
                img.dedup();
                assert_eq!(img, cyc);
                // у скінченній системі ω-границя досяжна
                assert_eq!(attained(&d, x), Att::Attained);
                assert!(all_codes().contains(&c.code(Att::Attained)));
            }
        }
        assert_eq!(chaos_status_finite(), Chaos::NonChaotic);
    }
}
