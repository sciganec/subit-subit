import Mathlib.Dynamics.PeriodicPts.Lemmas
import Subit.Discrete1
/-!
# SUBIT-∞ v6.11.5 — дискретний залишок II: C3(b),(c), C4a, χ_U (8.3, 8.4)
-/
open Classical
namespace Subit

section Chaos
variable {X : Type*}

/-- C3(b): CHAOTIC (h_top > 0, за (Π2) D[P] = P) ⇒ OrbitType = INVARIANT_DYNAMIC. -/
theorem C3b (d : X → X → ℝ) (D : X → X) (W : Set X) (hEq : EQ_IMAGE D (· ∈ W))
    (hW : Set.MapsTo D W W) (hpos : 0 < htopOn d D W hW) :
    OTpred D (· ∈ W) .invDynamic := by
  rcases (C3a D (· ∈ W)).1 hEq with hf | hd
  · exfalso
    have hid : restrict D W hW = id := by
      funext a
      exact Subtype.ext (hf.2.2 a.1 a.2)
    have : htopOn d D W hW = 0 := by
      unfold htopOn; rw [hid]; exact htop_id _
    rw [this] at hpos
    exact lt_irrefl _ hpos
  · exact hd

/-- C3(c): за (Π2) D[P] = P (входить до означення Min) мінімальність дає INVARIANT_FIXED
або INVARIANT_DYNAMIC. Формально це наслідок C3(а). -/
theorem C3c (D : X → X) (W : Set X) (hEq : EQ_IMAGE D (· ∈ W)) :
    OTpred D (· ∈ W) .invFixed ∨ OTpred D (· ∈ W) .invDynamic :=
  (C3a D (· ∈ W)).1 hEq

end Chaos

section C4
variable {X : Type*}

theorem iter_eq_iterate (D : X → X) (n : ℕ) (x : X) : iter D n x = D^[n] x := by
  induction n generalizing x with
  | zero => rfl
  | succ n ih => rw [Function.iterate_succ_apply', ← ih]; rfl

/-- C4a: скінченна P з D[P] = P: D|P — бієкція і кожна точка періодична. -/
theorem C4a (D : X → X) (W : Set X) (hf : W.Finite) (h : D '' W = W) :
    Set.BijOn D W W ∧ ∀ x ∈ W, ∃ p, 0 < p ∧ iter D p x = x := by
  have hmaps : Set.MapsTo D W W := fun x hx => h ▸ Set.mem_image_of_mem D hx
  have hsurj : Set.SurjOn D W W := by rw [Set.SurjOn, h]
  have hbij : Set.BijOn D W W := (hf.surjOn_iff_bijOn_of_mapsTo hmaps).1 hsurj
  refine ⟨hbij, fun x hx => ?_⟩
  haveI : Finite W := hf.to_subtype
  have hinj : Function.Injective (restrict D W hmaps) := by
    intro a b hab
    exact Subtype.ext (hbij.injOn a.2 b.2 (congrArg Subtype.val hab))
  obtain ⟨p, hp, hfix⟩ := hinj.mem_periodicPts ⟨x, hx⟩
  refine ⟨p, hp, ?_⟩
  have key : ∀ n (a : W), ((restrict D W hmaps)^[n] a).1 = D^[n] a.1 := by
    intro n; induction n with
    | zero => intro a; rfl
    | succ n ih =>
      intro a
      rw [Function.iterate_succ_apply, Function.iterate_succ_apply]
      exact ih (restrict D W hmaps a)
  rw [iter_eq_iterate, ← key p ⟨x, hx⟩]
  exact congrArg Subtype.val hfix

end C4

/-! ## χ_U (означення 8.3, твердження 8.4) -/

section Chi
variable {S : Type*} (f : S → S)

/-- χ_U(x) = min{n : fⁿ x ∈ U}; ∞, якщо такого n нема. -/
noncomputable def chi (U : Set S) (x : S) : ℕ∞ :=
  if h : ∃ k, iter f k x ∈ U then ((Nat.find h : ℕ) : ℕ∞) else ⊤

theorem iter_succ_apply (n : ℕ) (x : S) : iter f n (f x) = iter f (n + 1) x := by
  rw [show n + 1 = n + 1 from rfl, iter_add f n 1 x]; rfl

theorem natcast_sub_one (m : ℕ) (hm : 0 < m) : ((m - 1 : ℕ) : ℕ∞) = (m : ℕ∞) - 1 := by
  rw [ENat.coe_sub]; simp

variable {f}

theorem chi_eq_zero_iff (U : Set S) (x : S) : chi f U x = 0 ↔ x ∈ U := by
  unfold chi
  split_ifs with h
  · constructor
    · intro h0
      have : Nat.find h = 0 := by exact_mod_cast h0
      have := Nat.find_spec h
      rwa [‹Nat.find h = 0›] at this
    · intro hx
      have : Nat.find h = 0 := Nat.eq_zero_of_le_zero (Nat.find_min' h hx)
      simp [this]
  · simp only [ENat.top_ne_zero, false_iff]
    intro hx; exact h ⟨0, hx⟩

/-- 8.4(a): χ_U(f x) = max(χ_U(x) − 1, 0) для інваріантного U. -/
theorem chi_step {U : Set S} (hU : ∀ x ∈ U, f x ∈ U) (x : S) :
    chi f U (f x) = chi f U x - 1 := by
  by_cases h : ∃ k, iter f k x ∈ U
  · set m := Nat.find h with hm
    have hmU : iter f m x ∈ U := Nat.find_spec h
    rcases Nat.eq_zero_or_pos m with h0 | hpos
    · have hx : x ∈ U := by simpa [h0, iter] using hmU
      have h1 : chi f U (f x) = 0 := (chi_eq_zero_iff U _).2 (hU x hx)
      have h2 : chi f U x = 0 := (chi_eq_zero_iff U _).2 hx
      rw [h1, h2]; simp
    · have h' : ∃ k, iter f k (f x) ∈ U := ⟨m - 1, by
        rw [iter_succ_apply, Nat.sub_add_cancel hpos]; exact hmU⟩
      have hfind : Nat.find h' = m - 1 := by
        apply le_antisymm
        · exact Nat.find_min' h' (by rw [iter_succ_apply, Nat.sub_add_cancel hpos]; exact hmU)
        · have := Nat.find_spec h'
          rw [iter_succ_apply] at this
          have := Nat.find_min' h this
          omega
      unfold chi
      rw [dif_pos h, dif_pos h', hfind, ← hm]
      exact natcast_sub_one m hpos
  · have h' : ¬ ∃ k, iter f k (f x) ∈ U := by
      rintro ⟨k, hk⟩
      rw [iter_succ_apply] at hk
      exact h ⟨k + 1, hk⟩
    unfold chi
    rw [dif_neg h, dif_neg h']; simp


/-- Морфізм у Ω_Dyn: χ(f x) = χ(x) − 1 (усічена різниця в ℕ∪{∞}). -/
def IsDynMor (f : S → S) (χ : S → ℕ∞) : Prop := ∀ x, χ (f x) = χ x - 1

theorem iterate_dynmor {χ : S → ℕ∞} (h : IsDynMor f χ) (k : ℕ) (x : S) :
    χ (iter f k x) = χ x - k := by
  induction k with
  | zero => simp [iter]
  | succ k ih =>
    show χ (f (iter f k x)) = _
    rw [h, ih, tsub_tsub]; norm_cast

/-- 8.4(b), ланка 1: χ_U — морфізм, а χ_U⁻¹(0) = U. -/
theorem chi_isDynMor {U : Set S} (hU : ∀ x ∈ U, f x ∈ U) : IsDynMor f (chi f U) :=
  fun x => chi_step hU x

/-- 8.4(b), ланка 2: для морфізму χ множина χ⁻¹(0) інваріантна й χ_{χ⁻¹(0)} = χ. -/
theorem chi_of_dynmor {χ : S → ℕ∞} (h : IsDynMor f χ) :
    (∀ x ∈ {x | χ x = 0}, f x ∈ {x | χ x = 0}) ∧ chi f {x | χ x = 0} = χ := by
  refine ⟨fun x hx => ?_, ?_⟩
  · show χ (f x) = 0
    rw [h]; have : χ x = 0 := hx
    rw [this]; simp
  · funext x
    have hit := iterate_dynmor h
    induction hx : χ x using ENat.recTopCoe with
    | top =>
      unfold chi
      have : ¬ ∃ k, iter f k x ∈ {x | χ x = 0} := by
        rintro ⟨k, hk⟩
        have := hit k x
        have hk' : χ (iter f k x) = 0 := hk
        rw [hk', hx] at this
        simp at this
      rw [dif_neg this]
    | coe m =>
      unfold chi
      have hex : ∃ k, iter f k x ∈ {x | χ x = 0} := ⟨m, by
        show χ (iter f m x) = 0
        rw [hit, hx]; simp⟩
      rw [dif_pos hex]
      have : Nat.find hex = m := by
        apply le_antisymm
        · exact Nat.find_min' hex (by show χ (iter f m x) = 0; rw [hit, hx]; simp)
        · by_contra hlt
          have hlt : Nat.find hex < m := not_le.1 hlt
          have := Nat.find_spec hex
          have h0 : χ (iter f (Nat.find hex) x) = 0 := this
          rw [hit, hx] at h0
          have : ((m : ℕ∞) - (Nat.find hex : ℕ∞)) = ((m - Nat.find hex : ℕ) : ℕ∞) := by
            rw [ENat.coe_sub]
          rw [this] at h0
          have : m - Nat.find hex = 0 := by exact_mod_cast h0
          omega
      convert congrArg (Nat.cast : ℕ → ℕ∞) this

/-- 8.4: підоб'єкти (інваріантні U) ↔ морфізми S → Ω_Dyn (еквівалентність). -/
noncomputable def subobjEquiv (f : S → S) :
    {U : Set S // ∀ x ∈ U, f x ∈ U} ≃ {χ : S → ℕ∞ // IsDynMor f χ} where
  toFun U := ⟨chi f U.1, chi_isDynMor U.2⟩
  invFun χ := ⟨{x | χ.1 x = 0}, (chi_of_dynmor χ.2).1⟩
  left_inv U := by
    apply Subtype.ext
    ext x
    exact chi_eq_zero_iff U.1 x
  right_inv χ := by
    apply Subtype.ext
    exact (chi_of_dynmor χ.2).2

end Chi

end Subit
