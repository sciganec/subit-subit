import Mathlib.Data.Real.Basic
/-!
# SUBIT-∞ — A4 для 1 ≤ n ≤ 64^63 (твердження 2.4′; «довільного розміру» з v6.12 застаріло з v6.13.25)

ℛ_fin — МНОЖИНА правил, тож різні індекси мають давати різні функції ρ.
Конструкція: блоки розміру m (m + t ≤ 64), S₀ = {0,…,63}. Стан q ↦ (s, r) = (q mod m, q div m).
Правило r: ρ_r(s) = δ(m·r + s) mod m для s < m; ρ_r(m + j) = j-та цифра r у базі 64 для j < t.
Мітки роблять правила попарно різними, якщо k = ⌈n/m⌉ ≤ 64^t.
-/
namespace Subit

/-- j-та цифра (основа 64) числа ℓ — мітка блоку. -/
def A4dig (ℓ j : Nat) : Nat := (ℓ / 64 ^ j) % 64

theorem A4dig_succ (a j : Nat) : A4dig a (j + 1) = A4dig (a / 64) j := by
  unfold A4dig
  rw [pow_succ', ← Nat.div_div_eq_div_mul]

/-- Цифри (основа 64) однозначно визначають число, якщо всі цифри до t збігаються. -/
theorem A4dig_inj : ∀ (t a b : Nat), a < 64 ^ t → b < 64 ^ t →
    (∀ j < t, A4dig a j = A4dig b j) → a = b
  | 0, a, b, ha, hb, _ => by simp at ha hb; omega
  | t + 1, a, b, ha, hb, h => by
    have h0 : a % 64 = b % 64 := by
      have := h 0 (by omega)
      simpa [A4dig] using this
    have hlt : ∀ x, x < 64 ^ (t + 1) → x / 64 < 64 ^ t := by
      intro x hx
      apply Nat.div_lt_of_lt_mul
      rw [pow_succ] at hx
      rw [mul_comm]
      exact hx
    have h' : a / 64 = b / 64 := by
      apply A4dig_inj t _ _ (hlt a ha) (hlt b hb)
      intro j hj
      have := h (j + 1) (by omega)
      rw [A4dig_succ, A4dig_succ] at this
      exact this
    omega

/-- Крок SUBIT⁺ на парі (s, r): правило r застосовується до s; метаеволюція дає новий індекс. -/
def A4step (rule g : Nat → Nat → Nat) (s r : Nat) : Nat × Nat := (rule r s, g r s)

/-- Кодування стану q ↦ (s, r) = (q mod m, q div m). -/
def A4enc (m q : Nat) : Nat × Nat := (q % m, q / m)

theorem A4_blk_lt (n m : Nat) (hm : 1 ≤ m) (x : Nat) (hx : x < n) :
    x / m < (n + m - 1) / m := by
  have h1 : (x + m) / m ≤ (n + m - 1) / m := Nat.div_le_div_right (by omega)
  have h2 : (x + m) / m = x / m + 1 := Nat.add_div_right x (by omega)
  omega

theorem A4_general (n m t : Nat) (hn : 1 ≤ n) (hm : 1 ≤ m) (hmt : m + t ≤ 64)
    (hk : (n + m - 1) / m ≤ 64 ^ t) (δ : Nat → Nat) (hδ : ∀ q < n, δ q < n) :
    ∃ (rule g : Nat → Nat → Nat),
      (∀ r < (n + m - 1) / m, ∀ s < 64, rule r s < 64) ∧
      (∀ r < (n + m - 1) / m, ∀ s < 64, g r s < (n + m - 1) / m) ∧
      (∀ q < n, A4step rule g (A4enc m q).1 (A4enc m q).2 = A4enc m (δ q)) ∧
      (∀ q₁ < n, ∀ q₂ < n, A4enc m q₁ = A4enc m q₂ → q₁ = q₂) ∧
      (∀ a < (n + m - 1) / m, ∀ b < (n + m - 1) / m, (∀ s < 64, rule a s = rule b s) → a = b) := by
  refine ⟨fun r s => if s < m then δ (m * r + s) % m else A4dig r (s - m),
    fun r s => if m * r + s < n then δ (m * r + s) / m else 0, ?_, ?_, ?_, ?_, ?_⟩
  · intro r _ s hs
    dsimp only
    split_ifs with h
    · have : δ (m * r + s) % m < m := Nat.mod_lt _ (by omega)
      omega
    · unfold A4dig
      exact Nat.mod_lt _ (by norm_num)
  · intro r _ s _
    dsimp only
    split_ifs with h
    · exact A4_blk_lt n m hm _ (hδ _ h)
    · exact Nat.div_pos (by omega) (by omega)
  · intro q hq
    have hdm : m * (q / m) + q % m = q := Nat.div_add_mod q m
    have hs : q % m < m := Nat.mod_lt _ (by omega)
    unfold A4step A4enc
    simp only [hs, if_true, hdm, if_pos hq]
  · intro q₁ _ q₂ _ h
    simp only [A4enc, Prod.mk.injEq] at h
    obtain ⟨h1, h2⟩ := h
    calc q₁ = m * (q₁ / m) + q₁ % m := (Nat.div_add_mod q₁ m).symm
      _ = m * (q₂ / m) + q₂ % m := by rw [h1, h2]
      _ = q₂ := Nat.div_add_mod q₂ m
  · intro a ha b hb hab
    have hA : a < 64 ^ t := lt_of_lt_of_le ha hk
    have hB : b < 64 ^ t := lt_of_lt_of_le hb hk
    apply A4dig_inj t a b hA hB
    intro j hj
    have e1 := hab (m + j) (by omega)
    have hnlt : ¬ (m + j < m) := by omega
    simp only [if_neg hnlt, Nat.add_sub_cancel_left] at e1
    exact e1

end Subit
