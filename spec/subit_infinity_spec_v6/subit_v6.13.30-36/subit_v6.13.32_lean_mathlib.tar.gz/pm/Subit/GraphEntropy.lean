import Subit.Entropy
import Subit.LemmaEConcrete
import Mathlib.Topology.Instances.EReal.Lemmas
import Mathlib.Analysis.SpecialFunctions.Log.Basic

/-!
# G7, п. 3 (11.8): ентропія на графі за динамічно еквівалентною метрикою

Для компактного метричного Y і T : Y → Y метрика dX(a,b) := max(d(a,b), d(Ta,Tb)) дає ту саму
топологічну ентропію, що й d: h_top(dX, T) = h_top(d, T).
Доведено: (1) оцінка числа роздільних точок k^m; (2) порівняння sepNum з зсувом індексу на 1;
(3) монотонність h_top; (4) зсув limsup. Ізоморфізм графа з Y — в окремому кроці.
-/

open Filter Topology
namespace Subit

section Count
variable {Y : Type*} [MetricSpace Y] [Nonempty Y]

/-- Скінченне покриття дає експоненційну оцінку числа (m,ε)-роздільних точок. -/
theorem sep_card_pow (hY : TotallyBounded (Set.univ : Set Y)) (T : Y → Y) (ε : ℝ) (hε : 0 < ε) :
    ∃ k : ℕ, 1 ≤ k ∧ ∀ (m : ℕ) (S : Finset Y),
      IsSep (fun a b => dist a b) T m ε S → S.card ≤ k ^ m := by
  obtain ⟨t, htfin, hcov⟩ := Metric.totallyBounded_iff.1 hY (ε / 3) (by positivity)
  haveI := htfin.fintype
  have hmem : ∀ x : Y, ∃ c : t, dist x c < ε / 3 := by
    intro x
    have := hcov (Set.mem_univ x)
    simp only [Set.mem_iUnion] at this
    obtain ⟨c, hc, hxc⟩ := this
    exact ⟨⟨c, hc⟩, Metric.mem_ball.1 hxc⟩
  choose c hc using hmem
  have hne : Nonempty t := ⟨c (Classical.arbitrary Y)⟩
  refine ⟨Fintype.card t, Fintype.card_pos, ?_⟩
  intro m S hS
  let g : Y → (Fin m → t) := fun x i => c (iter T i.1 x)
  have hinj : Set.InjOn g (S : Set Y) := by
    intro x hx y hy hxy
    by_contra hne'
    obtain ⟨i, hi, hlt⟩ := hS x hx y hy hne'
    have hcomp : c (iter T i x) = c (iter T i y) := by
      have := congrFun hxy ⟨i, hi⟩
      simpa [g] using this
    have h1 := hc (iter T i x)
    have h2 := hc (iter T i y)
    rw [hcomp] at h1
    have h3 := dist_triangle (iter T i x) (c (iter T i y) : Y) (iter T i y)
    have h4 : dist (iter T i x) (iter T i y) < ε := by
      have : dist (c (iter T i y) : Y) (iter T i y) = dist (iter T i y) (c (iter T i y) : Y) :=
        dist_comm _ _
      linarith
    exact absurd hlt (not_lt.2 h4.le)
  have := Finset.card_le_card_of_injOn g (fun _ _ => Finset.mem_univ _) hinj
  simpa [Fintype.card_fun, Fintype.card_fin] using this


end Count

section Compare
variable {Y : Type*} [MetricSpace Y] [Nonempty Y]

/-- Метрика з образом: dX(a,b) = max(d(a,b), d(Ta,Tb)). -/
def dmaxT (T : Y → Y) : Y → Y → ℝ := fun a b => max (dist a b) (dist (T a) (T b))

omit [Nonempty Y] in
theorem sep_maxT_to_dist (T : Y → Y) (n : ℕ) (ε : ℝ) (S : Finset Y)
    (h : IsSep (dmaxT T) T n ε S) : IsSep (fun a b => dist a b) T (n + 1) ε S := by
  intro x hx y hy hxy
  obtain ⟨i, hi, hlt⟩ := h x hx y hy hxy
  rcases lt_max_iff.1 hlt with h1 | h2
  · exact ⟨i, by omega, h1⟩
  · exact ⟨i + 1, by omega, h2⟩

omit [Nonempty Y] in
theorem sep_dist_to_maxT (T : Y → Y) (n : ℕ) (ε : ℝ) (S : Finset Y)
    (h : IsSep (fun a b => dist a b) T n ε S) : IsSep (dmaxT T) T n ε S := by
  intro x hx y hy hxy
  obtain ⟨i, hi, hlt⟩ := h x hx y hy hxy
  exact ⟨i, hi, lt_max_of_lt_left hlt⟩

/-- Порівняння sepNum: s_dist(n) ≤ s_dmax(n) ≤ s_dist(n+1). -/
theorem sepNum_dist_le_maxT (hY : TotallyBounded (Set.univ : Set Y)) (T : Y → Y) (n : ℕ)
    (ε : ℝ) (hε : 0 < ε) :
    sepNum (fun a b => dist a b) T n ε ≤ sepNum (dmaxT T) T n ε := by
  obtain ⟨k, _, hk⟩ := sep_card_pow hY T ε hε
  apply sepNum_le (sepNum (dmaxT T) T n ε)
  intro S hS
  exact le_sepNum (B := k ^ (n + 1))
    (fun S' hS' => hk (n + 1) S' (sep_maxT_to_dist T n ε S' hS')) S
    (sep_dist_to_maxT T n ε S hS)

theorem sepNum_maxT_le_dist (hY : TotallyBounded (Set.univ : Set Y)) (T : Y → Y) (n : ℕ)
    (ε : ℝ) (hε : 0 < ε) :
    sepNum (dmaxT T) T n ε ≤ sepNum (fun a b => dist a b) T (n + 1) ε := by
  obtain ⟨k, _, hk⟩ := sep_card_pow hY T ε hε
  apply sepNum_le (sepNum (fun a b => dist a b) T (n + 1) ε)
  intro S hS
  exact le_sepNum (B := k ^ (n + 1)) (fun S' hS' => hk (n + 1) S' hS') S
    (sep_maxT_to_dist T n ε S hS)

theorem one_le_sepNum_dist (hY : TotallyBounded (Set.univ : Set Y)) (T : Y → Y) (n : ℕ)
    (ε : ℝ) (hε : 0 < ε) : 1 ≤ sepNum (fun a b => dist a b) T n ε := by
  obtain ⟨k, _, hk⟩ := sep_card_pow hY T ε hε
  obtain ⟨x⟩ := ‹Nonempty Y›
  have hs : IsSep (fun a b => dist a b) T n ε {x} := by
    intro a ha b hb hab
    simp only [Finset.mem_singleton] at ha hb
    exact absurd (ha.trans hb.symm) hab
  have := le_sepNum (B := k ^ n) (fun S' hS' => hk n S' hS') {x} hs
  simpa using this

theorem one_le_sepNum_maxT (hY : TotallyBounded (Set.univ : Set Y)) (T : Y → Y) (n : ℕ)
    (ε : ℝ) (hε : 0 < ε) : 1 ≤ sepNum (dmaxT T) T n ε := by
  obtain ⟨k, _, hk⟩ := sep_card_pow hY T ε hε
  obtain ⟨x⟩ := ‹Nonempty Y›
  have hs : IsSep (dmaxT T) T n ε {x} := by
    intro a ha b hb hab
    simp only [Finset.mem_singleton] at ha hb
    exact absurd (ha.trans hb.symm) hab
  have := le_sepNum (B := k ^ (n + 1))
    (fun S' hS' => hk (n + 1) S' (sep_maxT_to_dist T n ε S' hS')) {x} hs
  simpa using this

end Compare


section Htop
variable {Y : Type*} [MetricSpace Y] [Nonempty Y]

/-- Оцінка: при n ≥ 1, log s_dmax(n)/n ≤ log s_dist(n+1)/(n+1) + log k / n. -/
theorem log_step (a b L : ℝ) (n : ℕ) (hn : 1 ≤ n) (_ha : 0 ≤ a) (hab : a ≤ b)
    (_hb0 : 0 ≤ b) (hb : b ≤ ((n : ℝ) + 1) * L) :
    a / n ≤ b / ((n : ℝ) + 1) + L / n := by
  have hn' : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hpos : (0 : ℝ) < n := by linarith
  have hpos1 : (0 : ℝ) < (n : ℝ) + 1 := by linarith
  have e1 : b / n = b / ((n : ℝ) + 1) + b / (n * ((n : ℝ) + 1)) := by
    field_simp
  have e2 : b / (n * ((n : ℝ) + 1)) ≤ L / n := by
    rw [div_le_div_iff₀ (by positivity) hpos]
    nlinarith
  calc a / n ≤ b / n := div_le_div_of_nonneg_right hab hpos.le
    _ = b / ((n : ℝ) + 1) + b / (n * ((n : ℝ) + 1)) := e1
    _ ≤ b / ((n : ℝ) + 1) + L / n := by linarith

theorem htop_dist_le_maxT (hY : TotallyBounded (Set.univ : Set Y)) (T : Y → Y) :
    htop (fun a b => dist a b) T ≤ htop (dmaxT T) T := by
  unfold htop
  apply iSup_mono
  rintro ⟨ε, hε⟩
  refine limsup_le_limsup (Filter.Eventually.of_forall (fun n => ?_)) (by isBoundedDefault) (by isBoundedDefault)
  apply EReal.coe_le_coe_iff.2
  apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg n)
  apply Real.log_le_log
  · exact Nat.cast_pos.2 (lt_of_lt_of_le one_pos (one_le_sepNum_dist hY T n ε hε))
  · exact_mod_cast sepNum_dist_le_maxT hY T n ε hε

theorem htop_maxT_le_dist (hY : TotallyBounded (Set.univ : Set Y)) (T : Y → Y) :
    htop (dmaxT T) T ≤ htop (fun a b => dist a b) T := by
  unfold htop
  apply iSup_mono
  rintro ⟨ε, hε⟩
  obtain ⟨k, hk1, hk⟩ := sep_card_pow hY T ε hε
  set V : ℕ → ℝ := fun m => Real.log (sepNum (fun a b => dist a b) T m ε) / m with hV
  set L : ℝ := Real.log k with hL
  have hL0 : 0 ≤ L := Real.log_nonneg (by exact_mod_cast hk1)
  -- оцінка при n ≥ 1
  have hbound : ∀ᶠ n : ℕ in atTop,
      (((Real.log (sepNum (dmaxT T) T n ε) / n : ℝ)) : EReal) ≤
        (((V (n + 1) + L / n : ℝ)) : EReal) := by
    filter_upwards [eventually_ge_atTop 1] with n hn
    apply EReal.coe_le_coe_iff.2
    have hs1 := one_le_sepNum_maxT hY T n ε hε
    have hs2 := one_le_sepNum_dist hY T (n + 1) ε hε
    have hab : Real.log (sepNum (dmaxT T) T n ε) ≤
        Real.log (sepNum (fun a b => dist a b) T (n + 1) ε) := by
      apply Real.log_le_log (Nat.cast_pos.2 (lt_of_lt_of_le one_pos hs1))
      exact_mod_cast sepNum_maxT_le_dist hY T n ε hε
    have hb : Real.log (sepNum (fun a b => dist a b) T (n + 1) ε) ≤ ((n : ℝ) + 1) * L := by
      have h1 : Real.log (sepNum (fun a b => dist a b) T (n + 1) ε) ≤
          Real.log ((k : ℝ) ^ (n + 1)) := by
        apply Real.log_le_log (Nat.cast_pos.2 (lt_of_lt_of_le one_pos hs2))
        have h2 : sepNum (fun a b => dist a b) T (n + 1) ε ≤ k ^ (n + 1) :=
          sepNum_le (k ^ (n + 1)) (fun S hS => hk (n + 1) S hS)
        exact_mod_cast h2
      rw [Real.log_pow] at h1
      push_cast at h1
      linarith
    have := log_step (Real.log (sepNum (dmaxT T) T n ε))
      (Real.log (sepNum (fun a b => dist a b) T (n + 1) ε)) L n hn
      (Real.log_nonneg (by exact_mod_cast hs1))
      hab (Real.log_nonneg (by exact_mod_cast hs2)) hb
    simp only [hV]
    push_cast
    linarith
  have hlim1 := limsup_le_limsup hbound (by isBoundedDefault) (by isBoundedDefault)
  have hsplit : limsup (fun n : ℕ => (((V (n + 1) + L / n : ℝ)) : EReal)) atTop =
      limsup ((fun n : ℕ => ((V (n + 1) : ℝ) : EReal)) + (fun n : ℕ => ((L / n : ℝ) : EReal)))
        atTop := by
    congr 1
  have hw : limsup (fun n : ℕ => ((L / n : ℝ) : EReal)) atTop ≤ 0 := by
    have ht : Tendsto (fun n : ℕ => ((L / n : ℝ) : EReal)) atTop
        (nhds (((0 : ℝ)) : EReal)) :=
      (continuous_coe_real_ereal.tendsto 0).comp (tendsto_const_div_atTop_nhds_zero_nat L)
    rw [ht.limsup_eq]
    simp
  have hu_eq : limsup (fun n : ℕ => ((V (n + 1) : ℝ) : EReal)) atTop =
      limsup (fun m : ℕ => ((V m : ℝ) : EReal)) atTop := by
    have h := limsup_comp (fun m : ℕ => ((V m : ℝ) : EReal)) (fun n : ℕ => n + 1) atTop
    rw [show (fun n : ℕ => ((V (n + 1) : ℝ) : EReal)) =
        ((fun m : ℕ => ((V m : ℝ) : EReal)) ∘ (fun n : ℕ => n + 1)) from rfl, h,
      Filter.map_add_atTop_eq_nat 1]
  have hadd : limsup ((fun n : ℕ => ((V (n + 1) : ℝ) : EReal)) +
      (fun n : ℕ => ((L / n : ℝ) : EReal))) atTop ≤
      limsup (fun n : ℕ => ((V (n + 1) : ℝ) : EReal)) atTop := by
    apply le_of_forall_gt_imp_ge_of_dense
    intro a ha
    have := EReal.limsup_add_le_of_le ha hw
    simpa using this
  exact (hsplit ▸ hlim1).trans (hadd.trans hu_eq.le)

theorem htop_eq_of_maxT (hY : TotallyBounded (Set.univ : Set Y)) (T : Y → Y) :
    htop (dmaxT T) T = htop (fun a b => dist a b) T :=
  le_antisymm (htop_maxT_le_dist hY T) (htop_dist_le_maxT hY T)

end Htop


section Iso
variable {X Y : Type*}

theorem sepNum_iso (dX : X → X → ℝ) (dY : Y → Y → ℝ) (D : X → X) (T : Y → Y) (e : X ≃ Y)
    (hiso : ∀ a b, dX a b = dY (e a) (e b)) (hc : ∀ x, e (D x) = T (e x)) (n : ℕ) (ε : ℝ) :
    sepNum dX D n ε = sepNum dY T n ε := by
  have key : ∀ S : Finset X, IsSep dX D n ε S →
      IsSep dY T n ε (S.map e.toEmbedding) := by
    intro S hS y hy z hz hyz
    rw [Finset.mem_map] at hy hz
    obtain ⟨a, ha, rfl⟩ := hy
    obtain ⟨b, hb, rfl⟩ := hz
    have hab : a ≠ b := by
      rintro rfl
      exact hyz rfl
    obtain ⟨i, hi, hlt⟩ := hS a ha b hb hab
    refine ⟨i, hi, ?_⟩
    show ε < dY (iter T i (e a)) (iter T i (e b))
    rw [← iter_conj e D T hc i a, ← iter_conj e D T hc i b, ← hiso]
    exact hlt
  have key2 : ∀ S : Finset X, IsSep dY T n ε (S.map e.toEmbedding) →
      IsSep dX D n ε S := by
    intro S hS a ha b hb hab
    have ma : e a ∈ S.map e.toEmbedding := Finset.mem_map_of_mem _ ha
    have mb : e b ∈ S.map e.toEmbedding := Finset.mem_map_of_mem _ hb
    obtain ⟨i, hi, hlt⟩ := hS (e a) ma (e b) mb (fun h => hab (e.injective h))
    refine ⟨i, hi, ?_⟩
    rw [hiso, iter_conj e D T hc i a, iter_conj e D T hc i b]
    exact hlt
  unfold sepNum
  congr 1
  ext k
  constructor
  · rintro ⟨S, hS, rfl⟩
    exact ⟨S.map e.toEmbedding, key S hS, by simp⟩
  · rintro ⟨S', hS', rfl⟩
    refine ⟨S'.map e.symm.toEmbedding, key2 _ ?_, by simp⟩
    have : (S'.map e.symm.toEmbedding).map e.toEmbedding = S' := by
      simp [Finset.map_map]
    rw [this]
    exact hS'

end Iso


section Graph
variable {A : Type*} [Finite A]

theorem dist_kap (u v : TreeM A) : dist (kap u) (kap v) = dist u v := by
  rw [Subtype.dist_eq]
  apply le_antisymm
  · rw [ContinuousMap.dist_le dist_nonneg]
    intro x
    simp [kap_apply]
  · have := ContinuousMap.dist_apply_le_dist (f := (kap u : ContinuousMap (TreeM A) (TreeM A)))
      (g := (kap v : ContinuousMap (TreeM A) (TreeM A))) u
    simpa [kap_apply] using this

theorem dist_pair (T' : TreeM A → TreeM A) (c c' : TreeM A) :
    dist ((c, kap (T' c)) : TreeM A × RZ A) (c', kap (T' c')) =
      max (dist c c') (dist (T' c) (T' c')) := by
  rw [Prod.dist_eq, dist_kap]

/-- G7 п. 3 (11.8): h_top(D∞|G) = h_top(T) для графа G з метрикою добутку. -/
theorem htop_graph (Y : Set (TreeM A)) (hY : IsClosed Y) (T : Y → Y)
    (T' : TreeM A → TreeM A) (hT'Y : ∀ c : Y, T' c = (T c : TreeM A))
    (x0 : TreeM A) (_hP : IsClosed (Pset Y T'))
    (hDP : Dinf T' x0 '' Pset Y T' = Pset Y T') [Nonempty Y] :
    htop (fun p q : Pset Y T' => dist p q) (Dpset Y T' x0 hDP) =
      htop (fun a b : Y => dist a b) T := by
  have htb : TotallyBounded (Set.univ : Set Y) := by
    have : CompactSpace Y := isCompact_iff_compactSpace.1 hY.isCompact
    exact isCompact_univ.totallyBounded
  have hmemY : ∀ p : Pset Y T', ∃ c ∈ Y, (c, kap (T' c)) = p.1 := fun p => p.2
  let e : Pset Y T' ≃ Y :=
    { toFun := fun p => ⟨p.1.1, by
        obtain ⟨c, hc, h⟩ := hmemY p
        rw [← h]
        exact hc⟩
      invFun := fun c => ⟨(c, kap (T' c)), ⟨c, c.2, rfl⟩⟩
      left_inv := by
        intro p
        obtain ⟨c, hc, h⟩ := hmemY p
        apply Subtype.ext
        show ((p.1.1, kap (T' p.1.1)) : TreeM A × RZ A) = p.1
        rw [← h]
      right_inv := by
        intro c
        rfl }
  have hpair : ∀ p : Pset Y T', p.1 = (p.1.1, kap (T' p.1.1)) := by
    intro p
    obtain ⟨c, hc, h⟩ := hmemY p
    rw [← h]
  have hdist : ∀ p q : Pset Y T',
      (fun p q : Pset Y T' => dist p q) p q = dmaxT T (e p) (e q) := by
    intro p q
    show dist p.1 q.1 = max (dist (e p : Y) (e q : Y)) (dist (T (e p)) (T (e q)))
    have h2 : dist (T (e p)) (T (e q)) = dist (T' p.1.1) (T' q.1.1) := by
      show dist ((T (e p)) : TreeM A) (T (e q) : TreeM A) = dist (T' p.1.1) (T' q.1.1)
      rw [← hT'Y (e p), ← hT'Y (e q)]
      rfl
    rw [h2, Subtype.dist_eq (e p) (e q)]
    show dist p.1 q.1 = max (dist p.1.1 q.1.1) (dist (T' p.1.1) (T' q.1.1))
    rw [hpair p, hpair q, dist_pair]
  have hconj : ∀ p : Pset Y T', e (Dpset Y T' x0 hDP p) = T (e p) := by
    intro p
    apply Subtype.ext
    show (Dinf T' x0 p.1).1 = (T (e p) : TreeM A)
    rw [hpair p, Dinf_graph]
    exact hT'Y (e p)
  have step1 : htop (fun p q : Pset Y T' => dist p q) (Dpset Y T' x0 hDP) =
      htop (dmaxT T) T := by
    unfold htop
    simp only [sepNum_iso _ (dmaxT T) (Dpset Y T' x0 hDP) T e hdist hconj]
  exact step1.trans (htop_eq_of_maxT htb T)

end Graph

end Subit
