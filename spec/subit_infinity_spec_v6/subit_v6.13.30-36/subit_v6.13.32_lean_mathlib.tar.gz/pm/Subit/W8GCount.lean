import Subit.W8GWord
import Subit.W8Count

/-!
# W8 з довільними блоками n_k: підрахунок вікон (G-варіант)

Ключове спостереження: вікна на межі блоку α^{n_m} дають не більше 2N різних значень
незалежно від n_m (вікна цілком усередині блоку — одне слово α^N). Тому
p_d(N) ≤ 2 + 2N² для будь-якої послідовності n_k з n_k ≥ k+1.
-/

namespace Subit.W8G
open Finset

theorem wdG_succ (n : ℕ → ℕ) (k : ℕ) :
    wdG n (k + 1) = wdG n k ++ List.replicate (n k) true ++ wdG n k := rfl

theorem getD_left (n : ℕ → ℕ) (k i : ℕ) (h : i < (wdG n k).length) :
    (wdG n (k + 1)).getD i false = (wdG n k).getD i false := by
  rw [wdG_succ, List.getD_append _ _ _ _ (by simp only [List.length_append, List.length_replicate]; omega),
    List.getD_append _ _ _ _ h]

theorem getD_mid (n : ℕ → ℕ) (k i : ℕ) (h1 : (wdG n k).length ≤ i)
    (h2 : i < (wdG n k).length + n k) :
    (wdG n (k + 1)).getD i false = true := by
  rw [wdG_succ, List.getD_append _ _ _ _ (by simp only [List.length_append, List.length_replicate]; omega),
    List.getD_append_right _ _ _ _ h1, List.getD_eq_getElem?_getD, List.getElem?_replicate]
  split_ifs with hlt
  · rfl
  · omega

theorem getD_right (n : ℕ → ℕ) (k i : ℕ) (h : (wdG n k).length + n k ≤ i) :
    (wdG n (k + 1)).getD i false = (wdG n k).getD (i - ((wdG n k).length + n k)) false := by
  rw [wdG_succ, List.getD_append_right _ _ _ _ (by simp only [List.length_append, List.length_replicate]; omega)]
  congr 1
  simp only [List.length_append, List.length_replicate]

/-- Вікна на межі зліва від блоку α^{n_m}: початки в [L_m+1−N, L_m−1]. -/
def NCGL (n : ℕ → ℕ) (N m : ℕ) : Finset (List Bool) :=
  (Icc ((wdG n m).length + 1 - N) ((wdG n m).length - 1)).image
    (fun p => Subit.W8.win (wdG n (m + 1)) p N)

/-- Вікна на межі справа від блоку α^{n_m}: початки в [L_m+n_m−N+1, L_m+n_m−1]. -/
def NCGR (n : ℕ → ℕ) (N m : ℕ) : Finset (List Bool) :=
  (Icc ((wdG n m).length + n m - N + 1) ((wdG n m).length + n m - 1)).image
    (fun p => Subit.W8.win (wdG n (m + 1)) p N)

/-- Усі вікна, що перетинають межі блоку α^{n_m} (усередині блоку — лише α^N). -/
def NCG (n : ℕ → ℕ) (N m : ℕ) : Finset (List Bool) :=
  NCGL n N m ∪ {List.replicate N true} ∪ NCGR n N m

/-- Кандидати: усі-false, усі-true і NCG_m для m < N. -/
def TotG (n : ℕ → ℕ) (N : ℕ) : Finset (List Bool) :=
  {List.replicate N false, List.replicate N true} ∪ (range N).biUnion (NCG n N)

theorem decompG (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (N m p : ℕ) :
    (∃ q, Subit.W8.win (wdG n (m + 1)) p N = Subit.W8.win (wdG n m) q N) ∨
      Subit.W8.win (wdG n (m + 1)) p N ∈ NCG n N m := by
  have hpos := length_ge n hn m
  by_cases h1 : p + N ≤ (wdG n m).length
  · left
    exact ⟨p, Subit.W8.win_congr fun j hj => getD_left n m (p + j) (by omega)⟩
  by_cases h2 : (wdG n m).length + n m ≤ p
  · left
    refine ⟨p - ((wdG n m).length + n m), Subit.W8.win_congr fun j hj => ?_⟩
    rw [getD_right n m (p + j) (by omega)]
    congr 1
    omega
  right
  unfold NCG
  by_cases h3 : p < (wdG n m).length
  · refine Finset.mem_union_left _ (Finset.mem_union_left _ ?_)
    rw [NCGL, Finset.mem_image]
    exact ⟨p, Finset.mem_Icc.2 ⟨by omega, by omega⟩, rfl⟩
  · by_cases h4 : p + N ≤ (wdG n m).length + n m
    · refine Finset.mem_union_left _ (Finset.mem_union_right _ ?_)
      rw [Finset.mem_singleton]
      have hall : ∀ j : Fin N, (wdG n (m + 1)).getD (p + j) false = true :=
        fun j => getD_mid n m (p + j) (by omega) (by omega)
      unfold Subit.W8.win
      rw [show (fun j : Fin N => (wdG n (m + 1)).getD (p + j) false) = fun _ => true from
        funext fun j => hall j]
      exact List.ofFn_const N true
    · refine Finset.mem_union_right _ ?_
      rw [NCGR, Finset.mem_image]
      exact ⟨p, Finset.mem_Icc.2 ⟨by omega, by omega⟩, rfl⟩

/-- Стабілізація: для m = k+1 ≥ N вікна на межі блоку n_{k+1} є вікнами w_{k+1}. -/
theorem stabG (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (N k p : ℕ) (hN : N ≤ k + 1)
    (hp : (wdG n (k + 1)).length + 1 - N ≤ p)
    (hp2 : p ≤ (wdG n (k + 1)).length + n (k + 1) - 1) :
    ∃ q, Subit.W8.win (wdG n (k + 1 + 1)) p N = Subit.W8.win (wdG n (k + 1)) q N := by
  have hk := length_ge n hn k
  have hL1 := wdG_len n k
  have ha := hn k
  have hb := hn (k + 1)
  by_cases hA : p < (wdG n (k + 1)).length
  · refine ⟨(wdG n k).length - ((wdG n (k + 1)).length - p), Subit.W8.win_congr fun j hj => ?_⟩
    by_cases hjt : j < (wdG n (k + 1)).length - p
    · rw [getD_left n (k + 1) (p + j) (by omega), getD_right n k (p + j) (by omega),
        getD_left n k ((wdG n k).length - ((wdG n (k + 1)).length - p) + j) (by omega)]
      congr 1
      omega
    · rw [getD_mid n (k + 1) (p + j) (by omega) (by omega),
        getD_mid n k ((wdG n k).length - ((wdG n (k + 1)).length - p) + j) (by omega) (by omega)]
  · push Not at hA
    by_cases hsub : p + N ≤ (wdG n (k + 1)).length + n (k + 1)
    · refine ⟨(wdG n k).length, Subit.W8.win_congr fun j hj => ?_⟩
      rw [getD_mid n (k + 1) (p + j) (by omega) (by omega),
        getD_mid n k ((wdG n k).length + j) (by omega) (by omega)]
    · refine ⟨(wdG n k).length + n k - ((wdG n (k + 1)).length + n (k + 1) - p),
        Subit.W8.win_congr fun j hj => ?_⟩
      by_cases hja : j < (wdG n (k + 1)).length + n (k + 1) - p
      · rw [getD_mid n (k + 1) (p + j) (by omega) (by omega),
          getD_mid n k ((wdG n k).length + n k - ((wdG n (k + 1)).length + n (k + 1) - p) + j)
            (by omega) (by omega)]
      · rw [getD_right n (k + 1) (p + j) (by omega),
          getD_left n k (p + j - ((wdG n (k + 1)).length + n (k + 1))) (by omega),
          getD_right n k ((wdG n k).length + n k - ((wdG n (k + 1)).length + n (k + 1) - p) + j)
            (by omega)]
        congr 1
        omega

theorem card_NCGL_le (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (N m : ℕ) :
    (NCGL n N m).card ≤ N - 1 := by
  have hpos := length_ge n hn m
  unfold NCGL
  refine Finset.card_image_le.trans ?_
  rw [Nat.card_Icc]
  omega

theorem card_NCGR_le (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (N m : ℕ) :
    (NCGR n N m).card ≤ N - 1 := by
  have hpos := length_ge n hn m
  have hb := hn m
  unfold NCGR
  refine Finset.card_image_le.trans ?_
  rw [Nat.card_Icc]
  omega

theorem card_NCG_le (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (N m : ℕ) (hN : 1 ≤ N) :
    (NCG n N m).card ≤ 2 * N := by
  have hL := card_NCGL_le n hn N m
  have hR := card_NCGR_le n hn N m
  have hs : ({List.replicate N true} : Finset (List Bool)).card = 1 := Finset.card_singleton _
  unfold NCG
  have u1 := Finset.card_union_le (NCGL n N m ∪ {List.replicate N true}) (NCGR n N m)
  have u2 := Finset.card_union_le (NCGL n N m) {List.replicate N true}
  omega

theorem win_mem_TotG (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (N : ℕ) (hN : 1 ≤ N) (m p : ℕ) :
    Subit.W8.win (wdG n m) p N ∈ TotG n N := by
  induction m generalizing p with
  | zero =>
    have h0 : ∀ i, (wdG n 0).getD i false = false := by
      intro i
      cases i <;> simp [wdG]
    unfold TotG
    rw [Subit.W8.win_rep (wdG n 0) h0 p N]
    exact Finset.mem_union_left _ (Finset.mem_insert_self _ _)
  | succ m ih =>
    rcases decompG n hn N m p with ⟨q, hq⟩ | hmem
    · rw [hq]
      exact ih q
    · by_cases hm : m < N
      · unfold TotG
        exact Finset.mem_union_right _ (Finset.mem_biUnion.2 ⟨m, Finset.mem_range.2 hm, hmem⟩)
      · obtain ⟨k, rfl⟩ : ∃ k, m = k + 1 := ⟨m - 1, by omega⟩
        unfold NCG at hmem
        rcases Finset.mem_union.1 hmem with hmem' | hmem'
        · rcases Finset.mem_union.1 hmem' with hL | hS
          · rw [NCGL, Finset.mem_image] at hL
            obtain ⟨p', hp', hpeq⟩ := hL
            rw [Finset.mem_Icc] at hp'
            obtain ⟨q, hq⟩ := stabG n hn N k p' (by omega) hp'.1 (by omega)
            rw [← hpeq, hq]
            exact ih q
          · rw [Finset.mem_singleton] at hS
            rw [hS]
            unfold TotG
            exact Finset.mem_union_left _ (Finset.mem_insert_of_mem (Finset.mem_singleton_self _))
        · rw [NCGR, Finset.mem_image] at hmem'
          obtain ⟨p', hp', hpeq⟩ := hmem'
          rw [Finset.mem_Icc] at hp'
          obtain ⟨q, hq⟩ := stabG n hn N k p' (by omega) (by omega) (by omega)
          rw [← hpeq, hq]
          exact ih q

theorem card_TotG_le (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (N : ℕ) (hN : 1 ≤ N) :
    (TotG n N).card ≤ 2 + 2 * N ^ 2 := by
  unfold TotG
  refine (Finset.card_union_le _ _).trans ?_
  have h1 : ({List.replicate N false, List.replicate N true} : Finset (List Bool)).card ≤ 2 :=
    Finset.card_le_two
  have h2 : ((range N).biUnion (NCG n N)).card ≤ ∑ m ∈ range N, 2 * N :=
    Finset.card_biUnion_le.trans (Finset.sum_le_sum fun m _ => card_NCG_le n hn N m hN)
  rw [Finset.sum_const, Finset.card_range, nsmul_eq_mul] at h2
  nlinarith

/-- G9 (з довільними блоками): вікна довжини N слова d лежать у скінченній множині
розміру ≤ 2 + 2N². -/
theorem factor_bound_G (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (N : ℕ) (hN : 1 ≤ N) :
    ∃ T : Finset (List Bool), (∀ p : ℕ, List.ofFn (fun j : Fin N => dG n (p + j)) ∈ T) ∧
      T.card ≤ 2 + 2 * N ^ 2 := by
  refine ⟨TotG n N, fun p => ?_, card_TotG_le n hn N hN⟩
  have heq : List.ofFn (fun j : Fin N => dG n (p + j)) = Subit.W8.win (wdG n (p + N)) p N := by
    unfold Subit.W8.win
    congr 1
    funext j
    exact dG_eq n hn (p + N) (p + j) (by have := j.isLt; have := length_ge n hn (p + N); omega)
  rw [heq]
  exact win_mem_TotG n hn N hN _ p

end Subit.W8G
