import Subit.OmegaEntropy
import Subit.GraphEntropy
import Subit.LemmaEY
/-!
# h_top ω-границі графа G (11.8, ентропія на ω(x0))

Для компактного Y, неперервного T : Y → Y і x ∈ G := Gph Y T:
  h_top(D∞|ω(x)) ≤ h_top(T)   (метрика — метрика добутку S∞ × ℛ₀ на G).
Без сюр'єктивності T. Скінченність sepNum на G береться з цілковитої обмеженості Y.
-/
noncomputable section
namespace Subit.OmegaGraph
open Filter Set Subit Subit.LemmaEY

variable {A : Type*} [Finite A]

theorem DpY_eq (Y : Set (TreeM A)) (hY : IsCompact Y) (T : Y → Y) (hT : Continuous T)
    (x0 : TreeM A) :
    DpY Y T x0 = fun p => (graphHomeoY Y hY T hT).symm (T (graphHomeoY Y hY T hT p)) := by
  funext p
  rw [← conj_graph Y hY T hT x0 p]
  simp

theorem DpY_continuous (Y : Set (TreeM A)) (hY : IsCompact Y) (T : Y → Y) (hT : Continuous T)
    (x0 : TreeM A) : Continuous (DpY Y T x0) := by
  rw [DpY_eq Y hY T hT x0]
  exact (graphHomeoY Y hY T hT).symm.continuous.comp
    (hT.comp (graphHomeoY Y hY T hT).continuous)

theorem dist_Gph_eq (Y : Set (TreeM A)) (hY : IsCompact Y) (T : Y → Y) (hT : Continuous T)
    (a b : Gph Y T) :
    dist a.1 b.1 = dmaxT T (graphHomeoY Y hY T hT a) (graphHomeoY Y hY T hT b) := by
  obtain ⟨c, rfl⟩ := (gphPt_bij Y T).2 a
  obtain ⟨d, rfl⟩ := (gphPt_bij Y T).2 b
  rw [graphHomeoY_gphPt, graphHomeoY_gphPt]
  show dist (gpt Y T c) (gpt Y T d) = dmaxT T c d
  rw [Prod.dist_eq]
  show max (dist (c : TreeM A) (d : TreeM A))
      (dist (kap ((T c : Y) : TreeM A)) (kap ((T d : Y) : TreeM A))) =
    max (dist (c : TreeM A) (d : TreeM A)) (dist ((T c : Y) : TreeM A) ((T d : Y) : TreeM A))
  rw [dist_kap]

theorem htopOmega_le_htop (Y : Set (TreeM A)) (hY : IsCompact Y) (T : Y → Y) (hT : Continuous T)
    (x0 : TreeM A) (x : Gph Y T) :
    htopOn (fun a b : Gph Y T => dist a.1 b.1) (DpY Y T x0) (omega (DpY Y T x0) x)
      (fun y hy => omega_forward _ (DpY_continuous Y hY T hT x0) x ⟨y, hy, rfl⟩) ≤
      htop (fun a b : Y => dist a b) T := by
  haveI : CompactSpace Y := isCompact_iff_compactSpace.1 hY
  haveI : Nonempty Y := by
    obtain ⟨c, _⟩ := x.2
    exact ⟨c⟩
  have htb : TotallyBounded (Set.univ : Set Y) := isCompact_univ.totallyBounded
  set e := graphHomeoY Y hY T hT with he
  have hiso : ∀ a b : Gph Y T, dist a.1 b.1 = dmaxT T (e a) (e b) := dist_Gph_eq Y hY T hT
  have hc : ∀ p, e (DpY Y T x0 p) = T (e p) := conj_graph Y hY T hT x0
  have hEq : ∀ n ε, sepNum (fun a b : Gph Y T => dist a.1 b.1) (DpY Y T x0) n ε =
      sepNum (dmaxT T) T n ε := fun n ε => sepNum_iso _ (dmaxT T) _ T e.toEquiv hiso hc n ε
  have hmap : ∀ (n : ℕ) (ε : ℝ) (S : Finset (Gph Y T)),
      IsSep (fun a b : Gph Y T => dist a.1 b.1) (DpY Y T x0) n ε S →
      IsSep (dmaxT T) T n ε (S.map e.toEquiv.toEmbedding) := by
    intro n ε S hS y hy z hz hyz
    rw [Finset.mem_map] at hy hz
    obtain ⟨a, ha, rfl⟩ := hy
    obtain ⟨b, hb, rfl⟩ := hz
    have hab : a ≠ b := by
      rintro rfl
      exact hyz rfl
    obtain ⟨i, hi, hlt⟩ := hS a ha b hb hab
    refine ⟨i, hi, ?_⟩
    have h2 : ε < dist (Subit.iter (DpY Y T x0) i a).1 (Subit.iter (DpY Y T x0) i b).1 := hlt
    rw [hiso, iter_conj (⇑e) (DpY Y T x0) T hc i a, iter_conj (⇑e) (DpY Y T x0) T hc i b] at h2
    exact h2
  have hfin : ∀ (n : ℕ) (ε : ℝ), 0 < ε →
      BddAbove {k | ∃ S : Finset (Gph Y T), IsSep (fun a b : Gph Y T => dist a.1 b.1) (DpY Y T x0) n ε S
        ∧ S.card = k} := by
    intro n ε hε
    obtain ⟨k, _, hk⟩ := sep_card_pow htb T ε hε
    refine ⟨k ^ (n + 1), ?_⟩
    rintro _ ⟨S, hS, rfl⟩
    have h2 : IsSep (fun a b : Y => dist a b) T (n + 1) ε (S.map e.toEquiv.toEmbedding) :=
      sep_maxT_to_dist T n ε _ (hmap n ε S hS)
    have := hk (n + 1) _ h2
    rwa [Finset.card_map] at this
  calc htopOn (fun a b : Gph Y T => dist a.1 b.1) (DpY Y T x0) (omega (DpY Y T x0) x)
        (fun y hy => omega_forward _ (DpY_continuous Y hY T hT x0) x ⟨y, hy, rfl⟩)
      ≤ htop (fun a b : Gph Y T => dist a.1 b.1) (DpY Y T x0) :=
        Subit.OmegaEntropy.htopOn_le_htop _ _ _ _ hfin
    _ = htop (dmaxT T) T := by
        unfold htop
        simp only [hEq]
    _ = htop (fun a b : Y => dist a b) T := htop_eq_of_maxT htb T

end Subit.OmegaGraph
end
