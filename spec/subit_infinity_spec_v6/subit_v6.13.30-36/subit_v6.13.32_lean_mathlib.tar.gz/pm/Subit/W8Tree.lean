import Subit.W8Spine
import Subit.W8Attained
import Subit.OmegaGraph
import Subit.GraphEntropy
import Subit.W8Entropy
/-!
# W8 на Tree∞ (спец. NONMIN_ZERO × ATTAINED, §11.6, без вкладення в лему E як припущення)

Побудова: C := {α,β}^ℕ зі зсувом σ, слово d з W8 (n_k = k+1), t — «хребет» (W8Spine),
Y := t[C] ⊂ TreeM, T := t∘σ∘t⁻¹ (`TY`), c := t(d), x₀ := (c, κ_{T c}) ∈ G := Gph Y T.

Доведено (без sorry):
* `attained_TY`  — c ∈ ω_T(c);
* `nonmin_TY`    — ω_T(c) не мінімальна для T;
* `infinite_TY`  — ω_T(c) нескінченна;
* `htop_TY_zero` — h_top(T|ω_T(c)) = 0 (метрика d_S на Y);
* `w8_graph_zero` — для x₀ = (c, κ_{T c}) ∈ G: h_top(D∞|ω(x₀)) = 0 (метрика добутку на G).
-/
noncomputable section
namespace Subit.W8Tree
open Filter Set Topology Subit Subit.LemmaEY Subit.W8Spine Subit.OmegaGraph

section Scale
variable {X : Type*}

lemma sepNum_scale (c : ℝ) (hc : 0 < c) (d : X → X → ℝ) (T : X → X) (n : ℕ) (ε : ℝ) :
    sepNum (fun a b => c * d a b) T n ε = sepNum d T n (ε / c) := by
  have key : ∀ S : Finset X, IsSep (fun a b => c * d a b) T n ε S ↔ IsSep d T n (ε / c) S := by
    intro S
    unfold IsSep
    constructor
    · intro h x hx y hy hxy
      obtain ⟨i, hi, hlt⟩ := h x hx y hy hxy
      refine ⟨i, hi, ?_⟩
      rw [div_lt_iff₀ hc]
      linarith [mul_comm c (d (iter T i x) (iter T i y))]
    · intro h x hx y hy hxy
      obtain ⟨i, hi, hlt⟩ := h x hx y hy hxy
      refine ⟨i, hi, ?_⟩
      have := (div_lt_iff₀ hc).1 hlt
      linarith [mul_comm c (d (iter T i x) (iter T i y))]
  unfold sepNum
  congr 1
  ext k
  constructor
  · rintro ⟨S, hS, rfl⟩
    exact ⟨S, (key S).1 hS, rfl⟩
  · rintro ⟨S, hS, rfl⟩
    exact ⟨S, (key S).2 hS, rfl⟩

/-- Множення метрики на c > 0 не змінює h_top. -/
theorem htop_scale (c : ℝ) (hc : 0 < c) (d : X → X → ℝ) (T : X → X) :
    htop (fun a b => c * d a b) T = htop d T := by
  have key : ∀ ε : ℝ, limsup (fun n : ℕ => ((Real.log (sepNum (fun a b => c * d a b) T n ε) / n : ℝ)
      : EReal)) atTop = limsup (fun n : ℕ => ((Real.log (sepNum d T n (ε / c)) / n : ℝ) : EReal))
      atTop := by
    intro ε
    congr 1
    funext n
    rw [sepNum_scale c hc d T n ε]
  unfold htop
  apply le_antisymm
  · refine iSup_le fun ⟨ε, hε⟩ => ?_
    rw [key ε]
    exact le_iSup (fun δ : {δ : ℝ // 0 < δ} => limsup (fun n : ℕ =>
      ((Real.log (sepNum d T n δ.1) / n : ℝ) : EReal)) atTop) ⟨ε / c, div_pos hε hc⟩
  · refine iSup_le fun ⟨δ, hδ⟩ => ?_
    have h := key (c * δ)
    rw [mul_div_cancel_left₀ δ hc.ne'] at h
    rw [← h]
    exact le_iSup (fun ε : {ε : ℝ // 0 < ε} => limsup (fun n : ℕ =>
      ((Real.log (sepNum (fun a b => c * d a b) T n ε.1) / n : ℝ) : EReal)) atTop)
      ⟨c * δ, mul_pos hc hδ⟩

end Scale

section Y

variable {A : Type*} [Finite A]

omit [Finite A] in
/-- Y-рівень: ω_T(c) = t[ω(d)]. -/
theorem omega_TY (α β η : A) (hαβ : α ≠ β) (d : ℕ → Bool) :
    omega (TY α β η hαβ) (tHomeo α β η hαβ d) = (tHomeo α β η hαβ) '' omega shift d :=
  (omega_conj (tHomeo α β η hαβ) shift (TY α β η hαβ) (conj_TY α β η hαβ) d).symm

omit [Finite A] in
theorem attained_TY (α β η : A) (hαβ : α ≠ β) (d : ℕ → Bool) (hd : d ∈ omega shift d) :
    tHomeo α β η hαβ d ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ d) := by
  rw [omega_TY]
  exact Set.mem_image_of_mem _ hd

omit [Finite A] in
theorem infinite_TY (α β η : A) (hαβ : α ≠ β) (hinf : (omega shift (W8.dW)).Infinite) :
    (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)).Infinite := by
  rw [omega_TY]
  exact hinf.image (fun a _ b _ h => (tHomeo α β η hαβ).injective h)

omit [Finite A] in
theorem nonmin_TY (α β η : A) (hαβ : α ≠ β) (hnm : ¬ MinOn shift (omega shift W8.dW)) :
    ¬ MinOn (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) := by
  intro hM
  apply hnm
  have h : ∀ y, (tHomeo α β η hαβ).symm (TY α β η hαβ y) =
      shift ((tHomeo α β η hαβ).symm y) := by
    intro y
    unfold TY
    simp
  have := minOn_conj (tHomeo α β η hαβ).symm (TY α β η hαβ) shift h _ hM
  rw [omega_TY, Set.image_image] at this
  simpa using this

omit [Finite A] in
theorem htop_TY_zero (α β η : A) (hαβ : α ≠ β) :
    htopOn (fun a b : Set.range (tM α β η) => dist a.1 b.1) (TY α β η hαβ)
      (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) (fun y hy =>
        omega_forward _ (TY_continuous α β η hαβ) _ ⟨y, hy, rfl⟩) = 0 := by
  set ωs := omega shift W8.dW with hωs
  set W := omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW) with hW
  have hWmaps : Set.MapsTo (TY α β η hαβ) W W := fun y hy =>
    omega_forward _ (TY_continuous α β η hαβ) _ ⟨y, hy, rfl⟩
  have hωmaps : Set.MapsTo (shift : (ℕ → Bool) → (ℕ → Bool)) ωs ωs :=
    fun y hy => omega_forward _ W8Entropy.continuous_shift _ ⟨y, hy, rfl⟩
  have hiff : ∀ a : ℕ → Bool, a ∈ ωs ↔ tHomeo α β η hαβ a ∈ W := by
    intro a
    rw [hW, omega_TY]
    exact (tHomeo α β η hαβ).injective.mem_set_image.symm
  let e : {a // a ∈ ωs} ≃ {b // b ∈ W} :=
    Equiv.subtypeEquiv (tHomeo α β η hαβ).toEquiv hiff
  have hiso : ∀ a b : {a // a ∈ ωs},
      (1 / 2 : ℝ) * Subit.dC a.1 b.1 = dist (e a).1.1 (e b).1.1 := by
    intro a b
    show (1 / 2 : ℝ) * Subit.dC a.1 b.1 = dist (tM α β η a.1) (tM α β η b.1)
    rw [dist_tM α β η hαβ]
    ring
  have hc : ∀ a : {a // a ∈ ωs}, e (⟨shift a.1, hωmaps a.2⟩ : {a // a ∈ ωs}) =
      (⟨TY α β η hαβ (e a).1, hWmaps (e a).2⟩ : {b // b ∈ W}) := by
    intro a
    apply Subtype.ext
    show tHomeo α β η hαβ (shift a.1) = TY α β η hαβ (tHomeo α β η hαβ a.1)
    exact conj_TY α β η hαβ a.1
  have hsep : ∀ (n : ℕ) (ε : ℝ),
      sepNum (fun a b : {a // a ∈ ωs} => (1 / 2 : ℝ) * Subit.dC a.1 b.1)
        (restrict shift ωs hωmaps) n ε =
      sepNum (fun a b : {b // b ∈ W} => dist a.1 b.1) (restrict (TY α β η hαβ) W hWmaps) n ε := by
    intro n ε
    exact sepNum_iso _ _ _ _ e hiso hc n ε
  have hEq : htop (fun a b : {a // a ∈ ωs} => (1 / 2 : ℝ) * Subit.dC a.1 b.1)
      (restrict shift ωs hωmaps) =
      htop (fun a b : {b // b ∈ W} => dist a.1 b.1) (restrict (TY α β η hαβ) W hWmaps) := by
    unfold htop
    simp only [hsep]
  show htop (fun a b : {b // b ∈ W} => dist a.1 b.1) (restrict (TY α β η hαβ) W hWmaps) = 0
  rw [← hEq]
  refine (htop_scale (1 / 2) (by norm_num) (fun a b : {a // a ∈ ωs} => Subit.dC a.1 b.1)
    (restrict shift ωs hωmaps)).trans ?_
  exact W8Entropy.htop_omega_zero

end Y

section Graph

variable {A : Type*} [Finite A]

/-- Образ ω-множини графа при graphHomeoY дорівнює ω-множині Y у точці t(d). -/
theorem image_omegaG (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ)
        (TY_continuous α β η hαβ) '' omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) =
      omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW) := by
  have hconj := omega_conj
    (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))
    (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (TY α β η hαβ)
    (conj_graph (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ)
      (TY_continuous α β η hαβ) x0)
    (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))
  rw [graphHomeoY_gphPt] at hconj
  exact hconj

/-- Належність точки графа до ω-множини графа ⇔ образ під graphHomeoY належить ω-множині Y. -/
theorem mem_omegaG_iff (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) (a : Gph (Set.range (tM α β η)) (TY α β η hαβ)) :
    a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) ↔
      graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) a ∈
        omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW) := by
  rw [← image_omegaG α β η hαβ x0]
  constructor
  · intro h
    exact ⟨a, h, rfl⟩
  · rintro ⟨b, hb, hb'⟩
    rw [(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).injective hb'] at hb
    exact hb

/-- ATTAINED на графі: точка gphPt(t(d)) лежить у своїй ω-множині. -/
theorem attained_graph (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW) ∈
      omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) := by
  rw [mem_omegaG_iff, graphHomeoY_gphPt]
  exact attained_TY α β η hαβ W8.dW Subit.W8Attained.attained

/-- Нескінченність ω-множини графа. -/
theorem infinite_graph (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))).Infinite := by
  apply Set.Infinite.of_image (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ)
    (TY α β η hαβ) (TY_continuous α β η hαβ))
  rw [image_omegaG α β η hαβ x0]
  exact infinite_TY α β η hαβ Subit.W8Attained.omega_infinite

/-- W8 на графі: для довільної x0 ∈ Tree∞ і точки графа gphPt(t(d)) = (c, κ_{T c}), c = t(d),
    h_top(D∞|ω(gphPt(c))) = 0 (метрика добутку на G). Параметр x0 — точка обчислення ρ(x0), не точка графа. -/
theorem w8_graph_zero (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    htopOn (fun a b : Gph (Set.range (tM α β η)) (TY α β η hαβ) => dist a.1 b.1)
      (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)))
      (fun y hy => omega_forward _ (Subit.OmegaGraph.DpY_continuous (Set.range (tM α β η))
        (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) x0) _ ⟨y, hy, rfl⟩) = 0 := by
  have hY := Y_isCompact α β η hαβ
  haveI : CompactSpace (Set.range (tM α β η)) := isCompact_iff_compactSpace.1 hY
  have hT := TY_continuous α β η hαβ
  have hiffG : ∀ a : Gph (Set.range (tM α β η)) (TY α β η hαβ),
      a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
          (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) ↔
      graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT a ∈
        omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW) := by
    intro a
    have hconj := omega_conj (graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT)
      (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (TY α β η hαβ)
      (conj_graph (Set.range (tM α β η)) hY (TY α β η hαβ) hT x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))
    rw [graphHomeoY_gphPt] at hconj
    rw [← hconj]
    constructor
    · intro h
      exact ⟨a, h, rfl⟩
    · rintro ⟨b, hb, hb'⟩
      rw [(graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT).injective hb'] at hb
      exact hb
  let eG : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))} ≃
      {b // b ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)} :=
    Equiv.subtypeEquiv (graphHomeoY (Set.range (tM α β η)) hY (TY α β η hαβ) hT).toEquiv hiffG
  have hWc : IsCompact (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) := omega_isCompact _ _
  obtain ⟨w0, hw0⟩ := omega_nonempty (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)
  haveI : Nonempty {b // b ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)} := ⟨⟨w0, hw0⟩⟩
  haveI : CompactSpace {b // b ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)} :=
    isCompact_iff_compactSpace.1 hWc
  have hωmaps : Set.MapsTo (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)))
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))) := fun y hy =>
    omega_forward _ (Subit.OmegaGraph.DpY_continuous (Set.range (tM α β η)) hY
      (TY α β η hαβ) hT x0) _ ⟨y, hy, rfl⟩
  have hWmaps : Set.MapsTo (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))
      (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) := fun y hy =>
    omega_forward _ hT _ ⟨y, hy, rfl⟩
  have hiso : ∀ a b : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))},
      dist a.1.1 b.1.1 = dmaxT (restrict (TY α β η hαβ)
        (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) hWmaps) (eG a) (eG b) := by
    intro a b
    exact Subit.OmegaGraph.dist_Gph_eq (Set.range (tM α β η)) hY (TY α β η hαβ) hT a.1 b.1
  have hc : ∀ a : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))},
      eG (restrict (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) _ hωmaps a) =
        restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) hWmaps (eG a) := by
    intro a
    apply Subtype.ext
    exact Subit.LemmaEY.conj_graph (Set.range (tM α β η)) hY (TY α β η hαβ) hT x0 a.1
  have hsep : ∀ (n : ℕ) (ε : ℝ),
      sepNum (fun a b : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
          (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))} => dist a.1.1 b.1.1)
        (restrict (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) _ hωmaps) n ε =
      sepNum (dmaxT (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) hWmaps))
        (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) hWmaps) n ε := by
    intro n ε
    exact sepNum_iso _ _ _ _ eG hiso hc n ε
  have hmax := htop_eq_of_maxT isCompact_univ.totallyBounded
    (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) hWmaps)
  have hEq : htop (fun a b : {a // a ∈ omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))} => dist a.1.1 b.1.1)
      (restrict (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) _ hωmaps) =
      htop (dmaxT (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) hWmaps))
        (restrict (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) hWmaps) := by
    unfold htop
    simp only [hsep]
  exact (hEq.trans hmax).trans (htop_TY_zero α β η hαβ)

/-- Якщо T-мінімальність ω-множини графа G виконана, то вона виконана і на Y (через graphHomeoY). -/
theorem minOn_TY_of_graph (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A)
    (hM : MinOn (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)))) :
    MinOn (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) := by
  intro V' hV'W hV'ne hV'cl hV'inv
  have hVW : (⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V' ⊆ (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))) := by
    intro a ha
    rw [mem_omegaG_iff]
    exact hV'W ha
  have hVne : ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V').Nonempty := by
    obtain ⟨y, hy⟩ := hV'ne
    exact ⟨(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).symm y, by simpa using hy⟩
  have hVcl : IsClosed ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') := hV'cl.preimage (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).continuous
  have hVmaps : Set.MapsTo (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') := by
    intro a ha
    have hc := conj_graph (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) x0 a
    show (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)) ((DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) a) ∈ V'
    rw [hc]
    exact hV'inv ha
  have hVeq := hM ((⇑(graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ))) ⁻¹' V') hVW hVne hVcl hVmaps
  apply Set.Subset.antisymm hV'W
  intro y hy
  have ha : (graphHomeoY (Set.range (tM α β η)) (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ)).symm y ∈ (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))) := by
    rw [mem_omegaG_iff]
    simpa using hy
  rw [← hVeq] at ha
  simpa using ha

/-- Non-minimality на графі: ω-множина G не мінімальна для DpY. -/
theorem nonmin_graph (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    ¬ MinOn (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))) :=
  fun hM => nonmin_TY α β η hαβ Subit.W8Attained.nonmin (minOn_TY_of_graph α β η hαβ x0 hM)

end Graph


/-- Підсумок W8 на Tree∞ (рівень Y і графа): точка ATTAINED, ω(dW) нескінченна,
    мінімальності на Y немає, h_top(D∞ | ω(x0)) = 0. -/
theorem w8_tree_summary (α β η : A) (hαβ : α ≠ β) (x0 : TreeM A) :
    tHomeo α β η hαβ W8.dW ∈ omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW) ∧
    (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)).Infinite ∧
    gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW) ∈
      omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) ∧
    (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))).Infinite ∧
    ¬ MinOn (TY α β η hαβ) (omega (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)) ∧
    ¬ MinOn (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0) (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW))) ∧
    htopOn (fun a b : Gph (Set.range (tM α β η)) (TY α β η hαβ) => dist a.1 b.1)
      (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
      (omega (DpY (Set.range (tM α β η)) (TY α β η hαβ) x0)
        (gphPt (Set.range (tM α β η)) (TY α β η hαβ) (tHomeo α β η hαβ W8.dW)))
      (fun y hy => omega_forward _ (Subit.OmegaGraph.DpY_continuous (Set.range (tM α β η))
        (Y_isCompact α β η hαβ) (TY α β η hαβ) (TY_continuous α β η hαβ) x0) _ ⟨y, hy, rfl⟩) = 0 :=
  ⟨attained_TY α β η hαβ W8.dW Subit.W8Attained.attained,
   infinite_TY α β η hαβ Subit.W8Attained.omega_infinite,
   attained_graph α β η hαβ x0,
   infinite_graph α β η hαβ x0,
   nonmin_TY α β η hαβ Subit.W8Attained.nonmin,
   nonmin_graph α β η hαβ x0,
   w8_graph_zero α β η hαβ x0⟩

end Subit.W8Tree
end
