import Subit.Q28bR
import Subit.LemmaE
import Subit.D4

/-!
# Лема 11.8 (E) на S∞ × ℛ₀ (G7)

Конкретизація абстрактного ядра `LemmaE.lean` на D∞ з `Q28b.lean`: граф
P := {(c, κ_{T′(c)}) : c ∈ Y}, D∞|P, спряження з T через гомеоморфізм pr₁ : P → Y.

Формалізовано: компактність P і R_Y, D∞[P] = P, гомеоморфізм pr₁ : P ≃ₜ Y,
спряження pr₁ ∘ D∞ = T ∘ pr₁, збереження ω-границь і досяжності (через абстрактне ядро).
НЕ формалізовано: рівність h_top(D∞|P) = h_top(T) (пункт 3 11.8 для ентропії).
-/

namespace Subit
open Set Topology

variable {A : Type*} [Finite A]

lemma kap_apply (c x : TreeM A) : (kap c).1 x = c := rfl

/-- Гомеоморфізм pr₁ : P ≃ₜ Y для графа P = {(c, κ_{T′ c}) : c ∈ Y}. -/
noncomputable def graphHomeo (Y : Set (TreeM A)) (hY : IsClosed Y) (T' : TreeM A → TreeM A)
    (hT' : Continuous T') (_hP : IsClosed (Pset Y T')) : (Pset Y T') ≃ₜ Y := by
  classical
  let f : Y → Pset Y T' := fun c => ⟨(c, kap (T' c)), ⟨c, c.2, rfl⟩⟩
  have hf : Continuous f := by
    refine Continuous.subtype_mk ?_ _
    exact (continuous_subtype_val).prodMk
      (kap_lipschitz.continuous.comp (hT'.comp continuous_subtype_val))
  have hbij : Function.Bijective f := by
    constructor
    · intro a b hab
      exact Subtype.ext (congrArg (fun p : Pset Y T' => p.1.1) hab)
    · rintro ⟨⟨c, κ⟩, ⟨d, hd, hdeq⟩⟩
      simp only [Prod.mk.injEq] at hdeq
      obtain ⟨rfl, rfl⟩ := hdeq
      exact ⟨⟨d, hd⟩, rfl⟩
  haveI : CompactSpace Y := isCompact_iff_compactSpace.1 hY.isCompact
  haveI : CompactSpace (Pset Y T') := isCompact_iff_compactSpace.1 _hP.isCompact
  exact (Continuous.homeoOfEquivCompactToT2 (f := Equiv.ofBijective f hbij) hf).symm

/-- Пункт 1 (11.8): R_Y = {κ_c : c ∈ Y} компактна. -/
theorem lemmaE_RY_compact (Y : Set (TreeM A)) (hY : IsClosed Y) :
    IsCompact (kap '' Y) :=
  hY.isCompact.image kap_lipschitz.continuous

/-- D∞ на P як самовідображення P → P (за D∞[P] = P). -/
noncomputable def Dpset (Y : Set (TreeM A)) (T' : TreeM A → TreeM A) (x0 : TreeM A)
    (hDP : Dinf T' x0 '' Pset Y T' = Pset Y T') : Pset Y T' → Pset Y T' :=
  fun p => ⟨Dinf T' x0 p.1, by
    have h : Dinf T' x0 p.1 ∈ Dinf T' x0 '' Pset Y T' := ⟨p.1, p.2, rfl⟩
    rwa [hDP] at h⟩

/-- Ключова обчислювальна формула: D∞(c, κ_{T′ c}) = (T′ c, κ_{T′(T′ c)}). -/
lemma Dinf_graph (T' : TreeM A → TreeM A) (x0 c : TreeM A) :
    Dinf T' x0 (c, kap (T' c)) = (T' c, kap (T' (T' c))) := by
  simp only [Dinf, gInf, ev, kap_apply]

/-- Спряження pr₁ ∘ D∞ = T ∘ pr₁ на графі P. -/
theorem graph_conj (Y : Set (TreeM A)) (hY : IsClosed Y) (T : Y → Y)
    (T' : TreeM A → TreeM A) (hT' : Continuous T') (hT'Y : ∀ c : Y, T' c = (T c : TreeM A))
    (x0 : TreeM A) (hP : IsClosed (Pset Y T')) (hDP : Dinf T' x0 '' Pset Y T' = Pset Y T') :
    ∀ p : Pset Y T', graphHomeo Y hY T' hT' hP (Dpset Y T' x0 hDP p) = T (graphHomeo Y hY T' hT' hP p) := by
  intro p
  have hpf : ∀ c : Y, ((graphHomeo Y hY T' hT' hP).symm c : TreeM A × RZ A) = ((c : TreeM A), kap (T' c)) :=
    fun c => rfl
  have hp : p = (graphHomeo Y hY T' hT' hP).symm (graphHomeo Y hY T' hT' hP p) :=
    ((graphHomeo Y hY T' hT' hP).symm_apply_apply p).symm
  generalize graphHomeo Y hY T' hT' hP p = c at hp ⊢
  subst hp
  have key : Dpset Y T' x0 hDP ((graphHomeo Y hY T' hT' hP).symm c) =
      (graphHomeo Y hY T' hT' hP).symm (T c) := by
    apply Subtype.ext
    simp only [Dpset]
    rw [hpf c, Dinf_graph, hpf (T c), hT'Y c, hT'Y (T c)]
  rw [key, Homeomorph.apply_symm_apply]

/-- Пункт 2 (11.8), без ентропії: граф P компактний, D∞|P спряжений з T; ω-границі й
досяжність переносяться через pr₁ (абстрактне ядро `LemmaE.lean`). -/
theorem lemmaE_concrete (Y : Set (TreeM A)) (hY : IsClosed Y) (T : Y → Y)
    (T' : TreeM A → TreeM A) (hT' : Continuous T') (hT'Y : ∀ c : Y, T' c = (T c : TreeM A))
    (x0 : TreeM A) (hP : IsClosed (Pset Y T')) (hDP : Dinf T' x0 '' Pset Y T' = Pset Y T')
    (x : Pset Y T') :
    IsCompact (Pset Y T') ∧
    graphHomeo Y hY T' hT' hP '' omega (Dpset Y T' x0 hDP) x =
      omega T (graphHomeo Y hY T' hT' hP x) ∧
    ∀ n : ℕ, iter (Dpset Y T' x0 hDP) n x ∈ omega (Dpset Y T' x0 hDP) x ↔
      iter T n (graphHomeo Y hY T' hT' hP x) ∈ omega T (graphHomeo Y hY T' hT' hP x) := by
  have h := graph_conj Y hY T T' hT' hT'Y x0 hP hDP
  refine ⟨hP.isCompact, omega_conj _ _ _ h x, fun n => attained_conj _ _ _ h x n⟩

end Subit
