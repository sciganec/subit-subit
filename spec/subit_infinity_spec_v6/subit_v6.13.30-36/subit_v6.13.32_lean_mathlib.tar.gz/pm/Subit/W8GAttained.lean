import Subit.W8GEntropy
import Subit.W8Attained

/-!
# W8 з довільними блоками n_k: ATTAINED, нескінченність, NONMIN (G-варіант)

Припущення: `hn : ∀ k, k+1 ≤ n k` (для ATTAINED, NONMIN, h_top), `hmono : StrictMono n` (лише для нескінченності).
Для строго зростаючої n_k → ∞ обидва виконуються.

* `attained_G` — d ∈ ω(d).
* `nonmin_G` — ω(d) не мінімальна для σ (α^∞ ∈ ω(d), d ≠ α^∞).
* `omega_infinite_G` — ω(d) нескінченна; використовує `hmono : StrictMono n` (достатньо, не доведено необхідність).
* `w8G_summary` — ATTAINED, ітерації, нескінченність, NONMIN, h_top = 0.
-/

namespace Subit.W8GAttained
open Filter Topology Subit Subit.W8G

theorem dG_zero (n : ℕ → ℕ) : dG n 0 = false := by
  simp [dG, wdG]

/-- Блок α довжини n_k стоїть у w_{k+1} одразу після w_k. -/
theorem dG_block (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (k t : ℕ) (ht : t < n k) :
    dG n ((wdG n k).length + t) = true := by
  have hlt : (wdG n k).length + t < (wdG n (k + 1)).length := by
    rw [wdG_len]
    omega
  rw [dG_eq n hn (k + 1) _ hlt, getD_mid n k _ (by omega) (by omega)]

/-- Повернення: w_k знову з'являється в d після блоку α^{n_k}. -/
theorem dG_return (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (k t : ℕ) (ht : t < (wdG n k).length) :
    dG n ((wdG n k).length + n k + t) = dG n t := by
  have hlt : (wdG n k).length + n k + t < (wdG n (k + 1)).length := by
    rw [wdG_len]
    omega
  rw [dG_eq n hn (k + 1) _ hlt, getD_right n k _ (by omega), dG_eq n hn k t ht]
  congr 1
  omega

open Set in
/-- Координатна збіжність σ^{L_k + n_k}(d) → d. -/
theorem dG_coord_tendsto (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) :
    Tendsto (fun k => iter shift ((wdG n k).length + n k) (dG n)) atTop (𝓝 (dG n)) := by
  rw [tendsto_pi_nhds]
  intro i
  refine tendsto_const_nhds.congr' ?_
  filter_upwards [eventually_ge_atTop i] with k hk
  have hL := length_ge n hn k
  show dG n i = iter shift ((wdG n k).length + n k) (dG n) i
  rw [iter_shift]
  show dG n i = dG n (i + ((wdG n k).length + n k))
  rw [show i + ((wdG n k).length + n k) = (wdG n k).length + n k + i by omega]
  exact (dG_return n hn k i (by omega)).symm

/-- ATTAINED: d ∈ ω(d). -/
theorem attained_G (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) : dG n ∈ Subit.omega shift (dG n) :=
  Subit.W8Attained.mem_omega_of_seq (dG n) (dG n) (fun k => (wdG n k).length + n k)
    (tendsto_atTop_mono (fun k => by
      have := length_ge n hn k
      have := hn k
      simp only [id]
      omega) tendsto_id)
    (dG_coord_tendsto n hn)

/-- σⁿ(d) ∈ ω(d) для всіх n. -/
theorem iter_mem_omega_G (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (m : ℕ) :
    iter shift m (dG n) ∈ Subit.omega shift (dG n) := by
  induction m with
  | zero => exact attained_G n hn
  | succ m ih =>
    exact Subit.omega_forward shift Subit.W8Entropy.continuous_shift _
      (Set.mem_image_of_mem shift ih)

open Set in
/-- Координатна збіжність σ^{L_k}(d) → α^∞ (довгі блоки α). -/
theorem cTrue_coord_tendsto_G (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) :
    Tendsto (fun k => iter shift ((wdG n k).length) (dG n)) atTop
      (𝓝 Subit.W8Attained.cTrue) := by
  rw [tendsto_pi_nhds]
  intro i
  refine tendsto_const_nhds.congr' ?_
  filter_upwards [eventually_ge_atTop i] with k hk
  have hL := length_ge n hn k
  have hnk := hn k
  show Subit.W8Attained.cTrue i = iter shift ((wdG n k).length) (dG n) i
  rw [iter_shift]
  show Subit.W8Attained.cTrue i = dG n (i + (wdG n k).length)
  rw [show i + (wdG n k).length = (wdG n k).length + i by omega]
  exact (dG_block n hn k i (by omega)).symm

/-- α^∞ ∈ ω(d). -/
theorem cTrue_mem_omega_G (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) :
    Subit.W8Attained.cTrue ∈ Subit.omega shift (dG n) :=
  Subit.W8Attained.mem_omega_of_seq (dG n) Subit.W8Attained.cTrue (fun k => (wdG n k).length)
    (tendsto_atTop_mono (fun k => by
      have := length_ge n hn k
      simp only [id]
      omega) tendsto_id)
    (cTrue_coord_tendsto_G n hn)

/-- NONMIN: ω(d) не є мінімальною множиною зсуву. -/
theorem nonmin_G (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) :
    ¬ Subit.MinOn shift (Subit.omega shift (dG n)) := by
  intro hM
  have hsing : ({Subit.W8Attained.cTrue} : Set (ℕ → Bool)) = Subit.omega shift (dG n) :=
    hM {Subit.W8Attained.cTrue} (Set.singleton_subset_iff.2 (cTrue_mem_omega_G n hn))
      (Set.singleton_nonempty _) isClosed_singleton (by
        intro y hy
        rw [Set.mem_singleton_iff] at hy ⊢
        rw [hy]
        funext m
        rfl)
  have hd : dG n ∈ ({Subit.W8Attained.cTrue} : Set (ℕ → Bool)) := by
    rw [hsing]
    exact attained_G n hn
  rw [Set.mem_singleton_iff] at hd
  have h0 : dG n 0 = true := congrFun hd 0
  exact absurd ((dG_zero n).symm.trans h0) (by decide)

/-- ω(d) нескінченна (для строго зростаючої n). -/
theorem omega_infinite_G (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (hmono : StrictMono n) :
    (Subit.omega shift (dG n)).Infinite := by
  have hmem : ∀ k : ℕ, iter shift ((wdG n k).length) (dG n) ∈ Subit.omega shift (dG n) :=
    fun k => iter_mem_omega_G n hn _
  have hval_true : ∀ k i : ℕ, i < n k → iter shift ((wdG n k).length) (dG n) i = true := by
    intro k i hi
    rw [iter_shift]
    show dG n (i + (wdG n k).length) = true
    rw [Nat.add_comm]
    exact dG_block n hn k i hi
  have hval_false : ∀ k : ℕ, iter shift ((wdG n k).length) (dG n) (n k) = false := by
    intro k
    rw [iter_shift]
    have hL := length_ge n hn k
    show dG n (n k + (wdG n k).length) = false
    rw [show n k + (wdG n k).length = (wdG n k).length + n k + 0 by omega,
      dG_return n hn k 0 (by omega), dG_zero]
  have hinj : Function.Injective fun k : ℕ => iter shift ((wdG n k).length) (dG n) := by
    intro k j hkj
    have hkj' : iter shift ((wdG n k).length) (dG n) = iter shift ((wdG n j).length) (dG n) := hkj
    by_contra hne
    rcases lt_or_gt_of_ne hne with h | h
    · have h1 := hval_true j (n k) (hmono h)
      have h2 := hval_false k
      rw [hkj', h1] at h2
      exact absurd h2 (by decide)
    · have h1 := hval_true k (n j) (hmono h)
      have h2 := hval_false j
      rw [← hkj', h1] at h2
      exact absurd h2 (by decide)
  exact Set.infinite_of_injective_forall_mem hinj hmem

/-- Підсумок W8 з довільними блоками (строго зростаючі n_k): ATTAINED, нескінченність,
NONMIN, h_top = 0 на ω-границі слова d. -/
theorem w8G_summary (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (hmono : StrictMono n) :
    dG n ∈ Subit.omega shift (dG n) ∧ (∀ m, iter shift m (dG n) ∈ Subit.omega shift (dG n)) ∧
    (Subit.omega shift (dG n)).Infinite ∧ ¬ Subit.MinOn shift (Subit.omega shift (dG n)) ∧
    Subit.htopOn Subit.dC shift (Subit.omega shift (dG n)) (Subit.W8GEntropy.omega_maps_shift_gen (dG n)) = 0 :=
  ⟨attained_G n hn, iter_mem_omega_G n hn, omega_infinite_G n hn hmono, nonmin_G n hn,
    Subit.W8GEntropy.htop_omega_zero_G n hn⟩

end Subit.W8GAttained
