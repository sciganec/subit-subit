import Subit.WordW8

/-!
# W8 з довільною послідовністю блоків n_k (G-варіант)

w₀ := β (`false`), w_{k+1} := w_k α^{n_k} w_k (α = `true`).
Припущення `hn : ∀ k, k + 1 ≤ n k` — слабше за строге зростання n_k → ∞
(строго зростаюча послідовність натуральних чисел з n_0 ≥ 1 його задовольняє).
Для n_k = k+1 це узгоджується з `Subit.W8.wd`.
-/

namespace Subit.W8G

/-- Скінченні наближення w_k з блоками n. -/
def wdG (n : ℕ → ℕ) : ℕ → List Bool
  | 0 => [false]
  | k + 1 => wdG n k ++ List.replicate (n k) true ++ wdG n k

theorem length_ge (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (k : ℕ) :
    k + 1 ≤ (wdG n k).length := by
  induction k with
  | zero => simp [wdG]
  | succ k ih =>
    simp only [wdG, List.length_append, List.length_replicate]
    have := hn k
    omega

theorem wdG_len (n : ℕ → ℕ) (k : ℕ) :
    (wdG n (k + 1)).length = 2 * (wdG n k).length + n k := by
  simp only [wdG, List.length_append, List.length_replicate]
  omega

theorem wdG_prefix (n : ℕ → ℕ) (k : ℕ) : wdG n k <+: wdG n (k + 1) := by
  simp only [wdG]
  exact (List.prefix_append _ _).trans (List.prefix_append _ _)

theorem wdG_prefix_le (n : ℕ → ℕ) {k m : ℕ} (h : k ≤ m) : wdG n k <+: wdG n m := by
  obtain ⟨j, rfl⟩ := Nat.exists_eq_add_of_le h
  clear h
  induction j with
  | zero => exact List.prefix_refl _
  | succ j ih => exact ih.trans (wdG_prefix n (k + j))

/-- Значення слова d у позиції i (з будь-якого наближення, що містить i). -/
def dG (n : ℕ → ℕ) (i : ℕ) : Bool := (wdG n (i + 1)).getD i false

theorem dG_eq (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) (k i : ℕ) (hi : i < (wdG n k).length) :
    dG n i = (wdG n k).getD i false := by
  by_cases h : i + 1 ≤ k
  · have hp := wdG_prefix_le n h
    exact Subit.W8.getD_eq_of_prefix hp (by have := length_ge n hn (i + 1); omega)
  · have hp := wdG_prefix_le n (show k ≤ i + 1 by omega)
    exact (Subit.W8.getD_eq_of_prefix hp hi).symm

/-- Для n_k = k+1 слово збігається зі стандартним `Subit.W8.wd`. -/
theorem wdG_eq_wd (k : ℕ) : wdG (fun j => j + 1) k = Subit.W8.wd k := by
  induction k with
  | zero => rfl
  | succ k ih => simp only [wdG, Subit.W8.wd, ih]

end Subit.W8G
