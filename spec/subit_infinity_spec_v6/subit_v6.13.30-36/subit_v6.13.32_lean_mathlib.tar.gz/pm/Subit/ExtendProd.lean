import Subit.ExtendUltra
import Subit.TreeUltra
import Subit.RZero

/-!
# Лема 11.9 для добутку компактних ультраметричних просторів

Добуток X × Y з sup-метрикою (Mathlib: `Prod.dist_eq`, відстань = max) є ультраметричним,
тож `extend_ultra` застосовна до S∞ × ℛ₀ (для ℛ₀ див. RZero.lean).
-/

universe u

instance instIsUltrametricDistProd {X Y : Type u} [MetricSpace X] [IsUltrametricDist X]
    [MetricSpace Y] [IsUltrametricDist Y] : IsUltrametricDist (X × Y) where
  dist_triangle_max x y z := by
    simp only [Prod.dist_eq]
    refine max_le ?_ ?_
    · exact (IsUltrametricDist.dist_triangle_max x.1 y.1 z.1).trans
        (max_le (le_max_of_le_left (le_max_left _ _)) (le_max_of_le_right (le_max_left _ _)))
    · exact (IsUltrametricDist.dist_triangle_max x.2 y.2 z.2).trans
        (max_le (le_max_of_le_left (le_max_right _ _)) (le_max_of_le_right (le_max_right _ _)))

/-- Лема 11.9 для добутку компактних ультраметричних просторів. -/
theorem extend_prod {X Y : Type u} [MetricSpace X] [IsUltrametricDist X] [CompactSpace X]
    [MetricSpace Y] [IsUltrametricDist Y] [CompactSpace Y]
    (A : Set (X × Y)) (hA : IsClosed A) (f : A → X × Y) (hf : Continuous f) :
    ∃ F : X × Y → X × Y, Continuous F ∧ ∀ a : A, F a = f a :=
  extend_ultra A hA f hf

/-- ℛ₀ як компактний простір (за T6, `isCompact_RZ`). -/
instance instCompactSpaceRZ (A : Type) [Finite A] : CompactSpace (Subit.RZ A) :=
  isCompact_iff_compactSpace.1 (Subit.isCompact_RZ (A := A))

/-- Лема 11.9 для S∞ × ℛ₀ (Tree∞ з d_S і ℛ₀ з sup-метрикою). -/
theorem extend_S_R (A : Type) [Finite A] (C : Set (Subit.TreeM A × Subit.RZ A)) (hC : IsClosed C)
    (f : C → Subit.TreeM A × Subit.RZ A) (hf : Continuous f) :
    ∃ F : Subit.TreeM A × Subit.RZ A → Subit.TreeM A × Subit.RZ A, Continuous F ∧ ∀ a : C, F a = f a :=
  extend_prod C hC f hf
