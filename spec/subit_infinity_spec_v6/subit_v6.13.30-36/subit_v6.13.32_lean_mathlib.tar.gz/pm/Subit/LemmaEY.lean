import Subit.Q28b
import Subit.LemmaE

/-!
# Лема 11.8 (E) для компактного Y без глобального продовження T′

Попередні `Q28b.lean` / `LemmaEConcrete.lean` вимагали глобально неперервного T′ : S∞ → S∞.
Тут T′ замінено на допоміжну функцію `Tfun Y T`, яка збігається з T на Y і довільна поза Y.
Неперервність T′ не використовується: значення T′ обчислюються лише в точках
ρ(x₀) = c ∈ Y (для графа ρ = κ_c, c ∈ Y), де T′ = T.

Дані: Y ⊆ S∞ компактна, T : Y → Y неперервна (сюр'єктивність не потрібна для п. 1–3 нижче).
Граф G := {(c, κ_{T c}) : c ∈ Y} ⊆ S∞ × ℛ₀, D∞|G — динаміка з `Q28b.lean`.
-/

noncomputable section

namespace Subit.LemmaEY
open Set Topology Filter

variable {A : Type*} [Finite A]

/-- (κ_c)(x) = c, як у `LemmaEConcrete.lean`. -/
lemma kap_apply' (c x : TreeM A) : (kap c).1 x = c := rfl

open Classical in
/-- Допоміжне продовження: T′ c = T c для c ∈ Y, інакше T′ c = c. Не неперервне глобально;
неперервність тут не постулюється і не використовується. -/
def Tfun (Y : Set (TreeM A)) (T : Y → Y) : TreeM A → TreeM A :=
  fun c => if h : c ∈ Y then ((T ⟨c, h⟩ : Y) : TreeM A) else c

omit [Finite A] in
lemma Tfun_of (Y : Set (TreeM A)) (T : Y → Y) (c : TreeM A) (h : c ∈ Y) :
    Tfun Y T c = ((T ⟨c, h⟩ : Y) : TreeM A) := by
  unfold Tfun
  rw [dif_pos h]

omit [Finite A] in
lemma Tfun_coe (Y : Set (TreeM A)) (T : Y → Y) (c : Y) :
    Tfun Y T (c : TreeM A) = ((T c : Y) : TreeM A) :=
  Tfun_of Y T c c.2

/-! ### Динаміка D∞ з T′ = Tfun на Y -/

/-- Точка графа над c ∈ Y: (c, κ_{T c}) у координатах S∞ × ℛ₀. -/
def gpt (Y : Set (TreeM A)) (T : Y → Y) (c : Y) : TreeM A × RZ A :=
  ((c : TreeM A), kap ((T c : Y) : TreeM A))

/-- Граф G := {(c, κ_{T c}) : c ∈ Y} ⊆ S∞ × ℛ₀. -/
def Gph (Y : Set (TreeM A)) (T : Y → Y) : Set (TreeM A × RZ A) := Set.range (gpt Y T)

/-- Для c ∈ Y: D∞(c, κ_{T c}) = (T c, κ_{T(T c)}). Не залежить від x₀ і від значень T′ поза Y. -/
lemma Dinf_gpt (Y : Set (TreeM A)) (T : Y → Y) (x0 : TreeM A) (c : Y) :
    Dinf (Tfun Y T) x0 (gpt Y T c) = gpt Y T (T c) := by
  simp only [Dinf, gInf, gpt, ev, kap_apply']
  rw [Tfun_coe]

/-- D∞ як самовідображення графа G (спряжена з T). -/
def DpY (Y : Set (TreeM A)) (T : Y → Y) (x0 : TreeM A) : Gph Y T → Gph Y T :=
  fun p => ⟨Dinf (Tfun Y T) x0 p.1, by
    obtain ⟨c, hc⟩ := p.2
    exact ⟨T c, by rw [← hc]; exact (Dinf_gpt Y T x0 c).symm⟩⟩

/-! ### Граф: неперервність, гомеоморфізм з Y, компактність -/

lemma gpt_cont (Y : Set (TreeM A)) (T : Y → Y) (hT : Continuous T) :
    Continuous (gpt Y T) :=
  continuous_subtype_val.prodMk (kap_lipschitz.continuous.comp (continuous_subtype_val.comp hT))

/-- c ↦ (c, κ_{T c}) як точка графа. -/
def gphPt (Y : Set (TreeM A)) (T : Y → Y) (c : Y) : Gph Y T :=
  ⟨gpt Y T c, ⟨c, rfl⟩⟩

lemma gphPt_cont (Y : Set (TreeM A)) (T : Y → Y) (hT : Continuous T) :
    Continuous (gphPt Y T) :=
  Continuous.subtype_mk (gpt_cont Y T hT) _

lemma gphPt_bij (Y : Set (TreeM A)) (T : Y → Y) : Function.Bijective (gphPt Y T) := by
  constructor
  · intro a b hab
    exact Subtype.ext (congrArg (fun p : Gph Y T => p.1.1) hab)
  · rintro ⟨⟨a, κ⟩, ⟨d, hd⟩⟩
    have hd' : ((d : TreeM A), kap ((T d : Y) : TreeM A)) = (a, κ) := hd
    obtain ⟨rfl, rfl⟩ := Prod.mk.inj hd'
    exact ⟨d, rfl⟩

/-- Гомеоморфізм G ≃ₜ Y, обернений до c ↦ (c, κ_{T c}); на G це pr₁. -/
def graphHomeoY (Y : Set (TreeM A)) (hY : IsCompact Y) (T : Y → Y) (hT : Continuous T) :
    Gph Y T ≃ₜ Y := by
  haveI : CompactSpace Y := isCompact_iff_compactSpace.1 hY
  exact (Continuous.homeoOfEquivCompactToT2
    (f := Equiv.ofBijective (gphPt Y T) (gphPt_bij Y T)) (gphPt_cont Y T hT)).symm

lemma graphHomeoY_gphPt (Y : Set (TreeM A)) (hY : IsCompact Y) (T : Y → Y) (hT : Continuous T)
    (c : Y) : graphHomeoY Y hY T hT (gphPt Y T c) = c := by
  haveI : CompactSpace Y := isCompact_iff_compactSpace.1 hY
  unfold graphHomeoY
  exact (Homeomorph.symm_apply_eq _).2 rfl

/-! ### Пункт 1 (11.8): компактність R_Y і неперервність g∞ на R_Y × S∞ -/

/-- R_Y := {κ_c : c ∈ Y} компактна. -/
theorem RY_compact (Y : Set (TreeM A)) (hY : IsCompact Y) : IsCompact (kap '' Y) :=
  hY.image kap_lipschitz.continuous

/-- g∞(ρ, s) = κ_{T′(ρ(x₀))} неперервна за (ρ, s) на множині {ρ(x₀) ∈ Y} (T′ = T на Y). -/
lemma gInf_contOn (Y : Set (TreeM A)) (T : Y → Y) (hT : Continuous T) (x0 : TreeM A) :
    ContinuousOn (gInf (Tfun Y T) x0) {p : RZ A × TreeM A | ev x0 p.1 ∈ Y} := by
  set S := {p : RZ A × TreeM A | ev x0 p.1 ∈ Y} with hS
  have hev : Continuous (fun p : S => ev x0 p.1.1) :=
    (ev_lipschitz x0).continuous.comp (continuous_fst.comp continuous_subtype_val)
  have hF : Continuous (fun p : S => T ⟨ev x0 p.1.1, p.2⟩) :=
    hT.comp (Continuous.subtype_mk hev (fun p => p.2))
  rw [continuousOn_iff_continuous_restrict]
  have heq : S.restrict (gInf (Tfun Y T) x0) =
      fun p : S => kap ((T ⟨ev x0 p.1.1, p.2⟩ : Y) : TreeM A) := by
    funext p
    show kap (Tfun Y T (ev x0 p.1.1)) = _
    rw [Tfun_of Y T _ p.2]
  rw [heq]
  exact kap_lipschitz.continuous.comp (continuous_subtype_val.comp hF)

/-- Те саме на R_Y × S∞ (сталі правила κ_c, c ∈ Y). -/
lemma gInf_contOn_RY (Y : Set (TreeM A)) (T : Y → Y) (hT : Continuous T) (x0 : TreeM A) :
    ContinuousOn (gInf (Tfun Y T) x0) ((kap '' Y) ×ˢ univ) := by
  refine (gInf_contOn Y T hT x0).mono ?_
  rintro p ⟨⟨c, hc, hκ⟩, _⟩
  show ev x0 p.1 ∈ Y
  rw [← hκ]
  exact hc

/-! ### Пункт 2 (11.8): спряження D∞|G з T, без ентропії -/

/-- D∞|G спряжене з T через pr₁ (версія без глобального T′). -/
lemma conj_graph (Y : Set (TreeM A)) (hY : IsCompact Y) (T : Y → Y) (hT : Continuous T)
    (x0 : TreeM A) :
    ∀ p : Gph Y T, graphHomeoY Y hY T hT (DpY Y T x0 p) = T (graphHomeoY Y hY T hT p) := by
  intro p
  obtain ⟨c, rfl⟩ := (gphPt_bij Y T).2 p
  have hD : DpY Y T x0 (gphPt Y T c) = gphPt Y T (T c) :=
    Subtype.ext (Dinf_gpt Y T x0 c)
  rw [hD, graphHomeoY_gphPt, graphHomeoY_gphPt]

/-- Граф G після D∞ лежить у G, і D∞[G] = G, якщо T сюр'єктивна (п. 2, рівність). -/
theorem Dinf_image_Gph (Y : Set (TreeM A)) (T : Y → Y) (x0 : TreeM A)
    (hsurj : Function.Surjective T) :
    Dinf (Tfun Y T) x0 '' Gph Y T = Gph Y T := by
  ext q
  constructor
  · rintro ⟨r, hr, rfl⟩
    obtain ⟨c, rfl⟩ := hr
    rw [Dinf_gpt]
    exact ⟨T c, rfl⟩
  · rintro ⟨c, rfl⟩
    obtain ⟨d, hd⟩ := hsurj c
    refine ⟨gpt Y T d, ⟨d, rfl⟩, ?_⟩
    rw [Dinf_gpt, hd]

/-! ### Пункт 3 (11.8): ω-границі та досяжність -/

/-- Частина леми 11.8 для графа G = {(c, κ_{T c}) : c ∈ Y}, за лише T : Y → Y неперервним
на компактному Y. Висновок: (1) G компактний; (2) pr₁ спрягає D∞|G з T, ω-границі переносяться;
(3) досяжність (ATTAINED-еквівалентність) переноситься.
НЕ входить сюди: D∞[G] = G (потрібна сюр'єктивність, `Dinf_image_Gph`), компактність R_Y
і неперервність g∞ (`RY_compact`, `gInf_contOn_RY`), ентропія (`htop_graph`), Min(G) = Min(T).
Глобального продовження T′ немає. -/
theorem lemmaE_Y (Y : Set (TreeM A)) (hY : IsCompact Y) (T : Y → Y) (hT : Continuous T)
    (x0 : TreeM A) (x : Gph Y T) :
    IsCompact (Gph Y T) ∧
    graphHomeoY Y hY T hT '' omega (DpY Y T x0) x =
      omega T (graphHomeoY Y hY T hT x) ∧
    ∀ n : ℕ, iter (DpY Y T x0) n x ∈ omega (DpY Y T x0) x ↔
      iter T n (graphHomeoY Y hY T hT x) ∈ omega T (graphHomeoY Y hY T hT x) := by
  haveI : CompactSpace Y := isCompact_iff_compactSpace.1 hY
  have hc := conj_graph Y hY T hT x0
  refine ⟨isCompact_range (gpt_cont Y T hT), omega_conj _ _ _ hc x, fun n => attained_conj _ _ _ hc x n⟩

/-! ### Min(G) = Min(T) (11.8, мінімальність без ентропії) -/

/-- Мінімальність графа G для D∞|G (в обтяженні S∞ × ℛ₀) еквівалентна мінімальності T на Y.
Пряма: з G-інваріантної замкненої V' ⊆ Y будуємо gpt '' V' ⊆ G. Зворотна: з V ⊆ G будуємо
V' = gpt⁻¹ V ⊆ Y. Використовує лише компактність Y, неперервність T і T2-простір.
Сюр'єктивність T тут НЕ потрібна; для зв'язку з Min_D (§4.3), де потрібно D[G] = G, її треба додати (`Dinf_image_Gph`). -/
theorem minOn_Gph_iff (Y : Set (TreeM A)) (hY : IsCompact Y) (T : Y → Y) (hT : Continuous T)
    (x0 : TreeM A) :
    MinOn (Dinf (Tfun Y T) x0) (Gph Y T) ↔ MinOn T (Set.univ : Set Y) := by
  haveI : CompactSpace Y := isCompact_iff_compactSpace.1 hY
  have hgpt_inj : Function.Injective (gpt Y T) := fun a b h => Subtype.ext (congrArg Prod.fst h)
  have hDpt : ∀ c : Y, Dinf (Tfun Y T) x0 (gpt Y T c) = gpt Y T (T c) := Dinf_gpt Y T x0
  constructor
  · intro hM V' _ hV'ne hV'cl hV'inv
    have hcl : IsClosed (gpt Y T '' V') :=
      (hV'cl.isCompact.image (gpt_cont Y T hT)).isClosed
    have hsub : gpt Y T '' V' ⊆ Gph Y T := by
      rintro _ ⟨c, _, rfl⟩; exact ⟨c, rfl⟩
    have hinv : MapsTo (Dinf (Tfun Y T) x0) (gpt Y T '' V') (gpt Y T '' V') := by
      rintro _ ⟨c, hc, rfl⟩
      exact ⟨T c, hV'inv hc, (hDpt c).symm⟩
    have hEq := hM _ hsub (hV'ne.image _) hcl hinv
    refine Set.eq_univ_of_forall fun c => ?_
    have hc : gpt Y T c ∈ gpt Y T '' V' := by rw [hEq]; exact ⟨c, rfl⟩
    obtain ⟨d, hd, hdc⟩ := hc
    rwa [hgpt_inj hdc] at hd
  · intro hM V hVG hVne hVcl hVinv
    have hV'cl : IsClosed (gpt Y T ⁻¹' V) := hVcl.preimage (gpt_cont Y T hT)
    have hV'ne : (gpt Y T ⁻¹' V).Nonempty := by
      obtain ⟨q, hq⟩ := hVne
      obtain ⟨c, rfl⟩ := hVG hq
      exact ⟨c, hq⟩
    have hinv : MapsTo T (gpt Y T ⁻¹' V) (gpt Y T ⁻¹' V) := by
      intro c hc
      have h1 : Dinf (Tfun Y T) x0 (gpt Y T c) ∈ V := hVinv hc
      rw [hDpt] at h1
      exact h1
    have hall := hM _ (Set.subset_univ _) hV'ne hV'cl hinv
    ext q
    constructor
    · intro hq; exact hVG hq
    · rintro ⟨c, rfl⟩
      have hc : c ∈ gpt Y T ⁻¹' V := by rw [hall]; exact Set.mem_univ _
      exact hc

end Subit.LemmaEY

end
