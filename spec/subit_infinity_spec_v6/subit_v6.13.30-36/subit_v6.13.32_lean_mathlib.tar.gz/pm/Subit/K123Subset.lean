import Subit.CatSub

/-!
# K1–K3 для моделі §7.1 (G5)

Спеціфікація §7.4–7.6 задає SUBIT і SUBIT_full на об'єктах (S, ℛ, g) з ℛ ⊆ S^S (`SObj`, `SFObj` у `CatSub`).
Тут зафіксовано саме ці твердження: K1 (категорії), K2 (термінальний об'єкт, включно з повною підкатегорією),
K3 (добуток). Індексна модель `Cat.lean` — окремий допоміжний опис і сюди не входить.
-/

namespace Subit.CatSub
open CategoryTheory Limits

/-- K1 (§7.4): тотожний морфізм і композиція в SUBIT задовольняють закони категорії. -/
theorem K1_subset {X Y Z W : SObj} (φ : X ⟶ Y) (ψ : Y ⟶ Z) (χ : Z ⟶ W) :
    𝟙 X ≫ φ = φ ∧ φ ≫ 𝟙 Y = φ ∧ (φ ≫ ψ) ≫ χ = φ ≫ (ψ ≫ χ) :=
  ⟨Category.id_comp φ, Category.comp_id φ, Category.assoc φ ψ χ⟩

/-- K1 (§7.4): те саме для повної підкатегорії SUBIT_full. -/
theorem K1_full {X Y Z W : SFObj} (φ : X ⟶ Y) (ψ : Y ⟶ Z) (χ : Z ⟶ W) :
    𝟙 X ≫ φ = φ ∧ φ ≫ 𝟙 Y = φ ∧ (φ ≫ ψ) ≫ χ = φ ≫ (ψ ≫ χ) :=
  ⟨Category.id_comp φ, Category.comp_id φ, Category.assoc φ ψ χ⟩

/-- K2 (§7.5), SUBIT: термінальний об'єкт. -/
theorem K2_subset : Nonempty (IsTerminal term) := K2

/-- Термінальний об'єкт повної підкатегорії: той самий носій з тією ж динамікою. -/
def termF : SFObj := ⟨term⟩

/-- Єдиний морфізм X → termF у SUBIT_full: компонента ℛ відображає всі ρ в id. -/
def toTermF (X : SFObj) : SFHom X termF where
  toHom := toTerm X.toObj
  commG := fun _ _ => Subtype.ext (Set.mem_singleton_iff.mp (Subtype.property _))

/-- K2 (§7.5), SUBIT_full: термінальний об'єкт. -/
theorem K2_termF : Nonempty (IsTerminal termF) :=
  ⟨IsTerminal.ofUniqueHom toTermF fun X φ => by
    apply SFHom.ext
    · funext s; rfl
    · funext r; exact Subtype.ext (Set.mem_singleton_iff.mp (Subtype.property _))⟩

/-- K3 (§7.6), SUBIT: добуток існує (універсальна властивість). -/
theorem K3_subset (X Y : SObj) : Nonempty (IsLimit (BinaryFan.mk (prX X Y) (prY X Y))) :=
  ⟨prodIsLimit X Y⟩

/-- K3 (§7.6), SUBIT_full: добуток існує в повній підкатегорії. -/
theorem K3_full (X Y : SObj) :
    Nonempty (IsLimit (BinaryFan.mk (prXF X Y) (prYF X Y))) :=
  ⟨prodIsLimitFull X Y⟩

end Subit.CatSub
