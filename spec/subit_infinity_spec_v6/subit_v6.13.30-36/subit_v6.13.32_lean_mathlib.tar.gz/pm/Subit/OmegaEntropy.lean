import Subit.D6
/-!
# Ентропія звуження на інваріантну підмножину (монотонність h_top)

Для D : X → X, інваріантної W (MapsTo D W W) і метрики d на X:
h_top(D|W) ≤ h_top(D), якщо sepNum усього простору скінченні (обмежені зверху).
Без припущень про замкненість W. Для ω(x0) застосовується з W = ω-границя.
-/
noncomputable section
namespace Subit.OmegaEntropy
open Filter Set

variable {X : Type*}

private lemma hlog_mono {a b : ℕ} (h : a ≤ b) : Real.log a ≤ Real.log b := by
  rcases Nat.eq_zero_or_pos a with rfl | ha
  · simp; exact Real.log_natCast_nonneg b
  · exact Real.log_le_log (by exact_mod_cast ha) (by exact_mod_cast h)

lemma iter_restrict_val (D : X → X) (W : Set X) (hW : MapsTo D W W) (i : ℕ) (a : W) :
    (Subit.iter (Subit.restrict D W hW) i a).1 = Subit.iter D i a.1 := by
  induction i with
  | zero => rfl
  | succ k ih =>
    show (Subit.restrict D W hW (Subit.iter (Subit.restrict D W hW) k a)).1 = _
    simp only [Subit.restrict]
    rw [ih]; rfl

theorem sepNum_restrict_le (d : X → X → ℝ) (D : X → X) (W : Set X) (hW : MapsTo D W W)
    (hfin : ∀ (n : ℕ) (ε : ℝ), 0 < ε → BddAbove {k | ∃ S : Finset X, Subit.IsSep d D n ε S ∧ S.card = k})
    (n : ℕ) (ε : ℝ) (hε : 0 < ε) :
    Subit.sepNum (fun a b : W => d a.1 b.1) (Subit.restrict D W hW) n ε ≤
      Subit.sepNum d D n ε := by
  unfold Subit.sepNum
  refine csSup_le_csSup (hfin n ε hε) ⟨0, ∅, by intro x hx; simp at hx, rfl⟩ ?_
  rintro k ⟨S, hS, rfl⟩
  refine ⟨S.map (Function.Embedding.subtype W), ?_, Finset.card_map _⟩
  intro x hx y hy hxy
  rw [Finset.mem_map] at hx hy
  obtain ⟨a, ha, rfl⟩ := hx
  obtain ⟨b, hb, rfl⟩ := hy
  have hab : a ≠ b := by
    rintro rfl
    exact hxy rfl
  obtain ⟨i, hi, hlt⟩ := hS a ha b hb hab
  refine ⟨i, hi, ?_⟩
  change ε < d (Subit.iter D i a.1) (Subit.iter D i b.1)
  rw [← iter_restrict_val D W hW i a, ← iter_restrict_val D W hW i b]
  exact hlt

theorem htopOn_le_htop (d : X → X → ℝ) (D : X → X) (W : Set X) (hW : MapsTo D W W)
    (hfin : ∀ (n : ℕ) (ε : ℝ), 0 < ε → BddAbove {k | ∃ S : Finset X, Subit.IsSep d D n ε S ∧ S.card = k}) :
    Subit.htopOn d D W hW ≤ Subit.htop d D := by
  unfold Subit.htopOn Subit.htop
  refine iSup_mono fun ε => ?_
  obtain ⟨ε, hε⟩ := ε
  refine limsup_le_limsup (Eventually.of_forall fun n => ?_) (by isBoundedDefault) (by isBoundedDefault)
  exact EReal.coe_le_coe_iff.2
    (div_le_div_of_nonneg_right (hlog_mono (sepNum_restrict_le d D W hW hfin n ε hε)) (Nat.cast_nonneg n))

end Subit.OmegaEntropy
end
