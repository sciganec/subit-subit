import Subit.W8GCount
import Subit.W8Entropy

/-!
# W8 з довільними блоками: нульова ентропія ω-границі (G-варіант)

Узагальнення `Subit.W8Entropy` на довільне слово d з полиномною оцінкою числа вікон
(`hT`). Для d = dG n з n_k ≥ k+1 така оцінка дає `factor_bound_G`.
-/

open Filter Topology

namespace Subit.W8GEntropy

open Subit.W8Entropy (continuous_shift iter_restrict_val htop_eq_zero_of_poly)

section Language

theorem prefix_mem_factor_gen (d : ℕ → Bool) {x : ℕ → Bool} (hx : x ∈ Subit.omega shift d)
    (L : ℕ) : ∃ p : ℕ, ∀ j < L, x j = d (p + j) := by
  have hcl : x ∈ closure (Set.range fun k => iter shift (0 + k) d) :=
    Set.mem_iInter.1 hx 0
  have hU : IsOpen {y : ℕ → Bool | ∀ j < L, y j = x j} := by
    have e : {y : ℕ → Bool | ∀ j < L, y j = x j}
        = ⋂ j ∈ Finset.range L, (fun y : ℕ → Bool => y j) ⁻¹' {x j} := by
      ext y
      simp
    rw [e]
    exact isOpen_biInter_finset fun j _ =>
      (continuous_apply j).isOpen_preimage _ (isOpen_discrete _)
  obtain ⟨y, hyU, k, hk⟩ := mem_closure_iff.1 hcl _ hU (fun j _ => rfl)
  subst hk
  refine ⟨k, fun j hj => ?_⟩
  have h : d (j + (0 + k)) = x j := by
    have := hyU j hj
    simp only [iter_shift] at this
    exact this
  rw [show k + j = j + (0 + k) by omega]
  exact h.symm

end Language

section Count

theorem sepNum_restrict_le_gen (d : ℕ → Bool) (W : Set (ℕ → Bool)) (hW : Set.MapsTo shift W W)
    (hfac : ∀ x ∈ W, ∀ L : ℕ, ∃ p : ℕ, ∀ j < L, x j = d (p + j))
    (hT : ∀ N : ℕ, 1 ≤ N → ∃ T : Finset (List Bool),
      (∀ p : ℕ, List.ofFn (fun j : Fin N => d (p + j)) ∈ T) ∧ T.card ≤ 2 + 2 * N ^ 2)
    (K : ℕ) (ε : ℝ) (hK : (1 / 2 : ℝ) ^ K < ε) (n : ℕ) :
    sepNum (fun a b : W => Subit.dC a.1 b.1) (restrict shift W hW) n ε
      ≤ 2 + 2 * (n + K + 1) ^ 2 := by
  refine sepNum_le _ fun S hS => ?_
  obtain ⟨T, hTm, hcard⟩ := hT (n + K + 1) (by omega)
  refine le_trans ?_ hcard
  refine Finset.card_le_card_of_injOn
    (fun a : W => List.ofFn (fun j : Fin (n + K + 1) => a.1 j)) ?_ ?_
  · intro a _
    obtain ⟨p, hp⟩ := hfac a.1 a.2 (n + K + 1)
    have e : List.ofFn (fun j : Fin (n + K + 1) => a.1 j)
        = List.ofFn (fun j : Fin (n + K + 1) => d (p + j)) := by
      congr 1
      funext j
      exact hp j j.isLt
    show List.ofFn (fun j : Fin (n + K + 1) => a.1 j) ∈ T
    rw [e]
    exact hTm p
  · intro a ha b hb hab
    by_contra hne
    obtain ⟨i, hi, hd⟩ := hS a ha b hb hne
    have hfun := List.ofFn_injective hab
    have hagree : ∀ j, j < n + K + 1 → a.1 j = b.1 j := fun j hj =>
      congrFun hfun ⟨j, hj⟩
    have hle : Subit.dC (iter shift i a.1) (iter shift i b.1) ≤ (1 / 2 : ℝ) ^ K := by
      apply Subit.dC_le
      intro m hm
      rw [iter_shift, iter_shift]
      exact hagree (m + i) (by omega)
    simp only [iter_restrict_val] at hd
    linarith

end Count

section Zero

theorem htopOn_zero_gen (d : ℕ → Bool) (W : Set (ℕ → Bool)) (hW : Set.MapsTo shift W W)
    (hfac : ∀ x ∈ W, ∀ L : ℕ, ∃ p : ℕ, ∀ j < L, x j = d (p + j))
    (hT : ∀ N : ℕ, 1 ≤ N → ∃ T : Finset (List Bool),
      (∀ p : ℕ, List.ofFn (fun j : Fin N => d (p + j)) ∈ T) ∧ T.card ≤ 2 + 2 * N ^ 2) :
    Subit.htopOn Subit.dC shift W hW = 0 := by
  unfold Subit.htopOn
  apply htop_eq_zero_of_poly
  intro ε hε
  obtain ⟨K, hK⟩ := exists_pow_lt_of_lt_one hε (by norm_num : (1 / 2 : ℝ) < 1)
  refine ⟨2 + 2 * (K + 2) ^ 2, 2, fun n hn => ?_⟩
  have h1 := sepNum_restrict_le_gen d W hW hfac hT K ε hK n
  have h2 : n + K + 1 ≤ (K + 2) * n := by nlinarith
  have h3 : 1 ≤ n := hn
  have h4 : (1 : ℝ) ≤ (n : ℝ) ^ 2 := by
    have : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast h3
    nlinarith
  calc _ ≤ 2 + 2 * (n + K + 1) ^ 2 := h1
    _ ≤ 2 + 2 * ((K + 2) * n) ^ 2 := by gcongr
    _ = 2 + 2 * (K + 2) ^ 2 * n ^ 2 := by ring
    _ ≤ (2 + 2 * (K + 2) ^ 2) * n ^ 2 := by nlinarith

end Zero

theorem omega_maps_shift_gen (d : ℕ → Bool) :
    Set.MapsTo shift (Subit.omega shift d) (Subit.omega shift d) :=
  fun _ hy => Subit.omega_forward shift continuous_shift _ (Set.mem_image_of_mem shift hy)

/-- Головна теорема (довільні блоки n_k ≥ k+1): зсув на ω-границі слова d = dG n має
нульову топологічну ентропію. -/
theorem htop_omega_zero_G (n : ℕ → ℕ) (hn : ∀ k, k + 1 ≤ n k) :
    Subit.htopOn Subit.dC shift (Subit.omega shift (Subit.W8G.dG n))
      (omega_maps_shift_gen (Subit.W8G.dG n)) = 0 :=
  htopOn_zero_gen (Subit.W8G.dG n) _ _
    (fun _ hx L => prefix_mem_factor_gen _ hx L)
    (fun N hN => Subit.W8G.factor_bound_G n hn N hN)

end Subit.W8GEntropy
