import Subit.WordW8
import Mathlib.Data.List.GetD
import Mathlib.Data.Finset.Image
import Mathlib.Data.Finset.Card
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Tactic.Linarith
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Order.Interval.Finset.Nat

/-!
# G9: повний підрахунок вікон слова d з W8

Слово d з `WordW8.lean`: w₀ = β, w_{k+1} = w_k α^{k+1} w_k (α = `true`, β = `false`).

Теорема: для N ≥ 1 число різних вікон довжини N слова d не перевищує
1 + Σ_{m<N} (N + m) = 1 + N² + N(N−1)/2 ≤ 2N².

Доказ (без плиток і 2-адичних валюацій):
(1) Для w_{m+1} = w_m α^{m+1} w_m кожне вікно або є вікном w_m, або належить
    множині NC_m з не більше N + m вікон (початки в [L_m − N + 1, L_m + m]).
(2) Для m ≥ N кожне вікно з NC_m є вікном w_m (бо m ≥ N дає достатньо α після суфікса
    та перед префіксом w_m).
(3) Індукцією за M: кожне вікно w_M лежить у скінченній множині Tot = B ∪ ⋃_{m<N} NC_m.
-/

namespace Subit.W8
open Finset

/-- Вікно довжини N слова l з початку p. -/
def win (l : List Bool) (p N : ℕ) : List Bool :=
  List.ofFn (fun j : Fin N => l.getD (p + j) false)

theorem wd_succ (k : ℕ) : wd (k + 1) = (wd k ++ List.replicate (k + 1) true) ++ wd k := by
  simp only [wd]

theorem wd_len (k : ℕ) : (wd (k + 1)).length = 2 * (wd k).length + (k + 1) := by
  rw [wd_succ]
  simp only [List.length_append, List.length_replicate]
  omega

theorem getD_left (k i : ℕ) (h : i < (wd k).length) :
    (wd (k + 1)).getD i false = (wd k).getD i false := by
  rw [wd_succ, List.getD_append _ _ _ _ (by simp only [List.length_append, List.length_replicate]; omega),
    List.getD_append _ _ _ _ h]

theorem getD_mid (k i : ℕ) (h1 : (wd k).length ≤ i) (h2 : i < (wd k).length + (k + 1)) :
    (wd (k + 1)).getD i false = true := by
  rw [wd_succ, List.getD_append _ _ _ _ (by simp only [List.length_append, List.length_replicate]; omega),
    List.getD_append_right _ _ _ _ h1, List.getD_eq_getElem?_getD, List.getElem?_replicate]
  split_ifs with hlt
  · rfl
  · omega

theorem getD_right (k i : ℕ) (h : (wd k).length + (k + 1) ≤ i) :
    (wd (k + 1)).getD i false = (wd k).getD (i - ((wd k).length + (k + 1))) false := by
  rw [wd_succ, List.getD_append_right _ _ _ _ (by simp only [List.length_append, List.length_replicate]; omega)]
  congr 1
  simp only [List.length_append, List.length_replicate]


theorem win_congr {l l' : List Bool} {p q N : ℕ}
    (h : ∀ j, j < N → l.getD (p + j) false = l'.getD (q + j) false) :
    win l p N = win l' q N := by
  unfold win
  congr 1
  funext j
  exact h j j.isLt

theorem win_rep (l : List Bool) (hl : ∀ i, l.getD i false = false) (p N : ℕ) :
    win l p N = List.replicate N false := by
  unfold win
  rw [show (fun j : Fin N => l.getD (p + j) false) = fun _ => false from funext fun j => hl _]
  exact List.ofFn_const N false

/-- Вікна, що перетинають межу блоків w_m | α^{m+1} | w_m у w_{m+1}. -/
def NC (N m : ℕ) : Finset (List Bool) :=
  (Finset.Icc ((wd m).length + 1 - N) ((wd m).length + m)).image (fun p => win (wd (m + 1)) p N)

/-- Кандидати на вікна всіх рівнів: усі-false вікно та NC_m, m < N. -/
def Tot (N : ℕ) : Finset (List Bool) :=
  {List.replicate N false} ∪ (Finset.range N).biUnion (NC N)

theorem decomp (N m p : ℕ) :
    (∃ q, win (wd (m + 1)) p N = win (wd m) q N) ∨ win (wd (m + 1)) p N ∈ NC N m := by
  have hL := wd_len m
  by_cases h1 : p + N ≤ (wd m).length
  · left
    exact ⟨p, win_congr fun j hj => getD_left m (p + j) (by omega)⟩
  by_cases h2 : (wd m).length + (m + 1) ≤ p
  · left
    refine ⟨p - ((wd m).length + (m + 1)), win_congr fun j hj => ?_⟩
    rw [getD_right m (p + j) (by omega)]
    congr 1
    omega
  · right
    unfold NC
    rw [Finset.mem_image]
    exact ⟨p, Finset.mem_Icc.2 ⟨by omega, by omega⟩, rfl⟩

/-- Стабілізація: для m ≥ N вікна NC_m є вікнами w_m. -/
theorem stab (N k p : ℕ) (hN : N ≤ k + 1)
    (hp : (wd (k + 1)).length + 1 - N ≤ p) (hp2 : p ≤ (wd (k + 1)).length + (k + 1)) :
    ∃ q, win (wd (k + 1 + 1)) p N = win (wd (k + 1)) q N := by
  have hk := length_wd_ge k
  have hL1 := wd_len k
  by_cases hA : p < (wd (k + 1)).length
  · obtain ⟨t, ht⟩ : ∃ t, t = (wd (k + 1)).length - p := ⟨_, rfl⟩
    refine ⟨(wd k).length - t, win_congr fun j hj => ?_⟩
    by_cases hjt : j < t
    · rw [getD_left (k + 1) (p + j) (by omega), getD_right k (p + j) (by omega),
        getD_left k ((wd k).length - t + j) (by omega)]
      congr 1
      omega
    · rw [getD_mid (k + 1) (p + j) (by omega) (by omega),
        getD_mid k ((wd k).length - t + j) (by omega) (by omega)]
  · push Not at hA
    by_cases hsub : p + N ≤ (wd (k + 1)).length + (k + 1 + 1)
    · refine ⟨(wd k).length, win_congr fun j hj => ?_⟩
      rw [getD_mid (k + 1) (p + j) (by omega) (by omega),
        getD_mid k ((wd k).length + j) (by omega) (by omega)]
    · obtain ⟨a, ha⟩ : ∃ a, a = (wd (k + 1)).length + (k + 1 + 1) - p := ⟨_, rfl⟩
      refine ⟨(wd k).length + (k + 1) - a, win_congr fun j hj => ?_⟩
      by_cases hja : j < a
      · rw [getD_mid (k + 1) (p + j) (by omega) (by omega),
          getD_mid k ((wd k).length + (k + 1) - a + j) (by omega) (by omega)]
      · rw [getD_right (k + 1) (p + j) (by omega),
          getD_left k (p + j - ((wd (k + 1)).length + (k + 1 + 1))) (by omega),
          getD_right k ((wd k).length + (k + 1) - a + j) (by omega)]
        congr 1
        omega

theorem win_mem_Tot (N : ℕ) (hN : 1 ≤ N) (m p : ℕ) : win (wd m) p N ∈ Tot N := by
  induction m generalizing p with
  | zero =>
    have h0 : ∀ i, (wd 0).getD i false = false := by
      intro i
      cases i <;> simp [wd]
    unfold Tot
    rw [Finset.mem_union, win_rep (wd 0) h0 p N]
    exact Or.inl (Finset.mem_singleton_self _)
  | succ m ih =>
    rcases decomp N m p with ⟨q, hq⟩ | hmem
    · rw [hq]
      exact ih q
    · by_cases hm : m < N
      · unfold Tot
        rw [Finset.mem_union, Finset.mem_biUnion]
        exact Or.inr ⟨m, Finset.mem_range.2 hm, hmem⟩
      · obtain ⟨k, rfl⟩ : ∃ k, m = k + 1 := ⟨m - 1, by omega⟩
        unfold NC at hmem
        rw [Finset.mem_image] at hmem
        obtain ⟨p', hp', hpeq⟩ := hmem
        rw [Finset.mem_Icc] at hp'
        obtain ⟨q, hq⟩ := stab N k p' (by omega) hp'.1 hp'.2
        rw [← hpeq, hq]
        exact ih q

theorem card_NC_le (N m : ℕ) : (NC N m).card ≤ N + m := by
  unfold NC
  refine Finset.card_image_le.trans ?_
  rw [Nat.card_Icc]
  omega

theorem card_Tot_le (N : ℕ) : (Tot N).card ≤ 1 + ∑ m ∈ Finset.range N, (N + m) := by
  unfold Tot
  refine (Finset.card_union_le _ _).trans ?_
  have h1 : ({List.replicate N false} : Finset (List Bool)).card = 1 := Finset.card_singleton _
  have h2 : ((Finset.range N).biUnion (NC N)).card ≤ ∑ m ∈ Finset.range N, (N + m) :=
    Finset.card_biUnion_le.trans (Finset.sum_le_sum fun m _ => card_NC_le N m)
  omega

/-- G9 (повний): вікна довжини N слова d лежать у скінченній множині
з не більш ніж 1 + Σ_{m<N} (N+m) елементами. -/
theorem factor_bound (N : ℕ) (hN : 1 ≤ N) :
    ∃ T : Finset (List Bool), (∀ p : ℕ, List.ofFn (fun j : Fin N => dW (p + j)) ∈ T) ∧
      T.card ≤ 1 + ∑ m ∈ Finset.range N, (N + m) := by
  refine ⟨Tot N, fun p => ?_, card_Tot_le N⟩
  have hL := length_wd_ge (p + N)
  have heq : List.ofFn (fun j : Fin N => dW (p + j)) = win (wd (p + N)) p N := by
    unfold win
    congr 1
    funext j
    exact dW_eq (p + N) (p + j) (by have := j.isLt; omega)
  rw [heq]
  exact win_mem_Tot N hN _ p

theorem sum_bound (N : ℕ) (hN : 1 ≤ N) : 1 + ∑ m ∈ Finset.range N, (N + m) ≤ 2 * N ^ 2 := by
  rw [Finset.sum_add_distrib, Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  have h := Finset.sum_range_id_mul_two N
  obtain ⟨k, rfl⟩ : ∃ k, N = k + 1 := ⟨N - 1, by omega⟩
  rw [Nat.add_sub_cancel] at h
  nlinarith

/-- Та сама оцінка у спрощеному вигляді: не більше 2N² вікон довжини N (N ≥ 1). -/
theorem factor_bound_sq (N : ℕ) (hN : 1 ≤ N) :
    ∃ T : Finset (List Bool), (∀ p : ℕ, List.ofFn (fun j : Fin N => dW (p + j)) ∈ T) ∧
      T.card ≤ 2 * N ^ 2 := by
  obtain ⟨T, hT, hc⟩ := factor_bound N hN
  exact ⟨T, hT, hc.trans (sum_bound N hN)⟩

end Subit.W8
