import Subit.W8Entropy
/-!
# W8: ATTAINED і NONMIN у послідовнісній моделі (n_k = k+1)

Модель: X = ℕ → Bool, зсув `Subit.shift`, слово d := `Subit.W8.dW` (w_{k+1} = w_k α^{k+1} w_k,
α = true, β = false).

* `attained` — d ∈ ω(d), отже σⁿ(d) ∈ ω(d) для всіх n.
* `nonmin` — ω(d) не є мінімальною для σ: сталa точка α^∞ ∈ ω(d) і d ≠ α^∞.

Тільки: propext, Classical.choice, Quot.sound. Без sorry. Підстановка довільних strictly
зростаючих n_k НЕ зроблена (статус у специфікації лишається «частково»).
-/
namespace Subit.W8Attained
open Filter Topology Subit Subit.W8

theorem dW_zero : dW 0 = false := by decide

/-- Блок α довжини k+1 стоїть у w_{k+1} одразу після w_k. -/
theorem dW_block (k t : ℕ) (ht : t < k + 1) : dW ((wd k).length + t) = true := by
  have hlt : (wd k).length + t < (wd (k + 1)).length := by
    simp only [wd, List.length_append, List.length_replicate]
    omega
  rw [dW_eq (k + 1) _ hlt]
  simp only [wd, List.getD_eq_getElem?_getD]
  rw [List.getElem?_append_left (by simp only [List.length_append, List.length_replicate]; omega),
    List.getElem?_append_right (by omega)]
  simp [ht]

/-- Повернення: w_k знову з'являється в d з offset L_k + (k+1). -/
theorem dW_return (k t : ℕ) (ht : t < (wd k).length) :
    dW ((wd k).length + (k + 1) + t) = dW t := by
  have hlt : (wd k).length + (k + 1) + t < (wd (k + 1)).length := by
    simp only [wd, List.length_append, List.length_replicate]
    omega
  rw [dW_eq (k + 1) _ hlt, dW_eq k t ht]
  simp only [wd, List.getD_eq_getElem?_getD]
  rw [List.getElem?_append_right (by simp only [List.length_append, List.length_replicate]; omega)]
  have h1 : (wd k).length + (k + 1) + t - (wd k ++ List.replicate (k + 1) true).length = t := by
    simp only [List.length_append, List.length_replicate]; omega
  rw [h1]

open Set in
/-- Загальний критерій: якщо f → ∞ і σ^{f(k)}(x) → a, то a ∈ ω(x). -/
theorem mem_omega_of_seq (x a : ℕ → Bool) (f : ℕ → ℕ) (hf : Tendsto f atTop atTop)
    (hlim : Tendsto (fun k => iter shift (f k) x) atTop (𝓝 a)) : a ∈ Subit.omega shift x := by
  refine Set.mem_iInter.2 fun N => ?_
  refine mem_closure_of_tendsto hlim ?_
  filter_upwards [hf.eventually_ge_atTop N] with k hk
  refine ⟨f k - N, ?_⟩
  show iter shift (N + (f k - N)) x = iter shift (f k) x
  rw [show N + (f k - N) = f k by omega]

/-- Координатна збіжність σ^{L_k + (k+1)}(d) → d. -/
theorem dW_coord_tendsto :
    Tendsto (fun k => iter shift ((wd k).length + (k + 1)) dW) atTop (𝓝 dW) := by
  rw [tendsto_pi_nhds]
  intro n
  refine tendsto_const_nhds.congr' ?_
  filter_upwards [eventually_ge_atTop n] with k hk
  have hL := length_wd_ge k
  show dW n = iter shift ((wd k).length + (k + 1)) dW n
  rw [iter_shift]
  show dW n = dW (n + ((wd k).length + (k + 1)))
  rw [show n + ((wd k).length + (k + 1)) = (wd k).length + (k + 1) + n by omega]
  exact (dW_return k n (by omega)).symm

/-- ATTAINED: d ∈ ω(d). -/
theorem attained : dW ∈ Subit.omega shift dW :=
  mem_omega_of_seq dW dW (fun k => (wd k).length + (k + 1))
    (tendsto_atTop_mono (fun k => by have := length_wd_ge k; simp only [id]; omega) tendsto_id) dW_coord_tendsto

/-- σⁿ(d) ∈ ω(d) для всіх n. -/
theorem iter_mem_omega (n : ℕ) : iter shift n dW ∈ Subit.omega shift dW := by
  induction n with
  | zero => exact attained
  | succ n ih =>
    exact Subit.omega_forward shift Subit.W8Entropy.continuous_shift _
      (Set.mem_image_of_mem shift ih)

/-- Стала точка α^∞ (усі значення true). -/
def cTrue : ℕ → Bool := fun _ => true

/-- Координатна збіжність σ^{L_k}(d) → α^∞ (довгі блоки α). -/
theorem cTrue_coord_tendsto :
    Tendsto (fun k => iter shift ((wd k).length) dW) atTop (𝓝 cTrue) := by
  rw [tendsto_pi_nhds]
  intro n
  refine tendsto_const_nhds.congr' ?_
  filter_upwards [eventually_ge_atTop n] with k hk
  have hL := length_wd_ge k
  show cTrue n = iter shift ((wd k).length) dW n
  rw [iter_shift]
  show cTrue n = dW (n + (wd k).length)
  rw [show n + (wd k).length = (wd k).length + n by omega]
  exact (dW_block k n (by omega)).symm

/-- α^∞ ∈ ω(d). -/
theorem cTrue_mem_omega : cTrue ∈ Subit.omega shift dW :=
  mem_omega_of_seq dW cTrue (fun k => (wd k).length)
    (tendsto_atTop_mono (fun k => by have := length_wd_ge k; simp only [id]; omega) tendsto_id) cTrue_coord_tendsto

/-- NONMIN: ω(d) не є мінімальною множиною зсуву. -/
theorem nonmin : ¬ Subit.MinOn shift (Subit.omega shift dW) := by
  intro hM
  have hsing : ({cTrue} : Set (ℕ → Bool)) = Subit.omega shift dW :=
    hM {cTrue} (Set.singleton_subset_iff.2 cTrue_mem_omega) (Set.singleton_nonempty _)
      isClosed_singleton (by
        intro y hy
        rw [Set.mem_singleton_iff] at hy ⊢
        rw [hy]
        funext n
        rfl)
  have hd : dW ∈ ({cTrue} : Set (ℕ → Bool)) := by
    rw [hsing]
    exact attained
  rw [Set.mem_singleton_iff] at hd
  have h0 : dW 0 = true := congrFun hd 0
  exact absurd (dW_zero.symm.trans h0) (by decide)

/-- ω(d) нескінченна: точки σ^{L_k}(d) ∈ ω(d) попарно різні (перший false на позиції k+1). -/
theorem omega_infinite : (Subit.omega shift dW).Infinite := by
  have hmem : ∀ k : ℕ, iter shift ((wd k).length) dW ∈ Subit.omega shift dW :=
    fun k => iter_mem_omega _
  have hval_true : ∀ k i : ℕ, i < k + 1 → iter shift ((wd k).length) dW i = true := by
    intro k i hi
    rw [iter_shift]
    show dW (i + (wd k).length) = true
    rw [Nat.add_comm]
    exact dW_block k i hi
  have hval_false : ∀ k : ℕ, iter shift ((wd k).length) dW (k + 1) = false := by
    intro k
    rw [iter_shift]
    have hL := length_wd_ge k
    show dW (k + 1 + (wd k).length) = false
    rw [show k + 1 + (wd k).length = (wd k).length + (k + 1) + 0 by omega,
      dW_return k 0 (by omega), dW_zero]
  have hinj : Function.Injective fun k : ℕ => iter shift ((wd k).length) dW := by
    intro k j hkj
    have hkj' : iter shift ((wd k).length) dW = iter shift ((wd j).length) dW := hkj
    by_contra hne
    rcases lt_or_gt_of_ne hne with h | h
    · have h1 := hval_true j (k + 1) (by omega)
      have h2 := hval_false k
      rw [hkj', h1] at h2
      exact absurd h2 (by decide)
    · have h1 := hval_true k (j + 1) (by omega)
      have h2 := hval_false j
      rw [← hkj', h1] at h2
      exact absurd h2 (by decide)
  exact Set.infinite_of_injective_forall_mem hinj hmem

/-- Підсумок W8 у послідовнісній моделі (n_k = k+1): ATTAINED, нескінченність, NONMIN, h_top = 0. -/
theorem w8_seq_summary :
    dW ∈ Subit.omega shift dW ∧ (∀ n, iter shift n dW ∈ Subit.omega shift dW) ∧
    (Subit.omega shift dW).Infinite ∧ ¬ Subit.MinOn shift (Subit.omega shift dW) ∧
    Subit.htopOn Subit.dC shift (Subit.omega shift dW) Subit.W8Entropy.omega_maps_shift = 0 :=
  ⟨attained, iter_mem_omega, omega_infinite, nonmin, Subit.W8Entropy.htop_omega_zero⟩

end Subit.W8Attained
