import React, { useMemo, useState } from "react";
import { ChevronDown, Check, X, ArrowRight, Sparkles, Divide, Sigma, Play, RotateCcw, Shuffle, BookOpen, FlaskConical, ListChecks, GraduationCap, Infinity as InfinityIcon, TrendingDown, Calculator, Network, Link2, Eye } from "lucide-react";

const isPrime = (n:number)=>{ if(n<2) return false; for(let i=2;i*i<=n;i++) if(n%i===0) return false; return true; };
const divisors = (n:number)=>{ const r:number[]=[]; for(let i=1;i<=n;i++) if(n%i===0) r.push(i); return r; };
const primesUpTo = (x:number)=>{ const r:number[]=[]; for(let i=2;i<=x;i++) if(isPrime(i)) r.push(i); return r; };
const factorize = (n:number)=>{ let x=n; const r:number[]=[]; let d=2; while(d*d<=x){ while(x%d===0){ r.push(d); x/=d; } d++; } if(x>1) r.push(x); return r; };
const formatFactors = (fs:number[])=>{ const c=new Map<number,number>(); fs.forEach(f=>c.set(f,(c.get(f)||0)+1)); return [...c.entries()].map(([p,e])=> e>1? `${p}²`.replace("²", e===2?"²":e===3?"³":"⁴") : `${p}`).join(" × "); };
const formatFactorsExact = (fs:number[])=>{ const c=new Map<number,number>(); fs.forEach(f=>c.set(f,(c.get(f)||0)+1)); const sup:Record<number,string>={2:"²",3:"³",4:"⁴",5:"⁵",6:"⁶"}; return [...c.entries()].map(([p,e])=> e>1? `${p}${sup[e]||"^"+e}` : `${p}`).join(" × "); };

function Section({id,num,icon,title,kicker,main,children,checkQ,checkA}:{id:string;num:string;icon:React.ReactNode;title:string;kicker:string;main:string;children:React.ReactNode;checkQ:string;checkA:string}){
  const [open,setOpen]=useState(false);
  return <section id={id} className="bg-[var(--surface)] border border-[var(--line)] rounded-[22px] overflow-hidden shadow-[0_8px_28px_rgba(23,58,94,0.06)]">
    <div className="p-4 sm:p-5 pb-3">
      <div className="flex items-start gap-3">
        <div className="shrink-0 w-10 h-10 rounded-2xl bg-[var(--primary)] text-white grid place-items-center font-black">{num}</div>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 text-[11px] font-bold tracking-[0.12em] uppercase text-[var(--accent)]">{icon}<span className="[overflow-wrap:anywhere]">{kicker}</span></div>
          <h2 className="serif text-[22px] sm:text-[27px] leading-[1.1] font-bold mt-1 [overflow-wrap:anywhere]">{title}</h2>
        </div>
      </div>
      <div className="mt-3 rounded-xl bg-[var(--accent-soft)] border border-[var(--line)] p-3">
        <div className="text-[11px] font-black tracking-widest uppercase text-[var(--accent)]">Головне</div>
        <p className="text-[14px] leading-relaxed mt-1 [overflow-wrap:anywhere]">{main}</p>
      </div>
      <div className="mt-4">{children}</div>
    </div>
    <div className="border-t border-[var(--line)] bg-[var(--surface-2)]">
      <button onClick={()=>setOpen(!open)} className="w-full flex items-center justify-between px-4 py-3 text-left font-bold text-[13px]"><span>Міні-перевірка · {checkQ}</span><ChevronDown size={18} className={`transition ${open?"rotate-180":""}`}/></button>
      {open && <div className="px-4 pb-4 text-[13px] leading-relaxed text-[var(--muted)] [overflow-wrap:anywhere]"><b className="text-[var(--ink)]">Відповідь:</b> {checkA}</div>}
    </div>
  </section>
}
function Pill({children,tone="neutral"}:{children:React.ReactNode;tone?:"neutral"|"prime"|"comp"|"warn"}){ const c=tone==="prime"?"bg-[var(--teal-soft)] text-[var(--teal)] border-[var(--teal)]":tone==="comp"?"bg-[var(--rose-soft)] text-[var(--rose)] border-[var(--rose)]":tone==="warn"?"bg-[var(--accent-soft)] text-[var(--accent)]":"bg-[var(--surface-2)]"; return <span className={`inline-flex items-center gap-1 border rounded-full px-2.5 py-1 text-[12px] font-bold ${c}`}>{children}</span> }
function Stepper({value,set,min,max,label}:{value:number;set:(v:number)=>void;min:number;max:number;label:string}){ return <div><label className="text-[12px] font-bold text-[var(--muted)]">{label}: <b className="text-[var(--ink)] text-[15px]">{value}</b></label><input className="range w-full" type="range" min={min} max={max} value={value} onChange={e=>set(Number(e.target.value))}/><div className="flex justify-between text-[11px] text-[var(--muted)]"><span>{min}</span><span>{max}</span></div></div> }

const ALL_PRIMES = primesUpTo(100);
const GAPS = ALL_PRIMES.slice(1).map((p,i)=>p-ALL_PRIMES[i]);

export default function App(){
  const [nav,setNav]=useState("s1");
  const [n,setN]=useState(12);
  const [filter,setFilter]=useState<"all"|"prime"|"comp">("all");
  const [selected,setSelected]=useState(30);
  const [factN,setFactN]=useState(60);
  const [step,setStep]=useState(0);
  const [shuffleSeed,setShuffleSeed]=useState(0);
  const [euclidIdx,setEuclidIdx]=useState(0);
  const [gapCount,setGapCount]=useState(12);
  const [piX,setPiX]=useState(100);
  const [zetaS,setZetaS]=useState<2|3>(2);
  const [zetaTerms,setZetaTerms]=useState(6);
  const [eulerCount,setEulerCount]=useState(3);
  const [eulerS,setEulerS]=useState<2|3>(2);
  const [conclusion,setConclusion]=useState(0);
  const [answers,setAnswers]=useState<Record<number,string>>({});
  const [q120,setQ120]=useState("");
  const [dictOpen,setDictOpen]=useState(0);

  const divs = useMemo(()=>divisors(Math.max(1,Math.min(200, n||1))),[n]);
  const nKind = n===1?"one":isPrime(n)?"prime":"comp";
  const factSteps = useMemo(()=>{
    const start=Math.max(2,Math.min(200,factN||2)); const steps:{text:string; leaves:number[]}[]=[]; let leaves=[start]; steps.push({text:`Початок: ${start}`,leaves:[...leaves]});
    while(leaves.some(v=>!isPrime(v))){ const idx=leaves.findIndex(v=>!isPrime(v)); const v=leaves[idx]; const f=factorize(v)[0]; const q=v/f; const next=[...leaves]; next.splice(idx,1,f,q); leaves=next; steps.push({text:`${v} = ${f} × ${q}`,leaves:[...leaves]}); }
    return steps;
  },[factN]);
  const shownStep=Math.min(step,factSteps.length-1);
  const currentLeaves=factSteps[shownStep]?.leaves||[];
  const shuffled = useMemo(()=>{ const a=[2,3,5]; const arr=[...a]; for(let i=arr.length-1;i>0;i--){ const j=Math.floor(((shuffleSeed*9301+49297)%233280)/233280*(i+1)); [arr[i],arr[j]]=[arr[j],arr[i]]; } return arr; },[shuffleSeed]);
  const euclidSets=[[2,3,5],[2,3,5,7,11,13],[2,3],[2,3,5,7]];
  const euclidSet=euclidSets[euclidIdx]; const euclidN=euclidSet.reduce((a,b)=>a*b,1)+1; const euclidFactors=factorize(euclidN);
  const piVal=primesUpTo(Math.max(2,Math.min(1000,piX||2))).length; const approx=piX/Math.log(piX);
  const zetaSum = Array.from({length:zetaTerms},(_,i)=>1/Math.pow(i+1,zetaS)).reduce((a,b)=>a+b,0);
  const eulerProd = primesUpTo(11).slice(0,eulerCount).reduce((a,p)=>a*(1/(1-1/Math.pow(p,eulerS))),1);
  const conclusions=[
    ["Натуральні числа діляться на прості та складені","якщо розглядати числа, більші за 1."],
    ["Просте число має рівно два дільники","1 і саме себе."],
    ["Кожне складене число розкладається","на добуток простих множників."],
    ["Розклад єдиний","якщо не враховувати порядок множників."],
    ["Простих чисел нескінченно багато","це довів Евклід."],
    ["Вони стають рідшими","частка простих серед усіх чисел зменшується."],
    ["Розподіл можна оцінити","за формулою π(x) ≈ x / ln(x)."],
    ["Ейлер пов’язав суму і добуток","ζ(s) через усі N і через лише прості p."],
  ];
  const score = [answers[1]==="c",answers[2]==="b",answers[4]==="a",answers[5]==="c",answers[6]==="b"].filter(Boolean).length + (q120.replace(/\s/g,"")==="2³×3×5"||q120.replace(/\s/g,"")==="2^3*3*5"||q120.replace(/\s/g,"")==="2³*3*5"?1:0);

  const navItems=[["s1","1 · Вступ"],["s2","2 · Визначення"],["s3","3 · Прості vs складені"],["s4","4 · Розклад"],["s5","5 · Теорема"],["s6","6 · Евклід"],["s7","7 · Проміжки"],["s8","8 · Розрідження"],["s9","9 · Функція π(x)"],["s10","10 · Дзета"],["s11","11 · Добуток Ейлера"],["s12","12 · Висновки"],["s13","13 · Практика"],["s14","14 · Словник"]];
  const go=(id:string)=>{ setNav(id); document.getElementById(id)?.scrollIntoView({behavior:"smooth",block:"start"}); };

  return <div data-safe-area-inset-root style={{boxSizing:"border-box",paddingTop:"var(--safe-area-inset-top)"}} className="min-h-[100dvh] bg-[var(--bg)] text-[var(--ink)] overflow-x-clip">
    <header data-safe-area-sticky-top style={{top:"var(--safe-area-inset-top)"}} className="sticky z-30 bg-[var(--bg)]/95 backdrop-blur border-b border-[var(--line)]">
      <div className="max-w-[980px] mx-auto px-3 sm:px-5 py-3 flex items-center justify-between gap-3">
        <button onClick={()=>go("top")} className="text-left min-w-0"><div className="text-[10px] font-black tracking-[0.18em] uppercase text-[var(--accent)]">Курс · Лекція 2</div><div className="serif font-black text-[19px] sm:text-[22px] leading-none truncate">Прості числа та їхня особлива роль</div></button>
        <div className="hidden sm:flex items-center gap-2 text-[12px] font-bold"><span className="w-2 h-2 rounded-full bg-[var(--teal)]"/>14 розділів · українською</div>
        <button onClick={()=>go("s13")} className="shrink-0 bg-[var(--primary)] text-white rounded-full px-3 py-2 text-[12px] font-bold flex items-center gap-1"><ListChecks size={16}/>Практика</button>
      </div>
      <div className="max-w-[980px] mx-auto px-3 sm:px-5 pb-2 flex gap-1.5 overflow-x-auto no-scrollbar">{navItems.map(([id,label])=><button key={id} onClick={()=>go(id)} className={`chip ${nav===id?"active":""}`}>{label}</button>)}</div>
    </header>

    <main id="top" className="max-w-[980px] mx-auto px-3 sm:px-5 py-4 sm:py-6 space-y-4 sm:space-y-5">
      {/* HERO */}
      <section className="overflow-hidden rounded-[26px] bg-[var(--primary-2)] text-white relative">
        <div className="p-5 sm:p-7 relative z-10">
          <div className="flex flex-wrap gap-2"><span className="bg-white/15 rounded-full px-2.5 py-1 text-[11px] font-bold">ЛЕКЦІЯ 2</span><span className="bg-[var(--accent)] text-black rounded-full px-2.5 py-1 text-[11px] font-bold">ФУНДАМЕНТ АРИФМЕТИКИ</span></div>
          <h1 className="serif text-[clamp(30px,7vw,52px)] leading-[0.98] font-black mt-4 max-w-[720px]">Чому прості числа тримають усю арифметику?</h1>
          <p className="mt-3 text-[15px] sm:text-[17px] leading-relaxed text-white/85 max-w-[720px]">Вони здаються звичайними: 2, 3, 5, 7, 11, 13… Але саме їхній розподіл привів математику до дзета-функції Рімана.</p>
          <div className="mt-5 flex flex-wrap gap-2">
            {[2,3,5,7,11,13,17,19,23,29].map((p,i)=><span key={p} className="w-9 h-9 sm:w-10 sm:h-10 grid place-items-center rounded-full bg-white text-[var(--primary-2)] font-black" style={{transform:`translateY(${i%2?6:0}px)`}}>{p}</span>)}
          </div>
          <div className="mt-6 flex flex-wrap gap-2"><button onClick={()=>go("s1")} className="bg-white text-[var(--primary-2)] rounded-full px-4 py-2.5 font-bold text-[13px]">Почати з вступу →</button><button onClick={()=>go("s2")} className="border border-white/40 rounded-full px-4 py-2.5 font-bold text-[13px]">Перевірити число</button></div>
        </div>
        <div className="absolute right-0 top-0 h-full w-[42%] hidden sm:grid place-items-center text-[180px] leading-none opacity-[0.16] serif">ζ</div>
      </section>

      <div className="grid sm:grid-cols-3 gap-2">
        {[[ "π(10) = 4","лише 4 прості до 10"],["π(100) = 25","частка вже 1 з 4"],["π(1000) = 168","частка — 1 з 6"]].map(([a,b])=><div key={a} className="bg-[var(--surface)] border border-[var(--line)] rounded-2xl p-3"><div className="serif font-black text-[20px]">{a}</div><div className="text-[12px] text-[var(--muted)]">{b}</div></div>)}
      </div>

      <Section id="s1" num="01" icon={<BookOpen size={14}/>} title="Вступ: місце простих чисел" kicker="Зв’язок з Лекцією 1" main="У Лекції 1 ми описали світ чисел: N, Z, Q, R, C. Тепер дивимось усередину N — і бачимо особливу множину простих чисел, яка визначає мультиплікативну будову всіх натуральних чисел." checkQ="Що ми досліджуємо в цій лекції?" checkA="Не окремі «дивні» числа, а внутрішню структуру N: як кожне число пов’язане з простими множниками і чому розподіл простих веде до ζ(s).">
        <div className="grid sm:grid-cols-[1fr_1.2fr] gap-3">
          <div className="rounded-2xl border border-[var(--line)] p-3"><div className="font-bold text-[13px]">Множини з Лекції 1 → фокус Лекції 2</div><div className="mt-2 flex flex-wrap gap-1.5"><span className="chip">N · натуральні</span><span className="chip">Z · цілі</span><span className="chip">Q · раціональні</span><span className="chip">R · дійсні</span><span className="chip">C · комплексні</span></div><p className="text-[13px] leading-relaxed mt-2 text-[var(--muted)]">Сьогодні залишаємось у N. Прості числа — це не нова множина «поза» N, а її особлива підмножина.</p></div>
          <div className="rounded-2xl bg-[var(--teal-soft)] p-3"><div className="flex items-center gap-2 font-bold text-[13px]"><Sparkles size={16}/>Головна думка лекції</div><p className="text-[14px] leading-relaxed mt-1">Прості числа формують внутрішню мультиплікативну структуру всієї арифметики. А дзета-функція дозволяє досліджувати зв’язок між цією структурою та розподілом простих чисел.</p></div>
        </div>
      </Section>

      <Section id="s2" num="02" icon={<Divide size={14}/>} title="Визначення: що таке просте число?" kicker="Дільник · просте · число 1" main="Просте число — це натуральне число, більше за 1, яке має рівно два натуральні дільники: 1 і саме себе." checkQ="Чому 1 не є простим?" checkA="У числа 1 лише один натуральний дільник — воно саме. Для простого потрібно рівно два різні дільники. Тому 1 — ні просте, ні складене.">
        <div className="grid sm:grid-cols-2 gap-3">
          <div><label className="text-[12px] font-bold">Введіть число n (2…200)</label><input type="number" min={2} max={200} value={n} onChange={e=>setN(Number(e.target.value))}/><div className="flex gap-2 mt-2"><button className="chip" onClick={()=>setN(1)}>Показати 1</button><button className="chip" onClick={()=>setN(7)}>7 · просте</button><button className="chip" onClick={()=>setN(12)}>12 · складене</button></div></div>
          <div className="rounded-2xl border border-[var(--line)] p-3"><div className="flex items-center justify-between gap-2"><b className="text-[22px] serif">{n}</b>{nKind==="prime"?<Pill tone="prime">✓ Просте</Pill>:nKind==="comp"?<Pill tone="comp">Складене</Pill>:<Pill tone="warn">Особливий випадок: 1</Pill>}</div><p className="text-[12px] text-[var(--muted)] mt-1">Дільники ({divs.length}):</p><div className="flex flex-wrap gap-1.5 mt-1">{divs.map(d=><span key={d} className={`px-2.5 py-1 rounded-lg font-bold text-[13px] ${d===1||d===n?"bg-[var(--primary)] text-white":"bg-[var(--surface-2)]"}`}>{d}</span>)}</div><p className="text-[13px] leading-relaxed mt-2">{n===1?"1 має лише один дільник, тому не відповідає визначенню простого і не є складеним.":nKind==="prime"?`У ${n} рівно два дільники: 1 і ${n}.`: `${n} має ${divs.length} дільники, тобто більше ніж два, тому воно складене.`}</p></div>
        </div>
      </Section>

      <Section id="s3" num="03" icon={<Eye size={14}/>} title="Прості vs складені: 2…50" kicker="Інтерактивна таблиця" main="Прості мають лише два дільники. Складені — більше ніж два. Натисніть на число, щоб побачити його розклад." checkQ="Чому 15 складене?" checkA="Бо 15 = 3 × 5. Його можна отримати множенням двох менших натуральних чисел, більших за 1.">
        <div className="flex flex-wrap gap-1.5"><button className={`chip ${filter==="all"?"active":""}`} onClick={()=>setFilter("all")}>Всі · 49</button><button className={`chip ${filter==="prime"?"active":""}`} onClick={()=>setFilter("prime")}>Прості · 15</button><button className={`chip ${filter==="comp"?"active":""}`} onClick={()=>setFilter("comp")}>Складені · 34</button></div>
        <div className="grid grid-cols-7 sm:grid-cols-10 gap-1.5 mt-3">{Array.from({length:49},(_,i)=>i+2).filter(v=>filter==="all"||(filter==="prime"?isPrime(v):!isPrime(v))).map(v=><button key={v} onClick={()=>setSelected(v)} className={`aspect-square rounded-xl grid place-items-center font-black text-[14px] border ${selected===v?"bg-[var(--primary)] text-white border-[var(--primary)]":isPrime(v)?"bg-[var(--teal-soft)] text-[var(--teal)] border-transparent":"bg-[var(--surface-2)] border-transparent"}`}>{v}</button>)}</div>
        <div className="mt-3 rounded-2xl bg-[var(--surface-2)] p-3 flex flex-wrap items-center gap-2"><b className="serif text-[18px]">{selected}</b>{isPrime(selected)?<Pill tone="prime">Просте</Pill>:<Pill tone="comp">Складене</Pill>}<span className="text-[14px]">Розклад: <b>{isPrime(selected)?`${selected} — саме просте`:formatFactorsExact(factorize(selected))}</b></span><span className="text-[12px] text-[var(--muted)]">Дільники: {divisors(selected).join(", ")}</span></div>
      </Section>

      <Section id="s4" num="04" icon={<Network size={14}/>} title="Розклад на прості множники" kicker="Дерево розкладу · крок за кроком" main="Розклад — це представлення складеного числа як добутку простих множників. Розкладаємо, доки не залишаться лише прості числа." checkQ="Що означає «розкласти число»?" checkA="Подати його як добуток простих множників. Наприклад, 60 = 2² × 3 × 5. Це представлення, а не «розбиття» на частини.">
        <div className="flex flex-col sm:flex-row gap-2"><input type="number" min={2} max={200} value={factN} onChange={e=>{setFactN(Number(e.target.value));setStep(0)}}/><button className="chip" onClick={()=>{setFactN(60);setStep(0)}}>60</button><button className="chip" onClick={()=>{setFactN(84);setStep(0)}}>84</button><button className="chip" onClick={()=>{setFactN(120);setStep(0)}}>120</button></div>
        <div className="flex items-center gap-2 mt-3"><button disabled={shownStep===0} onClick={()=>setStep(s=>Math.max(0,s-1))} className="chip">← Назад</button><button disabled={shownStep>=factSteps.length-1} onClick={()=>setStep(s=>s+1)} className="bg-[var(--primary)] text-white rounded-full px-4 py-2 text-[12px] font-bold flex items-center gap-1"><Play size={14}/> Наступний крок</button><button onClick={()=>setStep(0)} className="chip flex items-center gap-1"><RotateCcw size={14}/> Спочатку</button><span className="text-[12px] font-bold">Крок {shownStep+1} з {factSteps.length}</span></div>
        <div className="mt-3 space-y-2">{factSteps.slice(0,shownStep+1).map((s,i)=><div key={i} className={`rounded-xl p-3 border ${i===shownStep?"bg-[var(--accent-soft)] border-[var(--accent)]":"bg-[var(--surface-2)] border-transparent"}`}><div className="text-[11px] font-bold text-[var(--muted)]">КРОК {i+1}</div><div className="font-bold">{s.text}</div><div className="flex flex-wrap gap-1.5 mt-1">{s.leaves.map((v,j)=><span key={j} className={`px-2 py-1 rounded-lg text-[13px] font-bold ${isPrime(v)?"bg-[var(--teal-soft)] text-[var(--teal)]":"bg-white border border-[var(--line)]"}`}>{v}{isPrime(v)?" ✓":""}</span>)}</div></div>)}</div>
        {shownStep===factSteps.length-1 && <div className="mt-3 rounded-2xl bg-[var(--teal-soft)] p-3 text-center"><div className="text-[11px] font-black tracking-widest">РЕЗУЛЬТАТ</div><div className="serif text-[24px] font-black">{factN} = {formatFactorsExact(factorize(factN))}</div><p className="text-[12px] text-[var(--muted)]">Усі листки дерева — прості числа. Розкладання завершено.</p></div>}
      </Section>

      <Section id="s5" num="05" icon={<Shuffle size={14}/>} title="Основна теорема арифметики" kicker="Єдиність розкладу" main="Кожне натуральне число, більше за 1, або є простим, або розкладається на добуток простих чисел. Такий розклад єдиний, якщо не враховувати порядок множників." checkQ="Чи змінює порядок множників саме число?" checkA="Ні. 2 × 3 × 5, 5 × 2 × 3 і 3 × 5 × 2 — це той самий набір множників і те саме число 30.">
        <div className="text-center rounded-2xl border border-[var(--line)] p-4"><div className="text-[11px] font-black tracking-widest text-[var(--muted)]">ПЕРЕМІШАЙТЕ МНОЖНИКИ ЧИСЛА 30</div><div className="flex items-center justify-center gap-2 mt-3 flex-wrap">{shuffled.map((f,i)=><React.Fragment key={i}><span className="factor w-12 h-12 grid place-items-center rounded-2xl bg-[var(--primary)] text-white text-[20px] font-black">{f}</span>{i<2&&<span className="text-[var(--muted)]">×</span>}</React.Fragment>)}</div><div className="serif text-[22px] font-black mt-3">30 = {shuffled.join(" × ")} = 30</div><button onClick={()=>setShuffleSeed(s=>s+1)} className="mt-3 bg-[var(--accent)] text-black rounded-full px-4 py-2 text-[12px] font-bold inline-flex items-center gap-1"><Shuffle size={14}/> Перемішати множники</button><p className="text-[13px] text-[var(--muted)] mt-2">Набір множників завжди один: 2, 3 і 5. Змінюється лише порядок запису.</p></div>
        <p className="text-[13px] leading-relaxed mt-3"><b>Обережна аналогія:</b> як слова складаються з літер, так складені числа складаються з простих множників. Це лише аналогія, а не визначення: прості числа не є «атомами» у фізичному сенсі.</p>
      </Section>

      <Section id="s6" num="06" icon={<InfinityIcon size={14}/>} title="Нескінченність простих: доведення Евкліда" kicker="Доведення від супротивного" main="Простих чисел нескінченно багато. Якщо припустити протилежне, побудоване число N дасть суперечність." checkQ="Чи доводить Евклід, що N завжди просте?" checkA="Ні. N може бути складеним. Важливо інше: N має простий дільник, якого не було в початковому списку. Саме це спростовує припущення про повний список.">
        <div className="flex flex-wrap gap-1.5">{euclidSets.map((s,i)=><button key={i} onClick={()=>setEuclidIdx(i)} className={`chip ${euclidIdx===i?"active":""}`}>{`{${s.join(", ")}}`}</button>)}</div>
        <div className="mt-3 rounded-2xl bg-[var(--surface-2)] p-3 space-y-2 text-[14px] leading-relaxed"><div><b>1 · Припущення:</b> нехай це всі прості: {`{${euclidSet.join(", ")}}`}</div><div><b>2 · Будуємо N:</b> <span className="serif font-bold">N = {euclidSet.join(" × ")} + 1 = {euclidN}</span></div><div><b>3 · Перевірка:</b> {euclidSet.map(p=><span key={p} className="inline-flex items-center gap-1 mr-2">{euclidN} ÷ {p} → остача 1 <X size={13} className="text-[var(--rose)]"/></span>)}</div><div className="rounded-xl bg-[var(--surface)] p-3"><b>4 · Ключовий нюанс:</b> {euclidN} {isPrime(euclidN)?"є простим — це і є новий простий дільник.":`не просте: ${euclidN} = ${formatFactorsExact(euclidFactors)}. Але його простий дільник ${euclidFactors[0]} відсутній у початковому списку.`} Отже, список не був повним — суперечність.</div></div>
      </Section>

      <Section id="s7" num="07" icon={<TrendingDown size={14}/>} title="Нерівномірність і проміжки" kicker="Діаграма проміжків" main="Прості числа не стоять через однакові проміжки: іноді поруч, іноді з більшою відстанню. Закономірність є, але вона складніша за рівний крок." checkQ="Чи означає нерівномірність відсутність закономірності?" checkA="Ні. Проміжки змінюються, але загальна тенденція розподілу описується математично — наприклад, через π(x).">
        <Stepper value={gapCount} set={setGapCount} min={5} max={20} label="Показати перших простих чисел"/>
        <div className="flex items-end gap-1.5 h-[140px] mt-3 border-b border-[var(--line)] px-1">{GAPS.slice(0,gapCount-1).map((g,i)=><div key={i} className="flex-1 flex flex-col items-center gap-1"><span className="text-[11px] font-bold">{g}</span><div className="bar w-full rounded-t-lg bg-[var(--primary)]" style={{height:`${g/8*100}px`}}/><span className="text-[10px] text-[var(--muted)]">{ALL_PRIMES[i]}</span></div>)}</div>
        <p className="text-[12px] text-[var(--muted)] mt-2">Висота стовпчика — проміжок від простого числа внизу до наступного. Послідовність починається: 1, 2, 2, 4, 2, 4, 2, 4, 6…</p>
        <div className="flex flex-wrap gap-1.5 mt-2">{ALL_PRIMES.slice(0,gapCount).map(p=><span key={p} className="px-2 py-1 rounded-lg bg-[var(--teal-soft)] text-[var(--teal)] font-bold text-[13px]">{p}</span>)}</div>
      </Section>

      <Section id="s8" num="08" icon={<TrendingDown size={14}/>} title="Розрідження простих чисел" kicker="Нескінченність ≠ щільність" main="Простих чисел нескінченно багато, але їхня частка серед усіх натуральних чисел поступово зменшується. Ці твердження не суперечать одне одному." checkQ="Як нескінченна множина може «рідшати»?" checkA="Бо «рідшати» описує частку серед перших x чисел, а не загальну кількість. Кількість зростає, а частка падає.">
        <div className="overflow-hidden rounded-2xl border border-[var(--line)]"><table className="w-full text-[13px]"><thead><tr className="bg-[var(--surface-2)] text-left"><th className="p-2.5">x</th><th className="p-2.5">π(x)</th><th className="p-2.5">Частка</th></tr></thead><tbody>{[[10,4,"40%"],[100,25,"25%"],[1000,168,"16,8%"],[10000,1229,"12,3%"]].map(([x,p,d])=><tr key={x} className="border-t border-[var(--line)]"><td className="p-2.5 font-bold">{x}</td><td className="p-2.5">{p}</td><td className="p-2.5"><div className="h-2.5 rounded-full bg-[var(--surface-2)] overflow-hidden"><div className="h-full bg-[var(--accent)]" style={{width:d as string}}/></div><span className="text-[11px] text-[var(--muted)]">{d}</span></td></tr>)}</tbody></table></div>
      </Section>

      <Section id="s9" num="09" icon={<Calculator size={14}/>} title="Функція π(x): калькулятор" kicker="Підрахунок, не число π" main="π(x) — це функція, яка рахує, скільки простих чисел не перевищують x. Не плутати з числом π ≈ 3,14159." checkQ="Що означає π(10) = 4?" checkA="Що до 10 включно є рівно чотири прості числа: 2, 3, 5 і 7.">
        <div className="bg-[var(--rose-soft)] border border-[var(--rose)]/30 rounded-xl p-3 text-[13px]"><b>⚠ Застереження:</b> тут π(x) — назва функції підрахунку, а не стале число π ≈ 3,14159.</div>
        <div className="grid sm:grid-cols-2 gap-3 mt-3"><div><label className="text-[12px] font-bold">Введіть x (2…1000)</label><input type="number" min={2} max={1000} value={piX} onChange={e=>setPiX(Number(e.target.value))}/><div className="flex gap-2 mt-2"><button className="chip" onClick={()=>setPiX(10)}>10</button><button className="chip" onClick={()=>setPiX(100)}>100</button><button className="chip" onClick={()=>setPiX(1000)}>1000</button></div></div><div className="rounded-2xl bg-[var(--surface-2)] p-3"><div className="serif text-[26px] font-black">π({piX}) = {piVal}</div><div className="text-[13px]">Оцінка: <b>{piX} / ln({piX}) ≈ {approx.toFixed(1)}</b></div><div className="text-[12px] text-[var(--muted)]">Формула дає загальну тенденцію, а не точне місце кожного простого числа.</div></div></div>
        <details className="mt-3 rounded-xl border border-[var(--line)]"><summary className="px-3 py-2.5 font-bold text-[13px] cursor-pointer flex justify-between">Список простих до {piX} <ChevronDown size={16}/></summary><div className="px-3 pb-3 flex flex-wrap gap-1">{primesUpTo(Math.max(2,Math.min(1000,piX||2))).map(p=><span key={p} className="px-2 py-1 rounded bg-[var(--teal-soft)] text-[var(--teal)] text-[12px] font-bold">{p}</span>)}</div></details>
        <div className="mt-3"><div className="text-[12px] font-bold">Порівняння: π(x) і x / ln(x)</div><div className="flex items-end gap-3 h-[110px] mt-2">{[[10,4,4.3],[100,25,21.7],[1000,168,144.8]].map(([x,a,b])=><div key={x} className="flex-1 text-center"><div className="flex items-end justify-center gap-1 h-[80px]"><div className="w-7 bg-[var(--primary)] rounded-t" style={{height:`${a/168*80}px`}} /><div className="w-7 bg-[var(--accent)] rounded-t" style={{height:`${b/168*80}px`}} /></div><div className="text-[11px] mt-1">x = {x}<br/>π={a} · оцінка={b}</div></div>)}</div><div className="flex gap-3 text-[11px] mt-1"><span>■ π(x)</span><span>■ x / ln(x)</span></div></div>
      </Section>

      <Section id="s10" num="10" icon={<Sigma size={14}/>} title="Дзета-функція Рімана" kicker="Сума за всіма N" main="ζ(s) = 1/1ˢ + 1/2ˢ + 1/3ˢ + … Змінюючи s, отримуємо різні значення. Це об’єкт, який дозволяє досліджувати всі натуральні числа одразу." checkQ="Що позначає s у ζ(s)?" checkA="Змінну — показник степеня в кожному доданку 1/nˢ. Від s залежить значення всієї суми.">
        <div className="rounded-2xl bg-[var(--primary-2)] text-white p-4 text-center serif text-[18px] sm:text-[22px]">ζ(s) = 1/1ˢ + 1/2ˢ + 1/3ˢ + 1/4ˢ + …</div>
        <div className="flex flex-wrap gap-1.5 mt-3"><button className={`chip ${zetaS===2?"active":""}`} onClick={()=>setZetaS(2)}>s = 2 · ζ(2) ≈ 1,644934</button><button className={`chip ${zetaS===3?"active":""}`} onClick={()=>setZetaS(3)}>s = 3 · ζ(3) ≈ 1,202057</button></div>
        <div className="flex items-center gap-2 mt-3"><button onClick={()=>setZetaTerms(t=>Math.min(20,t+1))} className="bg-[var(--primary)] text-white rounded-full px-4 py-2 text-[12px] font-bold">+ Додати доданок</button><button onClick={()=>setZetaTerms(1)} className="chip">Спочатку</button><span className="text-[12px] font-bold">Доданків: {zetaTerms}</span></div>
        <div className="mt-3 rounded-2xl border border-[var(--line)] p-3"><div className="text-[12px] text-[var(--muted)]">Часткова сума:</div><div className="serif text-[22px] font-black">S = {zetaSum.toFixed(6)}</div><div className="flex flex-wrap gap-1 mt-2">{Array.from({length:zetaTerms},(_,i)=><span key={i} className="text-[12px] bg-[var(--surface-2)] rounded px-1.5 py-0.5">1/{i+1}{zetaS===2?"²":"³"}</span>)}</div><div className="h-2 bg-[var(--surface-2)] rounded-full mt-3 overflow-hidden"><div className="h-full bg-[var(--teal)] transition-all" style={{width:`${zetaSum/(zetaS===2?1.644934:1.202057)*100}%`}}/></div><div className="text-[11px] text-[var(--muted)] mt-1">Прогрес до граничного значення ζ({zetaS})</div></div>
      </Section>

      <Section id="s11" num="11" icon={<Link2 size={14}/>} title="Добуток Ейлера: міст між N і простими" kicker="Мультиплікативний погляд" main="Ту саму ζ(s) можна записати через добуток лише за простими числами. Це міст між адитивним поглядом (сума за всіма N) і мультиплікативним (добуток за простими p)." checkQ="У чому головна ідея відкриття Ейлера?" checkA="Що ζ(s) можна подати двома способами: сумою за всіма натуральними числами і добутком, побудованим лише з простих чисел. Обидва описують ту саму функцію при Re(s) > 1.">
        <div className="rounded-2xl bg-[var(--surface-2)] p-3 text-center serif text-[18px]">ζ(s) = ∏<sub>p</sub> 1 / (1 − 1/pˢ)</div>
        <div className="grid sm:grid-cols-2 gap-3 mt-3"><div className="rounded-xl border border-[var(--line)] p-3"><b className="text-[13px]">Адитивний погляд</b><p className="text-[13px] text-[var(--muted)] mt-1">Сума за всіма натуральними числами: 1/1ˢ + 1/2ˢ + 1/3ˢ + …</p></div><div className="rounded-xl border border-[var(--teal)] bg-[var(--teal-soft)] p-3"><b className="text-[13px]">Мультиплікативний погляд</b><p className="text-[13px] mt-1">Добуток лише за простими: p = 2, 3, 5, 7, 11…</p></div></div>
        <div className="flex flex-wrap gap-1.5 mt-3"><button className={`chip ${eulerS===2?"active":""}`} onClick={()=>setEulerS(2)}>s = 2</button><button className={`chip ${eulerS===3?"active":""}`} onClick={()=>setEulerS(3)}>s = 3</button></div>
        <Stepper value={eulerCount} set={setEulerCount} min={1} max={5} label="Множників добутку"/>
        <div className="mt-2 space-y-1.5">{primesUpTo(11).slice(0,eulerCount).map(p=><div key={p} className="flex justify-between rounded-lg bg-[var(--surface-2)] px-3 py-2 text-[13px]"><span>p = {p}</span><span className="mono">1 / (1 − 1/{p}{eulerS===2?"²":"³"}) = {(1/(1-1/Math.pow(p,eulerS))).toFixed(4)}</span></div>)}</div>
        <div className="mt-3 rounded-xl bg-[var(--accent-soft)] p-3 text-center"><div className="text-[11px] font-black tracking-widest">ЧАСТКОВИЙ ДОБУТОК</div><div className="serif text-[22px] font-black">{eulerProd.toFixed(6)}</div><div className="text-[12px] text-[var(--muted)]">При s = {eulerS} добуток наближається до ζ({eulerS}) ≈ {eulerS===2?"1,644934":"1,202057"}. Умова: Re(s) &gt; 1.</div></div>
      </Section>

      <Section id="s12" num="12" icon={<GraduationCap size={14}/>} title="Висновки: ланцюжок лекції" kicker="8 пунктів · натискайте по черзі" main="Уся лекція — в одному ланцюжку: від поділу чисел до моста Ейлера. Натисніть крок, щоб побачити пояснення." checkQ="Яке головне питання лишається на Лекцію 3?" checkA="Як математична функція взагалі може описувати закономірності, які виникають у нескінченному світі чисел?">
        <div className="space-y-1.5">{conclusions.map((c,i)=><button key={i} onClick={()=>setConclusion(i)} className={`w-full text-left rounded-xl p-3 border flex gap-3 items-start ${conclusion===i?"bg-[var(--primary)] text-white border-[var(--primary)]":"bg-[var(--surface-2)] border-transparent"}`}><span className="font-black shrink-0">{i+1}.</span><span><b>{c[0]}</b><span className={`block text-[12px] ${conclusion===i?"text-white/80":"text-[var(--muted)]"}`}>{c[1]}</span></span><ArrowRight size={16} className="ml-auto shrink-0 mt-0.5"/></button>)}</div>
        <p className="text-[13px] mt-2">Наступна лекція: <b>Лекція 3 — «Математичні функції: як числа перетворюються на закономірності».</b></p>
      </Section>

      <Section id="s13" num="13" icon={<FlaskConical size={14}/>} title="Практика: 6 запитань" kicker="Тест з миттєвою перевіркою" main="Відповідайте — перевірка з’являється одразу, з поясненням. Це перевірка розуміння, а не оцінка." checkQ="Скільки правильних відповідей у вас?" checkA="Рахунок оновлюється одразу після вибору. Поверніться до розділу, де відповідь була неточною.">
        <div className="flex items-center justify-between rounded-xl bg-[var(--surface-2)] p-3"><span className="font-bold text-[13px]">Ваш результат</span><span className="serif font-black text-[20px]">{score} / 6</span></div>
        <div className="space-y-3 mt-3">
          {[
            {n:1,q:"Чому число 1 не вважається простим?",opts:[["a","Бо воно дуже маленьке"],["b","Бо воно парне"],["c","Бо має лише один дільник, а потрібно рівно два"]],exp:"Для простого потрібно рівно два різні дільники: 1 і саме число. У 1 — лише один."},
            {n:2,q:"Чи є число 91 простим? Як це перевірити?",opts:[["a","Так, бо 91 непарне"],["b","Ні: 91 = 7 × 13"],["c","Так, бо 91 не ділиться на 2"]],exp:"91 = 7 × 13, отже має більше ніж два дільники — воно складене."},
            {n:4,q:"Чому нескінченна кількість простих не означає однакові проміжки?",opts:[["a","Бо нескінченність описує кількість, а проміжки — розташування"],["b","Бо прості числа закінчуються"],["c","Бо проміжки завжди дорівнюють 2"]],exp:"Кількість може бути нескінченною, а відстані між сусідніми простими — різними."},
            {n:5,q:"Що означає π(10) = 4?",opts:[["a","Що 10 ділиться на 4"],["b","Що π дорівнює 4"],["c","Що до 10 є 4 прості: 2, 3, 5, 7"]],exp:"π(x) тут — функція підрахунку простих до x, а не число π ≈ 3,14159."},
            {n:6,q:"У чому головна ідея відкриття Ейлера?",opts:[["a","Що прості числа закінчуються"],["b","Що ζ(s) можна записати добутком лише за простими числами"],["c","Що ζ(s) — це сума лише парних чисел"]],exp:"Ейлер показав: сума за всіма N = добуток за простими p."},
          ].map(item=><div key={item.n} className="rounded-2xl border border-[var(--line)] p-3"><div className="font-bold text-[14px]">Запитання {item.n}. {item.q}</div><div className="space-y-1.5 mt-2">{item.opts.map(([k,t])=>{ const sel=answers[item.n]===k; const correct=k===item.opts.find(o=>o[0]===({1:"c",2:"b",4:"a",5:"c",6:"b"} as any)[item.n])?.[0]; const show=!!answers[item.n]; return <button key={k} onClick={()=>setAnswers(a=>({...a,[item.n]:k}))} className={`w-full text-left rounded-xl px-3 py-2 text-[13px] border ${sel?(show&&correct?"bg-[var(--teal-soft)] border-[var(--teal)]":show?"bg-[var(--rose-soft)] border-[var(--rose)]":"bg-[var(--surface-2)]"): "bg-[var(--surface-2)] border-transparent"}`}>{k}) {t} {show&&sel&&(correct?<Check size={15} className="inline text-[var(--teal)]"/>:<X size={15} className="inline text-[var(--rose)]"/>)}</button> })}</div>{answers[item.n]&&<p className="text-[12px] text-[var(--muted)] mt-2">Пояснення: {item.exp}</p>}</div>)}
          <div className="rounded-2xl border border-[var(--line)] p-3"><div className="font-bold text-[14px]">Запитання 3. Розкладіть 120 на прості множники.</div><p className="text-[12px] text-[var(--muted)] mt-1">Запишіть так: 2³×3×5. Підказка: скористайтесь розкладачем у розділі 4, ввівши 120.</p><input className="mt-2" value={q120} onChange={e=>setQ120(e.target.value)} placeholder="Наприклад: 2³×3×5"/><button onClick={()=>setQ120("2³×3×5")} className="chip mt-2">Показати приклад запису</button>{q120&&<p className={`text-[13px] mt-2 font-bold ${["2³×3×5","2^3*3*5","2³*3*5"].includes(q120.replace(/\s/g,""))?"text-[var(--teal)]":"text-[var(--rose)]"}`}>{["2³×3×5","2^3*3*5","2³*3*5"].includes(q120.replace(/\s/g,""))?"✓ Правильно: 120 = 2³ × 3 × 5.":"Перевірте: 120 = 8 × 15 = 2³ × 3 × 5."}</p>}</div>
        </div>
      </Section>

      <Section id="s14" num="14" icon={<BookOpen size={14}/>} title="Словник лекції" kicker="8 термінів · розгортайте" main="Точна термінологія: число — окремий елемент, множина — сукупність, розклад — представлення." checkQ="Чим розклад відрізняється від «розбиття»?" checkA="Розклад — це представлення числа як добутку простих множників. Слово «розбиття» тут неточне, бо ми не ділимо число на частини, а подаємо його в іншій формі.">
        <div className="space-y-1.5">{[["Дільник","Число, на яке інше число ділиться без остачі."],["Просте число","Натуральне число, більше за 1, яке має рівно два натуральні дільники: 1 і саме себе."],["Складене число","Натуральне число, більше за 1, яке має більше ніж два натуральні дільники."],["Прості множники","Прості числа, добуток яких утворює певне складене число."],["Основна теорема арифметики","Твердження про єдиність розкладу натурального числа на прості множники, якщо не враховувати порядок."],["Розподіл простих чисел","Закономірності розташування простих чисел серед натуральних чисел."],["π(x)","Функція, яка показує кількість простих чисел, що не перевищують x."],["Добуток Ейлера","Представлення дзета-функції через нескінченний добуток, побудований на простих числах."]].map(([t,d],i)=><div key={t} className="rounded-xl border border-[var(--line)] overflow-hidden"><button onClick={()=>setDictOpen(dictOpen===i?-1:i)} className="w-full flex justify-between px-3 py-2.5 text-left font-bold text-[14px]"><span>{t}</span><ChevronDown size={16} className={dictOpen===i?"rotate-180":""}/></button>{dictOpen===i&&<div className="px-3 pb-3 text-[13px] leading-relaxed text-[var(--muted)]">{d}</div>}</div>)}</div>
      </Section>

      <footer className="pb-8 pt-2 text-center text-[12px] text-[var(--muted)] leading-relaxed">Лекція 2 · Прості числа та їхня особлива роль<br/>Наступна: Лекція 3 — «Математичні функції: як числа перетворюються на закономірності»</footer>
    </main>
  </div>
}
