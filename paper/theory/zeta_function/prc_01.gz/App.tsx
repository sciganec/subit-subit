import React, { useEffect, useRef, useState } from "react";
import { Apple, ArrowLeft, ArrowRight, BookOpen, Check, ChevronDown, ChevronUp, CircleDot, Eye, EyeOff, List, MoveHorizontal, Pizza, Sigma, Sparkles } from "lucide-react";

const TITLES = [
  "Вступ: п’ять числових систем",
  "Натуральні числа",
  "Цілі числа",
  "Раціональні числа",
  "Дійсні числа",
  "Межа дійсних чисел",
  "Комплексне число a + bi",
  "Комплексна площина",
  "Зв’язок із ζ(s)",
  "Вкладеність систем",
  "Практика: 6 завдань",
  "Словник і висновок",
];

function fmt(n: number) {
  return String(n).replace(".", ",");
}
function formatComplex(a: number, b: number) {
  if (b === 0) return `${fmt(a)}`;
  if (a === 0) return `${fmt(b)}i`;
  const sign = b > 0 ? " + " : " − ";
  const bv = Math.abs(b) === 1 ? "" : fmt(Math.abs(b));
  return `${fmt(a)}${sign}${bv}i`;
}
function SectionHead({ n, kicker, title, lead }: { n: number; kicker: string; title: string; lead: string }) {
  return (
    <div>
      <div className="flex items-center gap-2">
        <span className="mono text-[11px] font-bold tracking-[0.14em] uppercase" style={{ color: "var(--accent)" }}>{kicker}</span>
        <span className="h-px flex-1" style={{ background: "var(--line)" }} />
        <span className="mono text-[11px] font-bold" style={{ color: "var(--muted)" }}>{String(n + 1).padStart(2, "0")} / 12</span>
      </div>
      <h1 className="mt-2 text-[clamp(1.55rem,6.2vw,2.35rem)] leading-[1.05] font-extrabold tracking-[-0.03em] [overflow-wrap:anywhere]">{title}</h1>
      <p className="mt-2 text-[14px] leading-6" style={{ color: "var(--muted)" }}>{lead}</p>
    </div>
  );
}
function MainPoint({ children }: { children: React.ReactNode }) {
  return <div className="rounded-2xl border p-3" style={{ background: "var(--surface-2)", borderColor: "var(--line)" }}><div className="mono text-[10px] font-bold tracking-[0.16em] uppercase mb-1" style={{ color: "var(--teal)" }}>Головне</div><div className="text-[14px] leading-6 font-semibold">{children}</div></div>;
}
function Detail({ title, children, open, onToggle }: { title: string; children: React.ReactNode; open: boolean; onToggle: () => void }) {
  return <div className="rounded-2xl border overflow-hidden" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
    <button onClick={onToggle} className="w-full flex items-center justify-between gap-2 px-3 py-3 text-left font-bold text-[14px]">{title}<span className="shrink-0">{open ? <ChevronUp size={18} /> : <ChevronDown size={18} />}</span></button>
    {open && <div className="px-3 pb-3 text-[13.5px] leading-6" style={{ color: "var(--muted)" }}>{children}</div>}
  </div>;
}
function MiniCheck({ children }: { children: React.ReactNode }) {
  return <div className="rounded-2xl border p-3" style={{ borderColor: "var(--line)", background: "var(--surface)" }}><div className="flex items-center gap-2 mb-2"><Check size={16} style={{ color: "var(--green)" }} /><span className="mono text-[10px] font-bold tracking-[0.16em] uppercase">Міні-перевірка</span></div>{children}</div>;
}
function SliderRow({ label, value, min, max, step, onChange, hint }: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; hint?: string }) {
  return <label className="block">
    <div className="flex justify-between items-baseline gap-2"><span className="text-[13px] font-bold">{label}</span><span className="mono text-[15px] font-bold" style={{ color: "var(--accent)" }}>{fmt(value)}</span></div>
    <input aria-label={label} className="w-full mt-1" type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    {hint && <div className="text-[12px]" style={{ color: "var(--muted)" }}>{hint}</div>}
  </label>;
}

function PlaneSVG({ a, b, showConjugate, highlight }: { a: number; b: number; showConjugate?: boolean; highlight?: string }) {
  const W = 320, H = 240, cx = 160, cy = 120, scale = 26;
  const x = cx + a * scale, y = cy - b * scale;
  const cy2 = cy + b * scale;
  return <div className="rounded-2xl border overflow-hidden" style={{ borderColor: "var(--line)", background: "var(--surface)" }}>
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full block" role="img" aria-label={`Точка ${formatComplex(a, b)} на комплексній площині`}>
      {Array.from({ length: 11 }, (_, i) => <line key={`v${i}`} x1={20 + i * scale} y1={10} x2={20 + i * scale} y2={230} stroke="var(--line)" strokeWidth="1" />)}
      {Array.from({ length: 9 }, (_, i) => <line key={`h${i}`} x1={10} y1={16 + i * scale} x2={310} y2={16 + i * scale} stroke="var(--line)" strokeWidth="1" />)}
      <line x1="10" y1={cy} x2="310" y2={cy} stroke="var(--ink)" strokeWidth="1.5" />
      <line x1={cx} y1="10" x2={cx} y2="230" stroke="var(--ink)" strokeWidth="1.5" />
      <text x="302" y={cy - 6} fontSize="10" fill="var(--muted)">Re</text><text x={cx + 6} y="18" fontSize="10" fill="var(--muted)">Im</text>
      <line x1={cx} y1={cy} x2={x} y2={y} stroke="var(--accent)" strokeWidth="2" strokeDasharray="4 3" />
      {showConjugate && <><line x1={cx} y1={cy} x2={x} y2={cy2} stroke="var(--teal)" strokeWidth="2" strokeDasharray="4 3" /><circle cx={x} cy={cy2} r="7" fill="var(--teal)" /><text x={x + 8} y={cy2 + 4} fontSize="12" fontWeight="800" fill="var(--teal)">{formatComplex(a, -b)}</text></>}
      <circle cx={x} cy={y} r="8" fill="var(--accent)" stroke="white" strokeWidth="2" />
      <text x={Math.min(250, x + 9)} y={y - 8} fontSize="13" fontWeight="800" fill="var(--accent)">{formatComplex(a, b)}</text>
    </svg>
    <div className="px-3 py-2 text-[12px] flex justify-between" style={{ color: "var(--muted)" }}><span>{highlight || "a — горизонтальна координата, b — вертикальна"}</span><span className="mono">({fmt(a)}; {fmt(b)})</span></div>
  </div>;
}

export default function App() {
  const [section, setSection] = useState(0);
  const [tocOpen, setTocOpen] = useState(false);
  const [detail, setDetail] = useState<Record<number, boolean>>({ 0: true });
  const toggleDetail = (i: number) => setDetail((s) => ({ ...s, [i]: !s[i] }));

  // 1
  const [sys, setSys] = useState("C");
  const sysInfo: Record<string, { name: string; adds: string; ex: string; color: string }> = {
    N: { name: "Натуральні", adds: "Множина для лічби: {1, 2, 3, …}.", ex: "7", color: "#e85d2f" },
    Z: { name: "Цілі", adds: "Додає 0 та від’ємні числа.", ex: "−3", color: "#0f7a6d" },
    Q: { name: "Раціональні", adds: "Додає числа виду a/b, b ≠ 0.", ex: "1/2", color: "#6b4fd8" },
    R: { name: "Дійсні", adds: "Додає ірраціональні числа: √2, π, e.", ex: "√2", color: "#e2a400" },
    C: { name: "Комплексні", adds: "Додає уявну одиницю i, де i² = −1.", ex: "s = 0,5 + 14,135i", color: "#172f5e" },
  };
  // 2
  const [apples, setApples] = useState(5);
  const [showSub, setShowSub] = useState(false);
  // 3
  const [owe, setOwe] = useState(8);
  const [dragPos, setDragPos] = useState(-3);
  const dragRef = useRef<HTMLDivElement>(null);
  const onDrag = (e: React.PointerEvent) => {
    const r = dragRef.current?.getBoundingClientRect(); if (!r) return;
    const v = Math.round(((e.clientX - r.left) / r.width) * 20 - 10);
    setDragPos(Math.max(-10, Math.min(10, v)));
  };
  // 4
  const [parts, setParts] = useState(4);
  const [taken, setTaken] = useState(1);
  useEffect(() => { if (taken > parts) setTaken(parts); }, [parts, taken]);
  // 5
  const [zoom, setZoom] = useState(1);
  const [num, setNum] = useState("1");
  const [den, setDen] = useState("3");
  const [check5, setCheck5] = useState<string | null>(null);
  // 6
  const [parabola, setParabola] = useState<"-4" | "+4">("-4");
  // 7
  const [a, setA] = useState(3); const [b, setB] = useState(2);
  // 8 canvas
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [pt, setPt] = useState({ x: 3, y: 2 });
  const [showConj, setShowConj] = useState(false);
  const drawCanvas = () => {
    const c = canvasRef.current; if (!c) return; const ctx = c.getContext("2d"); if (!ctx) return;
    const W = 320, H = 300, cx = 160, cy = 150, s = 26;
    ctx.clearRect(0, 0, W, H); ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--surface").trim() || "#fff"; ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = "#ddd7c8"; ctx.lineWidth = 1;
    for (let i = 0; i <= 12; i++) { ctx.beginPath(); ctx.moveTo(4 + i * s, 0); ctx.lineTo(4 + i * s, H); ctx.stroke(); }
    for (let i = 0; i <= 11; i++) { ctx.beginPath(); ctx.moveTo(0, 6 + i * s); ctx.lineTo(W, 6 + i * s); ctx.stroke(); }
    ctx.strokeStyle = "#17181c"; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(0, cy); ctx.lineTo(W, cy); ctx.stroke(); ctx.beginPath(); ctx.moveTo(cx, 0); ctx.lineTo(cx, H); ctx.stroke();
    ctx.font = "11px sans-serif"; ctx.fillStyle = "#6b6a64"; ctx.fillText("Re", 304, cy - 6); ctx.fillText("Im", cx + 6, 14);
    const px = cx + pt.x * s, py = cy - pt.y * s;
    ctx.strokeStyle = "#e85d2f"; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(px, py); ctx.stroke(); ctx.setLineDash([]);
    if (showConj) {
      const py2 = cy + pt.y * s; ctx.strokeStyle = "#0f7a6d"; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(px, py2); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = "#0f7a6d"; ctx.beginPath(); ctx.arc(px, py2, 7, 0, Math.PI * 2); ctx.fill(); ctx.font = "bold 12px sans-serif"; ctx.fillText(formatComplex(pt.x, -pt.y), Math.min(230, px + 10), py2 + 4);
    }
    ctx.fillStyle = "#e85d2f"; ctx.beginPath(); ctx.arc(px, py, 8, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = "#fff"; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = "#e85d2f"; ctx.font = "bold 13px sans-serif"; ctx.fillText(formatComplex(pt.x, pt.y), Math.min(230, px + 10), py - 10);
  };
  useEffect(drawCanvas, [pt, showConj]);
  const onCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const r = e.currentTarget.getBoundingClientRect(); const x = Math.round((e.clientX - r.left) / r.width * 320); const y = Math.round((e.clientY - r.top) / r.height * 300);
    const nx = Math.max(-5, Math.min(5, Math.round((x - 160) / 26))); const ny = Math.max(-5, Math.min(5, Math.round((150 - y) / 26))); setPt({ x: nx, y: ny });
  };
  // 9
  const [sigma, setSigma] = useState(0.5); const [tVal, setTVal] = useState(14.1);
  // 10
  const [vennNum, setVennNum] = useState("7");
  const vennData: Record<string, string[]> = { "7": ["N", "Z", "Q", "R", "C"], "−3": ["Z", "Q", "R", "C"], "1/2": ["Q", "R", "C"], "√2": ["R", "C"], "i": ["C"], "3 + 2i": ["C"] };
  // 11 quiz
  type Task = { label: string; correct: string[]; why: string };
  const tasks: Task[] = [
    { label: "7", correct: ["N", "Z", "Q", "R", "C"], why: "Число 7 належить до N, а отже, за вкладеністю, — і до кожної наступної системи: його можна записати як 7/1 та як 7 + 0i." },
    { label: "−3", correct: ["Z", "Q", "R", "C"], why: "Число −3 не належить до N, але належить до Z, а отже — до Q (−3/1), R і C." },
    { label: "1/2", correct: ["Q", "R", "C"], why: "Число 1/2 — раціональне, отже дійсне й комплексне. Цілим воно не є." },
    { label: "√2", correct: ["R", "C"], why: "√2 ≈ 1,414… — ірраціональне число. Його не можна точно записати у вигляді дробу a/b." },
    { label: "4 + 3i", correct: ["C"], why: "Дійсна частина дорівнює 4, уявна — 3. Число не належить до дійсної прямої." },
    { label: "0,5 + 14,135i", correct: ["C"], why: "σ = 0,5; t = 14,135. Точка на комплексній площині не належить до дійсної прямої." },
  ];
  const [answers, setAnswers] = useState<Record<number, string[]>>({});
  const [checked, setChecked] = useState<Record<number, boolean>>({});
  const toggleAns = (ti: number, s: string) => { setAnswers((p) => { const cur = p[ti] || []; return { ...p, [ti]: cur.includes(s) ? cur.filter((x) => x !== s) : [...cur, s] }; }); setChecked((p) => ({ ...p, [ti]: false })); };
  const score = tasks.filter((t, i) => checked[i] && JSON.stringify([...(answers[i] || [])].sort()) === JSON.stringify([...t.correct].sort())).length;
  const sets = ["N", "Z", "Q", "R", "C"];

  const go = (n: number) => { setSection(n); setTocOpen(false); setCheck5(null); window.scrollTo({ top: 0 }); };
  const progress = ((section + 1) / 12) * 100;

  const renderSection = () => {
    switch (section) {
      case 0: return <div className="space-y-3">
        <SectionHead n={0} kicker="Лекція 1 • Вступ" title="П’ять числових систем: чому розширення було необхідним" lead="Предметом лекції є не окремі числа, а послідовність числових систем. Кожне розширення виникло тоді, коли попередня система не забезпечувала розв’язності певного класу задач." />
        <MainPoint>Чисел у кожній системі нескінченно багато. Розширювалися не числа, а системи: виникло п’ять послідовних розширень — N ⊂ Z ⊂ Q ⊂ R ⊂ C.</MainPoint>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <div className="mono text-[10px] font-bold tracking-[0.16em] uppercase" style={{ color: "var(--teal)" }}>Термінологічне зауваження</div>
          <p className="text-[13.5px] leading-6 mt-1" style={{ color: "var(--muted)" }}><b style={{ color: "var(--ink)" }}>Число</b> — окремий елемент, наприклад 7, −3 або 1/2. <b style={{ color: "var(--ink)" }}>Числова множина</b> — сукупність чисел, наприклад N. <b style={{ color: "var(--ink)" }}>Числова система</b> — числова множина разом з операціями, визначеними на ній. Тому запитання «чому чисел стало п’ять?» є некоректним: п’ять — це кількість систем, а не чисел.</p>
          <div className="grid grid-cols-3 gap-2 mt-3 text-center">
            <div className="rounded-xl p-2" style={{ background: "var(--surface-2)" }}><div className="text-[11px]" style={{ color: "var(--muted)" }}>Число</div><div className="mono font-bold text-[13px]">7; −3; 1/2</div></div>
            <div className="rounded-xl p-2" style={{ background: "var(--surface-2)" }}><div className="text-[11px]" style={{ color: "var(--muted)" }}>Множина</div><div className="mono font-bold text-[13px]">N; Z; Q</div></div>
            <div className="rounded-xl p-2" style={{ background: "var(--surface-2)" }}><div className="text-[11px]" style={{ color: "var(--muted)" }}>Система</div><div className="mono font-bold text-[13px]">множина + операції</div></div>
          </div>
        </div>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <div className="flex items-center justify-between"><span className="font-bold text-[14px]">Ланцюжок розширень</span><span className="mono text-[12px]" style={{ color: "var(--muted)" }}>оберіть систему</span></div>
          <div className="flex flex-wrap items-center gap-1 mt-3">
            {sets.map((s, i) => <React.Fragment key={s}><button onClick={() => setSys(s)} aria-pressed={sys === s} className="h-11 min-w-[52px] px-3 rounded-xl font-extrabold text-[18px] border-2 transition" style={{ background: sys === s ? sysInfo[s].color : "var(--surface-2)", color: sys === s ? "white" : "var(--ink)", borderColor: sys === s ? sysInfo[s].color : "var(--line)" }}>{s}</button>{i < 4 && <span className="text-[18px] px-0.5" style={{ color: "var(--muted)" }}>⊂</span>}</React.Fragment>)}
          </div>
          <div className="mt-3 rounded-xl p-3" style={{ background: "var(--surface-2)" }}><div className="font-extrabold">{sysInfo[sys].name} — приклад: {sysInfo[sys].ex}</div><p className="text-[13.5px] leading-6 mt-1" style={{ color: "var(--muted)" }}>{sysInfo[sys].adds} {sys === "C" ? "Саме в цій системі визначена дзета-функція." : "Попередні системи зберігаються всередині наступної."}</p></div>
        </div>
        <Detail title="Як читати запис N ⊂ Z ⊂ Q ⊂ R ⊂ C" open={!!detail[0]} onToggle={() => toggleDetail(0)}>Символ ⊂ означає «є підмножиною». Кожне натуральне число є цілим, кожне ціле — раціональним, кожне раціональне — дійсним, кожне дійсне — комплексним. Обернене твердження не завжди істинне: число i є комплексним, але не є дійсним.</Detail>
        <MiniCheck><p className="text-[14px]">Яка система виникла для того, щоб результат ділення цілого числа на ціле завжди належав системі?</p><div className="flex gap-2 mt-2 flex-wrap"><button onClick={() => setCheck5("Q")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>Раціональні числа Q</button><button onClick={() => setCheck5("Z")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>Цілі числа Z</button></div>{check5 && <p className="mt-2 text-[13px] font-bold" style={{ color: check5 === "Q" ? "var(--green)" : "var(--red)" }}>{check5 === "Q" ? "✓ Правильно: у Q визначено ділення на ненульове число." : "Уточніть: система Z додає від’ємні числа та нуль, а не дроби."}</p>}</MiniCheck>
      </div>;
      case 1: return <div className="space-y-3">
        <SectionHead n={1} kicker="Система 1" title="Натуральні числа: множина N" lead="N = {1, 2, 3, 4, 5, 6, …} — множина чисел, якими здійснюється лічба. Вона не містить дробів, від’ємних чисел і не має найбільшого елемента." />
        <MainPoint>У системі N операції додавання та множення завжди дають натуральний результат. Операція віднімання такою властивістю не володіє.</MainPoint>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <SliderRow label="Кількість об’єктів лічби" value={apples} min={1} max={12} step={1} onChange={setApples} hint="Ілюстративний приклад лічби: 1 → 2 → 3 …" />
          <div className="flex flex-wrap gap-1.5 mt-3 min-h-[44px]" aria-label={`Ілюстрація лічби: ${apples} об’єктів`}>{Array.from({ length: apples }, (_, i) => <span key={i} className="w-9 h-9 rounded-full grid place-items-center" style={{ background: "#ffe7d9" }}><Apple size={20} color="#c93a2c" /></span>)}</div>
          <div className="mono text-[15px] font-bold mt-2">{apples} об’єктів • наступне число: {apples} + 1 = {apples + 1}</div>
          <p className="text-[12.5px] leading-5 mt-1" style={{ color: "var(--muted)" }}>Приклад із яблуками ілюструє лише лічбу. Визначенням N є множина {`{1, 2, 3, …}`}, а не конкретні предмети.</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}><div className="text-[12px] font-bold" style={{ color: "var(--muted)" }}>Замкненість у N</div><div className="mono text-[20px] font-bold mt-1">5 + 3 = 8</div><p className="text-[12.5px] leading-5 mt-1" style={{ color: "var(--muted)" }}>Сума двох натуральних чисел є натуральним числом.</p></div>
          <button onClick={() => setShowSub(!showSub)} className="rounded-2xl border p-3 text-left" style={{ background: showSub ? "#fff0ec" : "var(--surface)", borderColor: "var(--accent)" }}><div className="text-[12px] font-bold" style={{ color: "var(--accent)" }}>Перевірте межу ↓</div><div className="mono text-[20px] font-bold mt-1">5 − 8 = ?</div><p className="text-[12.5px] leading-5 mt-1">{showSub ? "У системі N розв’язку немає. Потрібне розширення → Z." : "Натисніть, щоб побачити."}</p></button>
        </div>
        <MiniCheck><p className="text-[14px]">Чи належить число 0 до множини N у цій лекції?</p><div className="flex gap-2 mt-2"><button onClick={() => setCheck5("no")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>Ні, N починається з 1</button><button onClick={() => setCheck5("yes")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>Так</button></div>{check5 && <p className="mt-2 text-[13px] font-bold" style={{ color: check5 === "no" ? "var(--green)" : "var(--red)" }}>{check5 === "no" ? "✓ Правильно: у лекції N = {1, 2, 3, …}." : "Ні. У цій лекції N починається з 1, а 0 з’являється в системі Z."}</p>}</MiniCheck>
      </div>;
      case 2: return <div className="space-y-3">
        <SectionHead n={2} kicker="Система 2" title="Цілі числа: множина Z" lead="Z = {…, −3, −2, −1, 0, 1, 2, 3, …}. Розширення додає нуль та від’ємні числа, завдяки чому віднімання стає завжди виконуваним." />
        <MainPoint>5 − 8 = −3. У системі Z різниця будь-яких двох цілих чисел є цілим числом.</MainPoint>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <div className="flex justify-between text-[12px] font-bold" style={{ color: "var(--muted)" }}><span>Маємо: 5</span><span>Віднімаємо: {owe}</span></div>
          <SliderRow label="Від’ємник" value={owe} min={0} max={12} step={1} onChange={setOwe} />
          <div className="mt-2 rounded-xl p-3 text-center" style={{ background: "var(--surface-2)" }}><div className="mono text-[22px] font-bold">5 − {owe} = {5 - owe}</div><div className="text-[13px] font-bold mt-1" style={{ color: 5 - owe < 0 ? "var(--red)" : "var(--green)" }}>{5 - owe < 0 ? `Результат — від’ємне число ${5 - owe}` : 5 - owe === 0 ? "Результат — нуль" : `Результат — додатне число ${5 - owe}`}</div></div>
          <div className="flex flex-wrap gap-1.5 mt-3">{["3 − 7 = −4", "10 − 15 = −5", "2 − 2 = 0"].map((x) => <span key={x} className="mono text-[12px] px-2 py-1.5 rounded-lg border font-bold" style={{ borderColor: "var(--line)" }}>{x}</span>)}</div>
        </div>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <div className="flex items-center gap-2"><MoveHorizontal size={16} /><span className="font-bold text-[14px]">Перемістіть точку на прямій</span><span className="mono ml-auto font-bold" style={{ color: "var(--accent)" }}>{dragPos}</span></div>
          <div ref={dragRef} onPointerDown={onDrag} onPointerMove={(e) => { if (e.buttons === 1) onDrag(e); }} className="relative h-12 mt-3 rounded-full cursor-grab active:cursor-grabbing touch-none" style={{ background: "var(--surface-2)" }}>
            <div className="absolute left-2 right-2 top-1/2 h-[2px]" style={{ background: "var(--line)" }} />
            <div className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 w-9 h-9 rounded-full grid place-items-center font-extrabold text-white shadow" style={{ left: `${((dragPos + 10) / 20) * 100}%`, background: "var(--accent)" }}>{dragPos}</div>
            <span className="absolute left-2 -bottom-0.5 mono text-[10px]" style={{ color: "var(--muted)" }}>−10</span><span className="absolute right-2 -bottom-0.5 mono text-[10px]" style={{ color: "var(--muted)" }}>10</span>
          </div>
          <p className="text-[12.5px] mt-2" style={{ color: "var(--muted)" }}>Точка {dragPos} {dragPos < 0 ? "розташована ліворуч від нуля." : dragPos === 0 ? "збігається з нулем." : "розташована праворуч від нуля."}</p>
        </div>
        <MiniCheck><p className="text-[14px]">Обчисліть: 10 − 15 = ?</p><div className="flex gap-2 mt-2"><button onClick={() => setCheck5("a")} className="px-3 py-2 rounded-xl border font-bold" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>−5</button><button onClick={() => setCheck5("b")} className="px-3 py-2 rounded-xl border font-bold" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>5</button></div>{check5 && <p className="mt-2 text-[13px] font-bold" style={{ color: check5 === "a" ? "var(--green)" : "var(--red)" }}>{check5 === "a" ? "✓ Правильно." : "Зверніть увагу на знак: віднімаємо більше число, ніж початкове."}</p>}</MiniCheck>
      </div>;
      case 3: return <div className="space-y-3">
        <SectionHead n={3} kicker="Система 3" title="Раціональні числа: множина Q" lead="Q = {a/b : a ∈ Z, b ∈ Z, b ≠ 0}. Розширення забезпечує виконуваність ділення на ненульове число." />
        <MainPoint>5 ÷ 2 = 2,5. Цього числа немає в системі Z, тому необхідною є система Q.</MainPoint>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <div className="flex justify-center"><svg viewBox="0 0 180 180" className="w-[170px] h-[170px]" role="img" aria-label={`Круг, поділений на ${parts} частин, виділено ${taken}`}><circle cx="90" cy="90" r="82" fill="#ffd98f" stroke="#e2a400" strokeWidth="3" />{Array.from({ length: parts }, (_, i) => { const a0 = (i / parts) * Math.PI * 2 - Math.PI / 2; const a1 = ((i + 1) / parts) * Math.PI * 2 - Math.PI / 2; const x0 = 90 + 82 * Math.cos(a0), y0 = 90 + 82 * Math.sin(a0), x1 = 90 + 82 * Math.cos(a1), y1 = 90 + 82 * Math.sin(a1); return <path key={i} d={`M90 90 L${x0} ${y0} A82 82 0 0 1 ${x1} ${y1} Z`} fill={i < taken ? "#e85d2f" : "#fff3d0"} stroke="#fff" strokeWidth="2" />; })}<circle cx="90" cy="90" r="8" fill="#e2a400" /></svg></div>
          <SliderRow label="Знаменник b — кількість частин" value={parts} min={1} max={8} step={1} onChange={setParts} />
          <SliderRow label="Чисельник a — кількість виділених частин" value={taken} min={1} max={parts} step={1} onChange={setTaken} />
          <div className="grid grid-cols-2 gap-2 mt-2 text-center"><div className="rounded-xl p-2" style={{ background: "var(--surface-2)" }}><div className="text-[11px]" style={{ color: "var(--muted)" }}>Дріб</div><div className="mono text-[20px] font-bold">{taken}/{parts}</div></div><div className="rounded-xl p-2" style={{ background: "var(--surface-2)" }}><div className="text-[11px]" style={{ color: "var(--muted)" }}>Десятковий запис</div><div className="mono text-[20px] font-bold">{fmt(Math.round((taken / parts) * 1000) / 1000)}</div></div></div>
        </div>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}><div className="font-bold text-[14px] flex items-center gap-2"><Pizza size={16} /> Нескінченність запису ≠ ірраціональність</div><p className="text-[13.5px] leading-6 mt-1" style={{ color: "var(--muted)" }}>1/2 = 0,5; 1/4 = 0,25; 1/3 = 0,333… — останній запис є нескінченним, проте число залишається раціональним, оскільки його можна точно подати у вигляді 1/3.</p></div>
        <MiniCheck><p className="text-[14px]">Чи є число 0,333… раціональним?</p><div className="flex gap-2 mt-2 flex-wrap"><button onClick={() => setCheck5("yes")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>Так, це 1/3</button><button onClick={() => setCheck5("no")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>Ні, бо запис нескінченний</button></div>{check5 && <p className="mt-2 text-[13px] font-bold" style={{ color: check5 === "yes" ? "var(--green)" : "var(--red)" }}>{check5 === "yes" ? "✓ Правильно." : "Нескінченність десяткового запису сама по собі не означає ірраціональності."}</p>}</MiniCheck>
      </div>;
      case 4: return <div className="space-y-3">
        <SectionHead n={4} kicker="Система 4" title="Дійсні числа: множина R" lead="Між числами 1 і 2 міститься нескінченно багато чисел. Проте не кожне дійсне число можна подати у вигляді дробу a/b." />
        <MainPoint>R = Q ∪ {`{ірраціональні числа}`}. Це множина всіх точок звичайної числової прямої.</MainPoint>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <SliderRow label="Масштаб прямої" value={zoom} min={1} max={3} step={1} onChange={setZoom} hint={zoom === 1 ? "Огляд: 0 … 4" : zoom === 2 ? "Ближче: 1 … 2" : "Ще ближче: 1,3 … 1,5"} />
          <div className="relative h-14 mt-2 rounded-xl" style={{ background: "var(--surface-2)" }}>
            <div className="absolute left-3 right-3 top-1/2 h-[2px]" style={{ background: "var(--ink)" }} />
            {[{ v: Math.SQRT2, label: "√2", c: "#e85d2f" }, { v: Math.PI, label: "π", c: "#6b4fd8" }, { v: Math.E, label: "e", c: "#0f7a6d" }].map((p) => { const min = zoom === 1 ? 0 : zoom === 2 ? 1 : 1.3; const max = zoom === 1 ? 4 : zoom === 2 ? 2 : 1.5; if (p.v < min || p.v > max) return null; const left = 12 + ((p.v - min) / (max - min)) * 76; return <div key={p.label} className="absolute -translate-x-1/2 text-center" style={{ left: `${left}%`, top: 4 }}><div className="mono text-[11px] font-bold" style={{ color: p.c }}>{p.label}</div><div className="w-2.5 h-2.5 rounded-full mx-auto mt-1" style={{ background: p.c }} /></div>; })}
          </div>
          <div className="grid grid-cols-3 gap-2 mt-2 text-center text-[12px]"><span className="mono font-bold">√2 ≈ 1,414…</span><span className="mono font-bold">π ≈ 3,14159</span><span className="mono font-bold">e ≈ 2,71828</span></div>
        </div>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <div className="font-bold text-[14px]">Перевірте дріб: чи є число раціональним?</div>
          <div className="flex items-center gap-2 mt-2"><input value={num} onChange={(e) => setNum(e.target.value)} inputMode="numeric" aria-label="Чисельник" className="w-[70px] rounded-lg border px-2 py-2 text-center mono font-bold" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }} /><span className="text-[20px]">/</span><input value={den} onChange={(e) => setDen(e.target.value)} inputMode="numeric" aria-label="Знаменник" className="w-[70px] rounded-lg border px-2 py-2 text-center mono font-bold" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }} /><button onClick={() => { const d = Number(den); if (!den || d === 0 || !Number.isInteger(Number(num)) || !Number.isInteger(d)) setCheck5("bad"); else setCheck5("ok"); }} className="ml-auto px-3 py-2 rounded-xl font-bold text-white text-[13px]" style={{ background: "var(--primary)" }}>Перевірити</button></div>
          {check5 === "ok" && <p className="mt-2 text-[13px] font-bold" style={{ color: "var(--green)" }}>✓ Раціональне число: це дріб двох цілих чисел. Його значення ≈ {fmt(Math.round((Number(num) / Number(den)) * 1000) / 1000)}.</p>}
          {check5 === "bad" && <p className="mt-2 text-[13px] font-bold" style={{ color: "var(--red)" }}>Введіть цілі числа, а знаменник — відмінним від 0. Дріб із цілими числами завжди є раціональним.</p>}
          <p className="text-[12.5px] mt-2" style={{ color: "var(--muted)" }}>Число √2 не можна точно подати у вигляді дробу: його десятковий запис є нескінченним і неперіодичним.</p>
        </div>
        <MiniCheck><p className="text-[14px]">Число √2 — це…</p><div className="flex gap-2 mt-2 flex-wrap"><button onClick={() => setCheck5("irr")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>Дійсне, ірраціональне</button><button onClick={() => setCheck5("rat")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>Раціональне</button></div>{(check5 === "irr" || check5 === "rat") && <p className="mt-2 text-[13px] font-bold" style={{ color: check5 === "irr" ? "var(--green)" : "var(--red)" }}>{check5 === "irr" ? "✓ Правильно." : "Ні: √2 не дорівнює жодному дробу a/b."}</p>}</MiniCheck>
      </div>;
      case 5: return <div className="space-y-3">
        <SectionHead n={5} kicker="Поворотний момент" title="Межа дійсних чисел: рівняння x² = −4" lead="Навіть множини всіх дійсних чисел недостатньо для розв’язання одного елементарного рівняння." />
        <MainPoint>Квадрат дійсного числа ніколи не є від’ємним. Тому рівняння x² = −4 не має розв’язків у системі R.</MainPoint>
        <div className="grid grid-cols-2 gap-2">
          <button onClick={() => setParabola("-4")} className="rounded-2xl border p-3 text-left" style={{ borderColor: parabola === "-4" ? "var(--accent)" : "var(--line)", background: "var(--surface)" }}><div className="mono font-bold">y = x² − 4</div><div className="text-[12px] mt-1" style={{ color: "var(--green)" }}>● перетинає вісь: x = 2 і −2</div></button>
          <button onClick={() => setParabola("+4")} className="rounded-2xl border p-3 text-left" style={{ borderColor: parabola === "+4" ? "var(--teal)" : "var(--line)", background: "var(--surface)" }}><div className="mono font-bold">y = x² + 4</div><div className="text-[12px] mt-1" style={{ color: "var(--red)" }}>● не перетинає вісь</div></button>
        </div>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <svg viewBox="0 0 320 190" className="w-full" role="img" aria-label="Графік параболи"><line x1="10" y1="150" x2="310" y2="150" stroke="var(--ink)" strokeWidth="1.5" /><line x1="160" y1="8" x2="160" y2="182" stroke="var(--ink)" strokeWidth="1.5" /><path d={parabola === "-4" ? "M30 35 Q160 270 290 35" : "M30 115 Q160 155 290 115"} fill="none" stroke={parabola === "-4" ? "#e85d2f" : "#0f7a6d"} strokeWidth="3" />{parabola === "-4" && <><circle cx="93" cy="150" r="6" fill="#178a4d" /><circle cx="227" cy="150" r="6" fill="#178a4d" /><text x="75" y="172" fontSize="11" fontWeight="700" fill="#178a4d">x = −2</text><text x="208" y="172" fontSize="11" fontWeight="700" fill="#178a4d">x = 2</text></>}<text x="270" y="145" fontSize="10" fill="var(--muted)">x</text></svg>
          <p className="text-[13px] leading-6" style={{ color: "var(--muted)" }}>{parabola === "-4" ? "Парабола перетинає вісь двічі — рівняння має два дійсні корені." : "Парабола розташована над віссю — дійсних коренів немає. Це є підставою для введення нової системи."}</p>
        </div>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface-2)", borderColor: "var(--line)" }}><div className="font-bold">Вводимо i: <span className="mono">i² = −1</span></div><p className="text-[13.5px] leading-6 mt-1" style={{ color: "var(--muted)" }}>Тоді (2i)² = 4 · i² = −4. Отже, рівняння x² = −4 має розв’язки x = 2i або x = −2i.</p><div className="flex flex-wrap gap-2 mt-2"><span className="mono px-2 py-1 rounded-lg border font-bold bg-white/60">2 × 2 = 4</span><span className="mono px-2 py-1 rounded-lg border font-bold bg-white/60">(−2) × (−2) = 4</span><span className="mono px-2 py-1 rounded-lg border font-bold bg-white/60">(2i)² = −4</span></div></div>
        <MiniCheck><p className="text-[14px]">Яке рівняння не має дійсних розв’язків?</p><div className="flex gap-2 mt-2 flex-wrap"><button onClick={() => setCheck5("a")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>x² = −4</button><button onClick={() => setCheck5("b")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>x² = 4</button></div>{check5 && <p className="mt-2 text-[13px] font-bold" style={{ color: check5 === "a" ? "var(--green)" : "var(--red)" }}>{check5 === "a" ? "✓ Правильно." : "Рівняння x² = 4 має розв’язки 2 і −2."}</p>}</MiniCheck>
      </div>;
      case 6: return <div className="space-y-3">
        <SectionHead n={6} kicker="Система 5" title="Комплексні числа: множина C" lead="C = {a + bi : a, b ∈ R, i² = −1}. Тут a — дійсна частина, b — уявна частина." />
        <MainPoint>Кожне дійсне число є комплексним. Обернене твердження не є істинним: не кожне комплексне число є дійсним.</MainPoint>
        <PlaneSVG a={a} b={b} />
        <div className="rounded-2xl border p-3 space-y-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <SliderRow label="Дійсна частина a" value={a} min={-5} max={5} step={1} onChange={setA} />
          <SliderRow label="Уявна частина b" value={b} min={-5} max={5} step={1} onChange={setB} />
          <div className="rounded-xl p-3 text-center" style={{ background: "var(--surface-2)" }}><span className="mono text-[22px] font-bold">s = {formatComplex(a, b)}</span><div className="text-[12.5px] mt-1" style={{ color: "var(--muted)" }}>a = {fmt(a)} • b = {fmt(b)}</div></div>
          <div className="flex gap-2 flex-wrap">{[{ a: 3, b: 2, l: "3 + 2i" }, { a: 5, b: -4, l: "5 − 4i" }, { a: 7, b: 0, l: "7 + 0i = 7" }].map((x) => <button key={x.l} onClick={() => { setA(x.a); setB(x.b); }} className="px-3 py-2 rounded-xl border mono font-bold text-[13px]" style={{ borderColor: "var(--line)", background: a === x.a && b === x.b ? "var(--ink)" : "var(--surface-2)", color: a === x.a && b === x.b ? "var(--bg)" : "var(--ink)" }}>{x.l}</button>)}</div>
        </div>
        <MiniCheck><p className="text-[14px]">У числі 5 − 4i уявна частина дорівнює…</p><div className="flex gap-2 mt-2"><button onClick={() => setCheck5("a")} className="px-3 py-2 rounded-xl border font-bold" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>−4</button><button onClick={() => setCheck5("b")} className="px-3 py-2 rounded-xl border font-bold" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>4</button></div>{check5 && <p className="mt-2 text-[13px] font-bold" style={{ color: check5 === "a" ? "var(--green)" : "var(--red)" }}>{check5 === "a" ? "✓ Правильно: b = −4." : "Зверніть увагу на знак мінус перед 4i."}</p>}</MiniCheck>
      </div>;
      case 7: return <div className="space-y-3">
        <SectionHead n={7} kicker="Два виміри" title="Комплексна площина" lead="Горизонтальна вісь — дійсна, вертикальна — уявна. Комплексне число подається точкою площини." />
        <MainPoint>Число 3 + 2i відповідає точці (3; 2), а число 3 − 2i — точці (3; −2).</MainPoint>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <div className="flex justify-between items-center mb-2"><span className="font-bold text-[14px]">Натисніть на площину</span><button onClick={() => setShowConj(!showConj)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl border font-bold text-[12.5px]" style={{ borderColor: "var(--line)", background: showConj ? "var(--surface-2)" : "var(--surface)" }}>{showConj ? <Eye size={15} /> : <EyeOff size={15} />} Спряжене число: {showConj ? "показано" : "приховано"}</button></div>
          <canvas ref={canvasRef} onClick={onCanvasClick} width={320} height={300} className="w-full rounded-xl border cursor-crosshair" style={{ borderColor: "var(--line)" }} />
          <div className="grid grid-cols-2 gap-2 mt-2 text-center"><div className="rounded-xl p-2" style={{ background: "var(--surface-2)" }}><div className="text-[11px]" style={{ color: "var(--muted)" }}>Точка</div><div className="mono font-bold">{formatComplex(pt.x, pt.y)}</div></div><div className="rounded-xl p-2" style={{ background: "var(--surface-2)" }}><div className="text-[11px]" style={{ color: "var(--muted)" }}>Спряжене число</div><div className="mono font-bold">{showConj ? formatComplex(pt.x, -pt.y) : "—"}</div></div></div>
          <p className="text-[12.5px] mt-2" style={{ color: "var(--muted)" }}>{showConj ? "Спряжене число — дзеркальне відображення відносно дійсної осі: знак уявної частини змінюється." : "Увімкніть спряжене число, щоб побачити дзеркальне відображення."}</p>
        </div>
        <Detail title="Приклади з лекції" open={!!detail[7]} onToggle={() => toggleDetail(7)}>Число 3 + 2i відповідає точці (3; 2). Число 3 − 2i відповідає точці (3; −2). Ці точки симетричні відносно горизонтальної осі. Замість одного виміру отримано два — і тепер можна описувати положення точки у двовимірному просторі.</Detail>
        <MiniCheck><p className="text-[14px]">Якій точці відповідає число 3 − 2i?</p><div className="flex gap-2 mt-2 flex-wrap"><button onClick={() => setCheck5("a")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>3 праворуч, 2 вниз</button><button onClick={() => setCheck5("b")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>3 вгору, 2 праворуч</button></div>{check5 && <p className="mt-2 text-[13px] font-bold" style={{ color: check5 === "a" ? "var(--green)" : "var(--red)" }}>{check5 === "a" ? "✓ Правильно." : "Перша координата — горизонтальна, друга — вертикальна."}</p>}</MiniCheck>
      </div>;
      case 8: return <div className="space-y-3">
        <SectionHead n={8} kicker="Мета курсу" title="Зв’язок із дзета-функцією" lead="ζ(s) — функція, аргумент якої s є комплексним числом." />
        <MainPoint>s = σ + ti. Саме в такому просторі досліджуватимуться нетривіальні нулі дзета-функції.</MainPoint>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <div className="flex items-center gap-2"><Sigma size={18} style={{ color: "var(--accent)" }} /><span className="mono text-[20px] font-bold">ζ(s)</span><span className="text-[13px]" style={{ color: "var(--muted)" }}>ζ — позначення функції, s — її аргумент</span></div>
          <div className="grid grid-cols-2 gap-2 mt-3"><div className="rounded-xl p-2" style={{ background: "var(--surface-2)" }}><div className="text-[11px]" style={{ color: "var(--muted)" }}>σ — дійсна частина</div><div className="mono font-bold">{fmt(sigma)}</div></div><div className="rounded-xl p-2" style={{ background: "var(--surface-2)" }}><div className="text-[11px]" style={{ color: "var(--muted)" }}>t — уявна частина</div><div className="mono font-bold">{fmt(tVal)}</div></div></div>
          <div className="mt-3"><SliderRow label="σ (0 … 1)" value={sigma} min={0} max={1} step={0.1} onChange={setSigma} /><SliderRow label="t (0 … 15)" value={tVal} min={0} max={15} step={0.1} onChange={setTVal} /></div>
          <button onClick={() => { setSigma(0.5); setTVal(14.1); }} className="mt-2 w-full py-2.5 rounded-xl font-bold text-white text-[13px]" style={{ background: "var(--primary)" }}>Показати приклад з лекції: s = 0,5 + 14,135i</button>
        </div>
        <div className="rounded-2xl border overflow-hidden" style={{ borderColor: "var(--line)", background: "var(--surface)" }}>
          <svg viewBox="0 0 320 220" className="w-full block" role="img" aria-label={`Точка s = ${fmt(sigma)} + ${fmt(tVal)}i`}><line x1="20" y1="190" x2="310" y2="190" stroke="var(--ink)" strokeWidth="1.5" /><line x1="35" y1="10" x2="35" y2="210" stroke="var(--ink)" strokeWidth="1.5" /><line x1={35 + sigma * 230} y1="10" x2={35 + sigma * 230} y2="210" stroke="var(--gold)" strokeWidth="2" strokeDasharray="5 4" /><circle cx={35 + sigma * 230} cy={190 - (tVal / 15) * 170} r="8" fill="var(--accent)" stroke="white" strokeWidth="2" /><text x={Math.min(220, 35 + sigma * 230 + 10)} y={190 - (tVal / 15) * 170 - 8} fontSize="12" fontWeight="800" fill="var(--accent)">s = {fmt(sigma)} + {fmt(tVal)}i</text><text x="260" y="185" fontSize="10" fill="var(--muted)">Re σ</text><text x="42" y="16" fontSize="10" fill="var(--muted)">Im t</text></svg>
          <p className="px-3 pb-3 text-[12.5px]" style={{ color: "var(--muted)" }}>Пунктирна пряма — вертикальна пряма σ = {fmt(sigma)}. У математичних текстах дійсну частину позначають грецькою літерою σ, а уявну частину — літерою t.</p>
        </div>
        <MiniCheck><p className="text-[14px]">У числі 0,5 + 14,135i дійсна координата — це…</p><div className="flex gap-2 mt-2"><button onClick={() => setCheck5("a")} className="px-3 py-2 rounded-xl border font-bold" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>0,5</button><button onClick={() => setCheck5("b")} className="px-3 py-2 rounded-xl border font-bold" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>14,135</button></div>{check5 && <p className="mt-2 text-[13px] font-bold" style={{ color: check5 === "a" ? "var(--green)" : "var(--red)" }}>{check5 === "a" ? "✓ Правильно: σ = 0,5." : "Число 14,135 — це уявна координата t."}</p>}</MiniCheck>
      </div>;
      case 9: return <div className="space-y-3">
        <SectionHead n={9} kicker="Карта систем" title="Вкладеність: N ⊂ Z ⊂ Q ⊂ R ⊂ C" lead="Кожен наступний крок розширював попередню систему. Оберіть число — і побачите, до яких систем воно належить." />
        <MainPoint>Кожне натуральне число є цілим, кожне ціле — раціональним, кожне раціональне — дійсним, кожне дійсне — комплексним.</MainPoint>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <div className="flex flex-wrap gap-2">{Object.keys(vennData).map((n) => <button key={n} onClick={() => setVennNum(n)} className="px-3 py-2 rounded-xl border mono font-bold text-[13px]" style={{ borderColor: vennNum === n ? "var(--accent)" : "var(--line)", background: vennNum === n ? "var(--accent)" : "var(--surface-2)", color: vennNum === n ? "white" : "var(--ink)" }}>{n}</button>)}</div>
          <div className="relative h-[190px] mt-3 overflow-hidden rounded-xl" style={{ background: "var(--surface-2)" }}>
            <div className="absolute inset-x-3 top-2 bottom-2 rounded-[90px] border-2 flex items-center justify-center" style={{ borderColor: "#172f5e" }}><span className="absolute top-1 left-4 mono text-[11px] font-bold" style={{ color: "#172f5e" }}>C</span>
              <div className="absolute inset-x-6 top-5 bottom-5 rounded-[80px] border-2 flex items-center justify-center" style={{ borderColor: "#e2a400" }}><span className="absolute top-1 left-3 mono text-[11px] font-bold">R</span>
                <div className="absolute inset-x-6 top-5 bottom-5 rounded-[70px] border-2 flex items-center justify-center" style={{ borderColor: "#6b4fd8" }}><span className="absolute top-1 left-3 mono text-[11px] font-bold">Q</span>
                  <div className="absolute inset-x-6 top-5 bottom-5 rounded-[55px] border-2 flex items-center justify-center" style={{ borderColor: "#0f7a6d" }}><span className="absolute top-0.5 left-2 mono text-[11px] font-bold">Z</span>
                    <div className="rounded-full w-[58px] h-[58px] grid place-items-center border-2 font-extrabold mono text-[14px]" style={{ borderColor: "#e85d2f", background: "var(--surface)" }}>N</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 px-3 py-1.5 rounded-full font-extrabold mono text-[15px] shadow" style={{ background: "var(--ink)", color: "var(--bg)" }}>{vennNum}</div>
          </div>
          <div className="flex flex-wrap gap-1.5 mt-3">{sets.map((s) => <span key={s} className="px-2.5 py-1.5 rounded-lg mono text-[12px] font-bold border" style={{ borderColor: vennData[vennNum].includes(s) ? "var(--green)" : "var(--line)", background: vennData[vennNum].includes(s) ? "#e6f6ec" : "var(--surface-2)", color: vennData[vennNum].includes(s) ? "var(--green)" : "var(--muted)" }}>{s} {vennData[vennNum].includes(s) ? "✓" : "—"}</span>)}</div>
          <p className="text-[13px] mt-2" style={{ color: "var(--muted)" }}>Число {vennNum} належить до систем: <b style={{ color: "var(--ink)" }}>{vennData[vennNum].join(", ")}</b>.</p>
        </div>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>
          <div className="mono text-[10px] font-bold tracking-[0.16em] uppercase" style={{ color: "var(--teal)" }}>Чому розширення було необхідним</div>
          <p className="text-[13.5px] leading-6 mt-1" style={{ color: "var(--muted)" }}>Кожне розширення є відповіддю на нерозв’язність певного класу операцій або рівнянь у попередній системі. Розширення не скасовує попередню систему, а включає її як підмножину.</p>
          <div className="space-y-2 mt-3">
            {[
              ["N → Z", "Віднімання в N", "Рівняння x + 8 = 5, тобто 5 − 8, не має розв’язку в N. У системі Z розв’язок — число −3."],
              ["Z → Q", "Ділення в Z", "Рівняння 2x = 5, тобто 5 ÷ 2, не має розв’язку в Z. У системі Q розв’язок — число 5/2."],
              ["Q → R", "Рівняння x² = 2 в Q", "Число √2 не належить до Q: його не можна подати у вигляді дробу a/b. У системі R це рівняння має розв’язки √2 і −√2."],
              ["R → C", "Рівняння x² = −1 в R", "Квадрат дійсного числа не буває від’ємним, тому рівняння не має розв’язку в R. У системі C розв’язки — числа i та −i."],
            ].map(([step, problem, result]) => <div key={step} className="rounded-xl p-3" style={{ background: "var(--surface-2)" }}><div className="flex flex-wrap items-baseline gap-x-2"><span className="mono font-extrabold text-[13px]" style={{ color: "var(--accent)" }}>{step}</span><span className="font-bold text-[13px]">{problem}</span></div><p className="text-[13px] leading-6 mt-1" style={{ color: "var(--muted)" }}>{result}</p></div>)}
          </div>
        </div>
        <MiniCheck><p className="text-[14px]">Чи є число i дійсним?</p><div className="flex gap-2 mt-2"><button onClick={() => setCheck5("no")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>Ні, тільки комплексним</button><button onClick={() => setCheck5("yes")} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>Так</button></div>{check5 && <p className="mt-2 text-[13px] font-bold" style={{ color: check5 === "no" ? "var(--green)" : "var(--red)" }}>{check5 === "no" ? "✓ Правильно." : "Число i не належить до дійсної прямої."}</p>}</MiniCheck>
      </div>;
      case 10: return <div className="space-y-3">
        <SectionHead n={10} kicker="Перевірте себе" title="Практика: 6 завдань" lead="Позначте всі системи, до яких належить число. Перевірка — миттєва, з поясненням." />
        <div className="rounded-2xl border p-3 flex items-center gap-2" style={{ background: "var(--surface)", borderColor: "var(--line)" }}><CircleDot size={18} style={{ color: "var(--accent)" }} /><span className="font-bold text-[14px]">Правильних відповідей: {score} / 6</span><span className="ml-auto mono text-[12px]" style={{ color: "var(--muted)" }}>{score === 6 ? "Фундамент засвоєно ✓" : score >= 3 ? "Результат задовільний" : "Почніть із завдання 1"}</span></div>
        <div className="space-y-3">{tasks.map((task, ti) => { const isOk = checked[ti] && JSON.stringify([...(answers[ti] || [])].sort()) === JSON.stringify([...task.correct].sort()); return <div key={task.label} className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: checked[ti] ? (isOk ? "var(--green)" : "var(--red)") : "var(--line)" }}>
          <div className="flex items-center gap-2"><span className="mono text-[11px] font-bold" style={{ color: "var(--muted)" }}>Завдання {ti + 1}</span><span className="mono text-[20px] font-extrabold">{task.label}</span>{checked[ti] && <span className="ml-auto text-[12px] font-bold" style={{ color: isOk ? "var(--green)" : "var(--red)" }}>{isOk ? "✓ Правильно" : "Ще не точно"}</span>}</div>
          <div className="flex flex-wrap gap-2 mt-2">{sets.map((s) => <label key={s} className="flex items-center gap-1.5 px-3 py-2 rounded-xl border cursor-pointer font-bold text-[13px]" style={{ borderColor: (answers[ti] || []).includes(s) ? "var(--ink)" : "var(--line)", background: (answers[ti] || []).includes(s) ? "var(--surface-2)" : "var(--surface)" }}><input type="checkbox" checked={(answers[ti] || []).includes(s)} onChange={() => toggleAns(ti, s)} />{s}</label>)}</div>
          <div className="flex gap-2 mt-2"><button onClick={() => setChecked((p) => ({ ...p, [ti]: true }))} className="px-3 py-2 rounded-xl font-bold text-white text-[13px]" style={{ background: "var(--primary)" }}>Перевірити</button><button onClick={() => { setAnswers((p) => ({ ...p, [ti]: [] })); setChecked((p) => ({ ...p, [ti]: false })); }} className="px-3 py-2 rounded-xl border font-bold text-[13px]" style={{ borderColor: "var(--line)" }}>Скинути</button></div>
          {checked[ti] && <p className="text-[13px] leading-6 mt-2" style={{ color: "var(--muted)" }}>{task.why}</p>}
        </div>; })}</div>
      </div>;
      default: return <div className="space-y-3">
        <SectionHead n={11} kicker="Фінал лекції" title="Словник і головний висновок" lead="Лекція розпочалася з лічби, а завершилася комплексними числами — системою, у якій визначена дзета-функція." />
        <MainPoint>Комплексні числа — не факультативне ускладнення. Це необхідна мова для опису дзета-функції.</MainPoint>
        <div className="grid grid-cols-1 gap-2">{[
          ["Натуральні числа", "Множина N = {1, 2, 3, 4, …}."],
          ["Цілі числа", "Множина Z = {…, −2, −1, 0, 1, 2, …}."],
          ["Раціональні числа", "Множина Q = {a/b : a ∈ Z, b ∈ Z, b ≠ 0}."],
          ["Ірраціональні числа", "Дійсні числа, які неможливо точно подати у вигляді дробу a/b."],
          ["Дійсні числа", "Множина R = Q ∪ {ірраціональні числа}."],
          ["Уявна одиниця", "Число i, квадрат якого дорівнює −1."],
          ["Комплексні числа", "Множина C = {a + bi : a, b ∈ R, i² = −1}."],
          ["Комплексна площина", "Горизонтальна координата — дійсна частина, вертикальна — уявна частина."],
        ].map(([t, d]) => <div key={t} className="rounded-2xl border p-3 flex gap-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}><div className="w-9 h-9 shrink-0 rounded-xl grid place-items-center font-extrabold" style={{ background: "var(--surface-2)" }}><BookOpen size={17} /></div><div><div className="font-extrabold text-[14px]">{t}</div><div className="text-[13px] leading-5" style={{ color: "var(--muted)" }}>{d}</div></div></div>)}</div>
        <div className="rounded-2xl p-4 text-white" style={{ background: "var(--primary)" }}><div className="flex items-center gap-2"><Sparkles size={18} /><span className="mono text-[11px] font-bold tracking-[0.14em] uppercase">Головний висновок</span></div><p className="mt-2 text-[15px] leading-7 font-medium">Якщо попередньої системи недостатньо, математика її розширює. Дзета-функція Рімана визначена в комплексному просторі, а її нулі описуються комплексними координатами. Комплексні числа не є менш реальними за дійсні: це повноцінний інструмент для структур, недоступних одновимірній прямій.</p></div>
        <div className="rounded-2xl border p-3" style={{ background: "var(--surface)", borderColor: "var(--line)" }}><div className="font-bold text-[14px]">Далі — лекція 2</div><p className="text-[13.5px] leading-6 mt-1" style={{ color: "var(--muted)" }}>«Прості числа та їхня особлива роль». Чому числа 2, 3, 5, 7, 11, 13 мають особливе значення — і як це пов’язано з дзета-функцією Ейлера.</p><button onClick={() => go(0)} className="mt-2 px-3 py-2 rounded-xl font-bold text-[13px] text-white" style={{ background: "var(--accent)" }}>Повернутися на початок</button></div>
      </div>;
    }
  };

  const shellStyle: React.CSSProperties = { boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" };
  return <div data-safe-area-inset-root style={shellStyle} className="min-h-[100dvh] overflow-x-clip" >
    <header data-safe-area-sticky-top style={{ top: "var(--safe-area-inset-top)" }} className="sticky z-30 border-b backdrop-blur" >
      <div className="px-3 pt-2 pb-2 max-w-[720px] mx-auto" style={{ background: "var(--bg)", borderColor: "var(--line)" }}>
        <div className="flex items-center gap-2">
          <button onClick={() => setTocOpen(!tocOpen)} aria-expanded={tocOpen} className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl border font-bold text-[12px]" style={{ borderColor: "var(--line)", background: "var(--surface)" }}><List size={15} /> Зміст</button>
          <div className="min-w-0 flex-1"><div className="font-extrabold text-[12px] leading-tight [overflow-wrap:anywhere]">Лекція 1 • Числові системи</div><div className="text-[11px]" style={{ color: "var(--muted)" }}>Від натуральних до комплексних</div></div>
          <span className="shrink-0 mono text-[12px] font-bold px-2 py-1 rounded-full" style={{ background: "var(--surface-2)" }}>{section + 1} / 12</span>
        </div>
        <div className="h-1.5 rounded-full mt-2 overflow-hidden" style={{ background: "var(--line)" }}><div className="h-full rounded-full transition-all" style={{ width: `${progress}%`, background: "var(--accent)" }} /></div>
        <nav aria-label="Розділи лекції" className="flex gap-1.5 overflow-x-auto no-scrollbar mt-2 -mx-1 px-1 pb-0.5">
          {TITLES.map((t, i) => <button key={t} onClick={() => go(i)} className={`shrink-0 px-2.5 py-1.5 rounded-full border text-[11.5px] font-bold ${section === i ? "chip-active" : ""}`} style={{ borderColor: "var(--line)", background: "var(--surface)" }}>{i + 1}. {t}</button>)}
        </nav>
        {tocOpen && <div className="mt-2 rounded-2xl border p-2" style={{ background: "var(--surface)", borderColor: "var(--line)" }}>{TITLES.map((t, i) => <button key={t} onClick={() => go(i)} className="w-full flex items-center gap-2 text-left px-2 py-2 rounded-xl text-[13px] font-semibold"><span className="mono text-[11px] w-5 shrink-0" style={{ color: "var(--muted)" }}>{String(i + 1).padStart(2, "0")}</span><span className="min-w-0 [overflow-wrap:anywhere]">{t}</span>{section === i ? <Check size={15} className="ml-auto shrink-0" style={{ color: "var(--green)" }} /> : null}</button>)}</div>}
      </div>
    </header>

    <main className="px-3 pb-6 pt-3 max-w-[720px] mx-auto">
      <div key={section}>{renderSection()}</div>
      <div className="flex items-center gap-2 mt-5">
        <button disabled={section === 0} onClick={() => go(section - 1)} className="flex items-center gap-1 px-3 py-2.5 rounded-xl border font-bold text-[13px] disabled:opacity-40" style={{ borderColor: "var(--line)", background: "var(--surface)" }}><ArrowLeft size={16} /> Назад</button>
        <div className="flex-1 text-center mono text-[11px]" style={{ color: "var(--muted)" }}>{TITLES[section]}</div>
        <button disabled={section === 11} onClick={() => go(section + 1)} className="flex items-center gap-1 px-3 py-2.5 rounded-xl font-bold text-[13px] text-white disabled:opacity-40" style={{ background: section === 11 ? "var(--muted)" : "var(--accent)" }}>Далі <ArrowRight size={16} /></button>
      </div>
      <p className="text-center text-[11px] mt-4" style={{ color: "var(--muted)" }}>Формули — юнікодом, без LaTeX • Кожен розділ — один екран • Перехід за змістом або кнопками</p>
    </main>
  </div>;
}
